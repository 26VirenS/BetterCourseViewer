/* Icon paths (24x24 viewBox, stroked). The first block is the set used by
 * the design mockup; the rest are the few extras the interpreted screens
 * need, drawn in the same 1.8–2px rounded stroke style. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  BCV.screens = BCV.screens || {}; // screens register here; app.js reads it last

  // mockup 11: the rounded set, drawn as bare glyphs (no tile behind them)
  BCV.IC = {
    grid: 'M5 6.6A1.6 1.6 0 016.6 5h2.8A1.6 1.6 0 0111 6.6v2.8A1.6 1.6 0 019.4 11H6.6A1.6 1.6 0 015 9.4zM13 6.6A1.6 1.6 0 0114.6 5h2.8A1.6 1.6 0 0119 6.6v2.8A1.6 1.6 0 0117.4 11h-2.8A1.6 1.6 0 0113 9.4zM5 14.6A1.6 1.6 0 016.6 13h2.8A1.6 1.6 0 0111 14.6v2.8A1.6 1.6 0 019.4 19H6.6A1.6 1.6 0 015 17.4zM13 14.6A1.6 1.6 0 0114.6 13h2.8A1.6 1.6 0 0119 14.6v2.8A1.6 1.6 0 0117.4 19h-2.8A1.6 1.6 0 0113 17.4z',
    dash: 'M3.8 10.9l7.3-6a1.4 1.4 0 011.8 0l7.3 6M6.2 9.4v8.8c0 .9.7 1.6 1.6 1.6h8.4c.9 0 1.6-.7 1.6-1.6V9.4M10 19.8v-4.6c0-.7.5-1.2 1.2-1.2h1.6c.7 0 1.2.5 1.2 1.2v4.6',
    book: 'M12 7.6C10.6 6.4 8.8 5.8 6.7 5.8c-.8 0-1.5.1-2 .2a.5.5 0 00-.4.5v10.8c0 .3.3.6.6.5.4-.1 1-.1 1.8-.1 2.1 0 3.9.6 5.3 1.8 1.4-1.2 3.2-1.8 5.3-1.8.8 0 1.4 0 1.8.1.3.1.6-.2.6-.5V6.5a.5.5 0 00-.4-.5c-.5-.1-1.2-.2-2-.2-2.1 0-3.9.6-5.3 1.8zM12 7.6v11.9',
    people: 'M9.4 11.6a3.2 3.2 0 100-6.4 3.2 3.2 0 000 6.4zM3.8 19.6c.3-2.9 2.6-4.8 5.6-4.8s5.3 1.9 5.6 4.8M16.4 6.3a2.9 2.9 0 010 5.7M17.6 15.1c1.9.5 3.1 1.9 3.4 4',
    check: 'M4.6 7.7l1.8 1.8 3.4-3.6M4.6 16.5l1.8 1.8 3.4-3.6M13.2 7.6h6.2M13.2 16.4h6.2',
    cal: 'M4.6 8.8A2.4 2.4 0 017 6.4h10a2.4 2.4 0 012.4 2.4v8.8A2.4 2.4 0 0117 20H7a2.4 2.4 0 01-2.4-2.4zM4.6 10.8h14.8M8.6 4.4v3.4M15.4 4.4v3.4',
    mail: 'M3.6 8.6A2.6 2.6 0 016.2 6h11.6a2.6 2.6 0 012.6 2.6v6.8a2.6 2.6 0 01-2.6 2.6H6.2a2.6 2.6 0 01-2.6-2.6zM4.3 8.3l6.9 4.9c.5.4 1.1.4 1.6 0l6.9-4.9',
    doc: 'M6.8 5.6A2.6 2.6 0 019.4 3h4.2l4.6 4.6v10.8A2.6 2.6 0 0115.6 21H9.4a2.6 2.6 0 01-2.6-2.6zM13.6 3v4.6h4.6M10 13.6h4.2M10 17h3',
    bolt: 'M13.3 3.3L6.4 13a.6.6 0 00.5 1h3.7l-1 6.1c-.1.6.7.9 1.1.4l6.9-9.7a.6.6 0 00-.5-1h-3.7l1-6.1c.1-.6-.7-.9-1.1-.4z',
    disc: 'M4.4 9.4A3.4 3.4 0 017.8 6h8.4a3.4 3.4 0 013.4 3.4v3.4a3.4 3.4 0 01-3.4 3.4h-4.4l-3.8 3a.6.6 0 01-1-.5v-2.5H7.8a3.4 3.4 0 01-3.4-3.4z',
    chart: 'M6 19.4v-6.2M12 19.4V5.8M18 19.4v-9.4',
    folder: 'M3.6 7.8A2.4 2.4 0 016 5.4h3c.6 0 1.2.3 1.6.8l1 1.2c.3.4.8.6 1.3.6H18a2.4 2.4 0 012.4 2.4v6.4A2.4 2.4 0 0118 19.2H6a2.4 2.4 0 01-2.4-2.4z',
    sheet: 'M4.6 7.4A2.4 2.4 0 017 5h10a2.4 2.4 0 012.4 2.4v9.2A2.4 2.4 0 0117 19H7a2.4 2.4 0 01-2.4-2.4zM4.6 10.2h14.8M10.4 10.2V19',
    page: 'M6.4 5.6A2.6 2.6 0 019 3h4.4l4.2 4.2v11.2A2.6 2.6 0 0115 21H9a2.6 2.6 0 01-2.6-2.6zM9.7 9.8h4.6M9.7 13.4h4.6M9.7 17h3',
    clock: 'M20 12a8 8 0 11-16 0 8 8 0 0116 0zM12 7.6V12l2.9 1.8',
    repeat: 'M17 2l4 4-4 4M3 11V9a4 4 0 014-4h14M7 22l-4-4 4-4M21 13v2a4 4 0 01-4 4H3', // (2.99.113: a plan that repeats)
    bell: 'M18.1 16.3c-.8-.9-1.2-1.6-1.2-4.3 0-2.6-1.3-4.6-3.4-5.3a1.6 1.6 0 00-3 0C8.4 7.4 7.1 9.4 7.1 12c0 2.7-.4 3.4-1.2 4.3-.4.4-.1 1.1.4 1.1h11.4c.5 0 .8-.7.4-1.1zM10.1 19.2a2.2 2.2 0 003.8 0',
    stream: 'M4.6 6.8h14.8M4.6 12h9.6M4.6 17.2h12.4',
    sun: 'M12 7.3a4.7 4.7 0 100 9.4 4.7 4.7 0 000-9.4zM12 3.3v1.3M12 19.4v1.3M4.6 12H3.3M20.7 12h-1.3M6.9 6.9L6 6M18 18l-.9-.9M17.1 6.9L18 6M6 18l.9-.9',
    moon: 'M20.1 14.7A8.4 8.4 0 019.3 3.9 8.4 8.4 0 1020.1 14.7z',
    shield: 'M11.5 3.4a1.4 1.4 0 011 0l5.5 2.1c.6.2 1 .8 1 1.4v4.7c0 4.4-2.9 7.5-7 8.7a1.4 1.4 0 01-.8 0c-4.2-1.2-7.1-4.3-7.1-8.7V6.9c0-.6.4-1.2 1-1.4z',
    // mockup one-offs
    search: 'M11 4a7 7 0 100 14 7 7 0 000-14zM16.5 16.5L21 21',
    chevron: 'M9 6l6 6-6 6',
    back: 'M15 6l-6 6 6 6',
    close: 'M6 6l12 12M18 6L6 18',
    // (2.99.37) the preview card's facts and its Close, as the Mac's draws them
    hash: 'M9.6 4.5L8 19.5M16 4.5l-1.6 15M5 9.2h14.5M4.5 14.8H19',
    xcircle: 'M20 12a8 8 0 11-16 0 8 8 0 0116 0zM9.4 9.4l5.2 5.2M14.6 9.4l-5.2 5.2',
    okcircle: 'M20 12a8 8 0 11-16 0 8 8 0 0116 0zM8.6 12.3l2.3 2.3 4.6-4.9',
    person: 'M12 11.6a3.4 3.4 0 100-6.8 3.4 3.4 0 000 6.8zM5.4 19.4c.9-3.1 3.5-5 6.6-5s5.7 1.9 6.6 5',
    dots: 'M12 6h.01M12 12h.01M12 18h.01',
    compose: 'M4 20h4l11-11-4-4L4 16zM14 5l4 4',
    download: 'M12 4v11M8 11l4 4 4-4M5 19h14',
    reader: 'M11 5H6a2 2 0 00-2 2v10a2 2 0 002 2h5M11 5v14M14 8l3 4-3 4M20 12h-6',
    sparkle: 'M12 3l1.9 4.1L18 9l-4.1 1.9L12 15l-1.9-4.1L6 9l4.1-1.9zM18 15l.9 2.1L21 18l-2.1.9L18 21l-.9-2.1L15 18l2.1-.9z',
    send: 'M12 19V5M6 11l6-6 6 6',
    warn: 'M12 4l9 16H3zM12 10v4M12 17h.01',
    star: 'M12 3.5l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3-5.4 3 1.2-6L3.3 9.8l6.1-.7z',
    // extras for interpreted screens
    link: 'M10 14a3.5 3.5 0 005 0l4-4a3.5 3.5 0 00-5-5l-1 1M14 10a3.5 3.5 0 00-5 0l-4 4a3.5 3.5 0 005 5l1-1',
    modules: 'M4 6h16M4 12h16M4 18h16M4 6h.01M4 12h.01M4 18h.01',
    external: 'M14 4h6v6M20 4l-9 9M19 14v5H5V5h5',
    plus: 'M12 5v14M5 12h14',
    reply: 'M9 7L4 12l5 5M4 12h11a5 5 0 015 5v2',
    copy: 'M9 9h11v11H9zM5 15V4h11',
    stop: 'M7 7h10v10H7z',
    settings: 'M12 9a3 3 0 100 6 3 3 0 000-6zM4 12h2M18 12h2M12 4v2M12 18v2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M6.3 17.7l1.4-1.4M16.3 7.7l1.4-1.4',
    image: 'M4 5h16v14H4zM4 15l5-5 4 4 3-3 4 4M15 9h.01',
    video: 'M3 6h13v12H3zM16 10l5-3v10l-5-3',
    audio: 'M12 4v16M8 8v8M16 8v8M4 11v2M20 11v2',
    zip: 'M4 4h16v16H4zM10 4v4M10 10v2M10 14v2',
    calendarPlus: 'M4 7h16v13H4zM4 11h16M8 4v4M16 4v4M12 13v4M10 15h4',
    lock: 'M6 11h12v9H6zM9 11V8a3 3 0 016 0v3',
    filter: 'M4 5h16l-6 8v5l-4 2v-7z',
    pencil: 'M4 20h4l11-11-4-4L4 16zM14 5l4 4',
    text: 'M5 6h14M12 6v14M9 20h6',
    // mockup 12: To Do priority flag and the student's own tasks
    flag: 'M6 4v16M6 4h11l-2 4 2 4H6',
    task: 'M9 11l3 3 5-6M5 5h14v14H5z',
    // the Tools mockup: the sidebar row, the five tools and their popups
    tool: 'M14.5 3.5a5 5 0 0 0-6 6l-5 5V20h4l5-5a5 5 0 0 0 6-6l-3 3-3-3z',
    // (2.99.115) the dial a little smaller and higher, so the whole sits on the pill's middle line beside the others (it hung low)
    timer: 'M12 7a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM12 10.5v3l2.2 1.4M9.5 3.5h5M12 3.5V7',
    graph: 'M4 20V4M4 20h16M7.5 16.5c2-8 4.5-9 6-4.5s3 5 4.5 1',
    calc: 'M7 3.5h10a1.5 1.5 0 011.5 1.5v14a1.5 1.5 0 01-1.5 1.5H7A1.5 1.5 0 015.5 19V5A1.5 1.5 0 017 3.5zM8.5 6.5h7v3.5h-7zM8.7 13.2h.1M12 13.2h.1M15.3 13.2h.1M8.7 16.6h.1M12 16.6h.1M15.3 16.6h.1',
    table: 'M4 5.5h4.5v4.5H4zM9.75 5.5h4.5v4.5h-4.5zM15.5 5.5H20v4.5h-4.5zM4 11.5h4.5V16H4zM9.75 11.5h4.5V16h-4.5zM15.5 11.5H20V16h-4.5zM7 19h10',
    convert: 'M7 4h7l4 4v12H7zM14 4v4h4M4.5 10.5v6h6M4.5 16.5l3-3',
    cards: 'M7.5 7.5h11v11h-11zM5 15.5V5h10',
    quote: 'M9 6.5C6.5 8 5.5 10 5.5 13v4.5h5V11H8c0-1.5.5-2.5 2-3.5zM18 6.5c-2.5 1.5-3.5 3.5-3.5 6.5v4.5h5V11H17c0-1.5.5-2.5 2-3.5z',
    globe: 'M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM3.5 12h17M12 3.5c2.5 2.3 2.5 14.2 0 17-2.5-2.8-2.5-14.7 0-17z',
    journal: 'M6 3.5h9l4 4v13H6zM15 3.5v4h4M9.5 13h6M9.5 16.5h4',
    slides: 'M4 5h16v10H4zM12 15v4M8.5 19h7',
    upload: 'M12 15V4M7.5 8.5 12 4l4.5 4.5M5 19.5h14', // (up, out of the tray: download is the same arrow pointing down)
    play: 'M8 5l11 7-11 7z',
    pause: 'M9 6v12M15 6v12',
    pin: 'M9 4h6l-1 5 3 3v2H7v-2l3-3zM12 14v6',
    // the four tools after them: what a grade needs, PDFs joined or cut, a PDF marked up, words read off a picture
    percent: 'M19 5L5 19M7.5 4.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM16.5 14.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z',
    merge: 'M7 3.5h7l4 4v13H7zM14 3.5v4h4M4.5 13h2M9 13h2M13.5 13h2M18 13h1.5', // (a page with a cut line across it)
    marker: 'M5 15l8.5-8.5 4 4L9 19H5zM12 8.5l4 4M3 21h9',
    scan: 'M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16M8.5 9h7M12 9v7',
    ruler: 'M3.5 15.5l12-12 5 5-12 12zM7 12l2 2M10 9l1.5 1.5M13 6l2 2', // (2.99.79: the unit converter)
    words: 'M4 6h16M4 10h10M4 14h16M4 18h8M17 17.5l1.5 1.5 3-3', // (2.99.79: the word counter — lines of text, ticked)
    scale: 'M12 4v16M7 20h10M5 7h14M5 7l-2.5 6a3 3 0 0 0 5 0zM19 7l-2.5 6a3 3 0 0 0 5 0z', // (2.99.82: the equation balancer)
    flask: 'M9.5 3h5M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3M7.5 14h9', // (2.99.82: molar mass & stoichiometry)
  };
})();
