/* The on-demand modules (content/app/lazy.js): each by name, the files that make it, in order, and
 * what it needs loaded first. A data script, so one list serves both readers: the page (lazy.js asks
 * for a module by name) and the background (background.js lands the files in the page's isolated
 * world, and loads nothing outside this list).
 *
 * The source manifest names the same files in a content-script group whose match never fires
 * (https://lazy.simplcourses.invalid/*): Safari and Firefox parse none of them until asked, and the
 * iPhone app, with no scripting API, injects that group whole. The Chrome builds leave the group out
 * — Chrome lists a content script's host among the sites the extension reads, and a new site at an
 * update switches every installed copy off until its owner accepts it (scripts/chrome-manifest.py)
 * — and load from this list alone. scripts/dev/api-test.mjs holds the group and this list equal. */
self.BCV_LAZY_MODULES = {
  quiz: { files: ['content/app/quiz-page.js', 'content/app/screens/quiz.js'] },
  quizsim: { needs: ['quiz'], files: ['content/app/quiz-sim.js'] }, // the simulation quiz (Settings → Developer → Quiz)
  submit: { files: ['content/app/screens/submit.js', 'content/app/screens/feedback.js'] },
  qr: { files: ['lib/vendor/qrcode.js'] }, // (2.99.96) the QR code of Hand in from Phone: loaded when its sheet is opened
  handin: { needs: ['qr'], files: ['content/app/handin.js'] }, // (2.99.135) Hand in from your phone: the sealed relay and its sheet, loaded with the code
  hub: { files: ['content/app/hub.js'] }, // the search box's commands, answers and row actions: loaded when the box is focused
  widgets: { files: ['content/app/tools/widgets.js'] }, // widgets of your own: the frame, the importer (loaded by Tools, and by the tray when one is kept)
  starters: { files: ['content/app/tools/widget-starters.js'] }, // the example widgets the importer offers
  'tool:cite': { files: ['content/app/tools/cite.js'] },
  'tool:fc': { files: ['content/app/tools/cards.js'] },
  'tool:conv': { files: ['content/app/tools/convert.js'] },
  'tool:need': { files: ['content/app/tools/need.js'] },
  'tool:pdfx': { files: ['content/app/tools/pdfs.js'] },
  'tool:mark': { files: ['content/app/tools/mark.js'] },
  'tool:ocr': { files: ['content/app/tools/ocr.js'] },
  'tool:ptable': { files: ['content/app/tools/ptable-data.js', 'content/app/tools/ptable.js'] },
  'tool:units': { files: ['content/app/tools/units.js'] },
  'tool:words': { files: ['content/app/tools/words.js'] },
  'tool:stats': { files: ['content/app/tools/stats.js'] },
  'tool:balance': { needs: ['tool:ptable', 'tool:stats'], files: ['content/app/tools/chem.js'] }, // (the elements' masses, and numbers written as Statistics writes them)
  'tool:moles': { needs: ['tool:balance'], files: ['content/app/tools/moles.js'] }, // (the balancer's reading and sums)
  'tool:matrix': { needs: ['tool:stats'], files: ['content/app/tools/matrix.js'] }, // (its numbers written as Statistics writes them)
  setupcss: { files: ['setup/setup-css.js'] }, // the setup's stylesheet: the setup, Personalize and What's New draw with it
  setup: { needs: ['setupcss'], files: ['content/app/personalize.js', 'content/app/setup.js'] },
  notes: { needs: ['setupcss'], files: ['content/app/whatsnew-notes.js'] },
  phone: { files: ['content/app/phone.js'] },
  appearance: { files: ['content/app/appearance.js'] }, // (2.99.60) Appearance, as the Mac's: over the Dashboard, loaded when it is opened
  rubric: { files: ['content/app/rubric-ring.js'] }, // the rubric ring (desktop): loaded when a rubric is opened
  docview: { files: ['content/app/docview.js'] }, // the file viewer's own pages (a PDF, a Word file, a picture, text): loaded when a file is first opened
  nativeapp: { files: ['content/app/native-app.js'] }, // the iPhone app's native shell (its engine calls and its navigation): only the app injects it, with the group
};
