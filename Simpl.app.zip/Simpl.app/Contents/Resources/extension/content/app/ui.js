/* UI building blocks for the redesigned interface: tiny element helpers,
 * the components the mockup repeats (cards, rows, tiles, segmented
 * controls, switches, badges…), date formatting in the mockup's style and
 * the colour math that derives text/tint variants from a course colour. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  const { h } = BCV.utils;
  const { overlayRoot } = BCV.utils;
  const IC = BCV.IC;

  // ---- svg ----------------------------------------------------------------
  const NS = 'http://www.w3.org/2000/svg';
  function svg(path, { size = 15, stroke = 'currentColor', width = 1.8, fill = 'none', cls = '', style = null, cap = 'round', join = 'round' } = {}) {
    const el = document.createElementNS(NS, 'svg');
    el.setAttribute('viewBox', '0 0 24 24');
    el.setAttribute('width', size);
    el.setAttribute('height', size);
    el.setAttribute('fill', fill);
    if (fill === 'none') {
      el.setAttribute('stroke', stroke);
      el.setAttribute('stroke-width', width);
      el.setAttribute('stroke-linecap', cap);
      el.setAttribute('stroke-linejoin', join);
    } else el.setAttribute('stroke', 'none');
    el.setAttribute('aria-hidden', 'true');
    if (cls) el.setAttribute('class', cls);
    if (style) Object.assign(el.style, style);
    const p = document.createElementNS(NS, 'path');
    p.setAttribute('d', path);
    el.append(p);
    return el;
  }
  const star = (filled, size = 16) => svg(IC.star, filled ? { size, fill: 'rgba(255,255,255,.94)' } : { size, stroke: 'var(--bcv-ink3)', width: 1.7, cap: 'butt' });
  const chev = () => svg(IC.chevron, { size: 15, stroke: 'var(--bcv-ink3)', width: 2, cls: 'bcv-chev' });

  // ---- primitives -----------------------------------------------------------
  const el = (cls, children, attrs = {}) => h('div', { class: cls, ...attrs }, children);
  const text = (cls, str, tag = 'div') => h(tag, { class: cls, text: str });

  function tile(icon, { color = 'var(--bcv-ink3)', tint = 'var(--bcv-fill2)', size = 30, iconSize = 15, width = 1.8, cls = '' } = {}) {
    const mod = size === 32 ? ' bcv-tile--32' : size === 28 ? ' bcv-tile--28' : '';
    return h('span', { class: `bcv-tile${mod} ${cls}`, style: { background: tint } }, svg(icon, { size: iconSize, stroke: color, width }));
  }

  function dot(color, mod = '') {
    return h('span', { class: `bcv-dot ${mod}`, style: { background: color } });
  }

  function card(children, mod = '') {
    return el(`bcv-card ${mod}`, children);
  }

  /** A list row. Pass `onClick` to make it a button-like link. */
  function row(children, { mod = '', onClick = null, href = null, cls = '' } = {}) {
    const attrs = { class: `bcv-row ${mod} ${onClick || href ? 'bcv-row--link' : 'bcv-row--hover'} ${cls}` };
    if (href) {
      attrs.href = href;
      return h('a', { ...attrs, style: { color: 'inherit' } }, children);
    }
    if (onClick) {
      attrs.onclick = onClick;
      return h('button', { ...attrs, type: 'button' }, children);
    }
    return h('div', attrs, children);
  }

  const label = (str, mod = '') => text(`bcv-label ${mod}`, str);
  const h2 = (str, mod = '') => text(`bcv-h2 ${mod}`, str, 'h2');
  const groupHead = (title, sub, mod = '') => el(`bcv-group__head ${mod}`, [h2(title), sub ? text('bcv-group__sub', sub, 'span') : null]);

  function badge(str, kind = '', size = '') {
    const mod = { red: 'bcv-badge--red', blue: 'bcv-badge--blue', green: 'bcv-badge--green', orange: 'bcv-badge--orange' }[kind] || '';
    return h('span', { class: `bcv-badge ${mod} ${size}`, text: str });
  }
  /** A status word as a small badge, coloured by its kind (store.workStatus / store.workFlags):
   *  bad red, warn orange, good green, info blue, muted or none the plain fill. */
  function statusBadge(st, size = 'bcv-badge--xs') {
    if (!st || !st.word) return null;
    const b = badge(st.word, { bad: 'red', warn: 'orange', good: 'green', info: 'blue' }[st.kind] || '', size);
    b.classList.add('bcv-status');
    return b;
  }

  /** A tap the phone should feel, in the iPhone app (its Taptic Engine, through the bridge); nothing anywhere else.
   *  light · medium · rigid · soft · select · success · warning · error. */
  const haptic = (kind = 'light') => { try { self.BCVBridge?.native?.haptic?.(kind); } catch { /* an older app */ } };

  function seg(options, value, onChange, { wide = false } = {}) {
    const wrap = el(`bcv-seg ${wide ? 'bcv-seg--wide' : ''}`);
    for (const [key, lbl] of options) {
      wrap.append(h('button', {
        type: 'button',
        class: `bcv-seg__btn ${key === value ? 'is-active' : ''}`,
        text: lbl,
        dataset: { value: key },
        onclick: () => {
          // (the highlight sets off at once — the screen the choice redraws lands after, its highlight starting from here)
          for (const b of wrap.querySelectorAll('.bcv-seg__btn')) b.classList.toggle('is-active', b.dataset.value === key);
          haptic('select');
          onChange(key);
        },
      }));
    }
    segSlide(wrap, '.bcv-seg__btn', options.map((o) => o[0]).join('|'));
    return wrap;
  }

  // ---- the segmented controls' sliding highlight (2.98.71) ------------------------------------------
  // One shape behind the options that glides to the one chosen, rather than the chosen one lighting up
  // where it is: in place when the control stays, and across a redraw — a view switched, the screen drawn
  // again with a new control of the same options — from where the last one's highlight stood (kept a
  // moment, by the options). It follows the chosen one however it becomes chosen (a class changed, the
  // buttons replaced: watched), and is put back at once when the control changes size. Reduced motion: no glide.
  const segMemo = new Map(); // options → where the highlight last stood in a control of them { left, top, width, height, at }
  const SEG_RECALL = 1500; // ms a redrawn control starts from the last one's place
  function segSlide(wrap, sel, memoKey = '') {
    if (wrap.bcvSlide) { wrap.bcvSlide(); return; }
    const thumb = h('span', { class: 'bcv-seg__thumb', 'aria-hidden': 'true' });
    wrap.classList.add('has-thumb');
    wrap.append(thumb); // (last, so the options keep their places among the children)
    let shown = null;
    // (moved by transform alone: the shape takes the chosen option's size at once and starts out scaled to where it
    // stands this instant — mid-glide too — so the glide is a translate and a scale settling to none, never a resize)
    const drawn = () => {
      const r = thumb.getBoundingClientRect(), w = wrap.getBoundingClientRect();
      const k = (wrap.offsetWidth && w.width / wrap.offsetWidth) || 1; // (inside a sheet still growing in: its scale taken out)
      return r.width ? { left: (r.left - w.left) / k - wrap.clientLeft, top: (r.top - w.top) / k - wrap.clientTop, width: r.width / k, height: r.height / k } : null;
    };
    const put = (g, glide) => {
      const from = glide && shown ? drawn() : null;
      thumb.style.transition = 'none';
      Object.assign(thumb.style, { width: `${g.width}px`, height: `${g.height}px`, borderRadius: g.radius, opacity: '1' });
      if (from && g.width && g.height) {
        thumb.style.transform = `translate(${from.left}px, ${from.top}px) scale(${from.width / g.width}, ${from.height / g.height})`;
        void thumb.offsetWidth;
        thumb.style.transition = '';
        thumb.style.transform = `translate(${g.left}px, ${g.top}px)`;
      } else {
        thumb.style.transform = `translate(${g.left}px, ${g.top}px)`;
        void thumb.offsetWidth;
        thumb.style.transition = '';
      }
      shown = g;
      if (memoKey) segMemo.set(memoKey, { ...g, at: Date.now() });
    };
    const place = ({ jump = false } = {}) => {
      if (thumb.parentNode !== wrap) wrap.append(thumb); // (the options drawn afresh in the same control)
      const b = wrap.querySelector(`${sel}.is-active`);
      if (!b) { thumb.style.opacity = '0'; shown = null; return; }
      if (!wrap.isConnected || !b.offsetWidth) return; // (not laid out yet: the first size it gets places it)
      const g = { left: b.offsetLeft, top: b.offsetTop, width: b.offsetWidth, height: b.offsetHeight, radius: getComputedStyle(b).borderTopLeftRadius };
      const same = (a) => a && a.left === g.left && a.top === g.top && a.width === g.width && a.height === g.height;
      if (!shown) {
        const was = memoKey ? segMemo.get(memoKey) : null;
        if (!jump && was && Date.now() - was.at < SEG_RECALL && !same(was) && !reducedMotion()) { put(was, false); requestAnimationFrame(() => put(g, true)); return; }
        put(g, false);
        return;
      }
      if (!same(shown)) put(g, !jump && !reducedMotion());
    };
    new MutationObserver(() => place()).observe(wrap, { subtree: true, childList: true, attributes: true, attributeFilter: ['class'] });
    if (self.ResizeObserver) {
      let first = true;
      new ResizeObserver(() => { place({ jump: !first }); first = false; }).observe(wrap); // (laid out: placed, from the last one's place; resized: put there)
    }
    wrap.bcvSlide = place;
  }

  function search(placeholder, onInput, mod = '') {
    const input = h('input', { type: 'search', placeholder, 'aria-label': placeholder });
    if (onInput) input.addEventListener('input', () => onInput(input.value.trim()));
    return el(`bcv-search ${mod}`, [svg(IC.search, { size: 14, stroke: 'var(--bcv-ink3)', width: 1.9, cap: 'round', join: 'miter' }), input]);
  }

  function switchEl(on, onToggle, ariaLabel = '') {
    const sw = h('button', { type: 'button', class: `bcv-switch ${on ? 'is-on' : ''}`, role: 'switch', 'aria-checked': on ? 'true' : 'false', 'aria-label': ariaLabel }, h('span', { class: 'bcv-switch__knob' }));
    sw.addEventListener('click', () => {
      const next = !sw.classList.contains('is-on');
      sw.classList.toggle('is-on', next);
      sw.setAttribute('aria-checked', next ? 'true' : 'false');
      haptic('light');
      onToggle(next);
    });
    return sw;
  }

  function btn(lbl, { icon = null, kind = '', onClick = null, iconColor = 'currentColor', iconSize = 14, cls = '', disabled = false, title = '' } = {}) {
    const mod = { primary: 'bcv-btn--primary', card: 'bcv-btn--card', fill36: 'bcv-btn--fill36', danger: 'bcv-btn--danger', dangerSolid: 'bcv-btn--danger-solid', sm: 'bcv-btn--sm', xs: 'bcv-btn--xs' }[kind] || '';
    const b = h('button', { type: 'button', class: `bcv-btn ${mod} ${cls}`, onclick: onClick, disabled: disabled || null, title: title || null }, [
      icon ? svg(icon, { size: iconSize, stroke: iconColor, width: 1.9 }) : null,
      lbl,
    ]);
    return b;
  }

  function iconbtn(icon, { onClick = null, size = 26, iconSize = 12, stroke = 'var(--bcv-ink3)', width = 2.3, title = '' } = {}) {
    const mod = size === 24 ? 'bcv-iconbtn--24' : size === 22 ? 'bcv-iconbtn--22' : size === 30 ? 'bcv-iconbtn--30' : '';
    return h('button', { type: 'button', class: `bcv-iconbtn ${mod}`, onclick: onClick, title: title || null, 'aria-label': title || null }, svg(icon, { size: iconSize, stroke, width }));
  }

  const pill = (lbl, onClick, mod = '') => h('button', { type: 'button', class: `bcv-pill ${mod}`, onclick: onClick, text: lbl });
  const empty = (str) => el('bcv-empty', str);
  const emptyCard = (str) => card(str, 'bcv-card--empty');
  /** Loading state (mockup 8): skeleton blocks shaped like the content they replace,
   *  so the layout does not jump when the data lands. `kind`: 'rows' (list rows,
   *  the default), 'cards' (course cards) or 'inset' (rows inside a card). Hidden
   *  from screen readers; a load faster than 150ms never shows them (CSS delay). */
  function loading(kind = 'rows', n = kind === 'cards' ? 6 : 3) {
    if (typeof kind !== 'string' || !['rows', 'cards', 'inset'].includes(kind)) kind = 'rows';
    const widths = ['72%', '58%', '84%', '64%', '76%', '52%'];
    const b = (cls, style = null) => h('span', { class: `bcv-skel__b ${cls}`, style });
    const items = Array.from({ length: n }, (_, i) => (kind === 'cards'
      ? el('bcv-skel__card', [
        el('bcv-skel__ctop', [b('bcv-skel__ring'), el('bcv-skel__lines', [b('bcv-skel__l1', { width: widths[i % 6] }), b('bcv-skel__l2', { width: '46%' }), b('bcv-skel__l3')])]),
        b('bcv-skel__bar'), b('bcv-skel__btn'),
      ])
      : el('bcv-skel__row', [b('bcv-skel__tile'), el('bcv-skel__lines', [b('bcv-skel__l1', { width: widths[i % 6] }), b('bcv-skel__l2')]), b('bcv-skel__badge')])));
    return el(`bcv-skel ${kind === 'cards' ? 'bcv-skel--cards' : kind === 'inset' ? 'bcv-skel--inset' : ''}`, items, { 'aria-hidden': 'true', role: 'presentation' });
  }
  /** A block saying something could not be loaded, with its error code (lib/errors.js) at its end —
   *  drawn from data-code (app.css), so the words stay the words; the code is kept for a report. */
  const errorBox = (str, err = null) => {
    const box = el('bcv-error', str);
    const c = BCV.errors?.codeFor?.(err);
    if (c) { box.dataset.code = c; BCV.errors.note(c); }
    return box;
  };
  const hint = (str, mod = '') => h('p', { class: `bcv-hint ${mod}`, text: str });

  function avatar(url, name, size = 38) {
    if (url && !/avatar-50|no_pic|dotted_pic|messages\/avatar-/.test(url)) {
      return h('img', { class: size === 30 ? 'bcv-account__avatar' : 'bcv-tile--38', src: url, alt: '', width: size, height: size, referrerpolicy: 'no-referrer' });
    }
    return h('span', { class: size === 30 ? 'bcv-account__avatar' : 'bcv-tile--38' });
  }

  let toastTimer = null;
  /** A note that floats down from the top for a moment. `alert`: a screen reader says it at once, as an alert, rather
   *  than when it is next free (a status) — for what the student did not ask for and must hear, such as an error
   *  Canvas's own page put up (app.js, relayFlash). */
  function toast(str, { error = false, ms = 2600, code = null, err = null, alert = false } = {}) {
    // (a toast already up — not on its way out — takes the new words where it stands, with a small nudge to say they
    // changed; it is not torn down for another to drop in from the top. One on its way out finishes leaving.)
    const live = [...document.querySelectorAll('.bcv-toast')].find((x) => !x.classList.contains('is-closing') && !x.classList.contains('bcv-sprung'));
    // a pill that floats down from the top centre, the Away Refresh pill's kind: a mark (a bell, or on an
    // error a red "!") and the words beside it
    const mark = error ? 'M12 7.5v6M12 16.8v.2' : 'M6.5 16.5h11l-1.4-2V10a4.1 4.1 0 00-8.2 0v4.5zM10.3 18.6a1.8 1.8 0 003.4 0';
    if (error) haptic('error');
    const parts = [
      h('span', { class: 'bcv-toast__ic', 'aria-hidden': 'true' }, svg(mark, { size: 16, width: error ? 2.8 : 2.2 })),
      h('span', { class: 'bcv-toast__text', text: str }),
    ];
    let t = live;
    if (t) {
      t.className = `bcv-toast ${error ? 'bcv-toast--error' : ''}`;
      t.setAttribute('role', alert ? 'alert' : 'status');
      t.replaceChildren(...parts);
      delete t.dataset.code;
      if (!reducedMotion() && !t.getAnimations().some((a) => a.playState === 'running')) t.animate([{ transform: 'scale(.97)' }, { transform: 'none' }], { duration: 160, easing: 'cubic-bezier(.23,1,.32,1)' });
    } else t = el(`bcv-toast ${error ? 'bcv-toast--error' : ''}`, parts, { role: alert ? 'alert' : 'status' });
    // an error says its code (lib/errors.js) after its words — drawn from data-code, and kept for a report — and stays a little longer to be read
    const c = error ? code || BCV.errors?.codeFor?.(err) : null;
    if (c) { t.dataset.code = c; BCV.errors.note(c); ms = Math.max(ms, 4200); }
    if (!live) overlayRoot().append(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => dismiss(t), ms); // (it leaves the way it came, on its spring)
    return t;
  }

  /** A dropdown that can show what a native one cannot.
   *
   *  A `<select>` renders its options as plain text, so an option that is a formula — which Canvas
   *  serves as a picture — comes out blank in one. This is a button that opens a list, so each
   *  option is drawn the way the rest of the interface draws Canvas content: pictures, formulas and
   *  all. It answers the keyboard the way a select does (arrows move, Enter and Space pick, Escape
   *  shuts, typing jumps to a label) and reports itself as a listbox.
   *
   *  options: [{ value, text, html }] — `html` is Canvas's own content for that option, when it has
   *  any. `value` is what onChange is given. */
  function picker(options, value, onChange, { label = '', placeholder = 'Choose…', cls = '' } = {}) {
    let list = null;
    let typed = '';
    let typedAt = 0;
    const opt = (v) => options.find((o) => String(o.value) === String(v)) || null;
    // only a value the list offers is a value: anything else (a null Canvas sent for "nothing picked",
    // read as the string "null") would sit in the picker unseen, its face saying Choose…, and be handed on as a pick
    const known = (v) => { const t = v === null || v === undefined ? '' : String(v); return t && opt(t) ? t : ''; };
    let cur = known(value);
    const face = el('bcv-picker__face');
    const btn = h('button', {
      type: 'button', class: `bcv-picker ${cls}`, 'aria-haspopup': 'listbox', 'aria-expanded': 'false', ...(label ? { 'aria-label': label } : {}),
    }, [face, svg('M6 9l6 6 6-6', { size: 13, stroke: 'var(--bcv-ink3)', width: 2.2, cls: 'bcv-picker__chev' })]);

    const drawFace = () => {
      const o = opt(cur);
      face.replaceChildren(o
        ? (String(o.html || '').trim() && !String(o.text || '').trim()
          ? BCV.screens.course.prose(o.html, { cls: 'bcv-picker__rich' })
          : text('bcv-picker__label bcv-ellip', o.text || BCV.utils.htmlToText(o.html || '', 80) || String(o.value), 'span'))
        : text('bcv-picker__label bcv-picker__label--none bcv-ellip', placeholder, 'span'));
      btn.classList.toggle('is-set', !!o);
    };

    function onAway(e) { if (!list?.contains(e.target) && !btn.contains(e.target)) close(); }
    /** The list goes back into its button the way it grew out of it (dismiss: a menu's pop, from
     *  wherever its entrance had got to, nothing in it pressable on the way); shut from the keyboard
     *  (Escape, Tab, a pick by key) it is simply gone. The next press opens a fresh one at once. */
    function close(keyed = false) {
      if (!list) return;
      if (keyed) list.remove();
      else { list.inert = true; dismiss(list, { reduced: true }); } // (reduced motion: its 150ms fade, waited for)
      list = null;
      btn.setAttribute('aria-expanded', 'false');
      document.removeEventListener('pointerdown', onAway, true);
      document.removeEventListener('keydown', listKeys, true);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('scroll', onScroll, true);
    }
    // the page moving under it takes it away — but the list scrolling inside itself does not
    function onScroll(e) { if (!list?.contains(e.target)) close(); }
    function onResize() { close(); }
    const pick = (v, keyed = false) => {
      cur = known(v);
      drawFace();
      close(keyed);
      btn.focus();
      onChange(cur);
    };

    function open() {
      if (list) { close(); return; }
      closeMenus();
      const nat = nativeUi();
      if (nat?.menu && options.length) { // (in the iPhone app: the phone's own action sheet, the current choice ticked)
        nat.menu({ title: label, items: options.map((o) => ({ label: o.text || BCV.utils.htmlToText(o.html || '', 120) || String(o.value), active: String(o.value) === cur })), rect: rectOf(btn) })
          .then((i) => { if (i >= 0 && options[i]) pick(options[i].value); })
          .catch(() => { /* nothing chosen */ });
        return;
      }
      const r = btn.getBoundingClientRect();
      list = el('bcv-picker__list', options.map((o) => h('button', {
        type: 'button', class: `bcv-picker__opt ${o.cls || ''} ${String(o.value) === cur ? 'is-on' : ''}`, role: 'option',
        'aria-selected': String(o.value) === cur ? 'true' : 'false', dataset: { value: String(o.value) },
        onclick: (e) => pick(o.value, e.detail === 0), // (e.detail 0: Enter or Space)
      }, [
        String(o.html || '').trim() && !String(o.text || '').trim()
          ? BCV.screens.course.prose(o.html, { cls: 'bcv-picker__rich' })
          : text('bcv-picker__opttext', o.text || BCV.utils.htmlToText(o.html || '', 120) || String(o.value), 'span'),
        svg('M20 6L9 17l-5-5', { size: 14, stroke: 'var(--bcv-blue)', width: 2.4, cls: 'bcv-picker__tick' }),
      ])), { role: 'listbox', ...(label ? { 'aria-label': label } : {}) });
      // over everything, under the button — or above it when the room is above (anchor)
      overlayRoot().append(list);
      anchor(list, r, { side: 'below', minWidth: 220 });
      btn.setAttribute('aria-expanded', 'true');
      (list.querySelector('.bcv-picker__opt.is-on') || list.firstElementChild)?.focus({ preventScroll: true });
      document.addEventListener('keydown', listKeys, true); // (the list's keys, for as long as it is open — not one more listener per picker for the page's life)
      requestAnimationFrame(() => {
        if (!list) return;
        document.addEventListener('pointerdown', onAway, true);
        window.addEventListener('resize', onResize);
        window.addEventListener('scroll', onScroll, true);
      });
    }

    const move = (from, step) => {
      const all = [...(list?.querySelectorAll('.bcv-picker__opt') || [])];
      if (!all.length) return;
      const i = all.indexOf(from);
      all[Math.max(0, Math.min(all.length - 1, (i < 0 ? 0 : i) + step))].focus();
    };
    const jump = (key) => {
      const now = Date.now();
      typed = now - typedAt > 900 ? key : typed + key;
      typedAt = now;
      const all = [...(list?.querySelectorAll('.bcv-picker__opt') || [])];
      all.find((x) => x.textContent.trim().toLowerCase().startsWith(typed.toLowerCase()))?.focus();
    };
    btn.addEventListener('click', open);
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
    });
    btn.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(true); });
    // the list's own keys: the buttons in it have focus while it is open
    function listKeys(e) {
      if (!list || !list.contains(e.target)) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); move(e.target, 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); move(e.target, -1); }
      else if (e.key === 'Home') { e.preventDefault(); move(null, 0); }
      else if (e.key === 'Escape') { e.preventDefault(); close(true); btn.focus(); }
      else if (e.key === 'Tab') close(true);
      else if (e.key.length === 1) jump(e.key);
    }
    drawFace();
    btn.bcvPicker = { set: (v) => { cur = known(v); drawFace(); }, get value() { return cur; }, close };
    return btn;
  }

  /** The app's own controls, where the page runs inside the iPhone app on the phone layout: its
   *  alert and its action sheet (Web/bridge.js). null in a browser — the drawn ones serve there. */
  const nativeUi = () => (document.documentElement.classList.contains('bcv-phone') ? self.BCVBridge?.native || null : null);
  const rectOf = (at) => {
    try { const r = at?.getBoundingClientRect ? at.getBoundingClientRect() : at; return r && Number.isFinite(r.left) ? { x: r.left, y: r.top, w: r.width || 0, h: r.height || 0 } : null; } catch { return null; }
  };

  /** Dropdown menu anchored under `anchor`. items: [{label, sub, active, onSelect}]. In the iPhone
   *  app it is the phone's own action sheet (the pick runs the same onSelect); the drawn menu is the
   *  fallback should the app not answer. */
  function menu(at, items) {
    const nat = nativeUi();
    if (nat?.menu && items?.length) {
      closeMenus();
      nat.menu({ items, rect: rectOf(at) }).then((i) => { if (i >= 0) items[i]?.onSelect?.(); }).catch(() => webMenu(at, items));
      return null;
    }
    return webMenu(at, items);
  }
  /** (2.99.122) A menu opened from inside a sheet — a plan's editor floating over the calendar — goes over that sheet:
   *  a menu sits under sheets (--bcv-z-menu), so there its items were hidden by the sheet and could not be pressed. */
  function overSheet(m, at) {
    const ov = at?.closest?.('.bcv-sheet-ov');
    if (!ov) return;
    const z = parseInt(getComputedStyle(ov).zIndex, 10);
    if (Number.isFinite(z)) m.style.zIndex = String(z + 1);
  }
  function webMenu(at, items) {
    closeMenus();
    const m = el('bcv-menu', items.map((it) => h('button', {
      type: 'button',
      class: `bcv-menu__item ${it.active ? 'is-active' : ''}`,
      onclick: () => {
        closeMenus();
        it.onSelect?.();
      },
    }, [
      it.color ? dot(it.color, 'bcv-dot--9') : null,
      h('span', { style: { flex: '1', minWidth: '0' } }, [
        h('span', { class: 'bcv-ellip', style: { display: 'block' }, text: it.label }),
        it.sub ? h('span', { class: 'bcv-menu__sub', text: it.sub }) : null,
      ]),
    ])));
    overSheet(m, at);
    overlayRoot().append(m);
    anchor(m, at, { side: 'below' }); // (under its button, or above it when the room is above; on screen either way)
    setTimeout(() => document.addEventListener('click', closeMenus, { once: true }), 0);
    return m;
  }
  // ---- the mechanisms every floating or moving thing uses -----------------------------------------
  // One way to wait for motion, one way to know an element has gone, one way to follow a box's
  // place on the page, one way to put a floating element beside another and keep it on screen.
  // Nothing waits a guessed number of milliseconds, measures once and hopes, or carries its own
  // observer: a change to a duration in the CSS, a slower machine, a zoomed window or a font that
  // arrives late are all answered here, once.

  /** Resolves when the element's (and its direct children's) running animations and transitions
   *  have ended — their own timing, read from the page — capped so a stuck one never holds a caller;
   *  at once under reduced motion, unless `reduced` says the exit keeps its short fade there (the
   *  stylesheet's reduce rules), which is then waited for too. Call it right after setting the class
   *  that starts the motion. */
  function afterMotion(el, cap = 450, { reduced = false } = {}) {
    return new Promise((resolve) => {
      if (!el || (reducedMotion() && !reduced)) { resolve(); return; }
      const t = setTimeout(resolve, cap);
      const done = () => { clearTimeout(t); resolve(); };
      let list = [];
      try {
        list = [el, ...el.children].flatMap((n) => n.getAnimations()).filter((a) => a.playState !== 'finished' && a.playState !== 'idle' && a.effect?.getTiming?.().iterations !== Infinity);
      } catch { list = []; }
      if (!list.length) { requestAnimationFrame(() => requestAnimationFrame(done)); return; } // (two frames: a class set this turn starts its motion on the next)
      Promise.all(list.map((a) => a.finished.catch(() => {}))).then(done);
    });
  }

  /** Calls fn once the element has left the document (swept away by a screen change, closed by
   *  another path, removed by a caller). One observer serves every registration. Returns forget(). */
  const goneList = new Map(); // element → { fn, armed }: armed once it has been seen on the page (registered before its append, it is not "gone" yet)
  let goneMo = null;
  function sweepGone() {
    for (const [el, w] of goneList) {
      if (!w.armed) { if (el.isConnected) w.armed = true; continue; }
      if (!el.isConnected) { goneList.delete(el); try { w.fn(); } catch { /* the caller's own */ } }
    }
    if (!goneList.size && goneMo) { goneMo.disconnect(); goneMo = null; }
  }
  function onGone(el, fn) {
    if (!el) return () => {};
    goneList.set(el, { fn, armed: el.isConnected });
    if (!goneMo) { goneMo = new MutationObserver(sweepGone); goneMo.observe(document.documentElement, { childList: true, subtree: true }); }
    return () => goneList.delete(el);
  }

  /** Follows an element's box: fn(rect) when it is first measured and whenever it may have moved —
   *  its own or the page's size changing, something around it (not inside it) drawn or restyled, an
   *  animation or a transition ending, the fonts arriving, the window resizing or zooming — and
   *  then again each frame until it has held still for three, so a slide that is still going at the
   *  first measure is measured at its end. Returns stop(); it stops by itself once the element, having
   *  been in the page, has left it (a screen drawn afresh), so its watchers do not pile up. */
  function watchLayout(el, fn, { within = null, frames = 3, limit = 240 } = {}) {
    let last = '', quiet = 0, n = 0, raf = 0, stopped = false, seen = false;
    const tick = () => {
      raf = 0;
      if (stopped) return;
      if (!el.isConnected) { if (seen) stop(); return; }
      seen = true;
      const r = el.getBoundingClientRect();
      const key = `${Math.round(r.top)},${Math.round(r.left)},${Math.round(r.width)},${Math.round(r.height)}`;
      if (key !== last) { last = key; quiet = 0; try { fn(r); } catch { /* the caller's own */ } } else quiet++;
      if (quiet < frames && n++ < limit) raf = requestAnimationFrame(tick);
    };
    const kick = () => { if (stopped) return; quiet = 0; n = 0; if (!raf) raf = requestAnimationFrame(tick); };
    const scope = within || el.closest('.bcv-screen') || document.body;
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(kick) : null;
    ro?.observe(el);
    ro?.observe(document.documentElement);
    if (scope !== el) ro?.observe(scope);
    const mo = new MutationObserver((recs) => { if (recs.some((m) => m.target !== el && !el.contains(m.target))) kick(); });
    mo.observe(scope, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden'] });
    scope.addEventListener('animationend', kick, true);
    scope.addEventListener('transitionend', kick, true);
    window.addEventListener('resize', kick);
    document.fonts?.ready?.then(kick).catch(() => {});
    function stop() { stopped = true; ro?.disconnect(); mo.disconnect(); scope.removeEventListener('animationend', kick, true); scope.removeEventListener('transitionend', kick, true); window.removeEventListener('resize', kick); if (raf) cancelAnimationFrame(raf); raf = 0; }
    kick();
    return stop;
  }

  /** Puts a floating element (already in the document, so it has a size) beside a rect or an
   *  element and keeps it on screen: below it — or above when the room is above — or to its right —
   *  or left; aligned to its start, centre or end; clamped to the viewport by a margin; a list placed
   *  above or below gets a maxHeight so it scrolls rather than runs off the edge. Call again after
   *  the element grows. */
  function anchor(el, at, { side = 'below', gap = 6, margin = 8, align = 'start', minWidth = 0 } = {}) {
    const r = at && at.getBoundingClientRect ? at.getBoundingClientRect() : at;
    if (!el || !r) return;
    const vw = window.innerWidth, vh = window.innerHeight;
    el.style.position = 'fixed';
    el.style.bottom = '';
    if (minWidth) el.style.minWidth = `${Math.max(r.width, minWidth)}px`;
    // (its laid-out size, not its box on screen: an entrance that scales it up has only begun, and a
    // box measured that small was placed too near the edge — a menu by the right edge ended past it)
    const size = () => ({ width: el.offsetWidth, height: el.offsetHeight });
    let m = size();
    let top, left;
    if (side === 'right' || side === 'left') {
      const roomRight = vw - r.right - gap - margin, roomLeft = r.left - gap - margin;
      const goRight = side === 'right' ? (m.width <= roomRight || roomRight >= roomLeft) : !(m.width <= roomLeft || roomLeft >= roomRight);
      left = goRight ? r.right + gap : r.left - gap - m.width;
      top = align === 'center' ? r.top + r.height / 2 - m.height / 2 : align === 'end' ? r.bottom - m.height : r.top;
    } else {
      const below = vh - r.bottom - gap - margin, above = r.top - gap - margin;
      const goBelow = side === 'below' ? (m.height <= below || below >= above) : !(m.height <= above || above >= below);
      el.style.maxHeight = `${Math.max(120, Math.floor(goBelow ? below : above))}px`;
      m = size();
      top = goBelow ? r.bottom + gap : r.top - gap - m.height;
      left = align === 'center' ? r.left + r.width / 2 - m.width / 2 : align === 'end' ? r.right - m.width : r.left;
    }
    el.style.left = `${Math.round(Math.max(margin, Math.min(left, vw - m.width - margin)))}px`;
    el.style.top = `${Math.round(Math.max(margin, Math.min(top, vh - m.height - margin)))}px`;
    // it grows out of the edge it hangs from (the entrance scales from the transform origin): under
    // its button from the top, above it from the bottom, beside it from the near side
    const ox = side === 'right' ? 'left' : side === 'left' ? 'right' : align === 'center' ? 'center' : align === 'end' ? 'right' : 'left';
    const oy = side === 'right' || side === 'left' ? (align === 'center' ? 'center' : align === 'end' ? 'bottom' : 'top') : (top < r.top ? 'bottom' : 'top');
    el.style.transformOrigin = `${ox} ${oy}`;
  }
  /** Keeps a fixed element that was placed by other means inside the viewport. */
  function keepOnScreen(el, margin = 16) {
    const m = el.getBoundingClientRect();
    const left = Math.max(margin, Math.min(m.left, window.innerWidth - m.width - margin));
    const top = Math.max(margin, Math.min(m.top, window.innerHeight - m.height - margin));
    if (Math.round(left) !== Math.round(m.left)) el.style.left = `${Math.round(left)}px`;
    if (Math.round(top) !== Math.round(m.top)) el.style.top = `${Math.round(top)}px`;
  }
  /** The box an element and everything drawn in it take up (a switch with a pill popped out of it). */
  function boundsOf(el) {
    const r = el.getBoundingClientRect();
    let left = r.left, top = r.top, right = r.right, bottom = r.bottom, n = 0;
    for (const c of el.querySelectorAll('*')) {
      if (n++ > 400) break;
      const cs = getComputedStyle(c);
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') continue;
      const q = c.getBoundingClientRect();
      if (!q.width || !q.height) continue;
      left = Math.min(left, q.left); top = Math.min(top, q.top); right = Math.max(right, q.right); bottom = Math.max(bottom, q.bottom);
    }
    return { left, top, right, bottom, width: right - left, height: bottom - top };
  }

  /** Closes an overlay, a menu or a sheet with its exit: is-closing starts the CSS's animation, and
   *  the element goes when that has ended (at once under reduced motion). */
  /** Which spring an element leaves on (docs/MOTION.md): a scrim fades while its sheet shrinks (a
   *  phone sheet slides down), a menu, a dropdown's list or a toast pops out, anything else fades. */
  function exitKindOf(ov) {
    const c = ov.classList;
    if (c.contains('bcv-sheet-ov')) return document.documentElement.classList.contains('bcv-phone') ? 'down' : 'shrink';
    if (c.contains('bcv-toast')) return 'toast';
    if (c.contains('bcv-menu') || c.contains('bcv-picker__list')) return 'pop'; // (back toward the edge it grew from: ui.anchor's origin)
    return 'fade';
  }
  const EXIT_CAP = 700; // ms: the longest exit spring settles well inside this, and an element has left by then whatever its animations do
  /** Closes an overlay, a menu or a sheet with its exit, and resolves once it has gone. On the springs
   *  (BCV.motion) the exit plays from wherever the entrance had got to — a sheet closed while still
   *  growing shrinks back from there; the springs start before the closing class goes on, because that
   *  class stands the stylesheet's motion down and the entrance is read for its progress while it
   *  runs. Without the springs, or under reduced motion, is-closing starts the stylesheet's exit and
   *  afterMotion sees it end. Either way the element is removed by EXIT_CAP: a promise that waits on
   *  an animation is raced against the clock, so nothing that never finishes leaves a scrim on the
   *  page (docs/SAFARI.md §4), and a spring that throws hands over to the stylesheet's exit. `reduced`:
   *  under reduced motion its 150ms fade (app.css) is waited for before it goes (ui.afterMotion), rather
   *  than its going at once. */
  function dismiss(ov, { reduced = false } = {}) {
    if (!ov || !ov.isConnected || ov.classList.contains('is-closing')) return Promise.resolve();
    const exit = (ov._bcvExit = { recalled: false }); // (recall() below can still bring it back, until it is gone)
    const gone = () => { if (exit.recalled) return; try { ov.remove(); } catch { /* already gone */ } };
    const cap = new Promise((resolve) => setTimeout(resolve, EXIT_CAP));
    const M = BCV.motion;
    if (M && !reducedMotion()) {
      try {
        const kind = exitKindOf(ov);
        const sheet = ov.classList.contains('bcv-sheet-ov') ? ov.querySelector(':scope > .bcv-sheet') : null;
        const parts = [M.exit(ov, sheet ? 'scrim' : kind)];
        if (sheet) parts.push(M.exit(sheet, kind));
        ov.classList.add('is-closing', 'bcv-sprung');
        return Promise.race([Promise.all(parts.map((p) => p.finished)), cap]).then(gone, gone); // (an exit cancelled by recall() rejects: still settled, and gone() stands down)
      } catch { ov.classList.remove('is-closing', 'bcv-sprung'); } // (the stylesheet's exit instead)
    }
    ov.classList.add('is-closing');
    return Promise.race([afterMotion(ov, 450, { reduced }), cap]).then(gone, gone);
  }
  /** Bring back something on its way out (dismiss above), from wherever its exit has got to — the pointer back over
   *  what opened it, say — rather than letting it go and opening a second one beside it. False when it is not leaving. */
  function recall(ov) {
    if (!ov || !ov.isConnected || !ov.classList.contains('is-closing') || !ov._bcvExit) return false;
    ov._bcvExit.recalled = true;
    const cs = getComputedStyle(ov);
    const from = { opacity: cs.opacity, transform: cs.transform };
    for (const a of ov.getAnimations()) a.cancel(); // (the exit, and the entrance's held last frame: the element's own look is where it lands)
    ov.classList.remove('is-closing', 'bcv-sprung');
    if (!reducedMotion()) ov.animate([from, { opacity: 1, transform: 'none' }], { duration: 180, easing: 'cubic-bezier(.23,1,.32,1)' });
    return true;
  }
  function closeMenus() {
    document.querySelectorAll('.bcv-menu:not([data-keep]):not(.is-closing)').forEach((m) => dismiss(m)); // (a box that only wears a menu's look stays: the inbox's recipient results)
  }

  /** Canvas's own course colour palette (the picker on its dashboard cards), plus a custom colour. */
  const COURSE_COLORS = [['#BD3C14', 'Brick'], ['#FF2717', 'Red'], ['#E71F63', 'Magenta'], ['#8F3E97', 'Purple'], ['#65499D', 'Deep purple'], ['#4554A4', 'Indigo'], ['#1770AB', 'Blue'], ['#0B9BE3', 'Light blue'], ['#06A3B7', 'Cyan'], ['#009688', 'Teal'], ['#009606', 'Green'], ['#8D9900', 'Olive'], ['#D97900', 'Pumpkin'], ['#FD5D10', 'Orange'], ['#F06291', 'Pink']];
  /** (2.99.118) `title`: what it colours ("Course colour" by default); `reset`: { label, onPick } — a first swatch that
   *  puts back the colour it had of its own (a card's or the sidebar's: the theme's), marked while nothing else is. */
  function colorMenu(anchor, current, onPick, { title = 'Course colour', reset = null } = {}) {
    closeMenus();
    const cur = String(current || '').toLowerCase();
    const custom = h('input', { type: 'color', class: 'bcv-swatch__input', value: /^#[0-9a-f]{6}$/i.test(cur) ? cur : '#8e8e93', 'aria-label': 'Custom colour' });
    custom.addEventListener('change', () => { closeMenus(); onPick(custom.value.toUpperCase()); });
    const m = el('bcv-menu bcv-menu--colors', [
      text('bcv-menu__title', title),
      el('bcv-swatches', [
        reset ? h('button', { type: 'button', class: `bcv-swatch bcv-swatch--reset ${!cur ? 'is-current' : ''}`, title: reset.label, 'aria-label': reset.label, dataset: { color: '' }, onclick: () => { closeMenus(); reset.onPick(); } }, !cur ? svg('M20 6L9 17l-5-5', { size: 12, stroke: '#fff', width: 2.6 }) : null) : null,
        ...COURSE_COLORS.map(([hex, name]) => h('button', {
          type: 'button', class: `bcv-swatch ${hex.toLowerCase() === cur ? 'is-current' : ''}`, title: name, 'aria-label': name, dataset: { color: hex }, style: { background: hex },
          onclick: () => { closeMenus(); onPick(hex); },
        }, hex.toLowerCase() === cur ? svg('M20 6L9 17l-5-5', { size: 12, stroke: '#fff', width: 2.6 }) : null)),
        h('label', { class: 'bcv-swatch bcv-swatch--custom', title: 'Custom colour' }, custom),
      ]),
    ]);
    m.addEventListener('click', (e) => e.stopPropagation());
    const r = anchor.getBoundingClientRect();
    const left = Math.max(8, Math.min(r.left, window.innerWidth - 230));
    // (it grows out of the dot that opened it, not from its own middle: bcv-pop scales from the origin)
    Object.assign(m.style, { position: 'fixed', top: `${r.bottom + 6}px`, left: `${left}px`, transformOrigin: `${Math.round(r.left + r.width / 2 - left)}px top` });
    overSheet(m, anchor);
    overlayRoot().append(m);
    setTimeout(() => document.addEventListener('click', closeMenus, { once: true }), 0);
    return m;
  }

  // ---- dates in the mockup's style ----------------------------------------------
  const DAY = 864e5;
  const startOfDay = (d) => {
    const x = new Date(d);
    x.setHours(0, 0, 0, 0);
    return x;
  };
  const addDays = (d, n) => {
    const x = new Date(d);
    x.setDate(x.getDate() + n);
    return x;
  };
  const sameDay = (a, b) => a && b && startOfDay(a).getTime() === startOfDay(b).getTime();
  const dayDiff = (d, now = new Date()) => Math.round((startOfDay(d) - startOfDay(now)) / DAY);
  /** Monday-start week (ISO), matching "Week of Sep 7". */
  const startOfWeek = (d) => {
    const x = startOfDay(d);
    const dow = (x.getDay() + 6) % 7;
    return addDays(x, -dow);
  };
  const parse = (v) => {
    if (!v) return null;
    const d = v instanceof Date ? v : new Date(v);
    return isNaN(d) ? null : d;
  };
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const MONTHS_LONG = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const DAYS_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  /** "11:59 PM" */
  function fmtTime(v) {
    const d = parse(v);
    if (!d) return '';
    let hr = d.getHours();
    const min = d.getMinutes();
    const ampm = hr >= 12 ? 'PM' : 'AM';
    hr = hr % 12 || 12;
    return `${hr}:${String(min).padStart(2, '0')} ${ampm}`;
  }
  /** "11:59pm" */
  const fmtTimeLower = (v) => fmtTime(v).replace(' ', '').toLowerCase();
  /** "Sep 10" */
  const fmtShort = (v) => {
    const d = parse(v);
    return d ? `${MONTHS[d.getMonth()]} ${d.getDate()}` : '';
  };
  /** "September 10" */
  const fmtLong = (v) => {
    const d = parse(v);
    return d ? `${MONTHS_LONG[d.getMonth()]} ${d.getDate()}` : '';
  };
  /** "Sep 1, 2026" */
  const fmtDateComma = (v) => {
    const d = parse(v);
    return d ? `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}` : '';
  };
  /** "Sep 10 at 11:59pm" */
  const fmtAt = (v) => {
    const d = parse(v);
    return d ? `${fmtShort(d)} at ${fmtTimeLower(d)}` : '';
  };
  /** "Sep 10 at 5:47 AM" */
  const fmtAtUpper = (v) => {
    const d = parse(v);
    return d ? `${fmtShort(d)} at ${fmtTime(d)}` : '';
  };
  /** "Sep 10 by 10:30am" (grades table) */
  const fmtBy = (v) => {
    const d = parse(v);
    return d ? `${fmtShort(d)} by ${fmtTimeLower(d)}` : '';
  };
  /** Day heading like the dashboard list: Today / Tomorrow / Sunday / Sep 21 */
  function dayTitle(v, now = new Date()) {
    const d = parse(v);
    if (!d) return 'No date';
    const diff = dayDiff(d, now);
    if (diff === 0) return 'Today';
    if (diff === 1) return 'Tomorrow';
    if (diff === -1) return 'Yesterday';
    if (diff > 1 && diff < 7) return DAYS_LONG[d.getDay()];
    return fmtShort(d);
  }
  /** "Thu, Sep 10" */
  const fmtDow = (v) => {
    const d = parse(v);
    return d ? `${DAYS[d.getDay()]}, ${fmtShort(d)}` : '';
  };
  /** Relative like "Friday", "modified Aug 26, 2026" helper */
  function fmtRecent(v, now = new Date()) {
    const d = parse(v);
    if (!d) return '';
    const diff = dayDiff(d, now);
    if (diff === 0) return 'today';
    if (diff === -1) return 'yesterday';
    if (diff < 0 && diff > -7) return DAYS_LONG[d.getDay()];
    return fmtDateComma(d);
  }
  /** Short "when" for list rows: today/tomorrow → time; within a week → weekday; else date */
  function whenShort(v, now = new Date()) {
    const d = parse(v);
    if (!d) return 'No date';
    const diff = dayDiff(d, now);
    if (diff === 0 || diff === 1) return fmtTime(d);
    if (diff > 1 && diff < 7) return DAYS[d.getDay()];
    return fmtShort(d);
  }
  function plural(n, one, many = `${one}s`) {
    return `${n} ${n === 1 ? one : many}`;
  }

  // ---- colours --------------------------------------------------------------------
  function hexToRgb(hex) {
    let s = String(hex || '').trim().replace(/^#/, '');
    if (s.length === 3) s = s.split('').map((c) => c + c).join('');
    if (!/^[0-9a-f]{6}$/i.test(s)) return null;
    const n = parseInt(s, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgbToHsl([r, g, b]) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let hh = 0, s = 0;
    const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) hh = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) hh = (b - r) / d + 2;
      else hh = (r - g) / d + 4;
      hh /= 6;
    }
    return [hh, s, l];
  }
  function hslToHex([hh, s, l]) {
    const f = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    let r, g, b;
    if (s === 0) r = g = b = l;
    else {
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = f(p, q, hh + 1 / 3); g = f(p, q, hh); b = f(p, q, hh - 1 / 3);
    }
    const c = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
    return `#${c(r)}${c(g)}${c(b)}`;
  }
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const rgba = (hex, a) => {
    const c = hexToRgb(hex);
    return c ? `rgba(${c[0]},${c[1]},${c[2]},${a})` : hex;
  };
  /** Text-legible variant of a course colour and its soft tint. */
  function palette(hex, dark) {
    const rgb = hexToRgb(hex);
    if (!rgb) return { text: dark ? '#c7c7cc' : '#3c3c43', tint: dark ? 'rgba(118,118,128,.28)' : 'rgba(118,118,128,.12)', raw: hex || '#8e8e93' };
    const [hh, s, l] = rgbToHsl(rgb);
    const textL = dark ? clamp(l + 0.16, 0.6, 0.82) : clamp(l - 0.19, 0.28, 0.46);
    const textS = dark ? clamp(s, 0.5, 1) : clamp(s, 0.45, 1);
    return { text: hslToHex([hh, textS, textL]), tint: rgba(hex, dark ? 0.2 : 0.14), raw: hex };
  }
  /** (2.99.128) A course's colour in Silent mode: its hue kept as a hint, most of its colour taken out — the courses'
   *  colours go quiet while what a colour means (late, done, a grade, a button) keeps its own. */
  function quiet(hex) {
    const rgb = hexToRgb(hex);
    if (!rgb) return hex;
    const [hh, s, l] = rgbToHsl(rgb);
    return hslToHex([hh, s * 0.28, clamp(l, 0.4, 0.62)]);
  }
  const FALLBACK_COLORS = ['#34c759', '#30b0c7', '#ff2d55', '#ff9500', '#c8901c', '#5856d6', '#0a84ff', '#6b5f7a', '#af52de', '#ff6b22'];

  /** Staggered entry (mockup 8/9): the element rises in after index × step ms, capped at
   *  420ms so a long list never crawls. A keyframe with a both fill; reduced motion drops it. */
  /** The word-mark's dot (the setup's and What's New's intro): placed where the word "Simpl" ends
   *  as this system's font draws it, and the drawing widened to hold it. */
  function placeDot(intro) {
    try {
      const svg = intro.querySelector('svg');
      const text = intro.querySelector('text');
      const dot = intro.querySelector('.intro__dot');
      if (!svg || !text || !dot) return;
      const b = text.getBBox();
      if (!(b.width > 0)) return;
      const cx = Math.round(b.x + b.width + 14);
      dot.setAttribute('cx', String(cx));
      dot.style.transformOrigin = `${cx}px 90px`;
      const w = Math.max(304, cx + 16);
      svg.setAttribute('viewBox', `0 0 ${w} 142`);
      svg.setAttribute('width', String(Math.round(w * (356 / 304))));
    } catch { /* the design's place */ }
  }

  // ---- a redraw is not an arrival ------------------------------------------------------------------
  // Entrances (the stagger below, the screen root's rise) belong to a screen arriving under the
  // student. A list drawn again because one row changed, or a screen drawn again silently because
  // the tab was away, must land in place, still: the same rows must not vanish and fade back in.
  // still(fn) runs fn — sync or async, nested as deep as it likes — with entrances off; enter() then
  // hands the node back untouched, and app.render({ quiet }) lands its root with bcv-screen--still.
  let stillDepth = 0;
  const isStill = () => stillDepth > 0;
  function still(fn) {
    stillDepth += 1;
    let out;
    try {
      out = fn();
    } catch (e) {
      stillDepth -= 1;
      throw e;
    }
    if (out && typeof out.then === 'function') return out.finally(() => { stillDepth -= 1; });
    stillDepth -= 1;
    return out;
  }

  function enter(node, i = 0, step = 55, dur = 380) {
    if (!node || isStill()) return node;
    node.classList.add('bcv-enter');
    node.style.setProperty('--bcv-delay', `${Math.min((i || 0) * step, 420)}ms`);
    if (dur !== 380) node.style.setProperty('--bcv-dur', `${dur}ms`);
    return node;
  }

  /** (2.99.80) Apple's continuous corner: the element drawn through a clip whose corners are the squircle iOS and macOS
   *  use — a corner that eases into its straight edges rather than meeting them at a circle's end — after Figma's
   *  reconstruction of it (corner smoothing 0.6 matches Apple's), at the element's own border radius. Kept to its size as
   *  it changes. */
  function squirclePath(w, h, r, smoothing = 0.6, ox = 0, oy = 0) {
    const budget = Math.min(w, h) / 2;
    r = Math.min(r, budget);
    if (!(r > 0) || !(w > 0) || !(h > 0)) return '';
    let p = (1 + smoothing) * r;
    if (p > budget) { smoothing = Math.max(0, Math.min(smoothing, budget / r - 1)); p = Math.min(p, budget); }
    const rad = (deg) => (deg * Math.PI) / 180;
    const arcMeasure = 90 * (1 - smoothing);
    const arc = Math.sin(rad(arcMeasure / 2)) * r * Math.SQRT2;
    const alpha = (90 - arcMeasure) / 2;
    const p3p4 = r * Math.tan(rad(alpha / 2));
    const beta = 45 * smoothing;
    const c = p3p4 * Math.cos(rad(beta));
    const d = c * Math.tan(rad(beta));
    const b = (p - arc - c - d) / 3;
    const a = 2 * b;
    const n = (v) => (Math.round(v * 1000) / 1000).toString();
    const ab = a + b, abc = a + b + c, bc = b + c;
    // (ox, oy: the path drawn that far in — a ring's inner edge)
    return [
      `M ${n(ox + w - p)} ${n(oy)}`,
      `c ${n(a)} 0 ${n(ab)} 0 ${n(abc)} ${n(d)}`, `a ${n(r)} ${n(r)} 0 0 1 ${n(arc)} ${n(arc)}`, `c ${n(d)} ${n(c)} ${n(d)} ${n(bc)} ${n(d)} ${n(abc)}`,
      `L ${n(ox + w)} ${n(oy + h - p)}`,
      `c 0 ${n(a)} 0 ${n(ab)} ${n(-d)} ${n(abc)}`, `a ${n(r)} ${n(r)} 0 0 1 ${n(-arc)} ${n(arc)}`, `c ${n(-c)} ${n(d)} ${n(-bc)} ${n(d)} ${n(-abc)} ${n(d)}`,
      `L ${n(ox + p)} ${n(oy + h)}`,
      `c ${n(-a)} 0 ${n(-ab)} 0 ${n(-abc)} ${n(-d)}`, `a ${n(r)} ${n(r)} 0 0 1 ${n(-arc)} ${n(-arc)}`, `c ${n(-d)} ${n(-c)} ${n(-d)} ${n(-bc)} ${n(-d)} ${n(-abc)}`,
      `L ${n(ox)} ${n(oy + p)}`,
      `c 0 ${n(-a)} 0 ${n(-ab)} ${n(d)} ${n(-abc)}`, `a ${n(r)} ${n(r)} 0 0 1 ${n(arc)} ${n(-arc)}`, `c ${n(c)} ${n(-d)} ${n(bc)} ${n(-d)} ${n(abc)} ${n(-d)}`,
      'Z',
    ].join(' ');
  }
  /** (2.99.84) A pill as Spotlight's field draws one: each end half a superellipse (|x/a|⁴ + |y/b|⁴ = 1) reaching in two
   *  thirds of the height, so the ends ease into the straight edges with no jump in curvature where a stadium's half-circles
   *  meet them. Drawn `ox, oy` in for a ring's inner edge. */
  function superPillPath(w, h, ox = 0, oy = 0) {
    if (!(w > 0) || !(h > 0)) return '';
    const b = h / 2, a = Math.min(h * 0.66, w / 2), N = 24;
    const n = (v) => (Math.round(v * 1000) / 1000).toString();
    const cy = oy + b, left = ox + a, right = ox + w - a;
    const pt = (cx, t) => { const c = Math.cos(t), sn = Math.sin(t); return `${n(cx + a * Math.sign(c) * Math.abs(c) ** 0.5)} ${n(cy + b * Math.sign(sn) * Math.abs(sn) ** 0.5)}`; };
    const out = [`M ${n(left)} ${n(oy)}`, `L ${n(right)} ${n(oy)}`];
    for (let i = 1; i <= N; i++) out.push(`L ${pt(right, -Math.PI / 2 + (Math.PI * i) / N)}`);
    out.push(`L ${n(left)} ${n(oy + h)}`);
    for (let i = 1; i <= N; i++) out.push(`L ${pt(left, Math.PI / 2 + (Math.PI * i) / N)}`);
    out.push('Z');
    return out.join(' ');
  }
  let squircleWatch = null;
  /** Fit an element's clip (and its ring's, where it has one) to its size now — at once, where a layout change must not
   *  wait a frame for the watcher. */
  function squircleFit(el) {
    const o = el._bcvSqOpt || {};
    const w = el.offsetWidth, h = el.offsetHeight;
    const r = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0;
    const key = `${w}x${h}x${r}`;
    if (el._bcvSq === key) return;
    el._bcvSq = key;
    const d = o.pill ? superPillPath(w, h) : squirclePath(w, h, r);
    el.style.clipPath = d ? `path('${d}')` : '';
    el.classList.toggle('bcv-squircle', !!d);
    // (a ring a pixel wide along the edge — the rim a border draws, which the clip would cut at the corners — as a picture
    //  for the background (--bcv-sq-ring): a background stays with the element's box while its content scrolls)
    if (o.ring) {
      const inner = o.pill ? superPillPath(w - 2, h - 2, 1, 1) : squirclePath(w - 2, h - 2, Math.max(0, r - 1), 0.6, 1, 1);
      const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}' viewBox='0 0 ${w} ${h}' preserveAspectRatio='none'><defs><linearGradient id='g' x1='0' y1='0' x2='.42' y2='1'><stop offset='0' stop-color='#fff' stop-opacity='.1'/><stop offset='.22' stop-color='#fff' stop-opacity='.03'/><stop offset='.48' stop-color='#fff' stop-opacity='.008'/><stop offset='.74' stop-color='#fff' stop-opacity='.015'/><stop offset='1' stop-color='#fff' stop-opacity='.06'/></linearGradient></defs><path fill='url(#g)' fill-rule='evenodd' d='${d} ${inner}'/></svg>`;
      el.style.setProperty('--bcv-sq-ring', d ? `url("data:image/svg+xml,${encodeURIComponent(svg)}")` : 'none');
    }
  }
  /** Draw an element through Apple's continuous corners, kept to its size; `pill`: Spotlight's superellipse pill instead;
   *  `ring`: its edge drawn again along the clip (class bcv-sqring). */
  function squircle(el, { pill = false, ring = false } = {}) {
    if (!el || typeof ResizeObserver === 'undefined') return el;
    el._bcvSqOpt = { pill, ring };
    el._bcvSq = '';
    if (ring) el.classList.add('bcv-sqring');
    if (!squircleWatch) squircleWatch = new ResizeObserver((entries) => { for (const e of entries) squircleFit(e.target); });
    squircleWatch.observe(el);
    return el;
  }

  /** (2.99.86) Every rounded rectangle of the app with Apple's continuous corners. Where the browser draws corner shapes
   *  itself (CSS corner-shape) a class asks for them, and borders, shadows and focus rings follow the corner; elsewhere
   *  (Safari) the element is drawn through a squircle clip (squircle above) — save where a clip would cut what shows
   *  outside it: a deep shadow (a popup, a menu), a fixed or sticky surface, or a clip of its own. Circles stay circles;
   *  a pill's ends become halves of a superellipse. Watched as the app draws: each element looked at once. */
  const CORNERS = (() => { try { return CSS.supports('corner-shape', 'superellipse(1.5)'); } catch { return false; } })();
  const seenSq = new WeakSet();
  let sqQueue = [], sqTimer = 0, sqWatch = null;
  // (2.99.90) not the tools in the bar either: each widget's panel grows out of its pin, inside the bar's capsule — a clip on
  // the capsule (Safari's way) cut the panel off, and the pins looked as if they did not open
  const SQ_SKIP = 'svg, svg *, img, video, canvas, iframe, math, math *, .bcv-prose *, .bcv-squircle, .bcv-nosq, .bcv-nosq *, #bcv-tray, #bcv-tray *';
  function squircleOne(el) {
    if (seenSq.has(el) || !el.isConnected) return;
    if (el.matches(SQ_SKIP)) { seenSq.add(el); return; }
    const w = el.offsetWidth, hh = el.offsetHeight;
    if (!w || !hh) return; // (not laid out yet: looked at again when it next changes)
    seenSq.add(el);
    const cs = getComputedStyle(el);
    if (cs.display === 'inline') return;
    const r = parseFloat(cs.borderTopLeftRadius) || 0;
    if (r < 4) return;
    // (a corner rounded on one side only — a group's first row, a tab — keeps its own shape)
    if (cs.borderTopRightRadius !== cs.borderTopLeftRadius || cs.borderBottomLeftRadius !== cs.borderTopLeftRadius || cs.borderBottomRightRadius !== cs.borderTopLeftRadius) return;
    const round = Math.min(w, hh) / 2;
    if (Math.abs(w - hh) <= 1 && r >= round - 0.5) return; // (a circle stays a circle)
    if (CORNERS) { el.classList.add('bcv-sqc'); return; } // (the element's own radius kept: what lays itself out by it still can)
    if (cs.clipPath && cs.clipPath !== 'none') return;
    if (cs.position === 'fixed' || cs.position === 'sticky') return;
    const deep = /(\d+(?:\.\d+)?)px\s+(\d+(?:\.\d+)?)px\s+(\d+(?:\.\d+)?)px/g;
    let m, shadow = 0;
    const outer = cs.boxShadow.split(/,(?![^(]*\))/).filter((s) => !/inset/.test(s)).join(',');
    while ((m = deep.exec(outer))) shadow = Math.max(shadow, parseFloat(m[3]) + Math.abs(parseFloat(m[2])));
    if (shadow > 6) return;
    squircle(el, { pill: r >= hh / 2 - 0.5 && w > hh });
  }
  // (looked at a little at a time, when the page is idle — never a long run of style reads in the middle of a motion)
  let sqPending = [];
  const sqIdle = self.requestIdleCallback ? (f) => self.requestIdleCallback(f, { timeout: 600 }) : (f) => setTimeout(() => f({ timeRemaining: () => 6, didTimeout: false }), 80);
  function squircleSweep(deadline) {
    sqTimer = 0;
    // (nothing looked at while something moves: a style read mid-transition can hold up its frames)
    if (document.getAnimations?.().some((a) => a.playState === 'running')) { sqTimer = setTimeout(() => { sqTimer = sqIdle(squircleSweep); }, 300); return; }
    for (const root of sqQueue.splice(0)) {
      if (!root.isConnected) continue;
      sqPending.push(root, ...root.querySelectorAll('[class]'));
    }
    let i = 0;
    while (i < sqPending.length && (deadline.timeRemaining() > 2 || (deadline.didTimeout && i < 40))) squircleOne(sqPending[i++]);
    sqPending = sqPending.slice(i);
    if (sqPending.length) sqTimer = sqIdle(squircleSweep);
  }
  const squircleSoon = (root) => {
    sqQueue.push(root);
    if (!sqTimer) sqTimer = sqIdle(squircleSweep);
  };
  /** Start watching: the app's root and what is drawn over it (sheets, menus, previews, the search afloat). */
  function squircleAll() {
    if (sqWatch || typeof MutationObserver === 'undefined') return;
    document.documentElement.classList.toggle('bcv-sq-css', CORNERS);
    sqWatch = new MutationObserver((records) => {
      for (const rec of records) for (const n of rec.addedNodes) if (n.nodeType === 1 && (n.id?.startsWith('bcv') || String(n.className?.baseVal ?? n.className ?? '').includes('bcv'))) squircleSoon(n);
    });
    sqWatch.observe(document.body, { childList: true, subtree: true });
    const app = document.getElementById('bcv-app');
    if (app) squircleSoon(app);
  }

  const initials = (name) => String(name || '').trim().split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || '').join('');

  const reducedMotion = () => {
    try {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch {
      return false;
    }
  };

  /** A list drawn again with one thing changed — a row ticked off, dismissed, added: what stays slides
   *  from where it was to where it now sits (200 ms, ease-out) instead of jumping. Rows and the groups
   *  holding them carry `data-flip` keys; a row moves by what is left after its group's own move, so a
   *  parent and its child never carry the same distance. Only `translate` moves; reduced motion: none. */
  function flipList(root, draw) {
    if (!root || reducedMotion()) return draw();
    const keyed = () => [...root.querySelectorAll('[data-flip]')];
    const before = new Map(keyed().map((el) => [el.dataset.flip, el.getBoundingClientRect().top]));
    const out = draw();
    const now = keyed();
    const top = new Map(now.map((el) => [el, el.getBoundingClientRect().top]));
    const shift = (el) => {
      const was = before.get(el.dataset.flip);
      return was === undefined ? 0 : was - top.get(el);
    };
    const ease = getComputedStyle(document.documentElement).getPropertyValue('--bcv-ease-out').trim() || 'cubic-bezier(.23,1,.32,1)';
    for (const el of now) {
      if (!before.has(el.dataset.flip)) continue; // (new here: it rides in with its group)
      const host = el.parentElement?.closest('[data-flip]');
      const dy = shift(el) - (host && top.has(host) ? shift(host) : 0);
      if (Math.abs(dy) >= 0.5) {
        try { el.animate([{ translate: `0 ${dy}px` }, { translate: '0 0' }], { duration: 200, easing: ease }); } catch { /* lands where it is */ }
      }
    }
    return out;
  }

  /** The success tick (a hand-in, a finished quiz): drawn in once, the first time it shows — its disc
   *  settles from 0.9 and the stroke draws over 400 ms (a rare moment, allowed its delight). A redraw,
   *  or a second showing, has it there already; reduced motion keeps only the fade (app.css). */
  function drawCheck(el, fresh = true) {
    if (!el || !fresh || isStill()) return el;
    for (const p of el.querySelectorAll('path')) p.setAttribute('pathLength', '1');
    el.classList.add('bcv-check--draw');
    return el;
  }

  /** What a disclosure opens, sliding open and shut rather than jumping: the course modules' collapsing
   *  grid row (0fr → 1fr takes the content's own height, nothing measured), the content fading in as it
   *  opens and out as it shuts (app.css .bcv-collapsible). Transitions, so a second press turns it round
   *  from wherever it has got to. Shut, the content is inert: out of the tab order and the accessibility
   *  tree, as [hidden] had it. Returns the wrapper; wrapper.setOpen(on) opens or shuts it. */
  function collapsible(content, open = false, cls = '') {
    const inner = el('bcv-collapsible__in', content);
    const wrap = el(`bcv-collapsible ${cls} ${open ? 'is-open' : ''}`, inner);
    inner.inert = !open;
    wrap.setOpen = (on) => { wrap.classList.toggle('is-open', on); inner.inert = !on; };
    return wrap;
  }

  /** Screen pixels per CSS pixel (a zoom, a scaled display), for a canvas drawn to be crisp: capped
   *  at 3, where a sharper drawing costs memory and shows nothing more. */
  const dpr = () => Math.min(3, Math.max(0.25, self.devicePixelRatio || 1));
  /** Calls fn whenever that changes — the page zoomed, or the window moved to another screen — until
   *  the returned function is called. */
  function onDprChange(fn) {
    let mq = null, gone = false;
    const arm = () => {
      if (gone) return;
      try { mq = matchMedia(`(resolution: ${self.devicePixelRatio || 1}dppx)`); mq.addEventListener('change', fire, { once: true }); } catch { mq = null; }
    };
    const fire = () => { if (gone) return; arm(); try { fn(dpr()); } catch { /* the caller's own */ } };
    arm();
    return () => { gone = true; try { mq?.removeEventListener('change', fire); } catch { /* gone */ } };
  }

  /** A number arrives rather than appears (mockup 11): 16 steps at 52ms — plausible digits
   *  below step 9 (under half a second), convergence above it — and the last step is always
   *  the exact value. Entry only: callers never roll a number the student is already reading.
   *  Reduced motion jumps straight to the final step. */
  const ROLL_STEPS = 16;
  const ROLL_MS = 52;
  function roll(node, target, { decimals = 0, seed = 0, format = null } = {}) {
    const fmt = format || ((v) => (decimals ? v.toFixed(decimals) : String(Math.round(v))));
    const finish = () => {
      clearInterval(node._bcvRoll);
      node._bcvRoll = null;
      node.textContent = fmt(target);
      delete node.dataset.rolling;
    };
    if (node._bcvRoll) clearInterval(node._bcvRoll);
    if (!Number.isFinite(target) || reducedMotion() || isStill()) { // (a number drawn again in place is already the student's: never scrambled)
      finish();
      return node;
    }
    const at = (n) => {
      if (n < 9) return decimals ? Math.abs(Math.sin(n * 1.9 + seed)) * Math.max(target, 1) : 1 + Math.floor(Math.abs(Math.sin(n * 1.7 + seed)) * Math.max(target, 4));
      const p = (n - 9) / (ROLL_STEPS - 9);
      return decimals ? target * (0.65 + 0.35 * p) : Math.max(0, Math.round(target * (0.6 + 0.4 * p)));
    };
    let n = 0;
    node.dataset.rolling = '1';
    node.textContent = fmt(at(0));
    node._bcvRoll = setInterval(() => {
      n += 1;
      if (n >= ROLL_STEPS || !node.isConnected) { // never a fabricated digit left behind: the last step is the real value
        finish();
        return;
      }
      node.textContent = fmt(at(n));
    }, ROLL_MS);
    return node;
  }

  /** A sheet grows out of the control that opened it (mockup 11): its transform origin is
   *  the anchor's centre, measured against the sheet's laid-out box (transforms aside, so
   *  the running animation does not skew the measurement). No anchor: from the centre. */
  function morphFrom(sheet, from) {
    if (!sheet) return sheet;
    const anchor = from && from.currentTarget ? from.currentTarget : from;
    let r = null;
    try {
      r = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
    } catch {
      r = null;
    }
    if (!r || !r.width) return sheet;
    const ov = sheet.offsetParent;
    const box = ov ? ov.getBoundingClientRect() : { left: 0, top: 0 };
    const x = r.left + r.width / 2 - (box.left + sheet.offsetLeft);
    const y = r.top + r.height / 2 - (box.top + sheet.offsetTop);
    sheet.style.transformOrigin = `${Math.round(x)}px ${Math.round(y)}px`;
    return sheet;
  }

  // ---- a date field and its calendar (after the date helpers it uses) ----
  /** A day the way people say it: "Today · Fri, Sep 11", "Tomorrow · Sat, Sep 12", "Fri, Sep 18", "Fri, Jan 8, 2027". */
  function fmtDay(v, now = new Date()) {
    const d = parse(v);
    if (!d) return 'No date';
    const diff = dayDiff(d, now);
    if (diff === 0) return `Today · ${fmtDow(d)}`;
    if (diff === 1) return `Tomorrow · ${fmtDow(d)}`;
    if (d.getFullYear() !== now.getFullYear()) return `${DAYS[d.getDay()]}, ${fmtDateComma(d)}`;
    return fmtDow(d);
  }
  /** A calendar popover under `anchor`: a month grid (today marked, the chosen day filled), ‹ › for
   *  the months, Today / Tomorrow / Next Monday shortcuts. Picking a day closes it and calls onPick(date). */
  function datePop(at, value, onPick) {
    closeMenus();
    const now = new Date();
    const sel = parse(value) ? startOfDay(parse(value)) : null;
    let month = new Date((sel || now).getFullYear(), (sel || now).getMonth(), 1);
    const m = el('bcv-menu bcv-datepop', null, { role: 'dialog', 'aria-label': 'Pick a date' });
    m.addEventListener('click', (e) => e.stopPropagation()); // moving months keeps it open
    const pick = (d) => { closeMenus(); onPick(startOfDay(d)); };
    const nextMonday = addDays(now, ((8 - now.getDay()) % 7) || 7);
    function draw() {
      const start = addDays(month, -month.getDay());
      const cells = [];
      for (let i = 0; i < 42; i++) {
        const d = addDays(start, i);
        const off = d.getMonth() !== month.getMonth();
        const today = sameDay(d, now);
        const on = !!sel && sameDay(d, sel);
        cells.push(h('button', { type: 'button', class: `bcv-datepop__day ${off ? 'is-off' : ''} ${today ? 'is-today' : ''} ${on ? 'is-on' : ''}`, text: String(d.getDate()), 'aria-label': `${DAYS_LONG[d.getDay()]}, ${fmtLong(d)}`, 'aria-pressed': on ? 'true' : 'false', onclick: () => pick(d) }));
      }
      m.replaceChildren(
        el('bcv-datepop__head', [
          h('button', { type: 'button', class: 'bcv-datepop__nav', 'aria-label': 'Previous month', onclick: () => { month = new Date(month.getFullYear(), month.getMonth() - 1, 1); draw(); } }, svg('M15 5l-7 7 7 7', { size: 14, width: 2.2 })),
          text('bcv-datepop__month', `${MONTHS_LONG[month.getMonth()]}${month.getFullYear() !== now.getFullYear() ? ` ${month.getFullYear()}` : ''}`, 'span'),
          h('button', { type: 'button', class: 'bcv-datepop__nav', 'aria-label': 'Next month', onclick: () => { month = new Date(month.getFullYear(), month.getMonth() + 1, 1); draw(); } }, svg('M9 6l6 6-6 6', { size: 14, width: 2.2 })),
        ]),
        el('bcv-datepop__dows', DAYS.map((x) => text('bcv-datepop__dow', x[0], 'span'))),
        el('bcv-datepop__grid', cells),
        el('bcv-datepop__quick', [
          h('button', { type: 'button', class: 'bcv-datepop__q', text: 'Today', onclick: () => pick(now) }),
          h('button', { type: 'button', class: 'bcv-datepop__q', text: 'Tomorrow', onclick: () => pick(addDays(now, 1)) }),
          h('button', { type: 'button', class: 'bcv-datepop__q', text: 'Next Monday', onclick: () => pick(nextMonday) }),
        ]),
      );
    }
    draw();
    overlayRoot().append(m);
    anchor(m, at, { side: 'below' }); // (under the field, or above it when the room is above; on screen either way)
    m.style.maxHeight = ''; // (a calendar is not a list: it is never cut, it moves)
    setTimeout(() => document.addEventListener('click', closeMenus, { once: true }), 0);
    m.querySelector('.bcv-datepop__day.is-on, .bcv-datepop__day.is-today')?.focus();
    return m;
  }
  /** A date field: a calendar glyph, the day as people say it, a chevron; a tap opens the calendar. */
  function dateField(value, onChange, { cls = '', label = 'Due date' } = {}) {
    let cur = parse(value) ? startOfDay(parse(value)) : null;
    const lbl = text('bcv-date__label bcv-ellip', fmtDay(cur), 'span');
    const b = h('button', { type: 'button', class: `bcv-date ${cls}`, 'aria-label': label, 'aria-haspopup': 'dialog' }, [
      svg(IC.cal, { size: 14, stroke: 'var(--bcv-blue)', width: 1.9 }),
      lbl,
      svg('M6 9l6 6 6-6', { size: 12, stroke: 'var(--bcv-ink3)', width: 2.2, cls: 'bcv-date__chev' }),
    ]);
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      datePop(b, cur, (d) => { cur = d; lbl.textContent = fmtDay(d); onChange(d); });
    });
    return b;
  }
  /** A small sheet with one text field: a title, a note, the field, Save (and an optional clear
   *  action, which saves an empty value). onSave may throw: the sheet stays and says why. */
  function promptSheet({ label = '', title, note = '', value = '', placeholder = '', maxLength = 120, saveLabel = 'Save', clearLabel = null, onSave, from = null }) {
    document.querySelector('.bcv-sheet-ov')?.remove();
    const ov = el('bcv-sheet-ov', null, { role: 'dialog', 'aria-label': label || title });
    const close = () => dismiss(ov);
    ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
    ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const input = h('input', { class: 'bcv-input bcv-prompt__input', type: 'text', value, placeholder, maxlength: String(maxLength), 'aria-label': title });
    let busy = false;
    let saveBtn = null;
    const save = async (v) => {
      if (busy) return;
      busy = true;
      saveBtn.disabled = true;
      try {
        await onSave(v);
        close();
      } catch (e) {
        busy = false;
        saveBtn.disabled = false;
        toast(`Could not save: ${e?.message || e}`, { error: true });
      }
    };
    saveBtn = btn(saveLabel, { kind: 'primary', cls: 'bcv-prompt__save', onClick: () => save(input.value.trim()) });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') save(input.value.trim()); });
    ov.append(el('bcv-sheet bcv-sheet--prompt', [
      el('bcv-sheet__head', [
        el('bcv-sheet__titles', [text('bcv-sheet__title', title), note ? text('bcv-sheet__note bcv-pretty', note) : null]),
        h('button', { type: 'button', class: 'bcv-sheet__close', 'aria-label': 'Close', onclick: close }, svg(IC.close, { size: 13, stroke: 'var(--bcv-ink2)', width: 2.3 })),
      ]),
      el('bcv-prompt', [
        input,
        el('bcv-prompt__btns', [
          clearLabel ? btn(clearLabel, { kind: 'danger', cls: 'bcv-prompt__clear', onClick: () => save('') }) : null,
          h('span', { style: { flex: '1' } }),
          btn('Cancel', { onClick: close }),
          saveBtn,
        ]),
      ]),
    ]));
    overlayRoot().append(ov);
    if (from) morphFrom(ov.firstElementChild, from);
    ov.tabIndex = -1;
    setTimeout(() => { input.focus(); input.select(); }, 30);
    return { close, input };
  }

  /** A question with two answers, or a note with one (cancelLabel null): resolves true for the main
   *  button, false for Cancel, Escape, the scrim or the X. */
  function askSheet(o = {}) {
    // in the iPhone app, the phone's own alert (a destructive answer in red, as iOS draws it); the
    // drawn sheet should the app not answer
    const nat = nativeUi();
    const { title, note = '', okLabel = 'OK', cancelLabel = 'Cancel', danger = false } = o;
    if (nat?.ask) return nat.ask({ title, note, okLabel, cancelLabel, danger }).catch(() => webAsk(o));
    return webAsk(o);
  }
  function webAsk({ label = '', title, note = '', okLabel = 'OK', cancelLabel = 'Cancel', danger = false, from = null } = {}) {
    // A question asked from inside another sheet — the hand-in box asking whether to convert a file —
    // rises over it rather than taking its place: the sheet below steps back (is-under, as it does
    // under a tool's popup) and comes forward again, with the focus, once the question is answered.
    // An earlier question still up is replaced.
    document.querySelector('.bcv-sheet-ov.bcv-ask-ov')?.remove();
    const under = document.querySelector('.bcv-sheet-ov:not(.is-under)');
    under?.classList.add('is-under');
    return new Promise((resolve) => {
      const ov = el('bcv-sheet-ov bcv-ask-ov', null, { role: 'dialog', 'aria-label': label || title });
      let settled = false;
      const done = (v) => {
        if (settled) return;
        settled = true;
        dismiss(ov);
        if (under?.isConnected) { under.classList.remove('is-under'); under.focus?.({ preventScroll: true }); }
        resolve(v);
      };
      ov.addEventListener('click', (e) => { if (e.target === ov) done(false); });
      ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.stopPropagation(); done(false); } });
      const ok = btn(okLabel, { kind: danger ? 'dangerSolid' : 'primary', cls: 'bcv-ask__ok', onClick: () => done(true) });
      ov.append(el('bcv-sheet bcv-sheet--prompt bcv-sheet--ask', [
        el('bcv-sheet__head', [
          el('bcv-sheet__titles', [text('bcv-sheet__title bcv-pretty', title)]),
          h('button', { type: 'button', class: 'bcv-sheet__close', 'aria-label': 'Close', onclick: () => done(false) }, svg(IC.close, { size: 13, stroke: 'var(--bcv-ink2)', width: 2.3 })),
        ]),
        el('bcv-prompt bcv-ask', [
          note ? text('bcv-ask__note bcv-pretty', note) : null,
          el('bcv-prompt__btns', [h('span', { style: { flex: '1' } }), cancelLabel ? btn(cancelLabel, { cls: 'bcv-ask__cancel', onClick: () => done(false) }) : null, ok]),
        ]),
      ]));
      overlayRoot().append(ov);
      if (from) morphFrom(ov.firstElementChild, from);
      ov.tabIndex = -1;
      setTimeout(() => ok.focus(), 30);
    });
  }

  /** A grade group picked by a press (the course's Grades tab, the Grades page's details): every
   *  element under `root` with a data-group names the group it belongs to, and pressing one with a
   *  data-pick picks that group — pressing it again, one with an empty data-pick, or Escape lets it
   *  go. The picked group's elements are marked is-picked, the rest is-dim, the root has-pick.
   *  `st.pick` keeps the choice across redraws: call apply() after each. Nothing is redrawn. */
  function groupPicker(root, st, { onChange = null } = {}) {
    const apply = () => {
      const pick = st.pick || null;
      root.classList.toggle('has-pick', !!pick);
      for (const e of root.querySelectorAll('[data-group]')) {
        const on = !!pick && e.dataset.group === pick;
        e.classList.toggle('is-picked', on);
        e.classList.toggle('is-dim', !!pick && !on);
        if (e.hasAttribute('data-pick') && e.dataset.pick) e.setAttribute('aria-pressed', on ? 'true' : 'false');
      }
      onChange?.(pick);
    };
    const toggle = (id) => { st.pick = !id || st.pick === id ? null : id; apply(); };
    const pickOf = (e) => { const t = e.target?.closest?.('[data-pick]'); return t && root.contains(t) ? t : null; };
    root.addEventListener('click', (e) => { const t = pickOf(e); if (!t) return; e.preventDefault(); e.stopPropagation(); toggle(t.dataset.pick); });
    root.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && st.pick) { e.stopPropagation(); toggle(null); return; }
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const t = pickOf(e);
      if (!t || t.tagName === 'BUTTON') return; // (a button presses itself)
      e.preventDefault();
      toggle(t.dataset.pick);
    });
    return { apply, toggle };
  }
  /** The attributes that make an element one of a grade group's (see groupPicker): `pick` makes a
   *  press on it pick the group, with its name for the reader. */
  function groupAttrs(id, color, { pick = false, name = '' } = {}) {
    const a = { 'data-group': String(id), style: { '--bcv-grp': color || 'var(--bcv-ink3)' } };
    if (pick) Object.assign(a, { 'data-pick': String(id), role: 'button', tabindex: '0', 'aria-pressed': 'false', title: name ? `Show what counts toward ${name}` : null });
    return a;
  }

  /* ---- graded work by letter (the Grades tab, the Grades page and its Details) ---------------------
   * An item's letter is the base letter of the Grades page's scale (gpa.js SCALE: A from 90%, B from
   * 80%, C from 70%, D from 60%, F under) for its score over its points. Work with no score, no
   * points or no letter to give (pass/fail, not graded) has none. */
  const BANDS = ['A', 'B', 'C', 'D', 'F'];
  function gradeBand(score, possible, gradingType = null) {
    if (score === null || score === undefined || !(Number(possible) > 0) || gradingType === 'pass_fail' || gradingType === 'not_graded') return null;
    const pct = (Number(score) / Number(possible)) * 100;
    if (!Number.isFinite(pct)) return null;
    const letter = BCV.screens?.gpa?.letterFor?.(pct)?.[0] || (pct >= 90 ? 'A' : pct >= 80 ? 'B' : pct >= 70 ? 'C' : pct >= 60 ? 'D' : 'F');
    return letter[0];
  }
  /** An item's letter, a small tag in the band's colour (an empty one keeps the column when there is none). */
  function bandChip(band, title = null) {
    return h('span', { class: `bcv-bandchip ${band ? `bcv-band--${band}` : 'is-empty'}`, text: band || '', title: band ? title : null, 'aria-hidden': band ? null : 'true' });
  }
  /** The slider: All · A · B · C · D · F, each stop with how many items it holds. Pressed, dragged
   *  across, or moved with the arrow keys; onChange(band) with 'all' or a letter. */
  function bandSlider(counts, value, onChange, { label = 'Show grades by letter' } = {}) {
    const total = BANDS.reduce((n, b) => n + (counts[b] || 0), 0);
    const stops = [['all', 'All', total], ...BANDS.map((b) => [b, b, counts[b] || 0])];
    const wrap = el('bcv-bands', null, { role: 'radiogroup', 'aria-label': label });
    wrap.append(h('span', { class: 'bcv-bands__thumb', 'aria-hidden': 'true' }));
    const btns = stops.map(([key, text, n]) => h('button', {
      type: 'button', role: 'radio', class: `bcv-bands__stop bcv-band--${key} ${n ? '' : 'is-none'}`, dataset: { band: key },
      'aria-label': `${key === 'all' ? 'All grades' : `${key} grades`}: ${n}`,
      onclick: () => { if (key !== value) set(key, true); },
    }, [h('span', { class: 'bcv-bands__l', text }), h('span', { class: 'bcv-bands__n', text: String(n) })]));
    wrap.append(...btns);
    function set(key, fire) {
      const i = Math.max(0, stops.findIndex((st) => st[0] === key));
      value = stops[i][0];
      wrap.style.setProperty('--i', String(i));
      wrap.dataset.band = value;
      btns.forEach((b, j) => { b.classList.toggle('is-active', j === i); b.setAttribute('aria-checked', j === i ? 'true' : 'false'); b.tabIndex = j === i ? 0 : -1; });
      if (fire) onChange(value);
    }
    // a slider: pressed anywhere along it, or dragged across it, it takes the stop under the pointer
    const stopAt = (x) => { const r = wrap.getBoundingClientRect(); return stops[Math.max(0, Math.min(stops.length - 1, Math.floor(((x - r.left) / r.width) * stops.length)))][0]; };
    let drag = false;
    wrap.addEventListener('pointerdown', (e) => { if (e.button !== 0) return; drag = true; try { wrap.setPointerCapture(e.pointerId); } catch {} const k = stopAt(e.clientX); if (k !== value) set(k, true); });
    wrap.addEventListener('pointermove', (e) => { if (!drag) return; const k = stopAt(e.clientX); if (k !== value) set(k, true); });
    const end = () => { if (!drag) return; drag = false; btns.find((b) => b.dataset.band === value)?.focus({ preventScroll: true }); };
    wrap.addEventListener('pointerup', end);
    wrap.addEventListener('pointercancel', end);
    wrap.addEventListener('keydown', (e) => {
      const i = stops.findIndex((st) => st[0] === value);
      const to = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? i + 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? i - 1 : e.key === 'Home' ? 0 : e.key === 'End' ? stops.length - 1 : null;
      if (to === null) return;
      e.preventDefault();
      const k = stops[Math.max(0, Math.min(stops.length - 1, to))][0];
      if (k !== value) set(k, true);
      btns.find((b) => b.dataset.band === value)?.focus();
    });
    set(value, false);
    return wrap;
  }

  /** What-if mode's "add an assignment": a piece of work made up to test, put in one of the course's
   *  groups (the categories its grade is weighted by), with a score out of its points. It counts in
   *  that group like any scored work there — its weight, its drop rules — and nothing leaves the page:
   *  onAdd({ groupId, name, score, possible }). `groups`: [{ id, name, weight }]; `group` the one
   *  chosen first (the last one used, or the group picked out); onGroup(id) as the choice changes. */
  function whatIfAdder(groups, { group = null, weighted = false, n = 1, onAdd, onGroup = null } = {}) {
    const label = (g) => (weighted ? `${g.name} · ${g.weight}%` : g.name);
    const sel = h('select', { class: 'bcv-select bcv-wfadd__group', 'aria-label': 'Category' }, groups.map((g) => h('option', { value: g.id, text: label(g) })));
    if (group !== null && groups.some((g) => g.id === String(group))) sel.value = String(group);
    const fallback = `What-if ${n}`;
    const name = h('input', { type: 'text', class: 'bcv-input bcv-wfadd__name', placeholder: fallback, maxlength: '80', 'aria-label': 'Assignment name' });
    const score = h('input', { type: 'text', inputmode: 'decimal', class: 'bcv-input bcv-wfadd__num', placeholder: 'Score', 'aria-label': 'Score' });
    const possible = h('input', { type: 'text', inputmode: 'decimal', class: 'bcv-input bcv-wfadd__num', value: '100', 'aria-label': 'Points possible' });
    const note = text('bcv-wfadd__note', '');
    const describe = () => {
      const g = groups.find((x) => x.id === sel.value);
      note.classList.remove('is-err');
      note.textContent = !g ? '' : weighted ? (g.weight ? `Counts in ${g.name}, ${g.weight}% of the grade.` : `Counts in ${g.name}, which carries no weight.`) : `Counts in ${g.name}, by its points.`;
    };
    const num = (f) => { const v = String(f.value).replace(/[^0-9.]/g, ''); const x = v === '' ? NaN : Number(v); return Number.isFinite(x) ? x : NaN; };
    const say = (msg, f) => { note.textContent = msg; note.classList.add('is-err'); f.focus(); };
    const add = () => {
      const p = num(possible), sc = num(score);
      if (!(p > 0)) { say('Give it the points it is out of.', possible); return; }
      if (!(sc >= 0)) { say('Give it a score to test.', score); return; }
      onAdd({ groupId: sel.value, name: name.value.trim() || fallback, score: sc, possible: p });
    };
    sel.addEventListener('change', () => { describe(); onGroup?.(sel.value); });
    for (const f of [name, score, possible]) f.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
    describe();
    return el('bcv-wfadd', [
      text('bcv-wfadd__h', 'Add a what-if assignment'),
      el('bcv-wfadd__row', [
        sel, name,
        el('bcv-wfadd__pts', [score, text('bcv-wfadd__of', '/', 'span'), possible, text('bcv-wfadd__of', 'pts', 'span')]),
        btn('Add', { kind: 'primary', icon: IC.plus, iconColor: '#fff', cls: 'bcv-wfadd__add', onClick: add }),
      ]),
      note,
    ]);
  }
  /** The X on a what-if assignment's row: it goes, and the grade with it (the row's own press is not a press on this). */
  const whatIfRemove = (name, onRemove) => h('button', {
    type: 'button', class: 'bcv-wfadd__rm', 'aria-label': `Remove ${name}`, title: 'Remove this what-if assignment',
    onclick: (e) => { e.preventDefault(); e.stopPropagation(); onRemove(); },
  }, svg(IC.close, { size: 11, stroke: 'currentColor', width: 2.4 }));

  // ---- the page holds still behind anything that asks for attention --------------------------------
  // A sheet, a counter's box, the mark box, the rubric ring, a tool, the viewer, the reader, the search
  // afloat: while one is up the wheel and the scroll keys move nothing behind it. Its own scrolling parts
  // still scroll, and do not hand the scroll on to the page when they reach an end. The page's scrollbar is
  // left where it is (hiding it would widen the page under the overlay); a phone's page is simply switched
  // off in the stylesheet. The listeners are there only while something is up — a wheel listener that can
  // cancel holds every wheel scroll for the page's script.
  const ATTENTION = 'body > :is(.bcv-sheet-ov:not(.is-closing):not(.is-folding), .bcv-spot-ov:not(.is-folding))';
  const SCROLL_KEYS = { ' ': 1, PageDown: 1, PageUp: -1, End: 1, Home: -1, ArrowDown: 1, ArrowUp: -1 };
  /** Whether something other than the page, from `from` outwards, can still scroll that way. */
  function movesInside(from, dy, dx) {
    for (let el = from; el && el !== document.body && el !== document.documentElement; el = el.parentElement) {
      if (el.id === 'bcv-app' || el.id === 'bcv-bar') return false; // (the page itself: held)
      const cs = getComputedStyle(el);
      if (dy && /(auto|scroll)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 1 && (dy > 0 ? el.scrollTop + el.clientHeight < el.scrollHeight - 1 : el.scrollTop > 0)) return true;
      if (dx && /(auto|scroll)/.test(cs.overflowX) && el.scrollWidth > el.clientWidth + 1 && (dx > 0 ? el.scrollLeft + el.clientWidth < el.scrollWidth - 1 : el.scrollLeft > 0)) return true;
    }
    return false;
  }
  const holdWheel = (e) => {
    if (e.ctrlKey) return; // (a pinch is a zoom)
    if (!movesInside(e.target instanceof Element ? e.target : null, Math.sign(e.deltaY), Math.sign(e.deltaX))) e.preventDefault();
  };
  const holdKeys = (e) => {
    if (e.defaultPrevented || e.altKey || e.metaKey || e.ctrlKey) return;
    const d = SCROLL_KEYS[e.key];
    if (!d || e.target?.closest?.('input, textarea, select, button, a, [contenteditable], [role="button"], [role="listbox"], [role="slider"], [role="tab"]')) return;
    const from = document.activeElement && document.activeElement !== document.body ? document.activeElement : null;
    if (!movesInside(from, e.key === ' ' && e.shiftKey ? -1 : d, 0)) e.preventDefault();
  };
  let holding = false;
  const holdSync = () => {
    const on = !document.documentElement.classList.contains('bcv-phone') && !!document.querySelector(ATTENTION);
    if (on === holding) return;
    holding = on;
    if (on) { addEventListener('wheel', holdWheel, { passive: false }); addEventListener('keydown', holdKeys); } else { removeEventListener('wheel', holdWheel); removeEventListener('keydown', holdKeys); }
  };
  if (document.body) new MutationObserver(holdSync).observe(document.body, { childList: true }); // (the body's own children only: overlays come and go there)

  // ---- a box that opens on a hover (the mark box 2.98.64, the Dashboard's counters 2.98.97) ----------
  /** The button opens its box on a hover too, where there is a mouse: after a moment's rest on it (a
   *  pointer passing over does nothing), never while another box is up or a tour runs (its steps wait
   *  for a press), and not again under a pointer that has not moved since the box folded back into it
   *  (it must leave the button first: hoverCool). A press still opens at once. */
  const HOVER_MS = 420;
  const canHover = () => !BCV.phone?.active?.() && !!self.matchMedia?.('(hover: hover) and (pointer: fine)').matches;
  const hoverBlocked = () => !!document.querySelector('.bcv-sheet-ov, #bcv-tour');
  // Only a mouse that moved counts: a button drawn under a pointer that is resting (the Dashboard
  // painting its counters where the pointer happens to be) is "entered" too, and must not open.
  let mouseAt = null, movedAt = -Infinity; // (never "just moved" before a move: a page painted within its first moments is not a hover)
  addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse' || (mouseAt && mouseAt.x === e.clientX && mouseAt.y === e.clientY)) return;
    mouseAt = { x: e.clientX, y: e.clientY };
    movedAt = performance.now();
  }, { passive: true, capture: true });
  const justMoved = () => performance.now() - movedAt < 120;
  function hoverOpens(btn, open) {
    let t = 0;
    const can = (e) => e.pointerType === 'mouse' && canHover() && !btn.dataset.bcvHoverCool && !hoverBlocked();
    const arm = () => {
      clearTimeout(t);
      t = setTimeout(() => { t = 0; if (btn.isConnected && btn.matches(':hover') && !hoverBlocked()) open(btn); }, HOVER_MS);
    };
    btn.addEventListener('pointerenter', (e) => { if (can(e) && justMoved()) arm(); });
    btn.addEventListener('pointermove', (e) => { if (!t && can(e) && justMoved()) arm(); }, { passive: true }); // (the pointer that was resting there moves after all)
    btn.addEventListener('pointerleave', () => { clearTimeout(t); t = 0; delete btn.dataset.bcvHoverCool; });
    btn.addEventListener('click', () => { clearTimeout(t); t = 0; });
    return btn;
  }
  /** As a box folds back into its button: a pointer last seen over the button (or not seen at all)
   *  leaves the button cool, so the box does not open again under a pointer that has not moved. */
  function hoverCool(btn, pt) {
    const r = btn.getBoundingClientRect();
    if (!pt || (pt.x >= r.left && pt.x <= r.right && pt.y >= r.top && pt.y <= r.bottom)) btn.dataset.bcvHoverCool = '1';
  }
  /** A box opened by a hover folds again (close) once the pointer has been off it a moment — unless it
   *  was taken up (a press in it, a key, a field): then it stays, as a pressed one does. `ov` is the
   *  box's layer (data-hover on it while the hover still holds it), `box` the box, `folding` whether it
   *  is already on its way back. */
  function hoverHold(ov, box, close, folding = () => false) {
    ov.dataset.hover = '';
    let kept = false, outT = 0;
    const keep = () => { kept = true; clearTimeout(outT); delete ov.dataset.hover; };
    const armedAt = performance.now() + 650; // (the box is still growing under the pointer)
    const leaveSoon = () => { if (!kept && !outT && !folding()) outT = setTimeout(() => { outT = 0; if (!kept) close(); }, 380); };
    box.addEventListener('pointerdown', keep, true);
    box.addEventListener('focusin', (e) => { if (e.target.matches?.('input, textarea, select, [contenteditable="true"]')) keep(); });
    ov.addEventListener('keydown', (e) => { if (e.key !== 'Escape') keep(); }, true);
    ov.addEventListener('pointermove', (e) => {
      if (kept || folding()) return;
      const r = box.getBoundingClientRect();
      const over = e.clientX >= r.left - 8 && e.clientX <= r.right + 8 && e.clientY >= r.top - 8 && e.clientY <= r.bottom + 8;
      if (over || performance.now() < armedAt) { clearTimeout(outT); outT = 0; return; }
      leaveSoon();
    }, { passive: true });
    document.documentElement.addEventListener('pointerleave', function gone() { // (off the window altogether)
      if (!ov.isConnected) { document.documentElement.removeEventListener('pointerleave', gone); return; }
      if (performance.now() >= armedAt) leaveSoon();
    });
  }

  // ---- a box that grows out of what opened it (2.99.4) ------------------------------------------------------------
  // A Dashboard counter's box and the mark's box are laid out once, where they go, and drawn through a clip that grows
  // from the card (or from wherever the box is drawn this instant) to the whole box: clip-path, never left, top, width
  // or height animated, so nothing in it is laid out again on each frame. Its shadow is a layer of its own that scales
  // with it, and the dim round it a gradient drawn once and moved by transform — the page focusing onto the box as the
  // dim's light middle closes in on it, letting go outward as it folds. The words that travel between the card and
  // the box's header (`glide`: [box's, card's]) are drawn where the card's are and glide to their own places.
  const pxs = (n) => `${Math.round(n * 100) / 100}px`;
  /** The clip that shows only `rect` (on screen) of a box laid out at `b` (on screen), its corners `radius`. */
  function clipTo(b, rect, radius) {
    return `inset(${pxs(Math.max(0, rect.top - b.top))} ${pxs(Math.max(0, b.right - rect.right))} ${pxs(Math.max(0, b.bottom - rect.bottom))} ${pxs(Math.max(0, rect.left - b.left))} round ${radius})`;
  }
  /** Where a clipped box is drawn this instant (its clip mid-way too), on screen. */
  function drawnOf(box) {
    const b = box.getBoundingClientRect();
    const m = /inset\(([^)]*)\)/.exec(getComputedStyle(box).clipPath || '');
    const [t = 0, r = t, bt = t, l = r] = m ? m[1].split(/\s+round\s+/)[0].trim().split(/\s+/).map((v) => parseFloat(v) || 0) : [];
    const left = b.left + l, top = b.top + t, right = b.right - r, bottom = b.bottom - bt;
    return { left, top, right, bottom, width: right - left, height: bottom - top };
  }
  const gentleEase = (at = document.documentElement) => {
    const v = getComputedStyle(at).getPropertyValue('--bcv-spring-gentle').trim();
    return v && (!/^linear\(/.test(v) || CSS.supports('animation-timing-function', v)) ? v : 'cubic-bezier(.32,.72,0,1)';
  };
  const gentleMs = (at = document.documentElement) => { const v = getComputedStyle(at).getPropertyValue('--bcv-t-gentle').trim(), n = parseFloat(v); return Number.isFinite(n) ? (/ms$/.test(v) ? n : n * 1000) : 460; }; // (motion.js writes ms, the stylesheet's fallback s)
  /** The motion of a box (`sheet`, position: fixed, in the overlay `ov`) that opens out of `card`. `geometry()` says
   *  where it goes ({ x, y, w, h }). Call with the sheet already in the overlay, before the overlay is in the page. */
  function cardBox({ ov, sheet, card, geometry, cardRadius = null }) {
    const cr = cardRadius || getComputedStyle(card).borderTopLeftRadius || '16px';
    const BOX_R = 'var(--bcv-r-sheet)';
    const shadow = el('bcv-card-shadow', null, { 'aria-hidden': 'true' });
    const dim = el('bcv-card-dim', null, { 'aria-hidden': 'true' });
    ov.append(dim, shadow); // (after the box, which stays the overlay's first child; under it by z-index)
    let G = null;
    let glide = [];
    const still = (els, fn) => { for (const e of els) e.style.transition = 'none'; fn(); void sheet.offsetWidth; for (const e of els) e.style.transition = ''; };
    const centre = (r) => [r.left + r.width / 2, r.top + r.height / 2];
    let dimK = 1, dimFar = 1;
    /** The dim, drawn once for this box: a 512px gradient scaled to cover the window round the box's centre. */
    function dimFor(g) {
      const vw = innerWidth, vh = innerHeight;
      const r0 = Math.hypot(g.w, g.h) / 2;
      const c = card.getBoundingClientRect();
      const reachOf = ([x, y]) => Math.max(x, vw - x, y, vh - y);
      const axis = Math.max(reachOf(centre({ left: g.x, top: g.y, width: g.w, height: g.h })), reachOf(centre(c)));
      dimK = (axis * 1.04) / 256;
      const R = 256 * dimK;
      dim.style.setProperty('--bcv-d1', `${((r0 * 0.8) / R) * 100}%`);
      dim.style.setProperty('--bcv-d2', `${((r0 + 220) / R) * 100}%`);
      dim.style.setProperty('--bcv-d3', `${((r0 + 900) / R) * 100}%`);
      dimFar = Math.max(1.5, (Math.hypot(vw, vh) + 120) / Math.max(40, r0 * 0.8)); // (far: the light middle holds the whole window)
    }
    const aim = (rect, far) => {
      const [x, y] = centre(rect);
      dim.style.translate = `${pxs(x)} ${pxs(y)}`;
      dim.style.scale = String(dimK * (far ? dimFar : 1));
    };
    /** Put the box where it goes, at once (its shadow's place with it). `keepDim`: the dim keeps its stops and takes the
     *  box's new size by its scale alone (which glides), not by stops set at once. */
    function layout({ keepDim = false } = {}) {
      const r0Was = G ? Math.hypot(G.w, G.h) / 2 : 0;
      G = geometry();
      const s = { left: `${Math.round(G.x)}px`, top: `${Math.round(G.y)}px`, width: `${Math.round(G.w)}px`, height: `${Math.round(G.h)}px` };
      Object.assign(sheet.style, s);
      Object.assign(shadow.style, s);
      if (keepDim && r0Was > 0) dimK *= Math.hypot(G.w, G.h) / 2 / r0Was;
      else dimFor(G);
      // the blur's clear hole: where the box lands, set with it — never animated (Safari drops a blur whose hole moves, once it settles)
      ov.style.setProperty('--bcv-mx', `${Math.round(G.x + G.w / 2)}px`);
      ov.style.setProperty('--bcv-my', `${Math.round(G.y + G.h / 2)}px`);
      ov.style.setProperty('--bcv-mr', `${Math.round(Math.hypot(G.w, G.h) / 2)}px`);
      return G;
    }
    const boxRect = () => ({ left: G.x, top: G.y, right: G.x + G.w, bottom: G.y + G.h, width: G.w, height: G.h });
    const clipAs = (rect, radius) => clipTo(boxRect(), rect, radius); // (from where the box is laid out: measurable before it is in the page)
    /** The shadow drawn as `rect` (scaled from the box's own), or as the box's. */
    const shadowAs = (rect) => {
      if (!rect) { shadow.style.transform = ''; shadow.style.opacity = '1'; return; }
      shadow.style.transform = `translate(${pxs(rect.left - G.x)}, ${pxs(rect.top - G.y)}) scale(${rect.width / G.w}, ${rect.height / G.h})`;
      shadow.style.opacity = '0';
    };
    // the words: where each lies with nothing moving it, and the move that draws it where the card's is
    // (measured with its transition off: a transition running would hand back where it is drawn, not where it lies)
    const restOf = (a) => { const t = a.style.transform, tr = a.style.transition; a.style.transition = 'none'; a.style.transform = 'none'; const r = a.getBoundingClientRect(); a.style.transform = t; a.style.transition = tr; return r; };
    const asCard = (rest, at) => `translate(${pxs(at.left - rest.left)}, ${pxs(at.top - rest.top)}) scale(${at.height / Math.max(1, rest.height)})`;
    /** Set the box as the card: laid out where it goes, drawn only where the card is (before the overlay is shown). */
    function start() {
      layout();
      still([sheet, shadow, dim], () => {
        sheet.style.clipPath = clipAs(card.getBoundingClientRect(), cr);
        shadowAs(card.getBoundingClientRect());
        aim(card.getBoundingClientRect(), true);
      });
      return G;
    }
    /** Open: the clip grows from the card to the whole box, the words glide out of the card's, the dim closes in. */
    function open(words) {
      glide = words;
      sheet.style.clipPath = clipAs(card.getBoundingClientRect(), cr); // (the card measured again: the overlay is in the page now)
      still(glide.map(([a]) => a), () => { for (const [a, b] of glide) a.style.transform = asCard(restOf(a), b.getBoundingClientRect()); });
      sheet.classList.remove('is-at-card');
      ov.classList.remove('is-far');
      sheet.style.clipPath = `inset(0px round ${BOX_R})`;
      shadowAs(null);
      aim(boxRect(), false);
      for (const [a] of glide) a.style.transform = '';
    }
    /** The box goes elsewhere or takes another size (a row's preview widening it, the window resized): laid out there
     *  once, what it holds moved there by transform, the clip growing from where the box was drawn to the whole of it. */
    function relayout() {
      const was = drawnOf(sheet), before = G;
      const kids = [...sheet.children].filter((k) => !k.classList.contains('bcv-pv--in'));
      const at = kids.map((k) => k.getBoundingClientRect());
      const now = geometry();
      if (before && Math.abs(now.x - before.x) < 1 && Math.abs(now.y - before.y) < 1 && Math.abs(now.w - before.w) < 1 && Math.abs(now.h - before.h) < 1) return;
      layout({ keepDim: true }); // (2.99.97: nothing round the box blurred, so no blur to carry to its new place)
      still([sheet, shadow], () => {
        sheet.style.clipPath = clipAs(was, BOX_R);
        shadowAs(was);
        shadow.style.opacity = '1';
      });
      sheet.style.clipPath = `inset(0px round ${BOX_R})`;
      shadowAs(null);
      aim(boxRect(), false);
      if (reducedMotion()) return;
      const easing = gentleEase(ov), duration = gentleMs(ov); // (the box's own spring: a counter's is the Mac's, app.css .bcv-sheet-ov--float)
      kids.forEach((k, i) => {
        const r = k.getBoundingClientRect(), dx = at[i].left - r.left, dy = at[i].top - r.top;
        if (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) k.animate([{ translate: `${pxs(dx)} ${pxs(dy)}` }, { translate: '0px 0px' }], { duration, easing });
      });
    }
    /** Fold back into the card, from wherever the box is drawn this instant; its words go back to the card's. */
    function fold() {
      const c = card.getBoundingClientRect();
      sheet.style.clipPath = clipAs(c, cr);
      shadowAs(c);
      aim(c, true);
      for (const [a, b] of glide) {
        const cur = getComputedStyle(a).transform; // (where it is drawn this instant: it goes back from there)
        let rest = null;
        still([a], () => { rest = restOf(a); a.style.transform = cur === 'none' ? '' : cur; });
        a.style.transform = asCard(rest, b.getBoundingClientRect());
      }
    }
    /** Open again on the way back (the card pressed again as the box folds into it): from wherever it is drawn. */
    function reopen() {
      sheet.style.clipPath = `inset(0px round ${BOX_R})`;
      shadowAs(null);
      aim(boxRect(), false);
      for (const [a] of glide) a.style.transform = '';
    }
    return { start, open, relayout, fold, reopen, layout };
  }

  BCV.ui = {
    groupPicker, groupAttrs, BANDS, gradeBand, bandChip, bandSlider, whatIfAdder, whatIfRemove,
    svg, star, chev, el, text, tile, dot, card, row, label, h2, groupHead, badge, statusBadge, seg, segSlide, search, switchEl, btn, iconbtn, pill, placeDot, haptic,
    squircle, squirclePath, squircleFit, superPillPath, squircleAll,
    empty, emptyCard, loading, errorBox, hint, avatar, toast, menu, closeMenus, picker, colorMenu, COURSE_COLORS, fmtDay, datePop, dateField, promptSheet, askSheet,
    DAY, startOfDay, addDays, sameDay, dayDiff, startOfWeek, parse, MONTHS, MONTHS_LONG, DAYS, DAYS_LONG,
    fmtTime, fmtTimeLower, fmtShort, fmtLong, fmtDateComma, fmtAt, fmtAtUpper, fmtBy, dayTitle, fmtDow, fmtRecent, whenShort, plural,
    hexToRgb, rgba, palette, quiet, FALLBACK_COLORS, initials, enter, still, isStill, roll, morphFrom, reducedMotion, flipList, drawCheck, collapsible, dpr, onDprChange, dismiss, recall,
    afterMotion, onGone, watchLayout, anchor, keepOnScreen, boundsOf, hoverOpens, hoverCool, hoverHold, cardBox,
  };
})();
