/* Dashboard: summary counters, the grades skyline beside this week's workload per course, and the
 * Cards / List / Recent activity views (the same three Canvas offers). */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  const { h } = BCV.utils;
  const U = BCV.ui;
  const IC = BCV.IC;
  const store = BCV.store;
  // The Dashboard's arrival (the counters rolling to their counts, the bars and towers rising) plays once a session — the
  // first time the student lands on it in this tab. Every later visit, and every redraw in place (back to the tab, a
  // theme photo arriving: ui.still), shows the real numbers at once: they are what the student came for.
  const ARRIVED = 'bcv:dash-arrived';
  let arrived = false;
  const arrivedBefore = () => { if (arrived) return true; try { return sessionStorage.getItem(ARRIVED) === '1'; } catch { return false; } };
  const markArrived = () => { arrived = true; try { sessionStorage.setItem(ARRIVED, '1'); } catch { /* (private window: this page's memory is enough) */ } };
  const SILENT_MORE = 4; // (what comes after the next: so many lines under it)

  /** The counters' own lists — shared by the Dashboard and the phone's Today (2.98.36), so the two
   *  never count differently: what is due today, tomorrow and in the next 7 days (and what of each is already
   *  done), what is overdue (and what was handed in late), what was graded this week (and the two
   *  before). Every list keeps to the course selection. Rows are the sheets' shape: { title, meta,
   *  course, color, tint, url, date }; an overdue row also carries its planner item and key, for the X. */
  function workLists({ planner, favs, overrides = [], dark = false, now = new Date(), lists = null }) {
    // every override, dismissed or not: an item's X changes the one it has rather than writing a second, which Canvas refuses
    const overrideByKey = new Map((Array.isArray(overrides) ? overrides : []).filter((o) => o && o.id).map((o) => [`${o.plannable_type}:${o.plannable_id}`, o]));
    const dismissedKeys = new Set([...overrideByKey].filter(([, o]) => o.dismissed).map(([k]) => k));
    const todayStart = U.startOfDay(now);
    const weekStart = U.startOfWeek(now);
    const weekEnd = U.addDays(weekStart, 7);
    const tomorrowStart = U.addDays(todayStart, 1);
    const nextEnd = U.addDays(todayStart, 7); // (2.98.94: the next 7 days — today and the six after it — not the calendar week)
    // every count respects the course selection (the favourites), so the cards agree with the page below them
    const favIds = new Set((favs || []).map((c) => String(c.id)));
    const inSel = (it) => it.custom || !it.courseId || favIds.has(String(it.courseId));
    const live = (planner || []).filter((it) => !it.complete && !it.dismissed && it.type !== 'announcement' && inSel(it));
    const dueItems = live.filter((it) => it.isDue && !it.excused); // (excused work is not due: it counts nowhere)
    const dueToday = dueItems.filter((it) => U.sameDay(it.date, now) && !it.submitted);
    const dueTomorrow = dueItems.filter((it) => U.sameDay(it.date, tomorrowStart) && !it.submitted);
    const dueNext = dueItems.filter((it) => it.date >= todayStart && it.date < nextEnd && !it.submitted);
    // (2.98.28) what a sheet shows under its list, quieter: work of the same span already handed in or marked done
    const doneIn = (from, to) => (planner || []).filter((it) => it.isDue && !it.excused && !it.dismissed && it.type !== 'announcement' && inSel(it) && (it.submitted || it.complete) && it.date >= from && it.date < to);
    const RECENT_MAX = 8;
    const byDate = (a, b) => a.date - b.date;
    const dueRow = (it) => {
      const c = it.course;
      const pal = c ? c.palette : U.palette('#8e8e93', dark);
      const when = U.sameDay(it.date, now) ? `due ${U.fmtTime(it.date)}` : `${U.DAYS[it.date.getDay()]} ${U.fmtTime(it.date)}`;
      // (2.99.33) `parts`: the row's facts one by one, for the apps' own columns (native-app.js sheetRow)
      return { title: it.title, meta: [it.kind, it.points !== null ? `${store.fmtPts(it.points)} pts` : null, when].filter(Boolean).join(' · '), course: c?.shortName || it.courseName || '—', color: pal.text, tint: pal.tint, url: it.url, date: it.date, parts: { kind: it.kind, points: it.points, due: it.date } };
    };
    // a done row says how it was done: graded, handed in, or marked done on the planner
    const doneRow = (it) => { const r = dueRow(it); const how = it.graded ? 'graded' : it.submitted ? 'handed in' : 'marked done'; r.meta = `${r.meta} · ${how}`; r.parts.how = how; return r; };
    const recentOf = (label, items) => (items.length ? { label, items: items.slice(0, RECENT_MAX) } : null);
    const courseCount = (items) => new Set(items.map((it) => it.courseId || it.courseName)).size;
    const kindOf = (a) => (a.is_quiz_assignment || a.quiz_id || (a.submission_types || []).includes('online_quiz') ? 'Quiz' : (a.submission_types || []).includes('discussion_topic') ? 'Discussion' : 'Assignment');
    const palOf = (c) => (c ? c.palette : U.palette('#8e8e93', dark));
    // Overdue and Graded this week read each selected course's assignments (their submissions carry
    // Canvas's own late / missing / graded_at flags). null when that fails: a card whose fetch fails
    // is dropped rather than shown as 0 (a false 0 on Overdue reads as "fine"). (2.98.92) `lists` hands in those
    // already asked for — or the ones kept from the last visit, which the Dashboard draws from first.
    const assignmentsP = (lists || Promise.all((favs || []).map(async (c) => ({ c, list: await store.assignments(c.id) })))).catch(() => null);
    const overdueP = assignmentsP.then((byCourse) => {
      if (!byCourse || !planner) return null;
      // Overdue: past due with nothing handed in (Canvas's missing flag, or the due time passed) and
      // still open to a late hand-in. Work handed in late and awaiting a grade is not overdue: it is
      // out of the student's hands, and Canvas counts nothing as 0 for it (2.98.17, after a late
      // hand-in sat on this list as "submitted late · ungraded").
      // Older missing work is read from the course's assignments rather than the planner window, so
      // its dismissal is looked up in the student's own list of overrides.
      const seen = new Set();
      const overdue = [];
      const plannerByKey = new Map((planner || []).map((it) => [it.id, it]));
      // an assignment's planner key: the quiz's for a quiz, the topic's for a graded discussion (as Canvas's planner names them), else its own
      const keyOf = (a) => (a.quiz_id ? `quiz:${a.quiz_id}` : a.discussion_topic?.id ? `discussion_topic:${a.discussion_topic.id}` : `assignment:${a.id}`);
      const aByKey = new Map();
      for (const { list } of byCourse) for (const a of list || []) { aByKey.set(keyOf(a), a); aByKey.set(`assignment:${a.id}`, a); }
      // marked is marked, whether or not anything was ever handed in (a tool sends a score back with
      // no submission; a teacher enters one): never overdue. Locked or closed work cannot be fixed:
      // it is left off the list rather than counted against you.
      const scored = (sub) => !!sub && (sub.workflow_state === 'graded' || (sub.score !== null && sub.score !== undefined));
      const closed = (a) => !!(a.locked_for_user || (a.lock_at && U.parse(a.lock_at) < now));
      for (const it of live) {
        if (!it.isDue || it.submitted || it.excused || !(it.missing || it.date < now)) continue;
        const key = `${it.type}:${it.raw.plannable_id}`;
        const a = aByKey.get(key);
        if (a && (scored(a.submission) || closed(a))) continue;
        seen.add(key);
        overdue.push({ key, item: it, title: it.title, meta: [it.kind, it.points !== null ? `${store.fmtPts(it.points)} pts` : null, `due ${U.fmtShort(it.date)}`, 'not submitted'].filter(Boolean).join(' · '), course: it.course?.shortName || it.courseName || '—', color: palOf(it.course).text, tint: palOf(it.course).tint, url: it.url, date: it.date, parts: { kind: it.kind, points: it.points, due: it.date, missing: !!it.missing } });
      }
      for (const { c, list } of byCourse) {
        for (const a of list || []) {
          const sub = a.submission;
          if (!sub || sub.excused || scored(sub) || sub.submitted_at) continue; // (handed in, late or not: waiting on a grade, not overdue)
          // never handed in and past due (Canvas's own "missing"), which the planner's window no
          // longer holds once it is older than that
          const missing = (sub.missing || (a.due_at && U.parse(a.due_at) < now)) && (a.submission_types || []).some((t) => !['none', 'on_paper', 'not_graded'].includes(t)) && !closed(a);
          if (!missing) continue;
          const key = keyOf(a);
          if (seen.has(key) || seen.has(`assignment:${a.id}`)) continue;
          seen.add(key);
          seen.add(`assignment:${a.id}`);
          if (dismissedKeys.has(key) || dismissedKeys.has(`assignment:${a.id}`) || plannerByKey.get(key)?.dismissed) continue;
          const item = plannerByKey.get(key) || { type: key.split(':')[0], raw: { plannable_id: key.split(':')[1], planner_override: overrideByKey.get(key) || overrideByKey.get(`assignment:${a.id}`) || null } };
          overdue.push({ key, item, title: a.name, meta: [kindOf(a), a.points_possible !== null && a.points_possible !== undefined ? `${store.fmtPts(a.points_possible)} pts` : null, a.due_at ? `due ${U.fmtShort(a.due_at)}` : null, 'not submitted'].filter(Boolean).join(' · '), course: c.shortName || c.name, color: c.palette.text, tint: c.palette.tint, url: a.html_url || `${c.url}/assignments/${a.id}`, date: U.parse(a.due_at) || now, parts: { kind: kindOf(a), points: a.points_possible ?? null, due: U.parse(a.due_at), missing: !!sub.missing } });
        }
      }
      overdue.sort(byDate);
      // (2.98.28) under them, quieter: past-due work handed in late in the last two weeks — no longer
      // overdue, out of the student's hands, but still there to look back at
      const lateIn = [];
      const since = U.addDays(todayStart, -14);
      for (const { c, list } of byCourse) {
        for (const a of list || []) {
          const sub = a.submission;
          const at = sub && U.parse(sub.submitted_at);
          const due = U.parse(a.due_at);
          if (!at || at < since || !(sub.late || (due && at > due))) continue;
          lateIn.push({ title: a.name, meta: [kindOf(a), due ? `due ${U.fmtShort(due)}` : null, `handed in ${U.fmtShort(at)}`, scored(sub) ? 'graded' : 'waiting for a grade'].filter(Boolean).join(' · '), course: c.shortName || c.name, color: c.palette.text, tint: c.palette.tint, url: a.html_url || `${c.url}/assignments/${a.id}`, date: at, parts: { kind: kindOf(a), points: a.points_possible ?? null, due, handed: at, how: scored(sub) ? 'graded' : 'waiting for a grade' } });
        }
      }
      lateIn.sort((x, y) => y.date - x.date);
      return { overdue, lateIn };
    });
    const gradedP = assignmentsP.then((byCourse) => {
      if (!byCourse || !planner) return null;
      // Graded this week: submissions graded inside this week (graded_at, never due_at); excused
      // ones count but carry no score, so they stay out of the points ratio
      const graded = [];
      const earlier = []; // (the two weeks before this one: the quiet list under this week's)
      const before = U.addDays(weekStart, -14);
      let earned = 0, possible = 0;
      for (const { c, list } of byCourse) {
        for (const a of list || []) {
          const sub = a.submission;
          const g = sub && U.parse(sub.graded_at);
          if (!g || g < before || g >= weekEnd) continue;
          const isScored = !sub.excused && sub.score !== null && sub.score !== undefined;
          if (!isScored && !sub.excused) continue;
          const row = { title: a.name, meta: `${kindOf(a)} · ${sub.excused ? 'excused' : `${store.fmtPts(sub.score)} / ${store.fmtPts(a.points_possible ?? 0)}`} · posted ${U.fmtShort(g)}`, course: c.shortName || c.name, color: c.palette.text, tint: c.palette.tint, url: a.html_url || `${c.url}/assignments/${a.id}`, date: g, parts: { kind: kindOf(a), points: a.points_possible ?? null, score: sub.excused ? null : sub.score, excused: !!sub.excused, posted: g, grade: a.grading_type && a.grading_type !== 'points' && sub.grade ? String(sub.grade) : null } };
          if (g < weekStart) { earlier.push(row); continue; }
          if (isScored) { earned += Number(sub.score) || 0; possible += Number(a.points_possible) || 0; }
          graded.push(row);
        }
      }
      graded.sort((x, y) => y.date - x.date);
      earlier.sort((x, y) => y.date - x.date);
      return { graded, earlier, earned, possible };
    });
    return { now, todayStart, weekStart, weekEnd, tomorrowStart, nextEnd, inSel, live, dueItems, dueToday, dueTomorrow, dueNext, doneIn, byDate, dueRow, doneRow, recentOf, courseCount, overrideByKey, dismissedKeys, assignmentsP, overdueP, gradedP };
  }

  // ---- the grades skyline (2.98.90) ------------------------------------------------------------------
  // A tower per course, as tall as its score; every assignment a window, lit in its grade's colour once
  // it is marked and posted (A green, B yellow-green, C yellow, D orange, F red), dark while it is to come.
  const SKY_H = 118; // (a full-marks tower, px)
  const SKY_LIT = { A: '#4cd964', B: '#b5e036', C: '#ffd426', D: '#ff9f0a', F: '#ff453a' };
  /** Each tower's short name: the subject in the course's name ("F26-MATH 021 20": MATH). Of two in one
   *  subject, the lab is LAB (its subject too, when there is more than one lab) and another gets its number;
   *  a nickname is kept as it is. */
  function skyNames(courses) {
    const raw = (c) => `${c.originalName || c.name || ''} ${c.code || ''}`;
    const subj = (c) => ((String(c.originalName || c.name || '').replace(/^[A-Z]{1,2}\d{2}[-\s]/, '').match(/[A-Za-z]{2,}/) || [c.shortName || c.name || '?'])[0]).toUpperCase();
    const isLab = (c) => /\blab\b/i.test(raw(c)) || /\d+[A-Z]*L\b/.test(raw(c));
    const subs = courses.map(subj);
    const labs = courses.filter(isLab).length;
    return courses.map((c, i) => {
      if (c.nickname) return c.nickname;
      const same = courses.filter((_, j) => subs[j] === subs[i]);
      if (same.length < 2) return subs[i];
      const lab = isLab(c);
      const name = lab ? (labs > 1 ? `${subs[i]} LAB` : 'LAB') : subs[i];
      if (same.filter((x) => isLab(x) === lab).length < 2) return name;
      const num = raw(c).replace(/^[A-Z]{1,2}\d{2}[-\s]/, '').match(/\d+[A-Z]*/);
      return num ? `${name} ${num[0]}` : name;
    });
  }
  /** A course's windows: every assignment the student sees (published), the marked and posted first, then what is to
   *  come, each in the order it was due; `band` is the marked one's letter. (2.98.91) `free` is work that does not
   *  count toward the total — left out of the grade (omit_from_final_grade), worth no points, not graded, excused, or
   *  in a group that weighs nothing (the course's weights, or the student's own from its Grades tab): drawn in grey. */
  function skyWindows(list, weights = null) {
    const rows = [];
    for (const a of list || []) {
      const sub = a.submission;
      if (a.published === false) continue;
      const pts = Number(a.points_possible) > 0;
      const free = !!(a.omit_from_final_grade || a.grading_type === 'not_graded' || !pts || sub?.excused
        || (weights && (Number(weights.get(String(a.assignment_group_id))) || 0) === 0));
      const posted = !!sub && sub.posted_at !== null; // (absent where a Canvas posts with the grade)
      const marked = posted && !sub.excused && ((sub.score !== null && sub.score !== undefined) || (a.grading_type === 'pass_fail' && !!sub.grade));
      const band = !marked ? null : a.grading_type === 'pass_fail' ? (String(sub.grade).toLowerCase() === 'complete' ? 'A' : 'F') : U.gradeBand(sub.score, a.points_possible, a.grading_type);
      rows.push({ a, band, free, score: marked ? sub.score : null, at: U.parse(a.due_at) || U.parse(sub?.graded_at) || null });
    }
    const t = (r) => (r.at ? r.at.getTime() : Infinity);
    return [...rows.filter((r) => r.band).sort((x, y) => t(x) - t(y)), ...rows.filter((r) => !r.band).sort((x, y) => t(x) - t(y))];
  }
  /** (2.99.68) Windows to a tower w wide and hgt tall: four across, always, at the size four across leaves — and only as many
   *  rows as the tower has floors for; the rest are not drawn (they were squeezed in, more across and smaller, until then).
   *  `up`, `down`: how many count and how many do not; those that count take the floors first. */
  function skyFit(up, down, w, hgt) {
    const g = 3, cols = 4;
    const s = Math.max(2, Math.floor(Math.min(6.5, (w - (cols - 1) * g) / cols) * 2) / 2);
    const floors = (h) => Math.max(0, Math.floor((h + g) / (s + g)));
    const total = floors(hgt);
    const upRows = Math.min(Math.ceil(up / cols), total);
    const downRows = Math.min(Math.ceil(down / cols), Math.max(0, floors(hgt - (upRows ? upRows * (s + g) + 6 : 0))));
    return { cols, s, g, up: Math.min(up, upRows * cols), down: Math.min(down, downRows * cols) };
  }

  const ACTIVITY_ICON = { Announcement: IC.bell, DiscussionTopic: IC.disc, Conversation: IC.mail, Message: IC.doc, Submission: IC.chart, Conference: IC.people, Collaboration: IC.people, AssessmentRequest: IC.people, WebConference: IC.people };
  const ACTIVITY_KIND = { Announcement: 'Announcement', DiscussionTopic: 'Discussion', Conversation: 'Message', Message: 'Notification', Submission: 'Grade posted', Conference: 'Conference', Collaboration: 'Collaboration', AssessmentRequest: 'Peer review' };

  async function render(ctx) {
    const { app } = ctx;
    const dark = app.isDark();
    const screen = U.el('bcv-screen');
    const segWrap = h('div', { class: 'bcv-dash__views' });
    const body = U.el('bcv-body');
    // (2.99.41) the Mac's head: a greeting with the student's first name, today's date under it, and the views with
    // New Task on a row of their own beneath (the name lands from the account, kept for the hour, a moment later)
    const today = new Date();
    const part = today.getHours() < 12 ? 'morning' : today.getHours() < 17 ? 'afternoon' : 'evening';
    const hello = h('h1', { class: 'bcv-h1 bcv-dash__hello', text: `Good ${part}` });
    store.me().then((me) => { const first = String(me?.shortName || me?.name || '').trim().split(/\s+/)[0]; if (first && first !== 'Account') hello.textContent = `Good ${part}, ${first}`; }).catch(() => {});
    BCV.plan?.ready(); // (2.99.107) the plans, for the pills on the rows (they paint when it lands)
    const newTask = U.btn('New Task', { kind: 'xs', icon: IC.plus, cls: 'bcv-dash__new', title: 'Add a task of your own to To Do', onClick: () => { BCV.todoAddNext = true; app.go('/#todo'); } });
    // (2.99.125) Silent mode (silentBlock, below): the desktop's alone — the phone has Today, and the apps draw their own.
    // (2.99.127) Silent is the whole app's now (app.js setSilent: the other screens in black and white); here it is read
    // from there, so a redraw starts in it rather than flashing the bar and the cards back first
    const desk = !BCV.phone?.active?.() && !self.BCVBridge?.native;
    let silent = desk && !!app.state.silent;
    const silentBtn = desk ? U.btn('Silent', { kind: 'xs', icon: IC.moon, cls: 'bcv-dash__silent', title: 'Silent mode: only what comes next, in large type on black', onClick: () => setSilent(true) }) : null;
    const paintSilent = () => {
      document.documentElement.classList.toggle('bcv-dash-silent', silent); // (the bar goes up out of view: app.css)
      screen.classList.toggle('bcv-screen--silent', silent);
    };
    paintSilent();
    screen.append(
      U.el('bcv-head bcv-head--hello', U.el('bcv-head__in', [
        U.el('bcv-head__row', [U.el('bcv-dash__title', [hello, U.text('bcv-dash__date', `${U.DAYS_LONG[today.getDay()]}, ${U.MONTHS_LONG[today.getMonth()]} ${today.getDate()}`, 'div')])]), // (E33: the search box is the top bar's here too)
        U.el('bcv-dash__bar', [segWrap, silentBtn, newTask].filter(Boolean)),
      ])),
      body,
    );
    if (!silent) body.append(U.loading('rows', 6)); // list-row skeletons hold the place until the planner lands (silent: black, and nothing)

    let view = 'list';
    // the views the setup (or Settings) asked for; with one, there is nothing to switch between. (2.99.132: the List or
    // Recent activity — the courses as cards are gone; a Cards kept from before opens the List)
    const ALL_VIEWS = [['list', 'List'], ['activity', 'Recent activity']];
    let views = ALL_VIEWS;
    let hideDone = false; // the list without what is already done; kept per site, like To Do's
    const draw = () => {
      segWrap.replaceChildren(...(views.length > 1 ? [U.seg(views, view, async (v) => {
        view = v;
        draw();
        store.setDashboardView(v);
      })] : []));
      renderBody();
    };

    // The announcements feed is the slow one — it waits for the course list and then asks per ten
    // courses — so the screen does not wait for it: its counter starts as "…" and fills when it
    // lands. Everything else here is already in the memo from the shell, so the first paint is one
    // round trip away, not three. The saved view is read alongside the data rather than before it.
    const feedP = store.announcementsFeed().catch(() => null);
    let feedById = null; // set when the feed lands; the activity view reads it at draw time
    // (2.98.92) Overdue, Graded this week and the skyline wait on every favourite course's assignments, Canvas's slowest
    // answer: asked for now, beside the planner rather than after it, with a weighted course's groups alongside — and
    // drawn first from the copy kept from the last visit (store.keptAssignments), so they are there on arrival and put
    // right, quietly, the moment Canvas answers.
    const favsP = store.favorites().catch(() => []);
    const freshP = favsP.then((fs) => Promise.all((fs || []).map(async (c) => ({ c, list: await store.assignments(c.id) })))).catch(() => null);
    const ownWeightsP = store.pref('gradeWeights', {}).then((p) => (p && typeof p === 'object' ? p : {})).catch(() => ({}));
    // what each group weighs where that decides what counts (2.98.91): the student's own weights for a course they set
    // them on (its Grades tab), else Canvas's for a weighted course; a course weighted by points has none to ask
    const weightMap = (o) => (o && typeof o === 'object' && Object.keys(o).length ? new Map(Object.entries(o).map(([g, w]) => [String(g), Number(w) || 0])) : null);
    const groupWeights = (groups) => (Array.isArray(groups) ? new Map(groups.map((g) => [String(g.id), Number(g.group_weight) || 0])) : null);
    const freshWeightsP = Promise.all([favsP, ownWeightsP]).then(([fs, own]) => Promise.all((fs || []).map(async (c) => [c.id, weightMap(own[c.id]) || (c.weighted ? groupWeights(await store.assignmentGroups(c.id).catch(() => null)) : null)]))).then((e) => new Map(e)).catch(() => new Map());
    const [planner, favs, courses, seen, savedView, settings, hidePref, overrides, kept] = await Promise.all([
      store.planner().catch(() => null),
      favsP,
      store.courses().catch(() => []),
      store.streamSeen().catch(() => new Set()), // stream items opened from here
      store.dashboardView().catch(() => 'list'),
      BCV.settings.get().catch(() => null),
      store.pref('dashHideDone', false).catch(() => false),
      store.plannerOverrides().catch(() => []), // what the X on the Overdue list wrote, on any device (see below)
      store.keptAssignments().catch(() => null),
    ]);
    if (!ctx.alive()) return screen;
    // the counters' lists, the same ones the phone's Today counts (workLists above): from the kept copy when it holds
    // every course (a part would count short), and again from Canvas's answer (Wf)
    const keptBy = kept ? favs.map((c) => ({ c, list: kept.get(String(c.id))?.list })) : [];
    const useKept = favs.length > 0 && keptBy.length === favs.length && keptBy.every((b) => Array.isArray(b.list));
    const Wf = workLists({ planner, favs, overrides, dark, lists: freshP });
    const W = useKept ? workLists({ planner, favs, overrides, dark, now: Wf.now, lists: Promise.resolve(keptBy) }) : Wf;
    const wanted = settings?.appearance?.dashboard || {};
    views = ALL_VIEWS.filter(([k]) => wanted[k] !== false);
    if (!views.length) views = ALL_VIEWS; // nothing chosen is not a dashboard: everything, as before
    // the view saved on the Canvas profile, unless it is one that was switched off here
    view = views.some(([k]) => k === savedView) ? savedView : views[0][0];
    hideDone = !!hidePref;
    silent = desk && !!app.state.silent;
    paintSilent();
    // Unread: the announcement's own read state when we know it, else the stream's flag; either
    // way an item opened from here loses its dot. The activity rows on screen are kept here so
    // that a feed landing after they were drawn settles their dots in place.
    let actRows = []; // { a, dot }
    const isUnread = (a) => {
      if (seen.has(String(a.id))) return false;
      if (a.type === 'Announcement' && feedById && a.announcement_id !== undefined) {
        const f = feedById.get(String(a.announcement_id));
        if (f) return f.read_state === 'unread';
      }
      return a.read_state === false;
    };
    feedP.then((feed) => {
      if (feed) feedById = new Map(feed.map((a) => [String(a.id), a]));
      if (!ctx.alive() || !feed) return;
      for (const { a, dot } of actRows) dot.style.background = isUnread(a) ? '#0a84ff' : 'transparent';
    });
    const courseMap = new Map(courses.map((c) => [c.id, c]));
    const { now, todayStart, weekStart, weekEnd, tomorrowStart, nextEnd, inSel, dueItems, dueToday, dueTomorrow, dueNext, doneIn, byDate, dueRow, doneRow, recentOf, courseCount } = W;
    const weekAll = (planner || []).filter((it) => it.isDue && !it.excused && it.date >= weekStart && it.date < weekEnd && (it.points === null || it.points > 0) && it.type !== 'announcement');

    // ---- stats -------------------------------------------------------------------
    // Each counter opens a sheet listing exactly the items it counted.
    // Entry motion (mockup 11) plays on the first draw of the session's first arrival (arrivedBefore, above): counters
    // roll to their value, workload bars wipe in. A redraw (view switch, a recolour, a quiet render) shows the final
    // numbers at once.
    let entered = U.isStill() || arrivedBefore();
    const clearedKeys = new Set(); // (Overdue rows cleared with their X: gone from Canvas's answer too, should it still hold them)
    const t0 = Date.now();

    function statsBlock() {
      const cards = [];
      const first = !entered; // this draw is the entry: a count that lands a moment later still rolls in
      if (planner) {
        const pts = dueToday.reduce((s, it) => s + (Number(it.points) || 0), 0);
        cards.push(stat('Due today', String(dueToday.length), `${store.fmtPts(pts)} points total`, IC.clock, '#ff453a', (from) => openSheet({
          label: 'Due today', value: String(dueToday.length), icon: IC.clock, color: '#ff453a',
          note: `${store.fmtPts(pts)} points across ${U.plural(courseCount(dueToday), 'course')} · ${U.DAYS_LONG[now.getDay()]}, ${U.MONTHS_LONG[now.getMonth()]} ${now.getDate()}`,
          items: [...dueToday].sort(byDate).map(dueRow), empty: 'Nothing is due today.', lead: 'Still to do',
          recent: recentOf('Already done', doneIn(todayStart, tomorrowStart).sort(byDate).map(doneRow)),
        }, from)));
        cards.push(stat('Next 7 days', String(dueNext.length), `Across ${U.plural(courseCount(dueNext), 'course')}`, IC.cal, '#34c759', (from) => openSheet({
          label: 'Next 7 days', value: String(dueNext.length), icon: IC.cal, color: '#34c759',
          note: `${U.fmtShort(todayStart)} – ${U.fmtShort(U.addDays(todayStart, 6))} · ${U.plural(courseCount(dueNext), 'course')}`,
          items: [...dueNext].sort(byDate).map(dueRow), empty: 'Nothing is due in the next 7 days.', lead: 'Still to do',
          recent: recentOf('Already done', doneIn(todayStart, nextEnd).sort(byDate).map(doneRow)),
        }, from)));
      }
      let unreadSheet = { label: 'Unread announcements', value: '…', icon: IC.bell, color: '#ff9500', note: 'Loading…', items: [] };
      const unreadCard = stat('Unread announcements', '…', '', IC.bell, '#ff9500', (from) => openSheet(unreadSheet, from));
      cards.push(unreadCard);
      // unread = [{ title, when, courseId, courseName, url }]; count is what the number shows
      const nameOf = (u) => courseMap.get(String(u.courseId))?.shortName || courseMap.get(String(u.courseId))?.name || u.courseName || '';
      const finish = (unread, count, more = '', read = []) => {
        const perCourse = new Map();
        for (const u of unread) perCourse.set(nameOf(u), (perCourse.get(nameOf(u)) || 0) + 1);
        let top = '';
        let n = 0;
        for (const [k, v] of perCourse) if (v > n) { top = k; n = v; }
        const valueEl = unreadCard.querySelector('.bcv-stat__value');
        if (first && Date.now() - t0 < 2500) U.roll(valueEl, count, { seed: 4.6 });
        else valueEl.textContent = String(count);
        // one phrase for the card and its sheet, so they never disagree: "All from MATH 021", "From 2 courses"
        const phrase = !count ? 'All caught up' : !perCourse.size ? 'Not all listed' : perCourse.size === 1 ? `${unread.length === 2 ? 'Both' : unread.length === 1 ? 'One' : 'All'} from ${top}` : `From ${U.plural(perCourse.size, 'course')}`;
        unreadCard.querySelector('.bcv-stat__note').textContent = phrase;
        const items = unread.map((u) => {
          const c = courseMap.get(String(u.courseId));
          const pal = c ? c.palette : U.palette('#5856d6', dark);
          return { title: u.title || 'Announcement', meta: `Posted ${U.fmtShort(u.when)} · unread`, course: nameOf(u) || '—', color: pal.text, tint: pal.tint, url: u.url };
        });
        const readItems = read.map((u) => {
          const c = courseMap.get(String(u.courseId));
          const pal = c ? c.palette : U.palette('#5856d6', dark);
          return { title: u.title || 'Announcement', meta: `Posted ${U.fmtShort(u.when)} · read`, course: nameOf(u) || '—', color: pal.text, tint: pal.tint, url: u.url };
        });
        unreadSheet = {
          label: 'Unread announcements', value: String(count), icon: IC.bell, color: '#ff9500', items, empty: 'All caught up.', more,
          note: phrase, lead: 'Unread', recent: recentOf('Read recently', readItems),
        };
      };
      feedP.then((feed) => {
        if (!ctx.alive()) return;
        if (feed) {
          // the Announcements API knows every announcement and whether you have read it
          const shape = (a) => ({ title: a.title, when: a.posted_at, courseId: String(a.context_code || '').replace(/^course_/, ''), courseName: a.context_name || '', url: a.html_url });
          const unread = feed.filter((a) => a.read_state === 'unread').map(shape);
          // (the ones already read from the last two weeks, newest first, for the quiet list under them)
          const since = U.addDays(todayStart, -14);
          const read = feed.filter((a) => a.read_state !== 'unread' && U.parse(a.posted_at) >= since).sort((x, y) => U.parse(y.posted_at) - U.parse(x.posted_at)).map(shape);
          finish(unread, unread.length, '', read);
          return;
        }
        // fallback: the activity stream's summary count and whatever unread announcements the stream still carries
        Promise.all([store.activitySummary().catch(() => null), store.activity().catch(() => [])]).then(([summary, stream]) => {
          if (!ctx.alive()) return;
          const ann = (summary || []).find((s) => s.type === 'Announcement');
          if (!ann) {
            unreadCard.remove();
            return;
          }
          const count = Number(ann.unread_count) || 0;
          const unread = (stream || []).filter((a) => a.type === 'Announcement' && a.read_state === false && !seen.has(String(a.id)))
            .map((a) => ({ title: a.title, when: a.updated_at || a.created_at, courseId: String(a.course_id || ''), courseName: a.context_name || '', url: activityUrl(a) }));
          finish(unread, count, count > unread.length ? `${U.plural(count - unread.length, 'more is', 'more are')} not in the recent activity stream` : '');
        });
      });

      // ---- the second row: Overdue, Due tomorrow, Graded this week ----
      const land = (card, count, note, seed) => {
        const valueEl = card.querySelector('.bcv-stat__value');
        if (first && Date.now() - t0 < 2500) U.roll(valueEl, count, { seed });
        else valueEl.textContent = String(count);
        card.querySelector('.bcv-stat__note').textContent = note;
      };
      const overdueSheet = { label: 'Overdue', value: '…', icon: IC.clock, color: '#ff453a', note: 'Loading…', items: [] }; // one object: an open sheet reads it after a clear
      let gradedSheet = { label: 'Graded this week', value: '…', icon: IC.chart, color: '#5856d6', note: 'Loading…', items: [] };
      const overdueCard = stat('Overdue', '…', '', IC.clock, '#ff453a', (from) => openSheet(overdueSheet, from));
      const gradedCard = stat('Graded this week', '…', '', IC.chart, '#5856d6', (from) => openSheet(gradedSheet, from));
      cards.push(overdueCard);
      // Due tomorrow: the planner's due items for the next day, the way Due today reads today's — what
      // tonight is for, one card over from what today is for
      if (planner) {
        const tmPts = dueTomorrow.reduce((s, it) => s + (Number(it.points) || 0), 0);
        cards.push(stat('Due tomorrow', String(dueTomorrow.length), dueTomorrow.length ? `${store.fmtPts(tmPts)} points total` : 'Nothing due tomorrow', IC.clock, '#ff9f0a', (from) => openSheet({
          label: 'Due tomorrow', value: String(dueTomorrow.length), icon: IC.clock, color: '#ff9f0a',
          note: `${store.fmtPts(tmPts)} points across ${U.plural(courseCount(dueTomorrow), 'course')} · ${U.DAYS_LONG[tomorrowStart.getDay()]}, ${U.MONTHS_LONG[tomorrowStart.getMonth()]} ${tomorrowStart.getDate()}`,
          items: [...dueTomorrow].sort(byDate).map(dueRow), empty: 'Nothing is due tomorrow.', lead: 'Still to do',
          recent: recentOf('Already done', doneIn(tomorrowStart, U.addDays(tomorrowStart, 1)).sort(byDate).map(doneRow)),
        }, from)));
      }
      cards.push(gradedCard);
      // (2.98.92) from the kept copy first (W), then from Canvas's answer (Wf): a count that changed is put right without
      // rolling again, and a failed answer leaves the kept count where it is rather than dropping the card
      let shown = ''; // '' · 'kept' · 'fresh'
      let overdue = [], lateIn = []; // (the Overdue list on show: the kept one, then Canvas's)
      const put = (card, count, note, seed, still) => {
        if (!still) land(card, count, note, seed);
        else {
          const valueEl = card.querySelector('.bcv-stat__value');
          if (card._bcvN !== count) { clearInterval(valueEl._bcvRoll); valueEl._bcvRoll = null; delete valueEl.dataset.rolling; valueEl.textContent = String(count); } // (the same count is left to finish its roll)
          card.querySelector('.bcv-stat__note').textContent = note;
        }
        card._bcvN = count;
      };
      const paintOverdue = (still = false) => {
        put(overdueCard, overdue.length, overdue.length ? U.plural(overdue.length, 'not submitted', 'not submitted') : 'Nothing overdue', 6.9, still);
        Object.assign(overdueSheet, {
          value: String(overdue.length), items: overdue, empty: 'Nothing is overdue.', lead: 'Not handed in', recent: recentOf('Handed in late', lateIn),
          note: overdue.length ? 'Past due with nothing handed in' : 'Nothing past its due date without a submission',
        });
      };
      // Each Overdue row has an X: the item is dismissed on Canvas's planner — the same call as the To
      // Do screen's X, so it leaves that list too and every device agrees (workLists reads the rest)
      const clearOverdue = async (o) => {
        await store.dismiss(o.item); // on Canvas: a failure leaves the row where it is
        clearedKeys.add(o.key); // (and it stays cleared when Canvas's answer replaces the kept list)
        const i = overdue.findIndex((x) => x.key === o.key);
        if (i >= 0) overdue.splice(i, 1);
        paintOverdue();
      };
      const show = ([od, gr], fresh) => {
        if (!ctx.alive() || shown === 'fresh') return;
        const again = !!shown;
        if (!od || !gr) { if (!again) { overdueCard.remove(); gradedCard.remove(); } return; }
        shown = fresh ? 'fresh' : 'kept';
        overdue = od.overdue.filter((o) => !clearedKeys.has(o.key));
        lateIn = od.lateIn;
        for (const o of overdue) o.clear = () => clearOverdue(o);
        paintOverdue(again);
        const { graded, earlier, earned, possible } = gr;
        put(gradedCard, graded.length, graded.length ? `${store.fmtPts(earned)} / ${store.fmtPts(possible)} points` : 'No grades posted this week', 9.2, again);
        gradedSheet = {
          label: 'Graded this week', value: String(graded.length), icon: IC.chart, color: '#5856d6', items: graded, empty: 'Nothing has been graded this week.', lead: 'This week', recent: recentOf('Earlier', earlier),
          note: graded.length ? `${store.fmtPts(earned)} of ${store.fmtPts(possible)} points earned · week of ${U.fmtShort(weekStart)}` : `Week of ${U.fmtShort(weekStart)}`,
        };
      };
      if (W !== Wf) Promise.all([W.overdueP, W.gradedP]).then((r) => show(r, false));
      Promise.all([Wf.overdueP, Wf.gradedP]).then((r) => show(r, true));
      for (const c of cards) U.squircle?.(c); // (2.99.80, a beta: Apple's continuous corners on the counters)
      return U.el('bcv-stats', cards);
    }
    let statIndex = 0;
    // (2.99.29) the Mac's shorter words, worn by a wide Dashboard's square counters (app.css), the full ones read aloud
    const STAT_SHORT = { 'Due tomorrow': 'Tomorrow', 'Unread announcements': 'Unread', 'Graded this week': 'Graded' };
    const shortLabel = (el, lbl) => { if (STAT_SHORT[lbl]) el.dataset.short = STAT_SHORT[lbl]; return el; };
    // each counter's slot for the theme's photo (lib/theme.js CARD_SLOTS): sharp at its bottom-right corner, blurred by a curve from there (app.css)
    const STAT_SLOT = { 'Due today': 'today', 'Next 7 days': 'week', 'Unread announcements': 'unread', Overdue: 'overdue', 'Due tomorrow': 'tomorrow', 'Graded this week': 'graded' };
    function stat(lbl, value, note, icon, color, onOpen) {
      const valueEl = U.el('bcv-stat__value', value);
      const i = statIndex++;
      if (!entered && /^\d+$/.test(value)) U.roll(valueEl, Number(value), { seed: i * 2.3 }); // the counter scrambles briefly, then lands on the real count
      const slot = STAT_SLOT[lbl] || null;
      const pic = slot ? BCV.theme.picAt(app.state?.themeImages, slot) : null; // { sharp, blur } (lib/theme.js assets)
      const tint = slot ? app.tintOf?.(slot) : null; // (2.99.118: a colour of its own, from Appearance)
      // the label and the number share the top row (the number on the right, large); the note and the chevron sit below
      const btn = h('button', { type: 'button', class: `bcv-card bcv-stat ${pic ? 'bcv-stat--pic' : ''} ${pic?.ink ? 'has-ink' : ''} ${pic?.scene ? 'is-scene' : ''} ${pic?.plain ? 'bcv-stat--plain' : ''} ${tint ? 'bcv-stat--tint' : ''}`, dataset: slot ? { stat: slot } : {}, style: pic || tint ? { ...(tint ? { '--bcv-stat-tone': tint, '--bcv-accent': tint } : {}), ...(pic ? { ...(pic.ink ? { '--bcv-pic-ink': BCV.theme.picCss(pic.ink), '--bcv-pic-ink-blur': BCV.theme.picCss(pic.inkBlur) } : { '--bcv-pic': BCV.theme.picCss(pic.sharp) }), '--bcv-veil': BCV.theme.veilBase(tint || app.state?.settings?.appearance?.theme?.accent || '', app.state?.themeImages?.tones?.[slot], 0.4), ...BCV.theme.placeVars(BCV.theme.placeOf(app.state?.themeImages, slot)) } : {}) } : null, onclick: (e) => onOpen(e.currentTarget) }, [
        ...(pic ? [h('span', { class: 'bcv-stat__pic', 'aria-hidden': 'true' }), h('span', { class: 'bcv-stat__pic bcv-stat__pic--blur', 'aria-hidden': 'true' }), h('span', { class: 'bcv-stat__pic bcv-stat__pic--veil', 'aria-hidden': 'true' })] : []),
        U.el('bcv-stat__head', [U.svg(icon, { size: 14, stroke: color, width: 1.9 }), shortLabel(U.text('bcv-label bcv-label--inline', lbl, 'span'), lbl), valueEl]),
        U.el('bcv-stat__noterow', [U.text('bcv-stat__note', note, 'span'), U.svg(IC.chevron, { size: 13, stroke: 'var(--bcv-ink3)', width: 2, cls: 'bcv-stat__chev' })]),
      ]);
      // (2.99.69: a press opens it, as on the Mac — no longer a moment's rest on it too)
      return U.enter(btn, 0); // no stagger: the six land together
    }

    /** The detail sheet behind a counter (2.98.45): the counter itself grows, where it stands, into a
     *  taller box holding its list, and folds back into it closing. (2.99.69) As the Mac app's: the box floats over
     *  the page — no dim, no blur, the page left as it is — as tall as its list (up to what the window has room
     *  for), on the Mac's own spring (motion.js morph); a press anywhere outside it folds it back and still does what
     *  it does (on another counter, that one grows as this one folds). With no counter to grow out of it opens in the
     *  middle, as before. */
    function openSheet(def, from = null) {
      const prev = document.querySelector('.bcv-sheet-ov:not(.is-folding)') || document.querySelector('.bcv-sheet-ov');
      if (prev?.bcvReopen && prev.bcvCard === from && prev.classList.contains('is-folding')) { prev.bcvReopen(); return; } // (pressed again as it folds: it opens again from where it is)
      if (prev?.bcvFold && !prev.classList.contains('is-folding')) prev.bcvFold(); // (another counter's box folds back as this one grows)
      else if (prev && !prev.bcvFold) { clearTimeout(prev._bcvFoldT); prev.remove(); } // (a counter's box already folding finishes)
      const card = from && from.getBoundingClientRect && from.isConnected ? from : null;
      const ov = U.el(`bcv-sheet-ov${card ? ' bcv-sheet-ov--card bcv-sheet-ov--float is-far' : ''}`, null, { role: 'dialog', 'aria-label': def.label });
      let folding = false;
      let lastPt = null; // (where the pointer was last seen over the box's layer)
      ov.addEventListener('pointermove', (e) => { lastPt = { x: e.clientX, y: e.clientY }; }, { passive: true });
      let box = null; // (U.cardBox: the box laid out once where it goes, drawn through a clip that grows out of the counter)
      const close = () => {
        if (!card) { BCV.ui.dismiss(ov); return; }
        if (folding || !ov.isConnected) return;
        folding = true;
        document.removeEventListener('pointerdown', outside, true);
        if (sheet.classList.contains('has-pv')) BCV.preview?.close({ gently: true }); // (its preview card goes first)
        U.hoverCool(card, lastPt); // (a pointer still over the counter as the box folds into it does not open it again until it has left)
        ov.classList.add('is-folding', 'is-far'); // (the focus lets go outward as the box folds)
        box.fold(); // (from wherever it is drawn — mid-growth too — back into the counter, its words back to the counter's)
        clearTimeout(ov._bcvFoldT);
        ov._bcvFoldT = setTimeout(() => { ov.remove(); card.classList.remove('is-lifted'); }, U.reducedMotion() ? 0 : 560);
      };
      // pressed again as it folds: the fold is called off and it opens again from where it has got to (never cut off
      // for a new box to grow from nothing, nor the counter left showing through it by the fold's timer)
      ov.bcvCard = card;
      ov.bcvFold = card ? close : null;
      // (2.99.69, the Mac's) a press anywhere but the box (and its preview card, a menu or a toast over it) folds it back;
      // the press goes on to what it was on — the box's layer lets everything else through (app.css .bcv-sheet-ov--float)
      const outside = (e) => {
        if (!ov.isConnected) { document.removeEventListener('pointerdown', outside, true); return; }
        if (folding || ov.contains(e.target) || e.target.closest?.('.bcv-pv, .bcv-menu, .bcv-toast, .bcv-sheet-ov:not(.bcv-sheet-ov--float)')) return;
        close();
      };
      if (card) document.addEventListener('pointerdown', outside, true);
      ov.bcvReopen = () => {
        clearTimeout(ov._bcvFoldT);
        folding = false;
        document.addEventListener('pointerdown', outside, true);
        ov.classList.remove('is-folding', 'is-far');
        card.classList.add('is-lifted');
        box.reopen();
        ov.focus();
      };
      ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
      ov.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;
        if (card && sheet.classList.contains('has-pv')) { BCV.preview?.close(); ov.focus(); return; } // (the preview first, then the box)
        close();
      });
      const sheet = U.el(`bcv-sheet ${card ? 'bcv-sheet--card bcv-sheet--stat is-at-card' : 'bcv-sheet--steady'}`, [
        // (2.99.37, the Mac's box) what it counts on a line of its own — its glyph, its name, the ✕ — then the number,
        // large, with what it means beside it
        U.el('bcv-sheet__head bcv-sheet__head--big', [
          U.el('bcv-sheet__top', [
            h('span', { class: 'bcv-sheet__tile' }, U.svg(def.icon, { size: 19, stroke: def.color, width: 1.9 })),
            U.text('bcv-sheet__label', def.label, 'span'),
            h('button', { type: 'button', class: 'bcv-sheet__close', 'aria-label': 'Close', onclick: close }, U.svg(IC.close, { size: 15, stroke: 'var(--bcv-ink3)', width: 2.2 })),
          ]),
          U.el('bcv-sheet__line', [U.text('bcv-sheet__value', def.value, 'span'), U.text('bcv-sheet__note bcv-pretty', def.note, 'span')]),
        ]),
        // (2.98.28) the list in two: what wants attention (not done, unread) under its own label, then —
        // quieter, set back in grey but still a press away — what else there is from the same span
        U.el('bcv-sheet__list', [
          def.recent ? U.text('bcv-sheet__sec', def.lead || def.label, 'div') : null,
          ...(def.items.length ? def.items.map((i) => rowFor(i)) : [U.empty(def.empty || 'Nothing here.')]),
          def.more ? U.text('bcv-sheet__more', def.more) : null,
          def.recent ? U.el('bcv-sheet__recent', [U.text('bcv-sheet__sec bcv-sheet__sec--quiet', def.recent.label, 'div'), ...def.recent.items.map((i) => rowFor(i, true))]) : null,
        ]),
        card ? null : U.el('bcv-sheet__pvhint', [U.svg(IC.doc, { size: 22, stroke: 'var(--bcv-ink3)', width: 1.7 }), U.text('bcv-sheet__pvhint-t', 'Press an item to preview it here', 'span')]),
      ]);
      // (2.99.72: its glass tinted by the counter's colour, as the Mac's panel — 2.99.77: under a colour of your own, the
      // counter's shade of it)
      const tone = card && document.documentElement.classList.contains('bcv-themed') ? getComputedStyle(card).getPropertyValue('--bcv-stat-tone').trim() : '';
      if (card && (tone || def.color)) sheet.style.setProperty('--bcv-stat-tint', tone || def.color);
      ov.append(sheet);
      // (2.99.37) a press in the box away from its rows puts its preview card away, the box staying
      sheet.addEventListener('pointerdown', (e) => { if (sheet.classList.contains('has-pv') && !e.target.closest('.bcv-sheet__row, .bcv-sheet__qrow, .bcv-sheet__x')) BCV.preview?.close({ gently: true }); });
      // where the box goes: the counter's own corner, as wide as a list wants (the list and the preview
      // side by side once a row is pressed) — (2.99.69) 440px as the Mac's panel is — and as tall as what it holds, or as
      // tall as the window allows, pushed back inside the window
      const M = 16, LIST_W = 440, PV_W = 500;
      /** How tall the box stands at width w with nothing holding it in: its header and its list — (2.99.76) no more than
       *  two and a half of its rows, the half row cut through saying the list scrolls on. Measured in the page (the layer
       *  put in, unseen, for the moment it takes when it is not in yet). */
      function naturalHeight(w) {
        const away = !ov.isConnected;
        if (away) { ov.style.visibility = 'hidden'; document.body.append(ov); }
        const list = sheet.querySelector('.bcv-sheet__list');
        const keep = [sheet.style.width, sheet.style.height, list?.style.maxHeight, list?.style.overflow];
        sheet.style.width = `${Math.round(w)}px`;
        sheet.style.height = 'auto';
        if (list) Object.assign(list.style, { maxHeight: 'none', overflow: 'visible' });
        const at = sheet.getBoundingClientRect();
        let hgt = Math.ceil(at.height);
        const rows = list ? [...list.querySelectorAll(':scope > .bcv-sheet__row, :scope > .bcv-sheet__item, .bcv-sheet__recent > .bcv-sheet__qrow')] : [];
        if (rows.length > 2) {
          const third = rows[2].getBoundingClientRect();
          hgt = Math.min(hgt, Math.ceil(third.top + third.height / 2 - at.top + (at.bottom - list.getBoundingClientRect().bottom)));
        }
        [sheet.style.width, sheet.style.height] = keep;
        if (list) Object.assign(list.style, { maxHeight: keep[2], overflow: keep[3] });
        if (away) { ov.remove(); ov.style.visibility = ''; }
        return hgt;
      }
      /** Where in its row the counter stands: the box hangs from its top-left corner (the left of the row), its top
       *  centre (the middle) or its top-right corner (the right) — growing away from the row's edge, and on the right
       *  its preview opening on the left of the list (2.98.82). */
      function sideOf() {
        const top = card.getBoundingClientRect().top;
        const row = [...document.querySelectorAll('.bcv-stats .bcv-stat')].filter((c) => Math.abs(c.getBoundingClientRect().top - top) < 4).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
        const i = row.indexOf(card);
        if (i < 0 || row.length < 2) { const r = card.getBoundingClientRect(), mid = r.left + r.width / 2; return mid < innerWidth / 3 ? 'start' : mid > (innerWidth * 2) / 3 ? 'end' : 'mid'; }
        return i === 0 ? 'start' : i === row.length - 1 ? 'end' : 'mid';
      }
      function geometry(back) {
        const r = card.getBoundingClientRect();
        if (back) return { x: r.left, y: r.top, w: r.width, h: r.height };
        const vw = innerWidth, vh = innerHeight, room = vw - 2 * M;
        const listW = Math.min(Math.max(r.width, LIST_W), room);
        const split = sheet.classList.contains('is-split');
        const narrow = split && room < listW + 360; // (no room for both: the preview takes the box)
        const w = split ? (narrow ? room : Math.min(listW + PV_W, room)) : listW;
        // (2.99.69, the Mac's) as tall as its list, down to the window's foot from the counter's top — pushed up only where
        // that leaves it shorter than 430px (a short window), never shorter than the counter
        const nat = naturalHeight(listW);
        const hgt = Math.max(Math.min(nat, vh - r.top - M), Math.min(nat, 430, vh - 2 * M), Math.min(r.height, vh - 2 * M));
        const side = sideOf();
        const x = Math.max(M, Math.min(side === 'end' ? r.right - w : side === 'mid' ? r.left + r.width / 2 - w / 2 : r.left, vw - M - w));
        const y = Math.max(M, Math.min(r.top, vh - M - hgt));
        sheet.classList.toggle('is-narrow', narrow);
        sheet.classList.toggle('is-from-end', side === 'end');
        sheet.dataset.from = side;
        sheet.style.setProperty('--bcv-list-w', `${Math.round(listW)}px`);
        return { x, y, w, h: hgt };
      }
      /** A row, and — where the item can be cleared (the Overdue list) — an X beside it: the item goes
       *  one press at a time, the header counts down with it, and a failure leaves the row and says so. */
      function rowFor(i, quiet = false) {
        // (2.99.37, the Mac's rows) the course's colour as a bar down the row's edge, its title, the course and the facts
        // under it in grey, a chevron at the end; pressed, it stays lit while its preview card is up
        const row = h('a', { class: quiet ? 'bcv-sheet__qrow' : 'bcv-sheet__row', href: i.url, onclick: (e) => { e.preventDefault(); if (!BCV.preview?.open(i.url, { host: ov.firstElementChild, anchor: e.currentTarget, course: i.course !== '—' ? i.course : null, color: i.color })) { close(); app.go(i.url); } } }, [
          h('span', { class: 'bcv-sheet__bar', style: { background: i.color } }),
          U.el('bcv-sheet__body', [U.text('bcv-sheet__title bcv-pretty', i.title), U.el('bcv-sheet__meta', [i.course && i.course !== '—' ? U.text('bcv-sheet__course', `${i.course} · `, 'span') : null, i.meta])]),
          U.svg(IC.chevron, { size: 13, stroke: 'var(--bcv-ink3)', width: 2.2, cls: 'bcv-sheet__chev' }),
        ]);
        if (!i.clear || quiet) return row;
        const x = U.iconbtn(IC.close, { size: 24, title: 'Clear', onClick: async (e) => {
          e.preventDefault();
          e.stopPropagation();
          x.disabled = true;
          wrap.classList.add('is-busy');
          try {
            await i.clear();
          } catch {
            wrap.classList.remove('is-busy');
            x.disabled = false;
            U.toast('Couldn’t clear that. Try again.', { error: true });
            return;
          }
          wrap.classList.add('is-gone');
          setTimeout(() => {
            wrap.remove();
            const list = ov.querySelector('.bcv-sheet__list');
            ov.querySelector('.bcv-sheet__value').textContent = def.value;
            ov.querySelector('.bcv-sheet__note').textContent = def.note;
            if (list && !list.querySelector('.bcv-sheet__row')) { const lead = list.querySelector(':scope > .bcv-sheet__sec'); const e = U.empty(def.empty || 'Nothing here.'); if (lead) lead.after(e); else list.prepend(e); }
            if (!folding) box?.relayout(); // (2.99.69: the box takes the height of what is left in it)
            ov.focus(); // the press took the focus with it; Escape still closes the sheet
          }, 220);
        } });
        x.classList.add('bcv-sheet__x');
        x.setAttribute('aria-label', `Clear: ${i.title}`);
        const wrap = U.el('bcv-sheet__item', [row, x]);
        return wrap;
      }
      // (2.98.73) the box is glass: the counter it grew out of is not left standing behind it — hidden while the box
      // is up (app.css: while the overlay is in the page), there again the moment the box has folded back over it;
      // lifted first, so the box is measured from the counter at rest, not raised by the pointer over it
      if (card) { for (const c of document.querySelectorAll('.bcv-stat.is-lifted')) c.classList.remove('is-lifted'); card.classList.add('is-lifted'); }
      // the box is laid out where it goes and drawn only where the counter is, its shadow and the dim with it, before the
      // overlay is in the page: the first frame is the counter, nothing eased in from nought (U.cardBox)
      if (card) { box = U.cardBox({ ov, sheet, card, geometry: () => geometry(false) }); box.start(); }
      document.body.append(ov);
      if (card) {
        // it grows out of the counter: the clip opens from the counter to the whole box, and the counter's icon, label and
        // number glide into the header's own (each first drawn where the counter's is, its size too); a row pressed (the
        // preview's is-split) or the window resized lays it out where it goes again, once, and moves what it holds there
        box.open([
          [sheet.querySelector('.bcv-sheet__value'), card.querySelector('.bcv-stat__value')],
          [sheet.querySelector('.bcv-sheet__label'), card.querySelector('.bcv-stat__head .bcv-label')],
          [sheet.querySelector('.bcv-sheet__tile > svg'), card.querySelector('.bcv-stat__head > svg')],
        ].filter(([a, b]) => a && b));
        const moved = new MutationObserver(() => { if (!ov.isConnected) { moved.disconnect(); return; } if (!folding) box.relayout(); });
        moved.observe(sheet, { attributes: true, attributeFilter: ['class'] });
        const onResize = () => { if (!ov.isConnected) { removeEventListener('resize', onResize); return; } if (!folding) box.relayout(); };
        addEventListener('resize', onResize);
      } else U.morphFrom(sheet, from);
      ov.tabIndex = -1;
      ov.focus({ preventScroll: true });
    }

    // ---- workload ------------------------------------------------------------------
    function workloadBlock() {
      if (!planner || !favs.length) return null;
      // on entry each row floats in and its bar wipes from the left, staggered down the list (mockup 11) — a course
      // with nothing assigned does not: its row arrives as its disclosure opens (an empty bar has nothing to wipe)
      const row = (c, mine, i) => {
        const done = mine.filter((it) => it.submitted).length;
        const pct = mine.length ? Math.round((done / mine.length) * 100) : 0;
        const k = Math.min(i, 6);
        const arrive = !entered && mine.length > 0;
        const fill = h('span', { class: `bcv-work__fill ${arrive ? 'bcv-work__fill--grow' : ''}`, style: { width: `${pct}%`, background: c.color, '--bcv-delay': `${120 + k * 70}ms` } }); // (just after its row)
        return U.el(`bcv-work__row ${arrive ? 'bcv-work__row--in' : ''}`, [
          U.dot(c.color, 'bcv-dot--9'),
          U.text('bcv-work__code bcv-ellip', c.shortName || c.name, 'span'),
          h('span', { class: 'bcv-work__bar' }, fill),
          U.text('bcv-work__count', `${done} / ${mine.length}`, 'span'),
        ], { style: { '--bcv-delay': `${90 + k * 70}ms` } });
      };
      const active = [], idle = [];
      for (const c of favs) {
        const mine = weekAll.filter((it) => it.courseId === c.id);
        (mine.length ? active : idle).push(row(c, mine, mine.length ? active.length : idle.length));
      }
      // Courses with nothing assigned this week fold away under a disclosure, sliding open under its chevron.
      const idleWrap = idle.length ? U.collapsible(U.el('bcv-work__idle', idle), false, 'bcv-work__fold') : null;
      const toggle = idle.length ? h('button', { type: 'button', class: 'bcv-work__more', 'aria-expanded': 'false', onclick: () => {
        const open = !toggle.classList.contains('is-open');
        idleWrap.setOpen(open);
        toggle.setAttribute('aria-expanded', String(open));
        toggle.classList.toggle('is-open', open);
      } }, [U.svg(IC.chevron, { size: 12, stroke: 'var(--bcv-ink3)', width: 2.2, cls: 'bcv-work__more-ic' }), `${U.plural(idle.length, 'course')} with nothing assigned this week`]) : null;
      return U.card(U.el('bcv-work', [
        U.el('bcv-work__head', [U.text('bcv-label bcv-label--inline', `Week of ${U.fmtShort(weekStart)} · workload`, 'span'), U.text('bcv-work__hint', 'Submitted / assigned this week', 'span')]),
        ...active,
        active.length ? null : U.text('bcv-hint', 'Nothing assigned this week.'),
        toggle,
        idleWrap,
      ]), 'bcv-work-card');
    }

    // ---- grades skyline (2.98.90) -----------------------------------------------------------------
    // each course's assignments and group weights: the kept copy's first, then Canvas's (see the top of render)
    let skyLists = null, skyFresh = false, skyGen = 0; // (the last that landed — a redraw paints its windows at once — and whose)
    const skyKeptP = useKept ? ownWeightsP.then((own) => ({ byCourse: keptBy, weights: new Map(favs.map((c) => [c.id, weightMap(own[c.id]) || (c.weighted ? weightMap(kept.get(String(c.id))?.weights) : null)])) })) : null;
    const skyFreshP = Promise.all([freshP, freshWeightsP]).then(([byCourse, weights]) => (byCourse ? { byCourse, weights } : null)).catch(() => null);
    // what the windows show, to tell whether Canvas's answer changed any of them
    const skySig = (data) => favs.map((c) => skyWindows(data.byCourse.find((b) => b.c.id === c.id)?.list, data.weights.get(c.id)).map((r) => `${r.a.id}:${r.band || ''}:${r.free ? 1 : 0}:${r.score ?? ''}`).join(',')).join('|');
    function skylineBlock() {
      if (!favs.length) return null;
      const first = !entered && !U.reducedMotion();
      const drawnAt = performance.now();
      const names = skyNames(favs);
      const TW = favs.length <= 6 ? 46 : favs.length <= 8 ? 40 : 32;
      const cols = favs.map((c, i) => {
        const score = c.score === null || c.score === undefined || c.hideFinal ? null : Number(c.score);
        const th = Math.round(SKY_H * (score === null ? 0.42 : Math.max(0.16, Math.min(1, score / 100))));
        const wins = U.el('bcv-sky__wins');
        const low = U.el('bcv-sky__wins bcv-sky__wins--free'); // (2.98.91: what does not count, on the floors at the street)
        const label = `${c.shortName || c.name}: ${score === null ? 'no score yet' : `${Math.round(score)}%`}`;
        const tower = h('button', {
          type: 'button', class: `bcv-sky__tower ${score === null ? 'is-ghost' : ''} ${first ? 'bcv-sky__tower--rise' : ''}`, title: c.shortName || c.name, 'aria-label': `${label}. Open its grades.`,
          style: { width: `${TW}px`, height: `${th}px`, '--sky-c': c.color, '--bcv-delay': `${120 + Math.min(i, 8) * 70}ms` },
          onclick: () => app.go(`${c.url}/grades`),
        }, [wins, low]);
        const pct = U.text(`bcv-sky__pct ${first ? 'bcv-sky__pct--in' : ''}`, score === null ? '—' : `${Math.round(score)}%`, 'span');
        pct.style.setProperty('--bcv-delay', `${360 + Math.min(i, 8) * 70}ms`); // (as its tower tops out)
        return { c, i, th, wins, low, tower, label, col: U.el('bcv-sky__col', [pct, tower], { dataset: { course: c.id } }) };
      });
      // the windows, as the courses' assignments come (the towers stand before them); returns when the last has faded in
      const paint = (data, fresh) => {
        let end = 0;
        for (const x of cols) {
          const rows = skyWindows(data.byCourse.find((b) => b.c.id === x.c.id)?.list, data.weights.get(x.c.id));
          // (2.98.91) what counts from the top floor down; what does not, in grey, on the floors at the street — one size of
          // window for both, fitted to the tower with room between the two
          const allUp = rows.filter((r) => !r.free), allDown = rows.filter((r) => r.free);
          const f = skyFit(allUp.length, allDown.length, TW - 10, x.th - 7 - (allDown.length ? 7 : 0));
          const up = allUp.slice(0, f.up), down = allDown.slice(0, f.down); // (2.99.68: four across; the rest hidden)
          for (const g of [x.wins, x.low]) {
            g.style.gridTemplateColumns = `repeat(${f.cols}, ${f.s}px)`;
            g.style.gridAutoRows = `${f.s}px`;
            g.style.gap = `${f.g}px`;
          }
          // on entry the windows fade in where they stand, one by one in reading order (2.98.93: no flight, no bounce),
          // once the tower has risen (or at once, if the assignments landed after it had)
          const fade = fresh && !U.reducedMotion();
          const base = fade ? Math.max(0, 120 + Math.min(x.i, 8) * 70 + 300 - (performance.now() - drawnAt)) : 0; // (its tower's .3s rise)
          if (fade) end = Math.max(end, base + rows.length * 45 + 450);
          const pane = (r, k) => h('i', {
            class: `bcv-sky__win ${r.band ? 'is-lit' : ''} ${r.free ? 'is-free' : ''} ${fade ? 'bcv-sky__win--in' : ''}`, dataset: { band: r.band || '' },
            style: {
              ...(r.band ? { '--w': SKY_LIT[r.band] } : {}),
              ...(fade ? { '--wd': `${Math.round(base + k * 45)}ms` } : {}),
            },
            title: `${r.a.name} · ${r.band ? `${store.fmtPts(r.score)} / ${store.fmtPts(r.a.points_possible ?? 0)} (${r.band})` : r.a.submission?.excused ? 'excused' : 'not graded yet'}${r.free ? ' · does not count toward the grade' : ''}`,
          });
          x.wins.replaceChildren(...up.map((r, j) => pane(r, j)));
          x.low.replaceChildren(...down.map((r, j) => pane(r, up.length + j)));
          x.low.hidden = !down.length;
          const lit = rows.filter((r) => r.band && !r.free).length, free = rows.filter((r) => r.free).length;
          x.tower.setAttribute('aria-label', `${x.label}, ${lit} graded, ${rows.length - lit - free} to come${free ? `, ${free} not counted` : ''}. Open its grades.`);
        }
        return performance.now() + end;
      };
      // (2.98.92) the kept copy's windows fade in the moment it is read; Canvas's answer, when it changes any, is put in
      // still once they are in (the same windows are left alone)
      const gen = ++skyGen;
      let onScreen = null, fadeEnd = 0, later = 0;
      const show = (data, fade) => {
        if (!ctx.alive() || gen !== skyGen) return;
        const sig = skySig(data);
        if (sig === onScreen) return;
        const was = onScreen;
        onScreen = sig;
        clearTimeout(later);
        if (was === null) fadeEnd = paint(data, fade);
        else later = setTimeout(() => { if (ctx.alive() && gen === skyGen) paint(data, false); }, Math.max(0, fadeEnd - performance.now()));
      };
      const card = U.card(U.el('bcv-sky', [
        U.el('bcv-sky__head', [
          U.text('bcv-label bcv-label--inline', 'Grades', 'span'),
          h('button', { type: 'button', class: 'bcv-sky__more', onclick: () => app.go('/grades') }, ['Window colour = score', U.svg(IC.chevron, { size: 12, stroke: 'currentColor', width: 2.2 })]),
        ]),
        U.el('bcv-sky__city', cols.map((x) => x.col)),
        U.el('bcv-sky__names', names.map((n) => U.text('bcv-sky__name bcv-ellip', n, 'span'))),
      ]), 'bcv-sky-card');
      if (skyLists) show(skyLists, false);
      if (!skyFresh) {
        if (!skyLists && skyKeptP) skyKeptP.then((d) => { if (!skyFresh) { skyLists = d; show(d, true); } });
        skyFreshP.then((d) => { if (!d) return; skyLists = d; skyFresh = true; show(d, true); });
      }
      return card;
    }

    // ---- list view -----------------------------------------------------------------------
    function listBlock() {
      if (!planner) return U.emptyCard('Your planner could not be loaded.');
      // Completed and submitted items stay in the list, ticked, so they can be unticked — unless
      // the list is asked to hide them, which one small button at its top does and undoes.
      // the same courses as the cards above (the favourites): a course kept off the dashboard stays off its list too
      const upcoming = (planner || []).filter((it) => !it.dismissed && it.type !== 'announcement' && it.date >= todayStart && inSel(it)).sort((a, b) => a.date - b.date);
      if (!upcoming.length) return U.emptyCard('Nothing coming up in the next three weeks.');
      const doneOf = (it) => !!(it.complete || it.submitted);
      const doneN = upcoming.filter(doneOf).length;
      const kept = hideDone ? upcoming.filter((it) => !doneOf(it)) : upcoming;
      // (2.99.41) the Mac's "Coming up" head: the title, how many are left and done, and Hide Completed at its right
      const tools = U.el('bcv-dash__tools bcv-dash__coming', [
        U.h2('Coming up', 'bcv-h2--19'),
        U.text('bcv-dash__count', `${upcoming.length - doneN} to do${doneN ? ` · ${doneN} done` : ''}`, 'span'),
        doneN || hideDone ? U.btn(hideDone ? `Show completed${doneN ? ` · ${doneN}` : ''}` : 'Hide completed', {
          kind: 'xs', icon: IC.check, cls: `bcv-dash__done ${hideDone ? 'is-on' : ''}`,
          title: hideDone ? 'Completed and submitted items are hidden' : 'Hide completed and submitted items',
          onClick: () => { hideDone = !hideDone; store.setPref('dashHideDone', hideDone); renderBody(); },
        }) : null,
      ].filter(Boolean));
      if (!kept.length) return U.el('bcv-col', [tools, U.emptyCard('Everything coming up is done.')].filter(Boolean), { style: { gap: '12px' } });
      const days = new Map();
      for (const it of kept) {
        const k = U.startOfDay(it.date).getTime();
        if (!days.has(k)) days.set(k, []);
        days.get(k).push(it);
      }
      const out = [];
      let shown = 0;
      const first = !entered; // the day groups follow the stat cards in, once; a list drawn again (Hide completed, the view switched back) lands in place
      for (const [k, items] of days) {
        if (shown++ >= 8) break;
        const d = new Date(k);
        const day = U.el('bcv-day', [
          U.el('bcv-day__head', [U.h2(U.dayTitle(d), 'bcv-h2--19'), U.dayNamed(d) ? null : U.text('bcv-day__date', U.fmtLong(d), 'span')]), // (past the week the heading is the date: "Monday, Nov 9", not "Nov 9 · November 9")
          U.card(items.map((it) => plannerRow(it)), 'bcv-card--list'),
        ]);
        out.push(first ? U.enter(day, out.length, 70, 420) : day);
      }
      return U.el('bcv-col', [tools, ...out].filter(Boolean), { style: { gap: '26px' } });
    }
    function plannerRow(it) {
      const pal = it.course ? it.course.palette : U.palette(null, dark);
      let rowEl;
      const isDone = () => it.complete || it.submitted;
      let paint = () => {};
      const circle = h('button', { type: 'button', class: 'bcv-circle', onclick: async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const next = !it.complete;
        paint(next || it.submitted);
        try {
          await store.setComplete(it, next);
          paint(isDone());
          app.refreshCounts();
        } catch (err) {
          paint(isDone());
          U.toast(`Could not update it: ${err.message}`, { error: true });
        }
      } });
      paint = (done) => {
        circle.classList.toggle('is-done', done);
        circle.replaceChildren(...(done ? [U.svg('M6 12l4 4 8-8', { size: 12, stroke: '#fff', width: 2.4 })] : []));
        circle.title = done ? 'Mark not done' : 'Mark done';
        circle.setAttribute('aria-label', `${done ? 'Mark not done' : 'Mark done'}: ${it.title}`);
        rowEl?.classList.toggle('bcv-row--done', done);
      };
      rowEl = U.row([
        circle,
        U.tile(it.icon, { color: pal.text, tint: pal.tint }),
        U.el('bcv-row__body', [
          // the course and the kind, then where the work stands (Missing, Late, Graded, Feedback, New) in the same words as To Do
          // (a task of your own: the course it was given, or just "My task" — never "My task · My task")
          h('div', { class: 'bcv-row__over bcv-row__over--flags' }, [h('span', { text: it.custom ? (it.course ? `${it.course.shortName || it.courseName} · My task` : 'My task') : `${it.courseName} · ${it.kind}${it.isDue ? '' : ' · to-do date'}` }), ...store.workFlags(it).map((st) => U.statusBadge(st)), BCV.plan?.pill(it)]),
          U.text('bcv-row__title bcv-ellip', it.title),
        ]),
        U.el('bcv-row__right', [
          U.text('bcv-row__pts', it.points !== null && it.points !== undefined ? `${store.fmtPts(it.points)} pts` : (it.isDue ? '' : it.kind)),
          U.text('bcv-row__due', it.graded ? 'Graded' : it.submitted && it.isDue ? 'Submitted' : `${it.isDue ? 'Due' : 'At'} ${U.fmtTime(it.date)}`), // (work with a grade is not due, whatever its date)
        ]),
        U.chev(),
      ], { mod: 'bcv-row--p14', href: it.url });
      paint(isDone());
      BCV.plan?.attach(rowEl, it); // (2.99.107) pulled to the right, it is planned (content/app/plan.js)
      return rowEl;
    }

    // ---- recent activity -------------------------------------------------------------------
    async function activityBlock() {
      const wrap = U.card(U.loading('inset', 3), 'bcv-card--list');
      const stream = await store.activity().catch(() => null);
      if (!ctx.alive()) return wrap;
      if (!stream) return U.emptyCard('Recent activity could not be loaded.');
      if (!stream.length) return U.emptyCard('No recent activity.');
      actRows = [];
      wrap.replaceChildren(...stream.slice(0, 30).map((a) => {
        const course = courseMap.get(String(a.course_id));
        const pal = course ? course.palette : U.palette('#5856d6', dark);
        const kind = a.type === 'Submission' ? submissionKind(a) : ACTIVITY_KIND[a.type] || a.type;
        const extra = a.type === 'DiscussionTopic' && a.total_root_discussion_entries ? ` · ${a.total_root_discussion_entries} replies` : '';
        const preview = BCV.utils.htmlToText(a.message || a.latest_messages?.[0]?.message || '', 160).replace(/\s+/g, ' ');
        const url = activityUrl(a);
        const dot = U.dot(isUnread(a) ? '#0a84ff' : 'transparent', 'bcv-act__dot');
        actRows.push({ a, dot });
        const rowEl = U.row([
          dot,
          U.tile(ACTIVITY_ICON[a.type] || IC.doc, { color: pal.text, tint: pal.tint, size: 32, iconSize: 16 }),
          U.el('bcv-row__body', [
            U.el('bcv-row__head', [U.text('bcv-act__title bcv-pretty', a.title || kind, 'span'), U.text('bcv-row__when', U.fmtShort(a.updated_at || a.created_at), 'span')]),
            U.text('bcv-act__kind', `${kind}${extra} · ${course?.name || a.context_name || (a.type === 'Conversation' ? 'Inbox' : '')}`),
            preview ? U.text('bcv-row__preview bcv-row__preview--13 bcv-pretty', preview) : null,
          ]),
        ], { mod: 'bcv-row--p15 bcv-row--top', href: url });
        rowEl.addEventListener('click', (e) => {
          if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return; // new-tab clicks stay native
          e.preventDefault();
          // reading it beside the list counts as opening it, so the unread dot clears either way
          const looked = BCV.preview?.open(url, { anchor: rowEl });
          store.markStreamSeen(a.id).catch(() => {}).then(() => { if (!looked) app.go(url); });
          if (looked) dot.style.background = 'transparent';
        });
        return rowEl;
      }));
      return wrap;
    }
    /** What a submission item is about: the score once it is posted (a held grade is not news yet),
     *  the teacher's comment when that is all there is, else the hand-in itself. */
    function submissionKind(a) {
      const posted = a.posted_at === undefined || a.posted_at !== null;
      const hasScore = (a.score !== null && a.score !== undefined) || (a.grade !== null && a.grade !== undefined && a.grade !== '');
      const comments = Array.isArray(a.submission_comments) ? a.submission_comments.filter((x) => x && (x.comment || x.media_comment)) : [];
      if (posted && hasScore) {
        const possible = a.assignment?.points_possible;
        const score = a.score !== null && a.score !== undefined ? store.fmtPts(a.score) : a.grade;
        const letter = a.grade && a.score !== null && a.score !== undefined && String(a.grade) !== String(a.score) ? ` · ${a.grade}` : '';
        return `Graded · ${score}${possible !== null && possible !== undefined ? ` / ${store.fmtPts(possible)}` : ''}${letter}`;
      }
      if (comments.length) return comments.length === 1 ? 'Comment' : `${comments.length} comments`;
      return 'Submitted';
    }
    function activityUrl(a) {
      if (a.html_url) return a.html_url;
      if (a.type === 'Conversation' && a.conversation_id) return `/conversations?id=${a.conversation_id}`;
      return '/';
    }

    // ---- (2.99.125) Silent mode -------------------------------------------------------------------
    // The Dashboard with nothing on it but what comes next: black, the next piece of work (or event, or task of the
    // student's own) in large type with when it is and its course, and the few after it under it. No head, no counters,
    // no cards; the bar across the top goes up out of view (app.css html.bcv-dash-silent) and the sidebar stays. Kept per site,
    // like Hide completed; Exit Silent Mode, at the top right, puts everything back. (2.99.127) Silent is the whole app's
    // (app.js setSilent): the other screens stay in it, in black and white, until it is left, here or in the account's menu.
    function setSilent(on) {
      silent = on;
      app.setSilent(on, { redraw: false });
      paintSilent();
      renderBody();
      scrollTo(0, 0);
      // (the button pressed is gone with what it was in: the keyboard lands on the one that goes back)
      screen.querySelector(on ? '.bcv-silent__exit' : '.bcv-dash__silent')?.focus({ preventScroll: true });
    }
    // (2.99.126) struck out here: still shown, struck through, while Silent stays up (to put back with a press); gone
    // the next time it is drawn afresh
    const struckHere = new Set();
    /** What is still ahead, soonest first: not done (or struck out here), not handed in, not dismissed, in the courses on
     *  the Dashboard. */
    const silentAhead = (at) => (planner || []).filter((it) => it.date && it.date >= at && (!it.complete || struckHere.has(it.id)) && !it.submitted && !it.graded && !it.excused && !it.dismissed && it.type !== 'announcement' && inSel(it)).sort(byDate);
    /** (2.99.126) An item's words as a press that strikes it out — marked done on Canvas's planner, as the circle on a
     *  list's row does — a line drawn through them and the whole of it dimmed; pressed again, put back. */
    function strikeWords(cls, it) {
      const btn = h('button', { type: 'button', class: 'bcv-silent__strike', dataset: { focusKey: `s:${it.id}` } }, [h('span', { class: cls }, [h('span', { class: 'bcv-silent__words', text: it.title })])]);
      const paint = (on) => {
        btn.closest('.bcv-silent__item')?.classList.toggle('is-struck', on);
        btn.setAttribute('aria-pressed', on ? 'true' : 'false');
        btn.title = on ? 'Done: press to put it back' : 'Press to strike it out';
        btn.setAttribute('aria-label', `${on ? 'Done' : 'Mark done'}: ${it.title}`);
      };
      btn.addEventListener('click', async () => {
        const on = btn.getAttribute('aria-pressed') !== 'true';
        struckHere.add(it.id);
        paint(on);
        try {
          await store.setComplete(it, on);
          app.refreshCounts();
        } catch (err) {
          paint(!!it.complete);
          U.toast(`Could not update it: ${err.message}`, { error: true });
        }
      });
      paint(!!it.complete); // (its item, not built yet, is given its class by the one building it)
      return btn;
    }
    /** "Open", beside the words: the item itself (shown while the pointer is on the item, or the keyboard is). */
    const openLink = (it) => (it.url ? h('a', { class: 'bcv-silent__open', href: it.url, title: `Open ${it.title}`, 'aria-label': `Open ${it.title}`, dataset: { focusKey: `o:${it.id}` }, text: 'Open' }) : null);
    /** "Today", "Tomorrow", "Friday" (within the week), else "November 3" (or the short forms: "Fri", "Nov 3"). */
    const silentDay = (d, at, short = false) => {
      const n = U.dayDiff(d, at);
      if (n === 0) return 'Today';
      if (n === 1) return 'Tomorrow';
      if (n < 7) return (short ? U.DAYS : U.DAYS_LONG)[d.getDay()];
      return short ? U.fmtShort(d) : `${U.MONTHS_LONG[d.getMonth()]} ${d.getDate()}`;
    };
    /** The next one's line: how soon, in words that count down within the day ("Due in 4 h 40 min"; an event "Starts…",
     *  a task of the student's own just "In…"), then the day and time when that is not already said, and its course. */
    function silentWords(it, at) {
      const left = it.date - at;
      const mins = Math.floor((left % 3600000) / 60000);
      const soon = left < 60 * 60000 ? `in ${U.plural(Math.max(1, Math.round(left / 60000)), 'minute')}`
        : left < 24 * 3600000 ? `in ${Math.floor(left / 3600000)} h${mins ? ` ${mins} min` : ''}`
          : '';
      const day = `${silentDay(it.date, at)} at ${U.fmtTime(it.date)}`;
      const verb = it.isDue ? 'Due' : it.type === 'calendar_event' ? 'Starts' : '';
      const lead = verb ? `${verb} ${soon || day.replace(/^(Today|Tomorrow)/, (w) => w.toLowerCase())}` : soon ? `I${soon.slice(1)}` : day;
      const course = it.custom ? (it.course ? `${it.course.shortName || it.courseName} · Your task` : 'Your task') : it.course?.shortName || it.courseName || '';
      return { lead, rest: [soon ? day : null, course].filter(Boolean) };
    }
    function silentBlock(enter) {
      const at = new Date();
      const [next, ...rest] = silentAhead(at);
      let n = 0;
      const piece = (el) => { el.classList.add('bcv-silent__piece'); el.style.setProperty('--bcv-i', n++); return el; };
      const kids = [];
      if (!planner) kids.push(piece(U.text('bcv-silent__title bcv-silent__title--quiet', 'Your planner could not be loaded.')));
      else if (!next) kids.push(piece(U.text('bcv-silent__label', 'Next')), piece(U.text('bcv-silent__title', 'Nothing coming up.')), piece(U.text('bcv-silent__when', 'Nothing is due in the next three weeks.')));
      else {
        const w = silentWords(next, at);
        kids.push(
          piece(U.text('bcv-silent__label', 'Next')),
          h('div', { class: `bcv-silent__item bcv-silent__next${next.complete ? ' is-struck' : ''}` }, [
            piece(strikeWords('bcv-silent__title', next)),
            piece(h('div', { class: 'bcv-silent__when' }, [h('span', { class: 'bcv-silent__soon', text: w.lead }), ...w.rest.map((t) => h('span', { text: ` · ${t}` })), openLink(next)].filter(Boolean))),
          ]),
        );
        const more = rest.slice(0, SILENT_MORE);
        if (more.length) {
          kids.push(piece(h('div', { class: 'bcv-silent__then' }, [
            U.text('bcv-silent__label', 'Then'),
            ...more.map((it) => h('div', { class: `bcv-silent__item bcv-silent__row${it.complete ? ' is-struck' : ''}` }, [
              strikeWords('bcv-silent__rowt', it),
              U.text('bcv-silent__roww', `${silentDay(it.date, at, true)}, ${U.fmtTime(it.date)}`, 'span'),
              openLink(it),
            ].filter(Boolean))),
          ])));
        }
      }
      const exit = h('button', { type: 'button', class: 'bcv-silent__exit', title: 'Back to the whole Dashboard', dataset: { focusKey: 'exit' }, onclick: () => setSilent(false) }, [U.svg(IC.moon, { size: 13, stroke: 'currentColor', width: 2 }), h('span', { text: 'Exit Silent Mode' })]);
      return U.el(`bcv-silent${enter && !U.isStill() ? ' is-entering' : ''}`, [exit, U.el('bcv-silent__in', kids)], { role: 'region', 'aria-label': 'Silent mode: what comes next' });
    }
    // the words count down: drawn again each half minute while it is up, when they say something else (the next one past,
    // "in 5 min" now "in 4 min"), the keyboard kept where it was
    const silentTick = setInterval(() => {
      if (!ctx.alive()) { clearInterval(silentTick); return; }
      if (!silent || document.hidden) return;
      const cur = body.querySelector('.bcv-silent');
      const fresh = silentBlock(false);
      if (cur && cur.textContent === fresh.textContent) return;
      const key = cur?.contains(document.activeElement) ? document.activeElement.dataset?.focusKey : null;
      body.replaceChildren(fresh);
      if (key) fresh.querySelector(`[data-focus-key="${CSS.escape(key)}"]`)?.focus({ preventScroll: true });
    }, 30000);

    let bodyGen = 0; // (the activity view lands after a wait: a view switched to meanwhile is not painted over)
    async function renderBody() {
      const gen = ++bodyGen;
      if (silent) { body.replaceChildren(silentBlock(true)); return; }
      const stats = statsBlock();
      const work = workloadBlock();
      const sky = skylineBlock();
      let viewEl;
      if (view === 'activity') viewEl = await activityBlock();
      else viewEl = listBlock();
      if (!ctx.alive() || gen !== bodyGen) return;
      // (2.98.90) the grades skyline at the workload's left, the two side by side (stacked when narrow)
      const pair = sky || work ? U.el('bcv-dash-pair', [sky, work].filter(Boolean)) : null;
      // (2.99.48) as the Mac lays it out: the view straight under the counters, the grades and the workload in a column of
      // their own beside it on a wide page (app.css), under it on a narrow one
      if (pair) pair.classList.add('bcv-dash-rail');
      body.replaceChildren(...[stats, U.el('bcv-dash-cols', [U.el('bcv-dash-view', [viewEl]), pair].filter(Boolean))].filter(Boolean));
      if (!entered) markArrived();
      entered = true;
    }

    draw();
    // a press on an item we can read opens it beside the list rather than navigating
    BCV.preview?.attach(screen);
    return screen;
  }

  /** Warm what the dashboard waits for beyond the shell's own data: the announcements feed, and
   *  each favourite's assignments and today's events (the Overdue, Graded and Classes counters). */
  async function prefetch() {
    store.announcementsFeed().catch(() => {});
    const favs = await store.favorites().catch(() => []);
    const today = U.startOfDay(new Date());
    await Promise.all([
      ...favs.map((c) => store.assignments(c.id).catch(() => {})),
      favs.length ? store.calendarEvents(today, today, favs.map((c) => `course_${c.id}`)).catch(() => {}) : null,
    ]);
  }

  BCV.screens.dashboard = { render, prefetch, workLists };
})();
