/* The guided setup, drawn over the Canvas page the student is on (the "First-Run Setup" mockup, in
 * a shadow root so Canvas's styles never reach it). An opaque ground, not a scrim: the page behind
 * is not yet configured, so showing it is noise. A word-mark plays first, then three steps with a
 * rail down the left that shows every step and the answer given so far — back is always open,
 * forward is Continue alone, steps ahead read "Not yet" and are really disabled:
 *   1 the courses, read from the enrolments (nothing ticked to start with — the student picks;
 *     unchecked ones stay hidden everywhere: they become the Canvas favourites, the one list every
 *     screen follows) ·
 *   2 grades (a history kept on this device, a goal, a target letter per course) ·
 *   3 what the Dashboard shows first — the List or Recent activity — chosen by looking at miniatures of the real layouts ·
 * then a read-back of what was chosen, and Continue to appearance writes it all at once and loads
 * the page afresh: (2.99.74) Appearance (content/app/appearance.js) over the real Dashboard, dimmed
 * but for what it changes, its bar at the foot — the look, a theme, the courses' colours — then Next:
 * the first course opens, and one sidebar or two is picked with the page itself as the preview; Done
 * brings the guided tour (content/app/welcome.js). On a phone (no sidebar, no dashboard views, no
 * Appearance) the read-back leads into Personalize (content/app/personalize.js) instead, and the
 * dashboard step is left out. Opened by ?bcv=setup (the toolbar popup's Set up, the account sheet
 * on a phone, the app's first launch). (2.99.74: the step that asked whether the courses are listed
 * or open on hover is gone: they are listed.) There is no Skip: an unconfigured install has nothing
 * to show. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  const { h } = BCV.utils;
  const S = BCV.settings;
  const store = BCV.store;
  const html = document.documentElement;

  const CHECK = 'M20 6L9 17l-5-5';
  const GRADES = ['C', 'B', 'B+', 'A-', 'A', 'A+']; // the target letters, lowest on the left (saved as the letter the Grades page reads)
  const PASS_FAIL = 'P/F'; // saved in place of a letter: the course is pass/fail, and stays out of the GPA
  // (2.99.132) the Dashboard's two views: the courses as cards are gone
  const VIEWS = [['list', 'List', 'Everything due, day by day, with a tick.'], ['activity', 'Recent activity', 'Announcements, replies and grades as they arrive.']];
  // the steps, in order, each with its name on the rail; the lists are settled when the card opens (see open())
  const ALL = [
    { key: 'courses', name: 'Your courses', build: courses },
    { key: 'grades', name: 'Grades', build: grades },
    { key: 'dashboard', name: 'Dashboard', build: dashboard },
  ];
  let STEPS = ALL;
  // (a phone has no dashboard views to choose between; the look, the colour and the photos follow in
  // Personalize there — content/app/personalize.js — which the read-back leads into)
  const PHONE_STEPS = ['courses', 'grades'];
  const settleSteps = () => { STEPS = BCV.phone?.active() ? ALL.filter((s) => PHONE_STEPS.includes(s.key)) : ALL; };
  const COPY = {
    courses: ['Which classes are you in?', 'Only select the courses that count towards your GPA.'],
    grades: ['Grades', `${BCV.lms.name} keeps no history. Simpl Courses can, on this device.`],
    dashboard: ['What you see first', 'The list of what is due, or what is new in your courses.'],
    done: ['You’re set', 'Next, the look: light or dark, a colour of your own, photos, and your sidebar.'],
    donePhone: ['You’re set', 'Next, the look: light or dark, a colour of your own, and photos.'],
  };


  let ui = null; // the open overlay: { host, overlay, intro, main, rail, stepLabel, body, foot, hint }
  let st = null;
  const active = () => !!ui;
  const reduced = () => !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const stagger = (nodes, step = 40, cap = 200) => nodes.forEach((n, i) => { n.style.animationDelay = `${Math.min(i * step, cap)}ms`; });
  const gpa2 = (n) => n.toFixed(2);
  const svg = (d, { size = 14, stroke = 'currentColor', width = 2.2, cls = '' } = {}) => {
    const el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.setAttribute('viewBox', '0 0 24 24');
    el.setAttribute('width', size);
    el.setAttribute('height', size);
    el.setAttribute('fill', 'none');
    el.setAttribute('stroke', stroke);
    el.setAttribute('stroke-width', width);
    el.setAttribute('stroke-linecap', 'round');
    el.setAttribute('stroke-linejoin', 'round');
    el.setAttribute('aria-hidden', 'true');
    if (cls) el.setAttribute('class', cls);
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', d);
    el.append(p);
    return el;
  };
  const chosen = () => st.courses.filter((c) => st.favs.has(c.id));
  const label = (c) => (String(st.nicks[c.id] ?? c.nickname ?? '').trim() || c.code);

  // ---- open / close --------------------------------------------------------------------------------
  async function open(app) {
    if (ui) return;
    // The ?bcv=setup that opened this is dropped from the address at once: a reload lands on the
    // page itself, and the welcome comes up on the reloaded page when the steps are done.
    const url = BCV.lms.routeUrl(); // (the interface's own address: on Brightspace its query rides in ?simpl=)
    // Personalize on its own (?bcv=personalize, and the older ?bcv=setup&step=theme): the look, the colour, the photos, for a change later
    const only = url.searchParams.get('bcv') === 'personalize' || (url.searchParams.get('bcv') === 'setup' && url.searchParams.get('step') === 'theme') ? 'personalize' : null;
    // then=appearance (the theme invitation's Personalize): the page after the editor points at the sidebar's Appearance button (welcome.js)
    const then = only && url.searchParams.get('then') === 'appearance' ? 'appearance' : null;
    if (url.searchParams.get('bcv') === 'setup' || url.searchParams.get('bcv') === 'personalize') {
      url.searchParams.delete('bcv');
      url.searchParams.delete('step');
      url.searchParams.delete('then');
      history.replaceState(BCV.app?.navState?.(false) || { bcv: true }, '', BCV.lms.pageFor(url));
      app.state.route = app.parseRoute();
    }
    const settings = await S.get();
    st = {
      app, settings, step: 0, visited: new Set([0]), only, then,
      scanning: false, scanError: null, courses: [], favs: new Set(), nicks: {},
      tracking: true, goal: 4, targets: {}, letters: {},
      dashView: 'list', // the list to start with, whatever Canvas has: the pick here is the student's
      sidebar: settings.appearance?.sidebar || 'one', // (2.99.39) one sidebar, unless two was chosen before
      closing: false,
    };
    settleSteps();
    // a note for the page after install (setup/setup.html), which closes itself once the setup is under way here
    BCV.api.storage.local.set({ 'setup:begun': Date.now() }).catch(() => {});
    const host = h('div', { id: 'bcv-setup' });
    host.setAttribute('data-theme', app.isDark() ? 'dark' : 'light');
    const shadow = host.attachShadow({ mode: 'open' });
    // the word-mark: "Simpl" in three bands sliding in, the dot popping, then the veil goes
    const intro = h('div', { class: 'intro', 'aria-hidden': 'true', html: '<svg viewBox="0 0 304 142" width="356" height="166" class="intro__svg"><defs><clipPath id="bcvBandTop"><rect x="-20" y="6" width="400" height="33"/></clipPath><clipPath id="bcvBandMid"><rect x="-20" y="42" width="400" height="28"/></clipPath><clipPath id="bcvBandLow"><rect x="-20" y="73" width="400" height="62"/></clipPath></defs><g clip-path="url(#bcvBandTop)" class="intro__band intro__band--a"><text x="4" y="98" class="intro__word intro__word--1">Simpl</text></g><g clip-path="url(#bcvBandMid)" class="intro__band intro__band--b"><text x="4" y="98" class="intro__word intro__word--2">Simpl</text></g><g clip-path="url(#bcvBandLow)" class="intro__band intro__band--c"><text x="4" y="98" class="intro__word intro__word--3">Simpl</text></g><circle cx="288" cy="90" r="9" class="intro__dot"/></svg>' });
    const stepLabel = h('span', { class: 'fr__count', id: 'stepLabel' });
    const rail = h('div', { class: 'rail', id: 'rail', role: 'list' });
    const body = h('div', { class: 'fr__body', id: 'body' });
    const hint = h('span', { class: 'fr__hint', id: 'hint' });
    const foot = h('div', { class: 'fr__foot', id: 'foot' });
    const main = h('div', { class: 'fr', id: 'card' }, [
      h('div', { class: 'fr__top' }, [
        h('button', { type: 'button', class: 'fr__brand', title: 'Replay', onclick: () => playIntro(), html: '<svg viewBox="22.9 22.4 75 75" width="20" height="20" aria-hidden="true"><path d="M50.55 24.94L50.27 25.03L46.73 25.11L46.23 25.29L44.82 25.39L44.32 25.57L43.28 25.64L42.95 25.84L42.19 25.91L41.86 26.11L41.05 26.20L40.77 26.38L40.45 26.39L39.36 26.76L39.09 26.94L38.55 27.03L38.32 27.20L37.18 27.57L34.61 28.91L32.18 30.57L30.07 32.50L28.15 34.82L28.00 35.21L27.57 35.68L27.18 36.57L26.77 37.01L26.56 37.50L26.58 37.73L26.01 38.86L26.03 39.09L25.68 39.82L25.08 42.55L25.03 44.27L24.84 45.64L25.03 46.77L25.11 48.68L25.29 49.18L25.39 50.32L25.56 50.55L25.65 51.09L25.84 51.36L26.19 52.59L27.03 54.27L28.41 56.34L30.02 58.05L31.55 59.36L32.41 59.93L32.76 60.05L34.05 61.02L36.68 62.30L36.91 62.29L38.86 63.12L39.09 63.11L40.50 63.67L44.64 64.63L44.86 64.76L51.91 66.11L55.45 66.92L56.05 67.21L56.27 67.20L56.86 67.49L57.09 67.47L57.68 67.76L57.91 67.74L59.05 68.30L59.27 68.29L59.55 68.55L59.82 68.56L60.19 68.91L61.05 69.30L62.32 70.50L62.92 71.27L63.47 72.36L63.56 72.91L63.75 73.18L63.79 76.00L63.38 77.32L63.39 77.55L63.13 78.09L62.16 79.55L61.30 80.41L59.86 81.47L58.23 82.29L56.86 82.65L56.59 82.84L55.85 82.91L55.05 83.15L53.82 83.21L53.32 83.39L49.23 83.39L46.50 83.03L43.92 82.32L43.18 81.92L42.91 81.92L42.64 81.65L42.36 81.64L42.09 81.38L41.82 81.37L40.67 80.50L40.28 80.36L38.82 78.91L38.23 78.17L37.12 75.95L37.02 75.09L36.84 74.86L36.83 74.55L36.68 74.40L23.77 74.39L23.55 74.44L23.47 74.64L23.47 75.36L23.66 75.91L23.75 77.32L23.92 77.77L24.01 78.64L24.21 78.95L24.29 79.73L24.50 80.09L24.57 80.86L25.56 82.73L25.67 83.32L26.10 83.82L26.47 84.55L27.82 86.39L29.86 88.50L30.59 88.95L31.45 89.82L32.49 90.32L33.68 91.22L34.23 91.49L34.45 91.47L34.77 91.76L35.00 91.74L35.41 91.91L36.77 92.62L39.95 93.67L44.09 94.49L44.55 94.47L47.05 94.84L49.59 94.89L54.68 94.84L55.45 94.66L58.64 94.32L59.39 94.09L60.14 94.02L60.36 93.85L61.18 93.76L61.45 93.57L62.23 93.50L63.41 93.01L63.95 92.93L64.36 92.69L64.82 92.64L68.59 90.74L69.91 89.76L70.23 89.65L72.15 88.00L73.77 86.27L74.23 85.55L74.91 84.85L75.59 83.38L76.02 82.91L77.30 79.45L77.85 76.73L77.83 75.73L77.98 74.50L77.93 71.27L77.75 70.77L77.66 69.64L77.49 69.18L77.38 68.27L77.20 68.00L76.84 66.64L75.73 64.42L74.64 62.80L73.03 61.09L72.46 60.73L71.77 60.05L71.10 59.64L70.67 59.23L69.68 58.77L69.27 58.39L67.05 57.28L66.64 57.10L66.41 57.12L65.27 56.56L65.05 56.58L64.41 56.26L62.82 55.74L62.59 55.76L59.82 54.92L57.59 54.51L57.36 54.38L48.95 52.76L45.56 51.77L44.14 51.20L42.50 50.38L42.04 49.95L41.65 49.82L40.18 48.36L39.85 47.86L39.30 46.77L39.02 44.59L39.12 44.23L39.11 43.50L39.40 42.64L39.38 42.41L40.41 40.44L41.47 39.27L42.09 38.76L42.41 38.65L42.91 38.21L44.50 37.41L44.95 37.35L45.36 37.12L46.23 37.02L46.45 36.85L47.59 36.75L48.14 36.56L51.00 36.47L53.82 36.66L55.87 37.14L56.77 37.44L57.95 38.03L58.23 38.04L58.56 38.36L59.41 38.76L60.43 39.59L61.27 40.44L62.08 41.50L62.65 42.64L62.76 43.23L62.93 43.45L63.20 44.50L63.27 45.32L63.41 45.49L76.45 45.52L76.65 45.41L76.57 43.77L76.39 43.23L76.30 41.59L76.10 41.27L75.52 38.95L75.30 38.59L74.92 37.45L74.36 36.33L73.00 34.16L71.64 32.53L69.32 30.33L68.92 30.18L68.45 29.75L68.10 29.64L67.67 29.23L67.28 29.09L66.85 28.68L64.64 27.57L61.18 26.29L58.36 25.63L55.41 25.19Z" class="fr__mark"/><circle cx="89.73" cy="87.0" r="7.56" fill="#0A84FF"/></svg><span>Set up Simpl Courses</span>' }),
        h('span', { class: 'fr__spacer' }),
        stepLabel,
      ]),
      h('div', { class: 'fr__cols' }, [
        rail,
        h('div', { class: 'fr__main' }, [body, foot]),
      ]),
    ]);
    const overlay = h('div', { class: 'overlay overlay--solid', role: 'dialog', 'aria-label': 'Simpl Courses setup' }, [h('main', { class: 'page page--fr' }, [main]), intro]);
    shadow.append(h('style', { text: self.BCV_SETUP_CSS || '' }), overlay);
    ui = { host, overlay, intro, main, rail, stepLabel, body, foot, hint, timers: [] };
    html.classList.add('bcv-setup-open');
    (document.body || html).append(host);
    if (only === 'personalize') personalize({ standalone: true }); // the look, the colour and the photos on their own, in the card's place
    else go(0, 1);
    playIntro();
  }
  /** The dot after "Simpl" sits where the word ends — measured, not drawn at a fixed place: the
   *  word is set in the system's font, and Windows (Segoe UI, Arial) and Linux draw it wider than
   *  the Mac's SF Pro, where the design's 288 sat just past the l and elsewhere lands on it. The
   *  drawing widens to fit, so the mark stays centred. The What's New page shares this. */
  const placeDot = (intro) => BCV.ui?.placeDot?.(intro); // (the one drawing, in ui.js: What's New is always here, the setup is loaded on demand)
  /** The word-mark, then the setup rises under it. Reduced motion goes straight to the setup. */
  function playIntro() {
    if (!ui) return;
    const { intro, main, timers } = ui;
    timers.forEach(clearTimeout);
    timers.length = 0;
    if (reduced()) { intro.hidden = true; main.classList.add('is-in'); return; }
    intro.hidden = false;
    intro.classList.remove('is-fading');
    main.classList.remove('is-in');
    placeDot(intro);
    void intro.offsetWidth; // restart the bands
    timers.push(setTimeout(() => { if (ui) ui.intro.classList.add('is-fading'); }, 1900));
    timers.push(setTimeout(() => { if (ui) { ui.intro.hidden = true; ui.main.classList.add('is-in'); } }, 2340));
  }

  // ---- the shell: the rail, the count, the footer, transitions -----------------------------------
  const isDone = () => st.step === STEPS.length;
  /** What each step has answered so far, in the rail's own words. */
  function answer(key) {
    const picked = chosen().length;
    switch (key) {
      case 'courses': return picked ? `${picked} ${picked === 1 ? 'course' : 'courses'}` : 'None yet';
      case 'grades': { const pf = st.courses.filter((c) => st.favs.has(c.id) && st.targets[c.id] === PASS_FAIL).length; return `${st.tracking ? `Tracking · goal ${gpa2(st.goal)}` : 'Not tracking'}${pf ? ` · ${pf} pass/fail` : ''}`; }
      case 'dashboard': return VIEWS.find(([k]) => k === st.dashView)[1];
      default: return '';
    }
  }
  function paintChrome() {
    const { rail, stepLabel } = ui;
    stepLabel.textContent = isDone() ? 'Ready' : `${st.step + 1} of ${STEPS.length}`;
    const ok = chosen().length > 0;
    rail.replaceChildren(...STEPS.map((s, i) => {
      const activeStep = st.step === i;
      // a step already seen stays open from the rail (its answers are kept); the ones ahead are locked
      const seen = st.visited.has(i);
      const complete = (isDone() || st.step > i || (seen && !activeStep)) && (i > 0 || ok);
      const locked = i > st.step && !seen;
      return h('button', {
        type: 'button', class: `rail__item ${activeStep ? 'is-active' : ''} ${complete ? 'is-done' : ''} ${locked ? 'is-locked' : ''}`,
        dataset: { step: s.key }, role: 'listitem', disabled: locked || null, 'aria-current': activeStep ? 'step' : null,
        onclick: () => { if (!locked && !st.closing) go(i); },
      }, [
        h('span', { class: 'rail__mark' }, complete ? [svg(CHECK, { size: 11, stroke: '#fff', width: 3.2 })] : [h('span', { text: String(i + 1) })]),
        h('span', { class: 'rail__body' }, [h('span', { class: 'rail__name', text: s.name }), h('span', { class: 'rail__answer', text: locked ? 'Not yet' : answer(s.key) })]),
      ]);
    }));
  }
  /** The main column's content changes step: the old one goes, the new one rises. */
  async function transitionTo(build, dir = 1) {
    const { body, foot, hint } = ui;
    if (!reduced() && body.childElementCount) {
      body.style.setProperty('--leave', `${-14 * dir}px`);
      body.classList.add('is-leaving');
      await BCV.ui.afterMotion(body);
      if (!ui) return;
    }
    body.classList.remove('is-leaving');
    body.replaceChildren();
    foot.replaceChildren();
    hint.textContent = '';
    build();
    paintChrome();
    if (reduced()) return;
    body.classList.remove('is-rising');
    void body.offsetWidth;
    body.classList.add('is-rising');
  }
  /** `disabled` may be a function, for a step whose button comes and goes with what is chosen: it is
   *  asked again when the button is released, so a press does not restore a stale answer. */
  function footer({ next = st.step === STEPS.length - 1 ? 'Finish' : 'Continue', onNext, disabled = false, back = st.step > 0 && !isDone() } = {}) {
    const off = () => (typeof disabled === 'function' ? !!disabled() : !!disabled);
    const nextBtn = h('button', { type: 'button', class: 'btn fr__next', id: 'next', disabled: off() || null }, [h('span', { text: next }), svg('M9 6l6 6-6 6', { size: 15, width: 2.4 })]);
    nextBtn.addEventListener('click', async () => {
      if (nextBtn.disabled) return;
      nextBtn.classList.add('is-busy');
      nextBtn.disabled = true;
      try {
        await onNext();
      } catch (e) {
        console.error('[Simpl Courses setup]', e);
      }
      nextBtn.classList.remove('is-busy');
      nextBtn.disabled = off();
    });
    ui.foot.append(...[
      back ? h('button', { type: 'button', class: 'btn btn--ghost fr__back', id: 'back', text: 'Back', onclick: () => go(st.step - 1, -1) }) : null,
      ui.hint,
      nextBtn,
    ].filter(Boolean));
    return nextBtn;
  }
  function go(n, dir = n > st.step ? 1 : -1) {
    st.step = Math.max(0, Math.min(STEPS.length, n));
    st.visited.add(st.step);
    transitionTo(isDone() ? done : STEPS[st.step].build, dir);
  }
  const heading = (key) => [h('h1', { class: 'fr__h1', text: COPY[key][0] }), h('p', { class: 'fr__blurb', text: COPY[key][1] })];

  // ---- 1 · the courses -------------------------------------------------------------------------------
  async function scan() {
    st.scanning = true;
    st.scanError = null;
    try {
      const [all, favs] = await Promise.all([store.courses({ force: true }), store.favorites({ force: true }).catch(() => [])]);
      const favIds = new Set((favs || []).map((c) => String(c.id)));
      const list = (all || []).filter((c) => c.state === 'current').map((c) => ({ id: String(c.id), code: c.code || c.name, name: c.name, originalName: c.originalName || c.name, nickname: c.nickname || '', color: c.color, favorite: !!c.favorite || favIds.has(String(c.id)) }));
      st.courses = list;
      // Nothing is ticked to begin with, whatever Canvas already has starred: this list is what every
      // screen then follows, so it is the student's to choose. Continue stays disabled while nothing
      // is ticked.
      st.favs = new Set();
      for (const c of list) if (!(c.id in st.targets)) st.targets[c.id] = 'A+';
    } catch (e) {
      st.scanError = e?.message || 'The course list could not be read.';
      st.courses = [];
    }
    st.scanning = false;
  }

  function courses() {
    const { body, hint } = ui;
    const head = h('h1', { class: 'fr__h1', text: 'Finding your courses' });
    const sub = h('p', { class: 'fr__blurb', text: 'Reading your enrollments.' });
    const wrap = h('div');
    body.append(head, sub, wrap);
    const nextBtn = footer({ disabled: true, onNext: () => go(1) });
    const sayHint = () => { hint.textContent = st.favs.size ? '' : 'Pick at least one course.'; };

    const ghostList = () => {
      const ghosts = h('div', { class: 'ghosts' }, [0, 1, 2, 3, 4].map(() => h('span', { class: 'ghost' })));
      [...ghosts.children].forEach((g, i) => { g.style.animationDelay = `${i * 130}ms`; });
      const spinner = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      spinner.setAttribute('viewBox', '0 0 50 50'); spinner.setAttribute('width', '15'); spinner.setAttribute('height', '15'); spinner.setAttribute('class', 'spinner');
      spinner.innerHTML = '<circle cx="25" cy="25" r="20" fill="none" stroke="var(--fill)" stroke-width="6"></circle><circle cx="25" cy="25" r="20" fill="none" stroke="#0a84ff" stroke-width="6" stroke-linecap="round" stroke-dasharray="32 100"></circle>';
      return [ghosts, h('div', { class: 'scanning' }, [spinner, h('span', { text: 'Reading enrollments' })])];
    };
    const draw = () => {
      const list = st.courses;
      const count = h('span', { text: `${st.favs.size} of ${list.length} selected` });
      const allBtn = h('button', { type: 'button', class: 'linkbtn', id: 'selectAll', text: st.favs.size === list.length ? 'Clear all' : 'Select all', onclick: () => {
        const all = st.favs.size === list.length;
        st.favs = new Set(all ? [] : list.map((c) => c.id));
        draw();
      } });
      const rows = h('div', { class: 'rows mscroll' }, list.map((c) => {
        const on = st.favs.has(c.id);
        // a nickname is Canvas's own (it shows everywhere, in Canvas too); typed here, saved with the rest
        const nick = h('input', { class: 'row__nick', type: 'text', placeholder: 'Nickname', maxlength: '60', 'aria-label': `Nickname for ${c.originalName}`, value: st.nicks[c.id] ?? c.nickname, oninput: (e) => { st.nicks[c.id] = e.target.value; }, onclick: (e) => e.stopPropagation(), onkeydown: (e) => e.stopPropagation() });
        const row = h('div', { class: `row ${on ? 'is-on' : ''}`, dataset: { course: c.id }, role: 'checkbox', tabindex: '0', 'aria-checked': on ? 'true' : 'false', 'aria-label': c.originalName }, [
          h('span', { class: 'row__box' }, svg(CHECK, { size: 13, stroke: '#fff', width: 3.2 })),
          h('span', { class: 'row__dot', style: { background: c.color } }),
          h('span', { class: 'row__body' }, [h('span', { class: 'row__code', text: c.code }), h('span', { class: 'row__name', text: c.originalName })]),
          nick,
        ]);
        const toggle = () => {
          if (st.favs.has(c.id)) st.favs.delete(c.id); else st.favs.add(c.id);
          const now = st.favs.has(c.id);
          row.classList.toggle('is-on', now);
          row.setAttribute('aria-checked', now ? 'true' : 'false');
          count.textContent = `${st.favs.size} of ${list.length} selected`;
          allBtn.textContent = st.favs.size === list.length ? 'Clear all' : 'Select all';
          nextBtn.disabled = st.favs.size === 0;
          sayHint();
          paintChrome();
        };
        row.addEventListener('click', toggle);
        row.addEventListener('keydown', (e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); toggle(); } });
        return row;
      }));
      stagger([...rows.children], 40);
      head.textContent = COPY.courses[0];
      sub.textContent = COPY.courses[1];
      sub.classList.add('fr__blurb--strong'); // the one thing to get right on this step, said big, bold and blue
      wrap.replaceChildren(...[h('div', { class: 'listhead' }, [count, allBtn]), rows, st.courses.length > 5 ? h('p', { class: 'scrollhint', text: 'Scroll down to see more courses' }) : null].filter(Boolean)); // (replaceChildren writes a null out as the word)
      nextBtn.disabled = st.favs.size === 0;
      sayHint();
      paintChrome();
    };
    const drawEmpty = () => {
      head.textContent = st.scanError ? 'The courses could not be read' : 'No active courses';
      sub.textContent = st.scanError ? st.scanError : `Between terms? ${BCV.lms.name} lists nothing active right now.`;
      sub.classList.remove('fr__blurb--strong');
      wrap.replaceChildren(h('div', { class: 'empty' }, [
        h('span', { text: st.scanError ? `Check that you are signed in to ${BCV.lms.name}, then try again.` : 'You can finish setup now and choose courses later on the Courses page.' }),
        h('button', { type: 'button', class: 'btn btn--sm', text: 'Try again', onclick: run }),
      ]));
      nextBtn.disabled = false;
      hint.textContent = '';
    };
    async function run() {
      head.textContent = 'Finding your courses';
      sub.textContent = 'Reading your enrollments.';
      wrap.replaceChildren(...ghostList());
      const t0 = Date.now();
      await scan();
      await new Promise((r) => setTimeout(r, Math.max(0, 450 - (Date.now() - t0)))); // the skeleton never flashes
      if (!ui || st.step !== 0) return;
      if (st.courses.length) draw(); else drawEmpty();
    }
    if (st.courses.length) draw(); else run();
  }

  // ---- 2 · grades ------------------------------------------------------------------------------------
  function grades() {
    const { body } = ui;
    const picked = chosen();
    const trackSwitch = h('button', { type: 'button', class: `switch ${st.tracking ? 'is-on' : ''}`, id: 'track', role: 'switch', 'aria-checked': st.tracking ? 'true' : 'false', 'aria-label': 'Keep a history' }, h('span', { class: 'switch__knob' }));
    const goalVal = h('span', { class: 'stepper__val', id: 'goal', text: gpa2(st.goal) });
    const tick = () => { goalVal.classList.remove('is-tick'); void goalVal.offsetWidth; goalVal.classList.add('is-tick'); };
    const goalRow = h('div', { class: `fr__line ${st.tracking ? '' : 'is-hidden'}`, id: 'goalPanel' }, [
      h('span', { class: 'fr__linebody' }, [h('span', { class: 'fr__linet', text: 'GPA goal' })]),
      h('div', { class: 'stepper' }, [
        h('button', { type: 'button', text: '−', 'aria-label': 'Lower the goal', onclick: () => { st.goal = Math.max(0, Math.round((st.goal - 0.05) * 100) / 100); goalVal.textContent = gpa2(st.goal); tick(); paintChrome(); } }),
        goalVal,
        h('button', { type: 'button', text: '+', 'aria-label': 'Raise the goal', onclick: () => { st.goal = Math.min(4, Math.round((st.goal + 0.05) * 100) / 100); goalVal.textContent = gpa2(st.goal); tick(); paintChrome(); } }),
      ]),
    ]);
    trackSwitch.addEventListener('click', () => {
      st.tracking = !st.tracking;
      trackSwitch.classList.toggle('is-on', st.tracking);
      trackSwitch.setAttribute('aria-checked', st.tracking ? 'true' : 'false');
      goalRow.classList.toggle('is-hidden', !st.tracking);
      paintChrome();
    });
    // the target rows carry the nickname, which is step 1 taking effect; a Pass/Fail switch on each
    // takes the letter scale away (the course counts for nothing in the GPA, and there is no letter
    // to aim at), and the letter it had comes back when the switch goes off
    const targets = picked.map((c) => {
      const pf = st.targets[c.id] === PASS_FAIL;
      const seg = h('div', { class: 'seg', hidden: pf }, GRADES.map((letter) => h('button', { type: 'button', class: `seg__b ${(pf ? st.letters[c.id] : st.targets[c.id]) === letter ? 'is-on' : ''}`, text: letter, onclick: (e) => {
        st.targets[c.id] = letter;
        st.letters[c.id] = letter;
        [...e.currentTarget.parentNode.children].forEach((b) => b.classList.toggle('is-on', b === e.currentTarget));
      } })));
      const pfSwitch = h('button', { type: 'button', class: `switch switch--sm target__pf ${pf ? 'is-on' : ''}`, role: 'switch', 'aria-checked': pf ? 'true' : 'false', 'aria-label': `${label(c)} is pass/fail` }, h('span', { class: 'switch__knob' }));
      const pfLabel = h('span', { class: 'target__pflabel', text: 'Pass/Fail' });
      pfSwitch.addEventListener('click', () => {
        const on = st.targets[c.id] !== PASS_FAIL;
        if (on) { st.letters[c.id] = GRADES.includes(st.targets[c.id]) ? st.targets[c.id] : 'A+'; st.targets[c.id] = PASS_FAIL; }
        else st.targets[c.id] = st.letters[c.id] || 'A+';
        seg.hidden = on;
        pfSwitch.classList.toggle('is-on', on);
        pfSwitch.setAttribute('aria-checked', on ? 'true' : 'false');
        paintChrome();
      });
      return h('div', { class: 'target', dataset: { course: c.id } }, [
        h('span', { class: 'row__dot', style: { background: c.color } }),
        h('span', { class: 'target__code', text: label(c) }),
        seg,
        h('span', { class: 'target__pfwrap' }, [pfLabel, pfSwitch]),
      ]);
    });
    stagger(targets, 40);
    body.append(
      ...heading('grades'),
      h('div', { class: 'fr__lines' }, [
        h('div', { class: 'fr__line' }, [
          h('span', { class: 'fr__linebody' }, [h('span', { class: 'fr__linet', text: 'Keep a history' }), h('span', { class: 'fr__lines2', text: 'One snapshot a day, on this device only.' })]),
          trackSwitch,
        ]),
        goalRow,
      ]),
      h('div', { class: 'kicker', text: 'Aiming for' }),
      h('div', { class: 'targets mscroll' }, targets.length ? targets : [h('div', { class: 'empty', text: 'No courses chosen: nothing to aim at yet.' })]),
    );
    footer({ onNext: () => go(st.step + 1) });
  }

  // ---- 3 · what you see first ------------------------------------------------------------------------
  /** A tile is a miniature of the real layout drawn from the student's own course colours — the
   *  words alone do not say what the difference is. The frame, the badge and the word all carry
   *  the selected state, so colour is never the only sign. */
  function tile({ dataset, on, title, why, mini, pick }) {
    const t = h('button', { type: 'button', class: `tile ${on ? 'is-on' : ''}`, dataset, 'aria-pressed': on ? 'true' : 'false', onclick: pick }, [
      h('span', { class: 'tile__frame' }, mini),
      h('span', { class: 'tile__foot' }, [
        h('span', { class: 'tile__body' }, [h('span', { class: 'tile__t', text: title }), h('span', { class: 'tile__s', text: why })]),
        h('span', { class: 'tile__state' }, [h('span', { class: 'tile__label', text: on ? 'Selected' : 'Choose' }), h('span', { class: 'tile__badge' }, svg(CHECK, { size: 11, stroke: '#fff', width: 3.2 }))]),
      ]),
    ]);
    return t;
  }
  const swatches = () => {
    const cs = chosen().map((c) => c.color).filter(Boolean);
    const base = ['#34c759', '#30b0c7', '#c8901c', '#ff9500'];
    return [0, 1, 2, 3].map((i) => cs[i] || base[i]);
  };
  const bar = (color, { w = '100%', hgt = 5 } = {}) => h('span', { class: 'mini__bar', style: { background: color, width: w, height: `${hgt}px` } });
  const dot = (color, size = 10, hollow = false) => h('span', { class: 'mini__dot', style: hollow ? { width: `${size}px`, height: `${size}px`, border: `1.5px solid ${color}` } : { width: `${size}px`, height: `${size}px`, background: color } });
  function dashboard() {
    const { body } = ui;
    const [a, b, c, d] = swatches();
    const minis = {
      list: () => [h('span', { class: 'mini mini--col' }, [[a, true], [b, false], [c, true], [d, true]].map(([col, hollow]) => h('span', { class: 'mini__row' }, [dot(col, 10, hollow), bar(col)])))],
      activity: () => [h('span', { class: 'mini mini--col mini--feed' }, [[a, '60%'], [c, '45%'], [d, '70%']].map(([col, w]) => h('span', { class: 'mini__row' }, [dot(col, 14), h('span', { class: 'mini__stack' }, [bar(col, { hgt: 4 }), h('span', { class: 'mini__bar mini__bar--faint', style: { width: w } })])])))],
    };
    let tiles;
    const draw = () => {
      tiles = VIEWS.map(([key, title, why]) => tile({ dataset: { view: key }, on: st.dashView === key, title, why, mini: minis[key](), pick: () => { st.dashView = key; draw(); paintChrome(); } }));
      grid.replaceChildren(...tiles);
    };
    const grid = h('div', { class: 'tiles tiles--2' });
    draw();
    body.append(...heading('dashboard'), grid);
    footer({ onNext: () => go(st.step + 1) });
  }

  // ---- ready: the read-back, then Open Canvas writes it all --------------------------------------------
  function done() {
    const { body } = ui;
    const picked = chosen().length;
    const rows = [
      ['Courses shown', `${picked} of ${st.courses.length}`],
      ['Grade history', st.tracking ? `On · goal ${gpa2(st.goal)}` : 'Off'],
      ...(STEPS.some((s) => s.key === 'dashboard') ? [['Dashboard', answer('dashboard')]] : []),
    ];
    body.append(
      ...heading(BCV.phone?.active() ? 'donePhone' : 'done'),
      h('div', { class: 'summary' }, rows.map(([k, v]) => h('div', { class: 'summary__row' }, [h('span', { class: 'summary__k', text: k }), h('span', { class: 'summary__v', text: v })]))),
    );
    footer({ next: 'Continue to appearance', back: true, onNext: () => finish() });
  }

  /** Everything the steps decided, written at once, where the screens read it: favourites through
   *  Canvas (the one list every screen follows), the grade preferences under this host, the
   *  dashboard view on the Canvas profile, the sidebar choice in the settings, and the "done" flags
   *  the popup and the every-page check read. Then the page reloads: it comes back with everything
   *  in place (the shell, the sidebar list and the dashboard view are all read at boot) and the
   *  welcome, armed before the reload, on it. The card stays up until the new page arrives.
   *  There is no other way out: the card is only done when the steps are. */
  /** Personalize (content/app/personalize.js) in this overlay, in the setup card's place: after the
   *  read-back, or on its own. Its Open Canvas loads the page afresh — with the welcome on it when
   *  it followed the setup. */
  function personalize({ standalone }) {
    const page = ui.overlay.querySelector('.page--fr');
    const then = st.then; // (the pointer at Appearance, when the theme invitation asked for it: armed as the editor's Open Canvas reloads)
    return BCV.personalize.open({ app: st.app, host: ui.host, page, standalone, onDone: async () => {
      if (then === 'appearance') { try { await BCV.welcome?.arm?.('appearance'); } catch { /* the page reloads all the same */ } }
      reloadClean();
    } });
  }
  /** A fresh load of this page, without the setup's own parameter (which would open the card again):
   *  a navigation to the address itself, and a plain reload after it should the first not take. */
  function reloadClean() {
    let next = location.href;
    try {
      const u = BCV.lms.routeUrl();
      u.searchParams.delete('bcv'); u.searchParams.delete('step'); u.searchParams.delete('then');
      next = BCV.lms.pageFor(u);
      history.replaceState(null, '', next);
    } catch { /* the address is left as it is */ }
    setTimeout(() => { try { location.reload(); } catch { /* the navigation below is under way */ } }, 1500);
    location.replace(next);
  }
  async function finish() {
    if (!st || st.closing) return;
    st.closing = true;
    try {
      await store.setPref('setupDone', true);
      const [targetsPref] = await Promise.all([store.pref('gradeTargets')]);
      const targets = { ...((targetsPref && typeof targetsPref === 'object') ? targetsPref : {}) };
      for (const c of st.courses) if (st.favs.has(c.id)) targets[c.id] = GRADES.includes(st.targets[c.id]) || st.targets[c.id] === PASS_FAIL ? st.targets[c.id] : 'A+';
      await Promise.all([
        st.tracking ? store.setPref('gpaGoal', st.goal) : null, // (the goal is asked with tracking: off, it was never shown, so none is set)
        store.setPref('gpaTracking', st.tracking ? { priorGpa: null, priorCourses: 0, since: new Date().toISOString().slice(0, 10) } : null),
        store.setPref('gradeTargets', targets),
        S.update({ appearance: { sidebar: st.sidebar } }).catch(() => {}), // (2.99.39: a new install has one sidebar, never the chooser; 2.99.74: Appearance's Next asks one or two. Where the courses sit is no longer asked: listed, as the settings have it)
        STEPS.some((s) => s.key === 'dashboard') ? store.setDashboardView(st.dashView).catch(() => {}) : Promise.resolve(),
      ]);
      const changes = st.courses.filter((c) => c.favorite !== st.favs.has(c.id));
      for (const c of changes) await store.setFavorite(c.id, st.favs.has(c.id)).catch(() => {});
      const renamed = st.courses.filter((c) => c.id in st.nicks && String(st.nicks[c.id]).trim() !== (c.nickname || ''));
      for (const c of renamed) await store.setNickname(c.id, st.nicks[c.id]).catch(() => {});
      // the version installed is seen: What's new is for updates, never for a fresh install
      let installed = null;
      try { installed = BCV.api.runtime.getManifest().version || null; } catch { /* no version to note */ }
      await BCV.api.storage.local.set({ 'setup:done': true, 'setup:offered': true, ...(installed ? { 'whatsnew:seen': installed } : {}) });
    } catch (e) {
      console.error('[Simpl Courses setup]', e);
    }
    if (BCV.welcome) await BCV.welcome.arm().catch(() => {}); // armed: the reloaded page runs the guided tour
    // (2.99.74) then the look, the colour, the photos and the sidebar: Appearance, over the real Dashboard of the page
    // loaded afresh (app.js: owed until its Done, so a reload — a new look is one — comes back into it); the card stays
    // up until the new page arrives. A phone keeps Personalize, in this same overlay, whose Open Canvas loads the page.
    if (!BCV.phone?.active() && BCV.appearance) {
      await BCV.appearance.arm().catch(() => {});
      reloadClean();
      return;
    }
    st.closing = false;
    await personalize({ standalone: false });
  }

  BCV.setup = { open, active, placeDot };
})();
