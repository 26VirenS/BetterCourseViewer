/* Grades tab, drawn to the mockup: one card with the nested rings (outer =
 * total, one ring per assignment group with graded work, 0%-weight rings
 * stippled) beside the total, a By-group legend and the weight bar, then
 * the assignment list. What-if mode recolours it all gray and never leaves
 * the browser; in it an assignment can be made up and put in any group (a
 * category), counted there with the group's weight. Pressing a group (its legend row, its weight, its ring) picks
 * it out: its ring, weight and assignments stay, the rest steps back. Each
 * graded assignment wears its letter, and the By letter slider (All · A · B ·
 * C · D · F) lists one letter's work alone. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  const { h } = BCV.utils;
  const U = BCV.ui;
  const IC = BCV.IC;
  const store = BCV.store;
  const NS = 'http://www.w3.org/2000/svg';

  const whatIfState = new Map(); // courseId -> { on, values, added: [{ id, groupId, name, possible }], seq, addGroup }

  async function render(ctx, shell) {
    const c = shell.course;
    const dark = shell.dark;
    const b = U.el('bcv-body bcv-body--course-cols');
    b.append(U.loading());
    const groups = await store.assignmentGroups(c.id, { maxAge: store.freshness.grades }).catch(() => null); // never a score older than the freshness: a tool may have posted one since
    if (!ctx.alive()) return b;
    if (!groups) return b.replaceChildren(U.errorBox('Grades could not be loaded.')) || b;
    const st = whatIfState.get(c.id) || { on: false, values: {}, added: [], seq: 0, addGroup: null };
    whatIfState.set(c.id, st);
    // the course's groups, as the what-if's "add an assignment" offers them (the categories the grade is weighted by)
    const cats = groups.map((g) => ({ id: String(g.id), name: g.name, weight: Number(g.group_weight) || 0 }));
    const whatIfAllowed = (await store.pref('whatIfScores', true)) !== false; // Settings → Grades → Show what-if scores
    if (!whatIfAllowed) st.on = false;
    // (2.98.59) the student's own weights for this course — a percent per group, from the syllabus,
    // for a course Canvas leaves unweighted or weighs another way — kept in the site's preferences
    // by course id and never sent to Canvas; the rings, the total and the GPA page follow them
    const ownPref = await store.pref('gradeWeights', {});
    let own = ownPref && typeof ownPref === 'object' && ownPref[c.id] && typeof ownPref[c.id] === 'object' && Object.keys(ownPref[c.id]).length ? { ...ownPref[c.id] } : null;
    const wEdit = { on: false, vals: {}, focus: false };
    let focusId = null;
    // the group picked out (U.groupPicker), kept across what-if redraws; the list's header says which
    const pickSt = { pick: null };
    const bandSt = { band: 'all' }; // the By letter slider's stop, kept across redraws
    let gm = null;
    const pickNote = h('span', { class: 'bcv-group__sub bcv-ml-auto bcv-gr__picknote' });
    function notePick(pick) {
      // in what-if mode the group pressed is the one a made-up assignment goes into
      const addSel = b.querySelector('.bcv-wfadd__group');
      if (pick && addSel && addSel.value !== pick && [...addSel.options].some((o) => o.value === pick)) { addSel.value = pick; addSel.dispatchEvent(new Event('change')); }
      const name = pick && gm ? (gm.legend.find((r) => r.id === pick)?.label ?? gm.ungraded.find((u) => u.id === pick)?.name) : null;
      if (!name) { pickNote.replaceChildren('By group, each by due date'); return; }
      const n = gm.rows.filter((r) => r.groupId === pick).length;
      pickNote.replaceChildren(h('button', { type: 'button', class: 'bcv-gr__pickchip', 'data-pick': '', style: { '--bcv-grp': colorOf(pick) }, 'aria-label': `Showing ${name}; show every assignment` }, [
        h('span', { class: 'bcv-gr__pickdot' }),
        U.text('bcv-gr__pickname', `${name} · ${U.plural(n, 'assignment')}`, 'span'),
        U.text('bcv-gr__pickall', 'Show all', 'span'),
      ]));
    }
    const colorOf = (id) => gm?.legend.find((r) => r.id === id)?.color || gm?.weightBar.find((w) => w.id === id)?.color || null;
    const picker = U.groupPicker(b, pickSt, { onChange: notePick });

    function draw() {
      gm = store.gradeModel(groups, c, st.values, st.on, dark, st.added, { ownWeights: own });
      const parts = [];
      if (st.on) {
        parts.push(U.el('bcv-banner', [
          U.svg(IC.warn, { size: 24, stroke: 'var(--bcv-red)', width: 2, style: { flex: 'none' } }),
          h('div', { style: { flex: '1', minWidth: '200px' } }, [U.text('bcv-banner__title', 'This is not your actual score.'), U.text('bcv-banner__sub', 'What-if mode — your real scores are loaded in; edit any of them, or add an assignment to a category, to test outcomes. Nothing is saved or sent to your instructor.')]),
          U.btn('Clear all what-if scores', { kind: 'danger', onClick: () => { st.values = {}; st.added = []; draw(); } }),
        ]));
      }

      // ---- rings + total ---------------------------------------------------------
      const svg = ns('svg');
      svg.setAttribute('viewBox', '0 0 160 160');
      svg.setAttribute('class', 'bcv-rings__svg');
      if (gm.stipples.length) {
        const defs = ns('defs');
        for (const p of gm.stipples) {
          const pat = ns('pattern');
          pat.setAttribute('id', p.id);
          pat.setAttribute('patternUnits', 'userSpaceOnUse');
          pat.setAttribute('width', '3');
          pat.setAttribute('height', '3');
          const dot = ns('circle');
          dot.setAttribute('cx', '1.5');
          dot.setAttribute('cy', '1.5');
          dot.setAttribute('r', '0.72');
          dot.setAttribute('fill', p.color);
          pat.append(dot);
          defs.append(pat);
        }
        svg.append(defs);
      }
      // each group's ring is that group's (pressed, it picks the group out); the outer one is the total
      const ringOf = (el, r) => {
        el.setAttribute('data-group', r.id || 'total');
        if (r.id) {
          el.setAttribute('data-pick', r.id);
          const t = ns('title');
          t.textContent = gm.legend.find((x) => x.id === r.id)?.label || '';
          el.append(t);
        }
        return el;
      };
      for (const r of gm.rings) svg.append(ringOf(circle(r.r, r.track, null, null, r.w), r));
      for (const r of gm.rings) svg.append(ringOf(circle(r.r, r.arc, r.cap, r.dash, r.w), r));
      const center = U.el('bcv-gr__center', [
        U.text('bcv-gr__label', gm.center.label),
        h('span', { class: 'bcv-gr__total', style: { color: gm.center.color }, text: gm.center.value }),
        U.text('bcv-gr__note bcv-pretty', gm.center.note),
        whatIfAllowed ? h('button', { type: 'button', class: `bcv-whatif-btn ${st.on ? 'is-on' : ''}`, text: st.on ? 'Exit what-if mode' : 'Try what-if scores', onclick: () => { st.on = !st.on; draw(); } }) : null,
      ]);

      // ---- by group ------------------------------------------------------------------
      const legendRow = (r) => U.el('bcv-legend__row', [
        h('span', { class: 'bcv-legend__dot', style: r.zero
          ? { background: `radial-gradient(${r.color} 34%, transparent 36%) 0 0 / 2.4px 2.4px` }
          : (r.ringed ? { background: r.color } : { background: 'transparent', border: `1.5px solid ${r.color}` }) }),
        U.el('bcv-legend__body', [U.text('bcv-legend__label', r.label, 'span'), U.text('bcv-legend__detail', r.detail, 'span')]),
        U.text('bcv-legend__weight', r.weightText, 'span'),
        U.text(`bcv-legend__value ${r.zero ? 'bcv-legend__value--muted' : ''}`, r.value, 'span'),
      ], U.groupAttrs(r.id, r.color, { pick: true, name: r.label }));
      const ungradedRow = (u) => U.el('bcv-legend__row bcv-legend__row--ungraded', [
        h('span', { class: 'bcv-legend__dot' }),
        U.el('bcv-legend__body', [U.text('bcv-legend__label bcv-ungraded__name', u.name, 'span'), U.text('bcv-legend__detail', 'Nothing graded yet — no ring', 'span')]),
        U.text('bcv-legend__weight', u.weightText, 'span'),
        U.text('bcv-legend__value', '—', 'span'),
      ], U.groupAttrs(u.id, null, { pick: true, name: u.name }));
      const byGroup = U.el('bcv-gr__sec', [
        U.text('bcv-gr__h', 'By group'),
        ...gm.legend.map(legendRow),
        ...gm.ungraded.map(ungradedRow),
        gm.legend.length || gm.ungraded.length ? null : U.text('bcv-gr__note', 'No assignment groups in this course.'),
      ]);

      // ---- how the grade is weighted ------------------------------------------------
      // (2.98.59) and a button to weight the groups yourself, from the syllabus; the editor takes the section's place
      let weightsSec;
      const ownBtn = h('button', { type: 'button', class: `bcv-gr__ownbtn ${own ? 'is-on' : ''}`, text: own ? 'Edit my weights' : 'Use my own weights', title: `Weight the groups yourself, from the syllabus — on this device only, never sent to ${BCV.lms.name}`, onclick: () => {
        wEdit.on = true;
        wEdit.focus = true;
        wEdit.vals = Object.fromEntries(groups.map((g) => [String(g.id), own ? (own[String(g.id)] ?? 0) : (Number(g.group_weight) || 0)]));
        draw();
      } });
      if (wEdit.on) weightsSec = weightEditor();
      else if (gm.weighted) {
        weightsSec = U.el('bcv-gr__sec bcv-gr__sec--w', [
          U.el('bcv-gr__hrow', [U.text('bcv-gr__h', 'How the grade is weighted', 'span'), U.text('bcv-gr__hsub', gm.own ? `${gm.weightSum}% · your own weights` : `${gm.weightSum}% of final grade`, 'span')]),
          gm.weightBar.length ? U.el('bcv-wbar', gm.weightBar.map((w) => { const ga = U.groupAttrs(w.id, w.color, { pick: true, name: w.name }); return h('div', { ...ga, class: `bcv-wbar__seg ${w.graded ? '' : 'bcv-wbar__seg--ungraded'}`, style: { ...ga.style, flex: `${w.weight} 1 0`, background: w.color || '' }, title: `${w.name} · ${w.weight}%` }); })) : null,
          U.el('bcv-wbar__rows', gm.weightBar.map((w) => U.el('bcv-wbar__row', [
            h('span', { class: `bcv-wbar__dot ${w.graded ? '' : 'bcv-wbar__dot--ungraded'}`, style: { background: w.color || '' } }),
            U.text('bcv-wbar__name', w.name, 'span'),
            U.text('bcv-wbar__w', `${w.weight}% of grade`, 'span'),
            U.text(`bcv-wbar__score ${w.graded ? '' : 'bcv-wbar__score--ungraded'}`, w.scoreLabel, 'span'),
          ], U.groupAttrs(w.id, w.color, { pick: true, name: w.name })))),
          gm.weightBar.length ? null : U.text('bcv-gr__wnote bcv-pretty', 'No assignment group carries weight yet.'),
          gm.weightNote ? h('p', { class: 'bcv-gr__wnote bcv-pretty', text: gm.weightNote }) : null,
          gm.own ? h('p', { class: 'bcv-gr__wnote bcv-gr__wnote--own bcv-pretty', text: `Your own weights, from the syllabus — not your instructor’s. They live on this device and never reach ${BCV.lms.name}.` }) : null,
          ownBtn,
        ]);
      } else {
        weightsSec = U.el('bcv-gr__sec', [
          U.text('bcv-gr__h', 'How the grade is weighted'),
          h('p', { class: 'bcv-gr__wnote bcv-pretty', text: 'This course does not weight assignment groups: the total is points earned over points possible.' }),
          ownBtn,
        ]);
      }
      /** The editor: a percent per group (every group, Canvas's figure beside it when it has one),
       *  the sum kept in view, Save / Cancel, and a way back to Canvas's weights once your own are on. */
      function weightEditor() {
        const num = (v) => { const n = parseFloat(String(v).replace(/[^0-9.]/g, '')); return Number.isFinite(n) && n >= 0 ? n : 0; };
        const sumEl = U.text('bcv-gr__wsum', '', 'span');
        const paintSum = () => {
          const s = Object.values(wEdit.vals).reduce((a, v) => a + num(v), 0);
          const whole = Math.abs(s - 100) < 0.05;
          sumEl.textContent = whole ? 'Total 100%' : `Total ${store.fmtPts(Math.round(s * 10) / 10)}% · shares taken in proportion`;
          sumEl.classList.toggle('is-off', !whole);
        };
        const save = async () => {
          const map = {};
          for (const [id, v] of Object.entries(wEdit.vals)) { const n = num(v); if (n > 0) map[id] = n; }
          if (!Object.keys(map).length) { U.toast(`Give at least one group a weight — or go back to ${BCV.lms.name}’s.`, { error: true }); return; }
          own = map;
          wEdit.on = false;
          await store.mergePref('gradeWeights', { [c.id]: map });
          draw();
          U.toast(`Your weights are on for this course. Nothing is sent to ${BCV.lms.name}.`);
        };
        const cancel = () => { wEdit.on = false; draw(); };
        const clear = async () => {
          own = null;
          wEdit.on = false;
          await store.mergePref('gradeWeights', { [c.id]: null });
          draw();
          U.toast(`Back to the weights ${BCV.lms.name} carries.`);
        };
        const rows = groups.map((g) => {
          const id = String(g.id);
          const inp = h('input', { type: 'text', inputmode: 'decimal', class: 'bcv-input bcv-gr__winput', value: String(wEdit.vals[id] ?? 0), 'aria-label': `Weight of ${g.name}`, dataset: { wgroup: id } });
          inp.addEventListener('input', () => { wEdit.vals[id] = inp.value; paintSum(); });
          inp.addEventListener('focus', () => inp.select());
          inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') cancel(); });
          return U.el('bcv-gr__wedit-row', [
            h('span', { class: 'bcv-wbar__dot', style: { background: colorOf(id) || 'var(--bcv-fill2)' } }),
            U.text('bcv-wbar__name', g.name, 'span'),
            c.weighted ? U.text('bcv-gr__wcanvas', `${BCV.lms.name}: ${Number(g.group_weight) || 0}%`, 'span') : null,
            inp,
            U.text('bcv-gr__wpct', '%', 'span'),
          ]);
        });
        paintSum();
        return U.el('bcv-gr__sec bcv-gr__sec--w bcv-gr__wedit', [
          U.el('bcv-gr__hrow', [U.text('bcv-gr__h', 'My own weights', 'span'), sumEl]),
          U.text('bcv-gr__wnote bcv-pretty', `A percent per group, as your syllabus gives them. The total here follows them; nothing is sent to ${BCV.lms.name} or your instructor.`),
          ...rows,
          U.el('bcv-gr__wbtns', [own ? U.btn(`Back to ${BCV.lms.name}’s weights`, { kind: 'danger', cls: 'bcv-gr__wclear', onClick: clear }) : null, h('span', { class: 'bcv-gr__wspace' }), U.btn('Cancel', { cls: 'bcv-gr__wcancel', onClick: cancel }), U.btn('Save', { kind: 'primary', cls: 'bcv-gr__wsave', onClick: save })]),
        ]);
      }
      const ringsCard = U.card(U.el('bcv-gr', [U.el('bcv-gr__top', [svg, center]), byGroup, weightsSec]), 'bcv-card--22');

      // ---- assignments ----------------------------------------------------------------
      const rows = gm.rows.map((g) => {
        const dotEl = h('span', { class: 'bcv-dot bcv-dot--7', style: { background: g.earned !== null ? '#0a84ff' : 'transparent' } });
        let scoreEl;
        if (!st.on) {
          scoreEl = h('span', { class: 'bcv-grade__score', title: 'Double-click to test a what-if score', text: `${g.grade ? `${g.grade} · ` : ''}${g.earned === null ? '—' : store.fmtPts(g.earned)} / ${store.fmtPts(g.possible)}` }); // (a letter or pass/fail grade first, as Canvas names it)
          // the row opens the assignment, so the score has to keep its own presses: otherwise the
          // first half of the double-click that starts a what-if would navigate away instead
          scoreEl.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); });
          scoreEl.addEventListener('dblclick', () => { st.on = true; focusId = g.id; draw(); });
        } else {
          const input = h('input', { type: 'text', inputmode: 'decimal', placeholder: '—', class: `bcv-whatif__input ${g.hypothetical ? 'is-hyp' : ''}`, dataset: { wf: g.id }, value: st.values[g.id] === undefined ? (g.earned === null ? '' : String(g.earned)) : st.values[g.id] });
          input.addEventListener('focus', () => input.select());
          input.addEventListener('change', () => { st.values[g.id] = input.value.replace(/[^0-9.]/g, ''); focusId = null; draw(); });
          input.addEventListener('keydown', (e) => { if (e.key === 'Enter') input.blur(); });
          scoreEl = U.el('bcv-whatif', [input, U.text('bcv-whatif__possible', `/ ${store.fmtPts(g.possible)}`, 'span')]);
          scoreEl.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); }); // typing a what-if is not opening the row
        }
        // the whole row opens the assignment it is a line about — a grade is the start of a question
        // ("why?"), and the answer is on the assignment's own page
        // its letter (U.gradeBand: what-if scores included), a tag in the letter's colour by the score
        const band = U.gradeBand(g.effective, g.possible, g.gradingType);
        const row = U.row([
          U.el('bcv-row__body', [
            h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '8px', flexWrap: 'wrap' } }, [U.text('bcv-grade__name bcv-pretty', g.name, 'span'), g.added ? U.badge('What-if', 'red', 'bcv-badge--xs') : g.badge ? U.badge(g.badge, g.badge === 'Late' ? 'orange' : g.badge === 'Missing' ? 'red' : '', 'bcv-badge--xs') : null]),
            // the group, the dates, and — on a marked assignment — how the class did (Canvas's own mean, high and low)
            // (2.99.36: the group is the section's head now, not said again in each row)
            U.text('bcv-row__sub', g.added ? `made up to test, not in ${BCV.lms.name}` : [g.due ? `due ${U.fmtBy(g.due)}` : 'no due date', g.submitted ? `submitted ${U.fmtAt(g.submitted)}` : (g.due && U.parse(g.due) > new Date() ? 'not due yet' : 'not submitted'), g.stats && g.earned !== null ? `class mean ${store.fmtPts(g.stats.mean)} · high ${store.fmtPts(g.stats.max)} · low ${store.fmtPts(g.stats.min)}` : null].filter(Boolean).join(' · ')),
          ]),
          dotEl,
          U.bandChip(band, band ? `${store.fmtPts(Math.round((g.effective / g.possible) * 1000) / 10)}% · ${band}` : null),
          scoreEl,
          g.added ? U.whatIfRemove(g.name, () => { st.added = st.added.filter((x) => x.id !== g.id); delete st.values[g.id]; draw(); }) : null,
          g.url ? U.chev() : null,
        ], { href: g.url || null });
        if (g.added) row.classList.add('is-wfadded');
        row.dataset.band = band || '';
        row.dataset.group = g.groupId; // (the group it counts toward: picked out with it)
        row.style.setProperty('--bcv-grp', colorOf(g.groupId) || 'var(--bcv-ink3)');
        return row;
      });
      // By letter: the slider lists one letter's work alone (the rows are the same; only the list is refilled)
      const counts = {};
      for (const r of rows) if (r.dataset.band) counts[r.dataset.band] = (counts[r.dataset.band] || 0) + 1;
      const listHost = h('div');
      // (2.99.36) the work partitioned by its group (the course's categories, in Canvas's order): each group under a
      // head of its own — its colour, its name, its weight and its score so far — rather than one list with the
      // group's name in each row's small print. Pressing a head picks the group out, as its legend row does.
      const groupSections = (shown) => {
        const order = groups.map((g) => String(g.id));
        const byId = new Map();
        for (const r of shown) {
          const id = r.dataset.group || '';
          if (!byId.has(id)) byId.set(id, []);
          byId.get(id).push(r);
        }
        const ids = [...order.filter((id) => byId.has(id)), ...[...byId.keys()].filter((id) => !order.includes(id))];
        return ids.map((id) => {
          const g = groups.find((x) => String(x.id) === id);
          const lg = gm.legend.find((x) => x.id === id);
          const name = g?.name || lg?.label || 'Other';
          const n = byId.get(id).length;
          // (its weight as the grade counts it — the student's own weights where set: the legend's, else the weight bar's)
          const wb = gm.weightBar.find((w) => w.id === id);
          const weight = !gm.weighted ? '' : lg?.weightText || (wb ? `${wb.weight}% of grade` : g ? 'not weighted' : '');
          const head = h('div', { ...U.groupAttrs(id, colorOf(id), { pick: !!g, name }), class: 'bcv-gr__ghead' }, [
            h('span', { class: 'bcv-gr__gdot', 'aria-hidden': 'true' }),
            U.text('bcv-gr__gname bcv-pretty', name, 'span'),
            U.text('bcv-gr__gmeta', [weight, `${n} ${n === 1 ? 'item' : 'items'}`].filter(Boolean).join(' · '), 'span'),
            U.text('bcv-gr__gscore', lg ? `${lg.detail.split(' · ')[0]} · ${lg.value}` : 'not graded yet', 'span'),
          ]);
          return h('section', { class: 'bcv-gr__gsec', 'aria-label': name }, [head, U.card(byId.get(id), 'bcv-card--list')]);
        });
      };
      const paintList = () => {
        const band = bandSt.band;
        const shown = band === 'all' ? rows : rows.filter((r) => r.dataset.band === band);
        listHost.replaceChildren(...(!rows.length ? [U.emptyCard('No assignments in this course.')]
          : shown.length ? groupSections(shown)
            : [U.emptyCard(`No ${band} grades in this course${st.on ? ' with these what-if scores' : ''}.`)]));
      };
      paintList();
      // what-if: an assignment made up and put in a group of the student's choosing, counted there like the rest
      const adder = st.on && cats.length ? U.whatIfAdder(cats, {
        group: st.addGroup ?? pickSt.pick, weighted: gm.weighted, n: st.seq + 1,
        onGroup: (id) => { st.addGroup = id; },
        onAdd: ({ groupId, name, score, possible }) => {
          st.seq += 1;
          const id = `wf-${st.seq}`;
          st.added.push({ id, groupId, name, possible });
          st.values[id] = String(score);
          st.addGroup = groupId;
          bandSt.band = 'all'; // (the new row in view, whatever letter it lands on)
          draw();
          b.querySelector('.bcv-wfadd__name')?.focus(); // (ready for the next)
        },
      }) : null;
      const tableCard = h('div', {}, [
        U.el('bcv-group__head bcv-group__head--10', [U.h2('Assignments'), pickNote]),
        adder,
        Object.keys(counts).length ? U.el('bcv-gr__bandrow', [
          U.text('bcv-gr__bandlbl', 'By letter', 'span'),
          U.bandSlider(counts, bandSt.band, (b) => { bandSt.band = b; paintList(); picker.apply(); }),
        ]) : null,
        listHost,
      ]);

      // The weights live in the grade card's "How the grade is weighted" section; no separate card.
      b.replaceChildren(...parts, U.el('bcv-grades__main', [ringsCard, tableCard]));
      if (pickSt.pick && !gm.rows.some((r) => r.groupId === pickSt.pick) && !gm.legend.some((r) => r.id === pickSt.pick) && !gm.ungraded.some((u) => u.id === pickSt.pick)) pickSt.pick = null;
      picker.apply();
      if (focusId) {
        const el = b.querySelector(`[data-wf="${CSS.escape(focusId)}"]`);
        if (el) { el.focus(); el.select(); }
        focusId = null;
      }
      if (wEdit.on && wEdit.focus) { // (the editor just opened: the first weight ready to type over)
        wEdit.focus = false;
        const first = b.querySelector('.bcv-gr__winput');
        if (first) { first.focus(); first.select(); }
      }
    }
    function ns(tag) {
      return document.createElementNS(NS, tag);
    }
    function circle(r, stroke, cap, dash, width = 12) {
      const el = ns('circle');
      el.setAttribute('cx', '80');
      el.setAttribute('cy', '80');
      el.setAttribute('r', r);
      el.setAttribute('fill', 'none');
      el.setAttribute('stroke', stroke);
      el.setAttribute('stroke-width', String(width));
      if (cap) el.setAttribute('stroke-linecap', cap);
      if (dash) el.setAttribute('stroke-dasharray', dash);
      return el;
    }
    draw();
    return b;
  }

  BCV.screens.grades = { render };
})();
