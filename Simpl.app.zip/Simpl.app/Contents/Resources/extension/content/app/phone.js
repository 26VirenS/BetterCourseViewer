/* The phone layout (the iPhone mockup): the same screens rebuilt for a narrow
 * touch screen. Five tabs (Today, Courses, To Do, Grades, Calendar) over a glass
 * tab bar; everything deeper is a push with a glass back bar whose label names
 * the parent (edge-swipe from the left pops it). Rows reveal actions on a swipe
 * left (Done / Priority on a task, Read / Clear on a notification), anything
 * modal is a bottom sheet with a grab handle (drag past 110px to dismiss), a
 * grade ring expands on a tap, an assignment is handed in on its own page, and
 * a quiz attempt takes the whole screen. The course list chosen in setup is the
 * ONLY set the phone shows, on every surface and in every count, filtered
 * before anything is counted. Nothing needs a hover; there is no Immersive
 * Reader on the phone (iOS has Reader, Speak Screen and Dynamic Type).
 * Active when html.bcv-phone is set (early.js, from a ≤700px viewport); the
 * desktop screens are untouched otherwise. Every number still comes from the
 * same Canvas reads the desktop uses. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  if (BCV.phone) return; // loaded once: this file is asked for on demand (content/app/lazy.js), and a second copy would listen to the page twice
  const { h, htmlToText } = BCV.utils;
  const U = BCV.ui;
  const IC = BCV.IC;
  const store = BCV.store;
  const html = document.documentElement;

  const active = () => html.classList.contains('bcv-phone');
  // the tab bar, icons as drawn in the mockup
  const TABS = [
    ['dashboard', 'Today', 'M4 11l8-7 8 7v9H4z', '/'],
    ['courses', 'Courses', 'M5 4h13v16H5zM5 17h13M9 8h5', '/courses'],
    ['todo', 'To Do', 'M5 6h14M5 12h14M5 18h9', '/#todo'],
    ['gpa', 'Grades', 'M4 19h16M7 16V9M12 16V5M17 16v-4', '/grades'],
    ['calendar', 'Calendar', 'M5 5h14v15H5zM5 10h14M9 3v4M15 3v4', '/calendar'],
  ];
  const ROOT = new Set(TABS.map((t) => t[0]));
  const CHEV = 'M9 6l6 6-6 6';
  const CHECK = 'M20 6L9 17l-5-5';
  const EXT = 'M9 6h9v9M18 6L7 17';
  const BELL = 'M12 4a5 5 0 015 5v4l2 3H5l2-3V9a5 5 0 015-5zM10 19a2 2 0 004 0';
  const gpa2 = (n) => (n === null || n === undefined ? '—' : n.toFixed(2));
  const byDate = (a, b) => a.date - b.date;
  const chev = (path = CHEV) => U.svg(path, { size: 14, stroke: 'var(--bcv-ink3)', width: 2.2, cls: 'bcv-ph-chev' });
  const native = () => self.BCVBridge?.native || null;
  /** Rows stagger 70ms apart, capped at 280ms: tighter than the desktop, the travel is shorter. */
  const enter = (node, i, dur = 360) => {
    if (U.isStill?.()) return node; // (a list drawn again in place: no entrance — ui.still)
    node.classList.add('bcv-enter');
    node.style.setProperty('--bcv-delay', `${Math.min(i * 70, 280)}ms`);
    node.style.setProperty('--bcv-dur', `${dur}ms`);
    return node;
  };
  // the app's semantic priority set (mockup 12), shared with the desktop To Do
  const PRI = [
    { lv: 0, label: 'None', short: '—', light: '#8e8e93', dark: '#8e8e93', tintLight: 'rgba(118,118,128,.12)', tintDark: 'rgba(118,118,128,.22)' },
    { lv: 1, label: 'Low', short: 'Low', light: '#1c6b7a', dark: '#6fd6e8', tintLight: 'rgba(48,176,199,.14)', tintDark: 'rgba(48,176,199,.22)' },
    { lv: 2, label: 'Medium', short: 'Med', light: '#8a5200', dark: '#ffb44d', tintLight: 'rgba(255,149,0,.18)', tintDark: 'rgba(255,149,0,.18)' },
    { lv: 3, label: 'High', short: 'High', light: '#c01d43', dark: '#ff8098', tintLight: 'rgba(255,45,85,.12)', tintDark: 'rgba(255,45,85,.22)' },
  ];
  const priMeta = (lv, dark) => {
    const p = PRI[lv] || PRI[0];
    return { ...p, color: dark ? p.dark : p.light, tint: dark ? p.tintDark : p.tintLight };
  };
  const TASK_PAL = (dark) => ({ text: dark ? '#a9a7f5' : '#5856d6', tint: dark ? 'rgba(88,86,214,.24)' : 'rgba(88,86,214,.13)' });

  // ---- the one course list ---------------------------------------------------------------------
  /** The courses chosen in setup (the Canvas favourites; every current course until one is starred).
   *  Every phone surface reads this list and filters BEFORE it counts anything. */
  async function selection() {
    const favs = await store.favorites().catch(() => []);
    return { list: favs, ids: new Set(favs.map((c) => String(c.id))) };
  }
  /** A planner item the phone shows: a task of the student's own, or work in a selected course. */
  const inSelection = (sel, it) => !!it.custom || !it.courseId || sel.ids.has(String(it.courseId));

  // ---- chrome: tab bar, top bar, gestures ----------------------------------------------------------
  let tabbarEl = null, topbarEl = null;
  function tabbar(app) {
    tabbarEl = h('nav', { id: 'bcv-tabbar', class: 'bcv-tabbar', 'aria-label': 'Main' });
    paintTabs(app);
    return tabbarEl;
  }
  function paintTabs(app) {
    if (!tabbarEl) return;
    const cur = app.state.route?.screen;
    tabbarEl.replaceChildren(...TABS.map(([key, label, icon, href]) => h('button', {
      type: 'button', class: `bcv-tabbar__item ${cur === key ? 'is-active' : ''}`, dataset: { tab: key }, 'aria-current': cur === key ? 'page' : null, onclick: () => app.go(href),
    }, [U.svg(icon, { size: 23, width: 1.9 }), h('span', { text: label })])));
  }
  function topbar() {
    topbarEl = h('div', { id: 'bcv-topbar', class: 'bcv-topbar', hidden: true });
    return topbarEl;
  }
  /** A row that leads to an item: the preview rises from the bottom where there is one to show,
   *  and the row goes where it always went where there is not. */
  const openItem = (app, url) => { if (!BCV.preview?.open(url)) app.go(url); };

  function paintChrome(app, { focus = false } = {}) {
    paintTabs(app);
    document.getElementById('bcv-app')?.classList.toggle('bcv-focus', focus);
  }
  /** Where "back" goes when there is no history to return to. */
  function parentOf(r) {
    if (r.screen === 'course') return r.tab === 'home' || !r.tab ? { label: 'Courses', href: '/courses' } : { label: 'Back', href: `/courses/${r.courseId}` };
    if (r.screen === 'group') return { label: 'Groups', href: '/groups' };
    if (r.screen === 'groups' || r.screen === 'inbox' || r.screen === 'notifications') return { label: 'Today', href: '/' };
    return { label: 'Back', href: '/' };
  }
  /** The screen Back names and goes to: the one this screen was reached from (the trail), else its structural parent. */
  const backOf = (app, r) => (app.backTo ? app.backTo(parentOf(r)) : parentOf(r));
  function goBack(app, r) {
    let sameSite = false;
    try { sameSite = !!document.referrer && new URL(document.referrer).origin === location.origin; } catch { sameSite = false; }
    const back = backOf(app, r);
    // history.back() keeps the stack honest when the previous entry is the one the button names: a
    // screen this page moved to in place (the entry carries a count of those moves — app.navState),
    // or a page of this site loaded before it. A typed URL or a fresh tab goes there directly.
    // (Pushing the parent instead, as every Back once did in the app — where a page arrives from the
    // school's sign-in and the referrer is never Canvas — piled screens on the stack, and the
    // phone's own swipe-back then walked forward through them.)
    const inPage = (Number(history.state?.d) || 0) > 0;
    if (back.fromTrail && history.length > 1 && (inPage || sameSite)) { app.markBack?.(); history.back(); }
    else { app.markBack?.(); app.go(back.href); }
  }
  /** In the app, the phone's own swipe-back (WebKit's, which follows the finger) takes the page back;
   *  it is offered only where there is somewhere to go back to — not on a tab's root screen, not
   *  during a quiz attempt — and the page's own edge swipe below stands down so one swipe is one Back. */
  const appSwipe = () => !!native()?.navState;
  let swipeSaid = null;
  function tellSwipe() {
    if (!appSwipe()) return;
    const can = active() && !html.classList.contains('bcv-ph-root') && !html.classList.contains('bcv-quiz') && !document.querySelector('.bcv-sheet-ov:not(.is-closing)') && history.length > 1;
    if (can === swipeSaid) return; // (said once per change, not on every class the page sets)
    swipeSaid = can;
    try { native().navState({ canSwipeBack: can }); } catch { /* the app is older than this */ }
  }
  /** After a screen lands: the top bar for pushed screens, the active tab. */
  function afterRender(app, r, el) {
    const isRoot = (ROOT.has(r.screen) && r.params.get('bcv') !== 'native') || r.params.get('bcv') === 'setup';
    html.classList.toggle('bcv-ph-root', isRoot);
    if (isRoot && el?.classList) { el.classList.remove('bcv-screen--fwd', 'bcv-screen--back'); el.classList.add('bcv-screen--tab'); } // (a tab change fades in place; only a pushed screen slides)
    paintTabs(app);
    closeSwipes();
    tellSwipe();
    if (!topbarEl) return;
    topbarEl.hidden = isRoot;
    if (isRoot) return;
    const parent = backOf(app, r);
    // an item page drops the course header altogether (its own title and course chip say where it is)
    const courseHead = el.querySelector('.bcv-head--course');
    if (courseHead && el.querySelector('.bcv-ph-body--item')) courseHead.remove();
    const titled = el.querySelector('[data-bcv-title]');
    const title = titled ? titled.dataset.bcvTitle : (el.querySelector('.bcv-head--course') ? '' : (el.querySelector('.bcv-h1, .bcv-sb__h1, .bcv-detail__title')?.textContent || document.title.split(' · ')[0] || '').trim());
    topbarEl.replaceChildren(
      h('button', { type: 'button', class: 'bcv-topbar__back', onclick: () => goBack(app, r) }, [U.svg('M15 5l-7 7 7 7', { size: 18, stroke: 'var(--bcv-blue)', width: 2.3 }), h('span', { text: parent.label })]),
      U.text('bcv-topbar__title bcv-ellip', title, 'span'),
      h('span', { class: 'bcv-topbar__right' }), // no reader button on the phone: iOS has Reader, Speak Screen and Dynamic Type
    );
  }
  // Edge-swipe from the left screen edge pops the stack, exactly like the Back button; not during a quiz attempt.
  let edge = null;
  document.addEventListener('pointerdown', (e) => {
    if (!active() || appSwipe() || html.classList.contains('bcv-ph-root') || html.classList.contains('bcv-quiz') || e.clientX > 24 || document.querySelector('.bcv-sheet-ov')) { edge = null; return; } // (a sheet up: the swipe is the sheet's, not the screen's; in the app, the phone's own swipe is the one)
    edge = { x: e.clientX, y: e.clientY, done: false };
  }, true);
  document.addEventListener('pointermove', (e) => {
    if (!edge || edge.done) return;
    const dx = e.clientX - edge.x, dy = Math.abs(e.clientY - edge.y);
    if (dx > 80 && dy < 60) { edge.done = true; goBack(BCV.app, BCV.app.state.route || BCV.app.parseRoute()); }
  }, true);
  document.addEventListener('pointerup', () => { edge = null; }, true);

  // ---- swipe-left row actions ------------------------------------------------------------------
  let openSwipe = null; // the one row whose actions are showing (a single reference, never a flag per row)
  function closeSwipes() {
    if (openSwipe) { openSwipe.close(); openSwipe = null; }
  }
  document.addEventListener('pointerdown', (e) => { if (openSwipe && !openSwipe.el.contains(e.target)) closeSwipes(); }, true);
  /** Trailing actions (76px each) behind a row: drag left up to the tray; past half it latches open on
   *  release, under it springs back. The finger tracks 1:1 (no easing during the drag); easing only on
   *  release. Tapping the body still opens the row; every action here also exists as a tap target. */
  function swipeable(front, actions) {
    const W = actions.length * 76;
    const tray = U.el('bcv-ph-swipe__acts', actions.map((a) => h('button', { type: 'button', class: 'bcv-ph-swipe__act', style: { background: a.color }, 'aria-label': a.label, onclick: (e) => { e.stopPropagation(); closeSwipes(); a.onSelect(); } }, [a.icon ? U.svg(a.icon, { size: 15, stroke: '#fff', width: a.width || 2.2 }) : null, h('span', { text: a.label })])));
    front.classList.add('bcv-ph-swipe__front');
    front.setAttribute('draggable', 'false'); // a link row must not start a native drag (which cancels the pointer)
    front.addEventListener('dragstart', (e) => e.preventDefault());
    const wrap = U.el('bcv-ph-swipe', [tray, front]);
    let x0 = 0, y0 = 0, dx = 0, base = 0, dragging = false, moved = false;
    let trail = []; // ([t, x] over the last tenth of a second: the finger's speed when it lets go)
    const RUB = 0.55; // (past an end: the further it is pulled, the less it follows — iOS's rubber band)
    const rubber = (over) => (over * 60 * RUB) / (60 + over * RUB);
    const set = (x, animate) => { front.style.transition = animate ? 'transform .22s var(--bcv-ease)' : 'none'; front.style.transform = `translateX(${x}px)`; };
    // a row is promoted to its own layer only while a finger is on it (will-change on every row of
    // a long list is a layer per row, held for the page's life)
    let layerT = 0;
    const layer = (on) => { clearTimeout(layerT); if (on) front.style.willChange = 'transform'; else layerT = setTimeout(() => { front.style.willChange = ''; }, 260); };
    const api = { el: wrap, close: () => { base = 0; set(0, true); wrap.classList.remove('is-open'); layer(false); } };
    front.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      x0 = e.clientX; y0 = e.clientY; dragging = true; moved = false;
      trail = [[e.timeStamp, e.clientX]];
      layer(true);
    });
    front.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const mx = e.clientX - x0, my = e.clientY - y0;
      if (!moved) {
        if (Math.abs(my) > Math.abs(mx) && Math.abs(my) > 6) { dragging = false; return; } // a scroll, not a swipe
        if (Math.abs(mx) < 4) return;
        moved = true;
        if (openSwipe && openSwipe !== api) closeSwipes();
        try { front.setPointerCapture(e.pointerId); } catch { /* not every pointer can be captured */ }
      }
      const raw = base + mx;
      dx = raw > 0 ? rubber(raw) : raw < -W ? -W - rubber(-W - raw) : raw;
      trail.push([e.timeStamp, e.clientX]);
      while (trail.length > 2 && e.timeStamp - trail[0][0] > 100) trail.shift();
      set(dx, false);
    });
    const end = () => {
      if (!dragging) return;
      dragging = false;
      if (!moved) { layer(false); return; }
      // the speed over the last tenth of a second, in px/ms (a finger that stopped before letting go has none)
      const [t0, xa] = trail[0] || [0, 0], [t1, xb] = trail[trail.length - 1] || [0, 0];
      const v = t1 - t0 > 0 && performance.now() - t1 < 80 ? (xb - xa) / (t1 - t0) : 0;
      const open = v < -0.11 ? true : v > 0.11 ? false : dx < -W / 2;
      if (open) { if (base !== -W) U.haptic?.('rigid'); base = -W; set(-W, true); wrap.classList.add('is-open'); openSwipe = api; }
      else { base = 0; set(0, true); wrap.classList.remove('is-open'); if (openSwipe === api) openSwipe = null; }
      layer(false);
    };
    front.addEventListener('pointerup', end);
    front.addEventListener('pointercancel', end);
    front.addEventListener('click', (e) => { if (moved) { e.stopImmediatePropagation(); e.preventDefault(); moved = false; } }, true); // a drag is not a tap (the row's own handler must not run)
    return wrap;
  }

  // ---- building blocks ------------------------------------------------------------------------
  /** A large title with a line above or below it, and something on the right. */
  function bigTitle(title, { above = '', below = '', right = null } = {}) {
    return U.el('bcv-ph-title', [
      h('div', { class: 'bcv-ph-title__text' }, [
        above ? U.text('bcv-ph-title__sub', above) : null,
        h('h1', { class: 'bcv-ph-h1', text: title }),
        below ? U.text('bcv-ph-title__sub bcv-ph-title__sub--below', below) : null,
      ]),
      right,
    ]);
  }
  const groupHead = (title, note) => U.el('bcv-ph-ghead', [U.text('bcv-ph-ghead__t', title, 'span'), note ? U.text('bcv-ph-ghead__n', note, 'span') : null]);
  const listCard = (rows, mod = '') => U.el(`bcv-ph-card bcv-ph-card--list ${mod}`, rows);
  const emptyRow = (text) => U.el('bcv-ph-empty', text);
  const circleBox = (done) => h('span', { class: `bcv-ph-circle ${done ? 'is-done' : ''}` }, U.svg(CHECK, { size: 12, stroke: '#fff', width: 3, cls: 'bcv-ph-circle__check' }));

  /** A bottom sheet: a grab handle (drag it down past 110px to dismiss; the scrim is the other way
   *  out), a title, rows (label / note / badge, tap to go or act), any body, big buttons. A row may
   *  be a section label ({ section }), quieter ({ quiet }: set back in grey, still a tap away), or
   *  clearable ({ clear }: an X beside it; the row goes once clear() lands, onCleared() after). */
  function openSheet({ title = '', note = '', rows = [], body = null, actions = [], label = title, cls = '' }) {
    document.querySelector('.bcv-sheet-ov')?.remove();
    const ov = U.el('bcv-sheet-ov', null, { role: 'dialog', 'aria-label': label || 'Sheet' });
    const close = () => BCV.ui.dismiss(ov); // (it slides down the way it rose: the CSS's own timing)
    ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
    ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const handle = h('div', { class: 'bcv-ph-sheet__handle' }, h('span'));
    const sheet = U.el(`bcv-sheet bcv-ph-sheet ${cls}`, [
      handle,
      title ? U.el('bcv-ph-sheet__head', [U.text('bcv-ph-sheet__title', title), note ? U.text('bcv-ph-sheet__note bcv-pretty', note) : null]) : null,
      rows.filter(Boolean).length ? U.el('bcv-ph-sheet__list', rows.filter(Boolean).map((r) => sheetRow(r))) : null,
      body,
      actions.filter(Boolean).length ? U.el('bcv-ph-sheet__actions', actions.filter(Boolean).map((a) => h('button', { type: 'button', class: `bcv-ph-bigbtn ${a.primary ? 'is-primary' : ''} ${a.cls || ''}`, text: a.label, onclick: () => { if (!a.keep) close(); a.onSelect?.(); } }))) : null,
    ]);
    function sheetRow(r) {
      if (r.section) return U.text(`bcv-ph-sheet__sec ${r.quiet ? 'is-quiet' : ''}`, r.section);
      const row = h('button', {
        type: 'button', class: `bcv-ph-srow ${r.danger ? 'is-danger' : ''} ${r.quiet ? 'is-quiet' : ''}`, onclick: () => { close(); if (r.href) BCV.app.go(r.href); else r.onSelect?.(); },
      }, [
        r.icon ? h('span', { class: 'bcv-ph-srow__tile', style: r.tint ? { background: r.tint } : null }, U.svg(r.icon, { size: 15, stroke: r.color || 'var(--bcv-ink2)', width: 1.9 })) : (r.color ? h('span', { class: 'bcv-ph-srow__bar', style: { background: r.color } }) : null),
        U.el('bcv-ph-srow__body', [U.text('bcv-ph-srow__label bcv-ellip', r.label), r.note ? U.text('bcv-ph-srow__note bcv-ellip', r.note) : null]),
        r.badge ? h('span', { class: 'bcv-ph-srow__badge', text: String(r.badge) }) : null,
        r.right ? U.text('bcv-ph-srow__right', r.right, 'span') : null,
        r.href || r.onSelect ? chev() : null,
      ]);
      if (!r.clear) return row;
      // the X: the item goes one tap at a time; a failure leaves the row where it is and says so
      const x = h('button', { type: 'button', class: 'bcv-ph-srow__x', 'aria-label': `Clear: ${r.label}`, onclick: async (e) => {
        e.stopPropagation();
        x.disabled = true;
        wrap.classList.add('is-busy');
        try {
          await r.clear();
        } catch {
          wrap.classList.remove('is-busy');
          x.disabled = false;
          U.toast('Couldn’t clear that. Try again.', { error: true });
          return;
        }
        wrap.classList.add('is-gone');
        setTimeout(() => { wrap.remove(); r.onCleared?.(sheet); }, 220);
      } }, U.svg(IC.close, { size: 12, stroke: 'var(--bcv-ink2)', width: 2.4 }));
      const wrap = U.el('bcv-ph-srow__item', [row, x]);
      return wrap;
    }
    // (moved like every sheet on the phone: by the grabber, the head, or a pull at the top of the list — sheetGrip below)
    ov.append(sheet);
    document.body.append(ov);
    ov.tabIndex = -1;
    ov.focus();
    return { close, sheet };
  }

  // ---- every bottom sheet moves like the phone's own ---------------------------------------------
  /* An iPhone sheet is held and moved: by its grabber, by its head, and by its content when that is
   * scrolled to the top (a pull down there moves the sheet, not the list). It rests at its own height,
   * or — where it holds more than it shows — nearly the full screen: pull it up to get there, down to
   * come back, further or faster to put it away. Every sheet the interface opens on the phone gets
   * this (the lists, a question, an event, a rubric, a preview), not only the ones drawn with a handle.
   * Touch is read as touch, so a pull at the top of a list can be told from a scroll and the scroll
   * stopped (pointer events cannot stop a scroll once it has begun); a mouse drags the grabber the same
   * way (a desk, the tests). Putting it away is the sheet's own close: its scrim is pressed for it,
   * after it has slid off, so whatever that close does (answer a question, forget a draft) still happens. */
  const gripped = new WeakSet();
  function sheetGrip(ov) {
    if (!active() || gripped.has(ov) || ov.classList.contains('is-closing')) return;
    const sheet = ov.querySelector(':scope > .bcv-sheet');
    if (!sheet) return;
    gripped.add(ov);
    let handle = sheet.querySelector(':scope > .bcv-ph-sheet__handle');
    if (!handle) { handle = h('div', { class: 'bcv-ph-sheet__handle bcv-ph-sheet__handle--added', 'aria-hidden': 'true' }, h('span')); sheet.prepend(handle); }
    const M = () => (BCV.motion && !U.reducedMotion() ? BCV.motion : null);
    const SCROLLY = /(auto|scroll)/;
    const scrollerOf = (el) => {
      for (let n = el; n && n !== ov; n = n.parentElement) {
        if (n.scrollHeight > n.clientHeight + 1 && (n === sheet ? SCROLLY.test(getComputedStyle(n).overflowY) || sheet.classList.contains('is-large') : SCROLLY.test(getComputedStyle(n).overflowY))) return n;
        if (n === sheet) break;
      }
      return null;
    };
    /** More than it shows: some part of it scrolls, or is cut off. */
    const holdsMore = () => {
      if (sheet.classList.contains('is-large')) return false;
      if (sheet.scrollHeight > sheet.clientHeight + 4) return true;
      let n = 0;
      for (const el of sheet.querySelectorAll('*')) { if (n++ > 500) break; if (el.scrollHeight > el.clientHeight + 4 && SCROLLY.test(getComputedStyle(el).overflowY)) return true; }
      return false;
    };
    const moreIn = (gest) => (gest.more ??= holdsMore()); // (once a gesture: it walks the sheet, so not on every move)
    const noDrag = (el) => !!el?.closest?.('input, textarea, select, [contenteditable="true"], canvas, .bcv-ph-chips, [data-no-sheet-drag]');
    let g = null;
    const HEIGHT = 'height .34s var(--bcv-ease)';
    const set = (y) => { sheet.style.transition = HEIGHT; sheet.style.transform = y ? `translateY(${y}px)` : ''; };
    /** To nearly the full screen and back, the height moving between the two (an auto height cannot
     *  be animated, so the one it leaves is held for a frame). */
    const grow = () => { const h0 = sheet.offsetHeight; sheet.style.height = `${h0}px`; sheet.classList.add('is-large'); void sheet.offsetHeight; sheet.style.transition = HEIGHT; sheet.style.height = ''; };
    const shrink = () => {
      const hL = sheet.offsetHeight;
      sheet.classList.remove('is-large');
      const h1 = sheet.offsetHeight;
      sheet.style.transition = 'none'; sheet.style.height = `${hL}px`; void sheet.offsetHeight;
      sheet.style.transition = HEIGHT; sheet.style.height = `${h1}px`;
      setTimeout(() => { if (!sheet.classList.contains('is-large')) sheet.style.height = ''; }, 360);
    };
    const begin = () => { for (const a of sheet.getAnimations()) a.cancel(); sheet.style.willChange = 'transform'; };
    const follow = (y, t) => {
      g.hist.push({ y, t });
      while (g.hist.length > 2 && t - g.hist[0].t > 150) g.hist.shift(); // (the last 150 ms of the finger's way)
      g.lastY = y; g.lastT = t;
      let dy = y - g.y0;
      if (dy < 0) {
        // pulled up: a sheet holding more grows to nearly the full screen at once; beyond that (or with nothing more to show) it gives a little and no more
        if (!g.grew && moreIn(g)) { g.grew = true; grow(); g.y0 = y; dy = 0; }
        else { const o = -dy; dy = -(o * 40 * 0.18) / (40 + o * 0.18); } // (a rubber band: a little at first, ever less, never a wall)
      }
      g.dy = dy;
      set(dy);
    };
    const settle = (from) => {
      sheet.style.willChange = '';
      const m = M();
      if (m && from) { try { sheet.style.transform = ''; m.run(sheet, { y: [from, 0] }, 'phone', { v0: Math.max(0, -(g?.vy || 0)) / Math.max(1, Math.abs(from)), fill: 'backwards' }); return; } catch { /* the plain way */ } }
      sheet.style.transition = `transform .25s var(--bcv-ease), ${HEIGHT}`; sheet.style.transform = '';
    };
    const putAway = (from, vy) => {
      const hh = sheet.offsetHeight + 40;
      const ms = Math.round(Math.max(160, Math.min(320, ((hh - from) / Math.max(1200, vy)) * 1000)));
      sheet.style.transition = `transform ${ms}ms cubic-bezier(.2,.7,.3,1)`;
      sheet.style.transform = `translateY(${hh}px)`;
      ov.style.transition = `opacity ${ms}ms ease`;
      ov.style.opacity = '0';
      setTimeout(() => {
        if (!ov.isConnected) return;
        ov.style.visibility = 'hidden';
        // the sheet's own way out: its scrim pressed, else Escape — whatever closing it means happens
        ov.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        if (ov.isConnected && !ov.classList.contains('is-closing')) ov.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
        setTimeout(() => {
          if (!ov.isConnected || ov.classList.contains('is-closing')) return;
          // a sheet that will not be put away this way (it holds work not yet sent): it comes back
          ov.style.visibility = ''; ov.style.opacity = ''; ov.style.transition = '';
          settle(Math.min(from, 200));
        }, 90);
      }, ms);
    };
    /** (2.99.131) How fast the finger was going as it let go, px/s: over its last 50 ms or more, the moves counted a frame
     *  apart at least — a busy page hands over moves it held back all at once, a few milliseconds apart, and read one by
     *  one a slow pull came out a throw (a sheet pulled down a little from nearly the full screen went, on a slow runner). */
    const speed = (h) => {
      if (h.length < 2) return 0;
      const last = h[h.length - 1];
      let i = h.length - 2;
      while (i > 0 && last.t - h[i].t < 50) i--;
      const span = Math.max(last.t - h[i].t, 16 * (h.length - 1 - i));
      return span > 0 ? ((last.y - h[i].y) / span) * 1000 : 0;
    };
    const release = () => {
      if (!g) return;
      const { dy = 0, grew } = g;
      const vy = performance.now() - g.lastT > 80 ? 0 : speed(g.hist); // (a finger that stopped before letting go threw nothing)
      g = null;
      const H = sheet.offsetHeight || 1;
      const large = sheet.classList.contains('is-large');
      if (dy <= 0) { settle(dy); return; }
      if (large && !grew) {
        // nearly full screen and pulled down: far or fast enough and it goes; less, and it comes back to its own height
        if (dy > H * 0.55 || vy > 1600) { U.haptic?.('soft'); putAway(dy, vy); return; }
        if (dy > 70 || vy > 500) { U.haptic?.('soft'); shrink(); settle(Math.min(dy, 120)); return; }
        settle(dy);
        return;
      }
      if (dy > Math.min(110, H * 0.3) || vy > 700) { U.haptic?.('soft'); putAway(dy, vy); } else settle(dy);
    };
    const startAt = (x, y, target) => {
      g = { x0: x, y0: y, lastY: y, lastT: performance.now(), hist: [{ y, t: performance.now() }], dy: 0, mode: null, target, scroller: scrollerOf(target), grew: false };
    };
    const decide = (x, y) => {
      const dx = x - g.x0, dy = y - g.y0;
      if (Math.abs(dy) < 6 && Math.abs(dx) < 6) return;
      if (Math.abs(dx) > Math.abs(dy) || noDrag(g.target)) { g.mode = 'none'; return; }
      const head = handle.contains(g.target) || !!g.target.closest?.('.bcv-ph-sheet__head, .bcv-sheet__head') || g.y0 - sheet.getBoundingClientRect().top < 30;
      const atTop = !g.scroller || g.scroller.scrollTop <= 0;
      g.mode = head || (atTop && dy > 0) || (atTop && dy < 0 && moreIn(g)) ? 'drag' : 'none';
      if (g.mode === 'drag') { begin(); g.y0 = y - Math.sign(dy) * 6; }
    };
    // touch: the gesture is decided on its first move; a drag stops the scroll it would have been
    sheet.addEventListener('touchstart', (e) => { if (e.touches.length !== 1) { g = null; return; } const t = e.touches[0]; startAt(t.clientX, t.clientY, e.target); g.touch = true; }, { passive: true });
    sheet.addEventListener('touchmove', (e) => {
      if (!g?.touch) return;
      const t = e.touches[0];
      if (!g.mode) decide(t.clientX, t.clientY);
      if (g?.mode !== 'drag') return;
      e.preventDefault();
      follow(t.clientY, e.timeStamp || performance.now());
    }, { passive: false });
    const touchEnd = () => { if (g?.touch) { if (g.mode === 'drag') release(); else g = null; } };
    sheet.addEventListener('touchend', touchEnd);
    sheet.addEventListener('touchcancel', touchEnd);
    // a mouse (or a pen): the grabber and the head
    sheet.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'touch' || (e.button ?? 0) !== 0) return;
      if (!handle.contains(e.target) && !e.target.closest?.('.bcv-ph-sheet__head')) return;
      startAt(e.clientX, e.clientY, e.target);
      g.mode = 'drag'; g.pointer = e.pointerId; g.lastT = e.timeStamp; g.hist = [{ y: e.clientY, t: e.timeStamp }];
      begin();
      try { sheet.setPointerCapture(e.pointerId); } catch { /* fine */ }
    });
    sheet.addEventListener('pointermove', (e) => { if (g && g.pointer === e.pointerId) follow(e.clientY, e.timeStamp); });
    const pointerEnd = (e) => { if (g && g.pointer === e.pointerId) release(); };
    sheet.addEventListener('pointerup', pointerEnd);
    sheet.addEventListener('pointercancel', pointerEnd);
  }
  /** Sheets are met as they arrive (they are put on the page, or under the overlay root, by many hands). */
  const sheetWatch = new MutationObserver((list) => {
    let any = false;
    for (const m of list) for (const n of m.addedNodes) if (n.nodeType === 1 && n.classList?.contains('bcv-sheet-ov')) { sheetGrip(n); any = true; }
    for (const m of list) if (m.removedNodes.length) any = true;
    if (any) tellSwipe();
  });
  sheetWatch.observe(document.documentElement, { childList: true });
  if (document.body) sheetWatch.observe(document.body, { childList: true });
  else document.addEventListener('DOMContentLoaded', () => sheetWatch.observe(document.body, { childList: true }), { once: true });
  new MutationObserver(() => tellSwipe()).observe(html, { attributes: true, attributeFilter: ['class'] });

  /** Inbox and Groups live under the avatar on a phone, with the appearance switch and Settings. */
  function accountSheet(app) {
    const me = app.state.me;
    const dark = app.isDark();
    openSheet({
      label: 'Account',
      // the name with the pronouns Canvas holds, then the e-mail (the login, or the school, when there is none)
      body: U.el('bcv-ph-me', [U.avatar(me?.avatar, me?.name, 38), h('div', { style: { minWidth: '0' } }, [U.text('bcv-ph-me__name bcv-ellip', `${me?.name || 'Account'}${me?.pronouns ? ` (${me.pronouns})` : ''}`), U.text('bcv-ph-me__sub bcv-ellip', me?.email || me?.loginId || app.siteName())])]),
      rows: [
        { icon: IC.mail, label: 'Inbox', note: app.state.unread ? U.plural(app.state.unread, 'unread message') : 'No unread messages', badge: app.state.unread || null, href: '/conversations' },
        { icon: IC.people, label: 'Groups', href: '/groups' },
        ...(native() ? [] : [{ icon: IC.tool, label: 'Tools', note: 'Citations, a focus timer, flashcards and more', href: '/#tools' }]), // (none in the iPhone app yet)
        ...(BCV.extras?.phoneRows?.(app) || []), // what the school added to Canvas's own nav
        { icon: dark ? IC.sun : IC.moon, label: dark ? 'Light appearance' : 'Dark appearance', onSelect: () => app.toggleTheme() },
        { icon: IC.settings, label: 'Settings', note: 'Look, courses and grades', onSelect: () => app.openSettings?.() },
        // the one setting that has to be reachable without the options page: the app has no tab to open one in
        { icon: IC.sparkle, label: 'Guided setup', note: 'Courses, grades and the welcome', href: '/?bcv=setup' },
        { icon: IC.star, label: 'What’s new', note: 'What changed in this version', onSelect: () => BCV.whatsnew?.open(app, { manual: true }) },
        { icon: IC.people, label: 'Profile', note: 'Your Canvas profile', href: '/profile' },
        { icon: IC.external, label: 'All Canvas settings', note: 'Profile, notifications, integrations', href: '/profile/settings' },
        { icon: IC.external, label: native()?.signOut ? 'Sign out' : 'Log out', note: native()?.signOut ? 'Clears the Canvas session on this device' : 'Ends your Canvas session', danger: true, onSelect: () => app.logout() },
      ],
    });
  }

  /** Where a quiz Canvas locks is taken. Turning the guard off is the one setting here that can cost
   *  a grade, so it is not a switch to flick past: the sheet says what it means and the button that
   *  takes it off says so too. Turning it back on needs no warning at all. */
  function workRow(app, it, { chip = true, time = false } = {}) {
    const isDone = () => !!(it.complete || it.submitted);
    const pal = it.custom ? (it.course ? it.course.palette : TASK_PAL(app.isDark())) : it.course ? it.course.palette : U.palette('#8e8e93', app.isDark()); // (a task given a course wears its colour)
    let rowEl;
    let paint = () => {};
    const circle = h('button', { type: 'button', class: 'bcv-ph-circle', onclick: async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const next = !it.complete;
      U.haptic?.(next ? 'success' : 'light');
      paint(next || it.submitted);
      try {
        await store.setComplete(it, next);
        paint(isDone());
        app.refreshCounts();
      } catch (err) {
        paint(isDone());
        U.toast(`Could not update it: ${err.message}`, { error: true });
      }
    } }, U.svg(CHECK, { size: 12, stroke: '#fff', width: 3, cls: 'bcv-ph-circle__check' }));
    paint = (done) => {
      circle.classList.toggle('is-done', done);
      circle.setAttribute('aria-label', `${done ? 'Mark not done' : 'Mark done'}: ${it.title}`);
      rowEl?.classList.toggle('is-done', done);
    };
    const pts = it.points !== null && it.points !== undefined ? ` · ${store.fmtPts(it.points)} pts` : '';
    rowEl = h('a', { class: 'bcv-ph-row', href: it.url, onclick: (e) => { if (e.metaKey || e.ctrlKey) return; e.preventDefault(); openItem(app, it.url); } }, [
      circle,
      U.el('bcv-ph-row__body', [
        U.text('bcv-ph-row__title bcv-ellip', it.title),
        time ? null : U.text('bcv-ph-row__sub bcv-ellip', it.custom ? 'My task' : `${it.kind}${pts}${it.isDue ? '' : ' · to-do date'}`),
      ]),
      U.statusBadge(store.workFlags(it)[0]), // Missing, Late, Excused, Feedback, New — the same words as everywhere else
      chip && (it.course || it.courseName) ? h('span', { class: 'bcv-ph-chip', style: { background: pal.tint, color: pal.text }, text: it.course?.shortName || it.courseName }) : null,
      time ? U.text('bcv-ph-row__time', U.fmtTime(it.date), 'span') : null,
      chev(),
    ]);
    paint(isDone());
    return rowEl;
  }

  /** Every item a counter counted, in a sheet — the Dashboard's sheet on a phone (2.98.36): what
   *  wants attention under its own label, then, quieter and still a tap away, the rest of the same
   *  span (already done, read, handed in late, graded earlier). Rows are the Dashboard's shape
   *  (screens/dashboard.js workLists): { title, meta, course, color, url, clear? }. */
  function itemsSheet(app, { title, note, items, empty, lead = 'Still to do', recent = null, onCleared = null }) {
    const toRow = (i, quiet = false) => ({ label: i.title, note: [i.course, i.meta].filter(Boolean).join(' · '), color: i.color || '#8e8e93', href: i.url, quiet, clear: quiet ? null : i.clear || null, onCleared });
    return openSheet({
      title, note, label: title, cls: 'bcv-ph-sheet--items',
      rows: [
        recent && items.length ? { section: lead } : null,
        ...items.map((i) => toRow(i)),
        ...(recent ? [{ section: recent.label, quiet: true }, ...recent.items.map((i) => toRow(i, true))] : []),
      ],
      body: items.length ? null : emptyRow(empty),
    });
  }

  // ---- Today ----------------------------------------------------------------------------------
  async function today(ctx) {
    const { app } = ctx;
    const now = new Date();
    const screen = U.el('bcv-screen bcv-ph-screen');
    const body = U.el('bcv-ph-body');
    // the bell opens Notifications (a pushed screen); the avatar the account sheet
    const badge = h('span', { class: 'bcv-ph-bell__badge', hidden: true });
    const bell = h('button', { type: 'button', class: 'bcv-ph-bell', 'aria-label': 'Notifications', onclick: () => app.go('/#notifications') }, [U.svg(BELL, { size: 17, stroke: 'var(--bcv-ink2)', width: 1.9 }), badge]);
    const avatarBtn = h('button', { type: 'button', class: 'bcv-ph-avatar', 'aria-label': 'Account', onclick: () => accountSheet(app) }, h('span', { text: '·' }));
    // the Dashboard's search box (content/app/search.js) under the title: courses, work, files, people and every
    // command from one field; while it has results they take the screen (the counters and lists step aside)
    const omni = BCV.search?.field?.(app);
    screen.append(bigTitle('Today', { above: `${U.DAYS_LONG[now.getDay()]}, ${U.MONTHS_LONG[now.getMonth()]} ${now.getDate()}`, right: U.el('bcv-ph-title__right', [bell, avatarBtn]) }), ...(omni ? [U.el('bcv-ph-search', omni)] : []), body);
    body.append(U.loading('rows', 4));

    // (2.98.92) the courses' assignments asked for beside the planner, and Overdue and Graded counted first from the copy
    // kept from the last visit, then again from Canvas's answer — the Dashboard's way
    const selP = selection();
    const freshP = selP.then((s) => Promise.all((s.list || []).map(async (c) => ({ c, list: await store.assignments(c.id) })))).catch(() => null);
    const [planner, sel, feed, me, notifs, overrides, kept] = await Promise.all([store.planner().catch(() => null), selP, store.announcementsFeed().catch(() => null), store.me().catch(() => null), store.notifUnread().catch(() => null), store.plannerOverrides().catch(() => []), store.keptAssignments().catch(() => null)]);
    if (!ctx.alive()) return screen;
    // the Dashboard's own lists (screens/dashboard.js workLists): the same counts, the same sheets
    const keptBy = kept ? sel.list.map((c) => ({ c, list: kept.get(String(c.id))?.list })) : [];
    const useKept = sel.list.length > 0 && keptBy.every((b) => Array.isArray(b.list));
    const Wf = BCV.screens.dashboard.workLists({ planner, favs: sel.list, overrides, dark: app.isDark(), now, lists: freshP });
    const W = useKept ? BCV.screens.dashboard.workLists({ planner, favs: sel.list, overrides, dark: app.isDark(), now, lists: Promise.resolve(keptBy) }) : Wf;
    avatarBtn.replaceChildren(me?.avatar && !/avatar-50|no_pic|dotted_pic/.test(me.avatar) ? h('img', { src: me.avatar, alt: '', referrerpolicy: 'no-referrer' }) : h('span', { text: U.initials(me?.name || '') || '·' }));
    if (notifs) { badge.textContent = String(notifs); badge.hidden = false; }
    const favs = sel.list;
    const todayStart = U.startOfDay(now);
    const weekStart = U.startOfWeek(now);
    const weekEnd = U.addDays(weekStart, 7);
    // filtered to the selected courses before anything is counted
    const live = (planner || []).filter((it) => !it.dismissed && it.type !== 'announcement' && inSelection(sel, it));
    const open = live.filter((it) => !it.complete && !it.submitted);
    const dueToday = [...W.dueToday].sort(byDate);
    const dueNext = [...W.dueNext].sort(byDate);
    const dueTomorrow = [...W.dueTomorrow].sort(byDate);
    const upcoming = open.filter((it) => it.isDue && it.date >= todayStart && !U.sameDay(it.date, now)).sort(byDate);
    const inSelFeed = (a) => !a.context_code || sel.ids.has(String(a.context_code).replace(/^course_/, ''));
    const unread = feed ? feed.filter((a) => a.read_state === 'unread' && inSelFeed(a)) : null;
    const readSince = U.addDays(todayStart, -14);
    const readRecently = feed ? feed.filter((a) => a.read_state !== 'unread' && inSelFeed(a) && U.parse(a.posted_at) >= readSince).sort((x, y) => U.parse(y.posted_at) - U.parse(x.posted_at)) : [];
    const weekAll = live.filter((it) => it.isDue && it.date >= weekStart && it.date < weekEnd && (it.points === null || it.points > 0));

    // the six counters (the Dashboard's six, 2.98.36) roll to their value on entry; each opens the
    // list it counted, split the Dashboard's way. Overdue and Graded read each course's assignments
    // and land a moment later; a pair whose read fails leaves rather than show a false 0.
    const stat = (label, value, onTap, seed, tone = '') => {
      const v = U.text('bcv-ph-stat__value', value);
      if (/^\d+$/.test(value)) U.roll(v, Number(value), { seed });
      return h('button', { type: 'button', class: `bcv-ph-stat ${tone}`, onclick: onTap }, [U.text('bcv-ph-stat__label', label, 'span'), v]);
    };
    const land = (btn, n, seed) => { const v = btn.querySelector('.bcv-ph-stat__value'); if (v) U.roll(v, n, { seed }); };
    const dayLine = (d) => `${U.DAYS_LONG[d.getDay()]}, ${U.MONTHS_LONG[d.getMonth()]} ${d.getDate()}`;
    const ptsOf = (items) => items.reduce((n, it) => n + (Number(it.points) || 0), 0);
    const dueSheet = (title, items, from, to, day, empty) => () => itemsSheet(app, {
      title, note: items.length ? `${store.fmtPts(ptsOf(items))} points across ${U.plural(W.courseCount(items), 'course')} · ${day}` : day,
      items: items.map(W.dueRow), empty, recent: W.recentOf('Already done', W.doneIn(from, to).sort(byDate).map(W.doneRow)),
    });
    const annRow = (a, state) => ({ title: a.title || 'Announcement', meta: `Posted ${U.fmtShort(a.posted_at)} · ${state}`, course: a.context_name || '', color: '#ff9500', url: a.html_url });
    let overdueN = null; // (the Overdue sheet's live list: a clear counts it down)
    const overdueBtn = stat('Overdue', '…', () => overdueN && overdueN.open(), 6.9, 'is-red');
    const gradedBtn = stat('Graded', '…', () => gradedN && gradedN.open(), 9.2);
    let gradedN = null;
    const stats = U.el('bcv-ph-stats bcv-ph-stats--six', [
      stat('Due today', String(dueToday.length), dueSheet('Due today', dueToday, todayStart, U.addDays(todayStart, 1), dayLine(now), 'Nothing is due today.'), 0),
      stat('Next 7 days', String(dueNext.length), dueSheet('Next 7 days', dueNext, todayStart, W.nextEnd, `${U.fmtShort(todayStart)} – ${U.fmtShort(U.addDays(todayStart, 6))}`, 'Nothing is due in the next 7 days.'), 2.3),
      stat('Unread', unread ? String(unread.length) : '—', () => itemsSheet(app, {
        title: 'Unread announcements', note: unread?.length ? U.plural(unread.length, 'announcement') : 'All caught up',
        items: (unread || []).map((a) => annRow(a, 'unread')), empty: 'All caught up.', lead: 'Unread',
        recent: W.recentOf('Read recently', readRecently.map((a) => annRow(a, 'read'))),
      }), 4.6),
      overdueBtn,
      stat('Tomorrow', String(dueTomorrow.length), dueSheet('Due tomorrow', dueTomorrow, U.addDays(todayStart, 1), U.addDays(todayStart, 2), dayLine(U.addDays(todayStart, 1)), 'Nothing is due tomorrow.'), 3.4),
      gradedBtn,
    ]);
    let shown = ''; // '' · 'kept' · 'fresh'
    const cleared = new Set(); // (rows cleared with their X stay cleared when Canvas's answer comes)
    const show = ([od, gr], fresh) => {
      if (!ctx.alive() || shown === 'fresh') return;
      const again = !!shown;
      if (!od || !gr) { if (!again) { overdueBtn.remove(); gradedBtn.remove(); } return; } // (a failed answer leaves the kept counts)
      shown = fresh ? 'fresh' : 'kept';
      // a count Canvas's answer changed is put right without rolling again
      const put = (btn, n, seed) => {
        const v = btn.querySelector('.bcv-ph-stat__value');
        if (!again) land(btn, n, seed);
        else if (v && btn._bcvN !== n) { clearInterval(v._bcvRoll); v._bcvRoll = null; delete v.dataset.rolling; v.textContent = String(n); }
        btn._bcvN = n;
      };
      const overdue = od.overdue.filter((o) => !cleared.has(o.key));
      const { lateIn } = od;
      const overdueNote = () => (overdue.length ? 'Past due with nothing handed in' : 'Nothing past its due date without a submission');
      // the X on a row dismisses it on Canvas's planner — the Dashboard's X, the To Do screen's
      for (const o of overdue) o.clear = async () => { await store.dismiss(o.item); cleared.add(o.key); const i = overdue.indexOf(o); if (i >= 0) overdue.splice(i, 1); land(overdueBtn, overdue.length, 0); overdueBtn._bcvN = overdue.length; };
      overdueN = {
        open: () => itemsSheet(app, {
          title: 'Overdue', note: overdueNote(), items: overdue, empty: 'Nothing is overdue.', lead: 'Not handed in', recent: W.recentOf('Handed in late', lateIn),
          onCleared: (sheet) => { const n = sheet.querySelector('.bcv-ph-sheet__note'); if (n) n.textContent = overdueNote(); if (!sheet.querySelector('.bcv-ph-srow__item')) { const lead = sheet.querySelector('.bcv-ph-sheet__sec'); lead?.replaceWith(emptyRow('Nothing is overdue.')); } },
        }),
      };
      put(overdueBtn, overdue.length, 6.9);
      overdueBtn.classList.toggle('is-clear', !overdue.length);
      const { graded, earlier, earned, possible } = gr;
      gradedN = {
        open: () => itemsSheet(app, {
          title: 'Graded this week', note: graded.length ? `${store.fmtPts(earned)} of ${store.fmtPts(possible)} points earned · week of ${U.fmtShort(weekStart)}` : `Week of ${U.fmtShort(weekStart)}`,
          items: graded, empty: 'Nothing has been graded this week.', lead: 'This week', recent: W.recentOf('Earlier', earlier),
        }),
      };
      put(gradedBtn, graded.length, 9.2);
    };
    if (W !== Wf) Promise.all([W.overdueP, W.gradedP]).then((r) => show(r, false));
    Promise.all([Wf.overdueP, Wf.gradedP]).then((r) => show(r, true));

    // the list: what is due today (or, on a quiet day, what comes next)
    const list = dueToday.length ? dueToday : upcoming.slice(0, 6);
    const heading = dueToday.length ? (now.getHours() >= 17 ? 'Tonight' : 'Today') : 'Next up';
    const latest = dueToday.length ? dueToday[dueToday.length - 1].date : null;
    const note = dueToday.length ? `${U.plural(dueToday.length, 'item')} · by ${U.fmtTime(latest)}` : (upcoming.length ? 'nothing due today' : '');
    const listBlock = h('div', {}, [
      groupHead(heading, note),
      list.length ? listCard(list.map((it) => workRow(app, it))) : listCard([emptyRow(planner ? 'Nothing due in the next three weeks.' : 'Your planner could not be loaded.')]),
    ]);

    // week load: submitted over assigned this week, per selected course, bars wiping in from the left
    const rows = [];
    let idle = 0;
    favs.forEach((c, i) => {
      const mine = weekAll.filter((it) => it.courseId === c.id);
      if (!mine.length) { idle++; return; }
      const done = mine.filter((it) => it.submitted).length;
      rows.push(U.el('bcv-ph-load__row', [
        U.text('bcv-ph-load__code bcv-ellip', c.shortName || c.name, 'span'),
        h('span', { class: 'bcv-ph-load__bar' }, h('span', { class: 'bcv-ph-load__fill bcv-work__fill--grow', style: { width: `${mine.length ? Math.round((done / mine.length) * 100) : 0}%`, background: c.color, '--bcv-delay': `${140 + Math.min(i, 6) * 90}ms` } })),
        U.text('bcv-ph-load__count', `${done}/${mine.length}`, 'span'),
      ]));
    });
    const load = favs.length ? U.el('bcv-ph-card bcv-ph-load', [
      U.text('bcv-ph-kicker', 'Week load', 'span'),
      ...rows,
      rows.length ? null : U.text('bcv-ph-load__none', 'Nothing assigned this week.'),
      idle ? U.text('bcv-ph-load__none', `${U.plural(idle, 'course')} with nothing assigned this week`) : null,
    ]) : null;

    body.replaceChildren(...[enter(stats, 0), enter(listBlock, 1), load ? enter(load, 2) : null].filter(Boolean));
    return screen;
  }

  // ---- Notifications (pushed from the bell) ----------------------------------------------------
  const NF_META = (dark) => ({
    overdue: { label: 'Overdue', ink: dark ? '#ff8098' : '#c01d43', tint: dark ? 'rgba(255,45,85,.2)' : 'rgba(255,45,85,.12)', icon: IC.warn },
    soon: { label: 'Due soon', ink: dark ? '#ffb44d' : '#8a5200', tint: 'rgba(255,149,0,.18)', icon: IC.clock },
    graded: { label: 'Graded', ink: dark ? '#5ddb7d' : '#1a6b30', tint: dark ? 'rgba(52,199,89,.2)' : 'rgba(52,199,89,.14)', icon: IC.chart },
    feedback: { label: 'Feedback', ink: dark ? '#7ab8ff' : '#0a5dc2', tint: dark ? 'rgba(10,132,255,.22)' : 'rgba(10,132,255,.12)', icon: IC.disc },
    message: { label: 'Messages', ink: dark ? '#7dd3e6' : '#0e6f80', tint: dark ? 'rgba(48,176,199,.22)' : 'rgba(48,176,199,.13)', icon: IC.mail },
    discuss: { label: 'Discussions', ink: dark ? '#d29bf0' : '#6b2f8c', tint: dark ? 'rgba(175,82,222,.22)' : 'rgba(175,82,222,.13)', icon: IC.people },
    announce: { label: 'News', ink: dark ? '#a9a7f5' : '#3f3ea8', tint: dark ? 'rgba(88,86,214,.22)' : 'rgba(88,86,214,.13)', icon: BELL },
    system: { label: 'System', ink: dark ? '#c7c7cc' : '#3c3c43', tint: 'rgba(118,118,128,.18)', icon: IC.shield },
  });
  const NF_ORDER = ['overdue', 'soon', 'graded', 'feedback', 'message', 'discuss', 'announce', 'system'];
  function relDay(d) {
    if (!d) return 'Earlier';
    const diff = U.dayDiff(d);
    if (diff === 0) return 'Today';
    if (diff === -1) return 'Yesterday';
    if (diff > -7 && diff < 0) return U.DAYS_LONG[d.getDay()];
    return U.fmtShort(d);
  }
  async function notifications(ctx) {
    const { app } = ctx;
    const dark = app.isDark();
    const meta = NF_META(dark);
    const screen = U.el('bcv-screen bcv-ph-screen', null, { dataset: { bcvTitle: 'Notifications' } });
    const chips = U.el('bcv-ph-nfchips');
    const body = U.el('bcv-ph-body bcv-ph-body--nf');
    screen.append(U.el('bcv-ph-nfhead', chips), body);
    body.append(U.loading('rows', 4));
    let feed = null;
    let state = { read: {}, gone: {} };
    let filter = 'all';
    let sel = null;
    try {
      [feed, state, sel] = await Promise.all([store.notifications(), store.notifState(), selection()]);
    } catch {
      feed = null;
    }
    if (!ctx.alive()) return screen;
    if (!feed) {
      body.replaceChildren(U.errorBox('Notifications could not be loaded.'));
      return screen;
    }
    feed = feed.filter((n) => { const cid = n.courseId ?? n.course_id; return !cid || sel.ids.has(String(cid)); }); // only the selected courses, before any count
    const live = () => feed.filter((n) => !state.gone[n.id]);
    const persist = async () => {
      await store.setNotifState(state).catch(() => {});
      app.refreshCounts();
    };
    function drawChips() {
      const all = live();
      const defs = [{ key: 'all', label: 'All', count: all.length }, ...NF_ORDER.map((k) => ({ key: k, label: meta[k].label, count: all.filter((n) => n.cat === k).length }))].filter((c) => c.count > 0 || c.key === 'all');
      chips.replaceChildren(...defs.map((c) => h('button', { type: 'button', class: `bcv-ph-nfchip ${filter === c.key ? 'is-on' : ''}`, dataset: { cat: c.key }, text: c.count ? `${c.label} ${c.count}` : c.label, onclick: () => { filter = c.key; draw(); } })));
    }
    function row(n) {
      const m = meta[n.cat] || meta.system;
      const isRead = !!state.read[n.id];
      const open = async () => {
        if (!state.read[n.id]) { state.read[n.id] = true; await persist(); }
        app.go(n.url || '/');
      };
      const front = h('div', { class: `bcv-ph-nfrow ${isRead ? 'is-read' : ''}`, dataset: { id: n.id, cat: n.cat }, role: 'link', tabindex: '0', onclick: open, onkeydown: (e) => { if (e.key === 'Enter') open(); } }, [
        h('span', { class: 'bcv-ph-nfrow__tile', style: { background: m.tint } }, U.svg(m.icon, { size: 15, stroke: m.ink, width: 1.9 })),
        U.el('bcv-ph-nfrow__body', [
          U.el('bcv-ph-nfrow__line', [U.text('bcv-ph-nfrow__title bcv-pretty', n.title, 'span'), h('span', { class: 'bcv-ph-nfrow__dot' })]),
          U.text('bcv-ph-nfrow__sub', [n.course, n.note, n.whenText].filter(Boolean).join(' · ')),
          h('span', { class: 'bcv-ph-nfrow__cat', style: { background: m.tint, color: m.ink }, text: m.label }),
        ]),
      ]);
      // Read sits under the thumb; Clear (the destructive one) outboard of it
      const wrap = swipeable(front, [
        { label: 'Read', color: '#0a84ff', icon: CHECK, width: 2.8, onSelect: async () => { state.read[n.id] = true; await persist(); draw(); } },
        { label: 'Clear', color: '#ff453a', icon: IC.close, onSelect: async () => { state.gone[n.id] = true; await persist(); draw(); } },
      ]);
      wrap.dataset.flip = n.id;
      return wrap;
    }
    // drawn once with its entrance; after that (a Read, a Clear, a chip) the same list changes in place —
    // no entrance again, and the rows that stay slide into the gap (ui.flipList)
    let drawn = false;
    function draw() {
      if (drawn) return U.still(() => U.flipList(body, paint));
      paint();
      drawn = true;
    }
    function paint() {
      closeSwipes();
      drawChips();
      const all = live();
      const unread = all.filter((n) => !state.read[n.id]).length;
      const vis = filter === 'all' ? all : all.filter((n) => n.cat === filter);
      const parts = [U.el('bcv-ph-nfcount', [
        U.text('bcv-ph-nfcount__t', `${U.plural(all.length, 'notification')} · ${unread} unread`, 'span'),
        h('button', { type: 'button', class: 'bcv-ph-nfcount__btn', id: 'bcv-nf-readall', text: 'Read all', onclick: async () => { for (const n of all) state.read[n.id] = true; await persist(); draw(); } }),
        h('button', { type: 'button', class: 'bcv-ph-nfcount__btn', id: 'bcv-nf-clear', text: 'Clear all', onclick: async () => { for (const n of all) state.gone[n.id] = true; await persist(); draw(); } }),
      ])];
      if (!vis.length) parts.push(U.el('bcv-ph-nfempty', [U.text('bcv-ph-nfempty__t', 'Nothing here'), U.text('bcv-ph-nfempty__s', all.length ? 'Nothing in this category.' : 'Cleared notifications do not come back.')]));
      const days = new Map();
      for (const n of vis) {
        const k = relDay(n.when);
        if (!days.has(k)) days.set(k, []);
        days.get(k).push(n);
      }
      let gi = 0;
      for (const [day, items] of days) parts.push(enter(h('div', { class: 'bcv-ph-nfgroup', dataset: { flip: `d-${day}` } }, [U.text('bcv-ph-nfgroup__t', day), listCard(items.map(row))]), gi++));
      const gone = Object.keys(state.gone).filter((id) => feed.some((n) => n.id === id));
      if (gone.length) parts.push(h('button', { type: 'button', class: 'bcv-ph-disclose', id: 'bcv-nf-restore', text: `Restore ${U.plural(gone.length, 'cleared notification')}`, onclick: async () => { state.gone = {}; await persist(); draw(); } }));
      parts.push(U.hint('Swipe a notification left to mark it read or clear it.', 'bcv-ph-foot'));
      body.replaceChildren(...parts);
    }
    draw();
    return screen;
  }

  // ---- Courses --------------------------------------------------------------------------------
  async function courses(ctx) {
    const { app } = ctx;
    const screen = U.el('bcv-screen bcv-ph-screen');
    const body = U.el('bcv-ph-body');
    const sub = U.text('bcv-ph-title__sub bcv-ph-title__sub--below', '…');
    const titleEl = bigTitle('Courses', {});
    titleEl.querySelector('.bcv-ph-title__text').append(sub);
    screen.append(titleEl, body);
    body.append(U.loading('rows', 5));
    const [all, sel, term, feed] = await Promise.all([store.courses().catch(() => null), selection(), store.currentTerm().catch(() => ''), store.announcementsFeed().catch(() => null)]);
    if (!ctx.alive()) return screen;
    if (!all) {
      body.replaceChildren(U.errorBox('Your courses could not be loaded.'));
      return screen;
    }
    const current = all.filter((c) => c.state === 'current');
    const list = sel.list; // the selected courses only, in the order they were chosen
    sub.textContent = `${term ? `${term} · ` : ''}${list.length === current.length ? `${list.length} enrolled` : `${list.length} of ${current.length} selected`}`;
    const unreadFor = (c) => (feed ? feed.filter((a) => a.read_state === 'unread' && String(a.context_code || '') === `course_${c.id}`).length : 0);
    function row(c, i) {
      const name = c.nickname ? c.originalName : (c.code && c.code !== c.name ? c.code : c.name);
      const progress = U.text('bcv-ph-crow__sub bcv-ellip', name);
      store.progress(c.id).then(({ done, total }) => {
        if (!total) return;
        progress.textContent = `${name} · ${done} of ${total} submitted`;
      }).catch(() => {});
      const n = unreadFor(c);
      const front = h('a', { class: 'bcv-ph-crow', href: c.url, onclick: (e) => { e.preventDefault(); app.go(c.url); } }, [
        h('span', { class: 'bcv-ph-crow__tile', style: { background: c.palette.tint } }, h('span', { class: 'bcv-ph-crow__dot', style: { background: c.color } })),
        U.el('bcv-ph-crow__body', [U.text('bcv-ph-crow__code bcv-ellip', c.shortName || c.name), progress]),
        n ? h('span', { class: 'bcv-ph-badge', text: String(n), title: U.plural(n, 'unread announcement') }) : null,
        U.text('bcv-ph-crow__pct', c.score !== null && c.score !== undefined ? `${store.fmtPts(c.score)}%` : 'N/A', 'span'),
        chev(),
      ]);
      // swipe left: a nickname (Canvas's own, so it shows in Canvas too)
      const wrap = swipeable(front, [{ label: 'Nickname', color: '#5856d6', icon: IC.pencil, onSelect: () => nicknameSheet(c) }]);
      wrap.classList.add('bcv-ph-swipe--card');
      return enter(wrap, i);
    }
    function nicknameSheet(c) {
      const real = c.originalName || c.name;
      const input = h('input', { class: 'bcv-input bcv-ph-nick__input', type: 'text', value: c.nickname || '', placeholder: real, maxlength: '60', 'aria-label': 'Nickname', autocapitalize: 'words' });
      const save = async (v) => {
        try {
          await store.setNickname(c.id, v);
          app.loadShellData({ force: true });
          app.render();
          U.toast(v ? 'Nickname saved.' : 'Nickname removed.');
        } catch (e) {
          U.toast(`Could not save it: ${e.message}`, { error: true });
        }
      };
      const sh = openSheet({
        title: 'Nickname', label: 'Course nickname', note: `Shown instead of “${real}” everywhere, in Canvas too.`,
        body: U.el('bcv-ph-nick', input),
        actions: [
          { label: 'Save', primary: true, onSelect: () => save(input.value.trim()) },
          c.nickname ? { label: 'Remove nickname', cls: 'is-danger', onSelect: () => save('') } : null,
        ],
      });
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { sh.close(); save(input.value.trim()); } });
      setTimeout(() => input.focus(), 60);
    }
    body.replaceChildren(
      U.el('bcv-ph-clist', list.length ? list.map(row) : [emptyRow('No courses selected. Choose them in the guided setup or Settings.')]),
      list.length < current.length ? U.hint(`${U.plural(current.length - list.length, 'other course')} hidden here and everywhere else on the phone. Change the selection in Settings → Courses & targets.`, 'bcv-ph-foot') : null,
    );
    return screen;
  }

  // ---- To Do ----------------------------------------------------------------------------------
  const endOfDay = (d) => { const x = new Date(d); x.setHours(23, 59, 0, 0); return x; };
  async function todo(ctx) {
    const { app } = ctx;
    const dark = app.isDark();
    const screen = U.el('bcv-screen bcv-ph-screen');
    const body = U.el('bcv-ph-body');
    const sub = U.text('bcv-ph-title__sub bcv-ph-title__sub--below', '…');
    const titleEl = bigTitle('To Do', {});
    titleEl.querySelector('.bcv-ph-title__text').append(sub);
    screen.append(titleEl, body);
    body.append(U.loading('rows', 5));
    let group = await store.pref('todoGroup', 'date');
    if (!['date', 'priority', 'course'].includes(group)) group = 'date';
    let showDone = !!(await store.pref('todoShowDone', false));
    const priPref = await store.pref('todoPriority', {});
    let pri = priPref && typeof priPref === 'object' ? { ...priPref } : {}; // replaced by the merged map on every write
    const repPref = await store.pref('todoRepeat', {});
    let rep = repPref && typeof repPref === 'object' ? { ...repPref } : {}; // item id → { every, series }: which tasks of your own repeat
    let [items, sel] = await Promise.all([store.todoWindow().catch(() => null), selection()]);
    if (!ctx.alive()) return screen;
    if (!items) {
      body.replaceChildren(U.errorBox('Your planner could not be loaded.'));
      return screen;
    }
    const isOpen = (it) => !it.complete && !it.dismissed && !it.submitted && !it.excused; // (excused work is nothing to do)
    const isDone = (it) => it.complete || it.submitted;
    const priOf = (it) => Number(pri[it.id]) || 0;
    const setPri = (it, lv) => { // one entry, merged against the latest map in storage
      if (lv) pri[it.id] = lv; else delete pri[it.id];
      store.mergePref('todoPriority', { [it.id]: lv || null }).then((map) => { if (ctx.alive()) pri = map; });
    };
    const now = new Date();
    const visibleItems = () => items.filter((it) => !it.dismissed && inSelection(sel, it)); // the selected courses and the student's own tasks
    async function reload() {
      items = await store.todoWindow({ force: true }).catch(() => items);
      if (!ctx.alive()) return;
      app.refreshCounts();
      draw();
    }
    async function toggleDone(it) {
      U.haptic?.(it.complete ? 'light' : 'success');
      try {
        await store.setComplete(it, !it.complete);
        app.refreshCounts();
        draw();
      } catch (e) {
        U.toast(`Could not update it: ${e.message}`, { error: true });
      }
    }
    const repeatOf = (it) => (it.custom && rep[it.id] && typeof rep[it.id] === 'object' ? rep[it.id] : null);
    const repeatWord = (r) => store.REPEATS.find((x) => x.key === r?.every)?.short || '';
    /** The other tasks of a repeating task's series still on the planner. */
    const seriesOf = (it) => { const s = repeatOf(it)?.series; return s ? items.filter((x) => x.custom && x.id !== it.id && rep[x.id]?.series === s) : []; };
    /** A task of your own, or every task left in its series, after a confirmation. */
    async function removeTask(it, series = null) {
      const list = series || [it];
      const ask = list.length > 1 ? `Delete all ${list.length} repeats of “${it.title}”? This removes them from your Canvas planner.` : `Delete “${it.title}”? This removes the task from your Canvas planner.`;
      if (!window.confirm(ask)) return;
      try {
        await store.deleteNotes(list.map((x) => x.raw.plannable_id));
        const gone = {};
        for (const x of list) { delete pri[x.id]; delete rep[x.id]; gone[x.id] = null; }
        store.mergePref('todoPriority', gone).then((map) => { if (ctx.alive()) pri = map; });
        store.mergePref('todoRepeat', gone).then((map) => { if (ctx.alive()) rep = map; });
        await reload();
      } catch (e) {
        U.toast(`Could not delete it: ${e.message}`, { error: true });
        await reload(); // (some of a series may have gone before the refusal)
      }
    }
    // a task of your own: "My task · Personal", or its course's short name · "My task" once it was given one; "repeats weekly" when it does
    const metaOf = (it) => (it.custom ? [it.course ? 'My task' : 'Personal', repeatOf(it) ? `repeats ${repeatWord(repeatOf(it))}` : null].filter(Boolean).join(' · ') : `${it.kind}${it.points !== null && it.points !== undefined ? ` · ${store.fmtPts(it.points)} pts` : ''}`);
    const courseOf = (it) => (it.custom && !it.course ? 'My task' : (it.course?.shortName || it.courseName || 'Course'));

    /** The task sheet: priority, mark done, open the source (or delete a task of your own — or its whole series). */
    function taskSheet(it) {
      const done = isDone(it);
      const pal = it.custom ? (it.course ? it.course.palette : TASK_PAL(dark)) : it.course ? it.course.palette : U.palette('#8e8e93', dark);
      const rest = it.custom ? seriesOf(it) : [];
      const cur = priOf(it);
      let sheet = null;
      const body = U.el('bcv-ph-tsheet', [
        U.el('bcv-ph-tsheet__head', [
          h('span', { class: 'bcv-ph-tsheet__dot', style: { background: pal.text } }),
          h('div', { style: { flex: '1', minWidth: '0' } }, [U.text('bcv-ph-tsheet__title bcv-pretty', it.title), U.text('bcv-ph-tsheet__sub', `${courseOf(it)} · ${metaOf(it)} · ${U.whenShort(it.date)}`)]),
        ]),
        U.text('bcv-ph-kicker bcv-ph-tsheet__k', 'Priority', 'span'),
        U.el('bcv-ph-tsheet__pris', [3, 2, 1, 0].map((lv) => {
          const m = priMeta(lv, dark);
          const on = cur === lv;
          return h('button', { type: 'button', class: `bcv-ph-tsheet__pri ${on ? 'is-on' : ''}`, dataset: { pri: lv }, style: on ? { background: m.tint } : null, onclick: () => { setPri(it, lv); sheet?.close(); draw(); } }, [
            h('span', { class: 'bcv-ph-tsheet__pdot', style: { background: m.color } }),
            h('span', { class: 'bcv-ph-tsheet__plabel', text: m.label }),
            U.svg(CHECK, { size: 15, stroke: 'var(--bcv-blue)', width: 2.8, style: { opacity: on ? '1' : '0', flex: 'none' } }),
          ]);
        })),
      ]);
      sheet = openSheet({
        label: it.title, cls: 'bcv-ph-sheet--task', body,
        actions: [
          { label: done ? 'Mark not done' : 'Mark done', cls: done ? '' : 'is-green', onSelect: () => toggleDone(it) },
          it.custom ? null : { label: it.type === 'quiz' ? 'Take quiz' : it.type === 'assignment' ? 'Open assignment' : 'Open', onSelect: () => app.go(it.url) },
          it.custom ? { label: 'Delete task', cls: 'is-danger', onSelect: () => removeTask(it) } : null,
          rest.length ? { label: `Delete all ${rest.length + 1} repeats`, cls: 'is-danger', onSelect: () => removeTask(it, [it, ...rest]) } : null,
        ],
      });
    }

    /** A To Do row: the circle marks it done, the body opens the task sheet, a swipe left reveals Priority / Done. */
    function todoRow(it, { withCourse = true } = {}) {
      const done = isDone(it);
      const lv = priOf(it);
      const pm = priMeta(lv, dark);
      const circle = h('button', { type: 'button', class: `bcv-ph-circle ${done ? 'is-done' : ''}`, 'aria-label': `${done ? 'Mark not done' : 'Mark done'}: ${it.title}`, onclick: (e) => { e.stopPropagation(); toggleDone(it); } }, U.svg(CHECK, { size: 12, stroke: '#fff', width: 3, cls: 'bcv-ph-circle__check' }));
      const front = h('div', { class: `bcv-ph-row bcv-ph-trow ${done ? 'is-done' : ''}`, dataset: { item: it.id }, role: 'button', tabindex: '0', onclick: () => taskSheet(it), onkeydown: (e) => { if (e.key === 'Enter') taskSheet(it); } }, [
        circle,
        U.el('bcv-ph-row__body', [
          U.text('bcv-ph-row__title bcv-ellip', it.title),
          U.text('bcv-ph-row__sub bcv-ellip', withCourse ? `${courseOf(it)} · ${metaOf(it)}` : metaOf(it)),
        ]),
        U.statusBadge(store.workFlags(it)[0]), // where the work stands — Missing, Late, Excused, Feedback, New — the same words as everywhere else
        lv ? h('span', { class: 'bcv-ph-pri', style: { background: pm.tint, color: pm.color } }, [U.svg(IC.flag, { size: 9, stroke: pm.color, width: 2.4 }), h('span', { text: pm.short })]) : null,
        U.text('bcv-ph-row__time', U.fmtTime(it.date), 'span'),
      ]);
      return swipeable(front, [
        { label: 'Priority', color: '#ff9500', icon: IC.flag, onSelect: () => taskSheet(it) },
        { label: 'Done', color: '#34c759', icon: CHECK, width: 2.8, onSelect: () => toggleDone(it) },
      ]);
    }

    // ---- adding a task of your own (a Canvas planner note) ----
    // the date starts at today and is picked on a calendar; the task is due by the end of that day.
    // It can be given a course (one of the selected ones) and a repeat — daily, weekly, every two
    // weeks or monthly, until a date (eight weeks on unless changed) — one note per day it lands on.
    const REPEAT_UNTIL_DAYS = 56;
    const blank = () => ({ open: false, title: '', date: null, pri: 2, busy: false, course: '', repeat: '', until: null, progress: '' });
    const draft = blank();
    const draftStart = () => U.startOfDay(draft.date || now);
    const draftDates = () => (draft.repeat ? store.repeatDates(draftStart(), draft.until || U.addDays(draftStart(), REPEAT_UNTIL_DAYS), draft.repeat) : [draftStart()]);
    const canAdd = () => !!draft.title.trim() && !draft.busy && draftDates().length > 0;
    function composer() {
      if (!draft.open) {
        return h('button', { type: 'button', class: 'bcv-ph-todo__add', onclick: () => { draft.open = true; draw(); body.querySelector('.bcv-ph-composer__title')?.focus(); } }, [
          h('span', { class: 'bcv-ph-todo__addic' }, U.svg(IC.plus, { size: 14, stroke: 'var(--bcv-blue)', width: 2.4 })),
          h('span', { class: 'bcv-ph-todo__addlabel', text: 'Add your own task' }),
        ]);
      }
      let addBtn;
      const addLabel = () => { const n = draftDates().length; return draft.busy ? (draft.progress || 'Adding…') : n > 1 ? `Add ${n} tasks` : 'Add task'; };
      const syncAdd = () => { addBtn.disabled = !canAdd(); addBtn.textContent = addLabel(); };
      const title = h('input', { class: 'bcv-ph-composer__title', type: 'text', placeholder: 'What do you need to do?', 'aria-label': 'Task', value: draft.title, oninput: () => { draft.title = title.value; syncAdd(); }, onkeydown: (e) => { if (e.key === 'Enter' && canAdd()) addTask(); } });
      const dateField = U.dateField(draft.date || now, (d) => { draft.date = d; syncAdd(); }, { cls: 'bcv-ph-composer__date' });
      // the course (the selected courses) and the repeat, side by side; an "until" date once it repeats
      const courseSel = U.picker([{ value: '', text: 'No course' }, ...sel.list.map((c) => ({ value: String(c.id), text: c.shortName || c.name }))], draft.course, (v) => { draft.course = v; }, { label: 'Course', placeholder: 'No course', cls: 'bcv-ph-composer__course' });
      const repeatSel = U.picker([{ value: '', text: 'Doesn’t repeat' }, ...store.REPEATS.map((x) => ({ value: x.key, text: x.label }))], draft.repeat, (v) => { draft.repeat = v; if (v && !draft.until) draft.until = U.addDays(draftStart(), REPEAT_UNTIL_DAYS); draw(); }, { label: 'Repeat', placeholder: 'Doesn’t repeat', cls: 'bcv-ph-composer__repeat' });
      const until = draft.repeat ? U.el('bcv-ph-composer__until', [
        U.text('bcv-ph-composer__untillbl', 'until', 'span'),
        U.dateField(draft.until, (d) => { draft.until = d; syncAdd(); }, { cls: 'bcv-ph-composer__date bcv-ph-composer__untildate', label: 'Repeat until' }),
      ]) : null;
      const pris = U.el('bcv-ph-composer__pris', [3, 2, 1, 0].map((lv) => {
        const m = priMeta(lv, dark);
        const on = draft.pri === lv;
        return h('button', { type: 'button', class: `bcv-ph-composer__pri ${on ? 'is-on' : ''}`, dataset: { pri: lv }, style: on ? { background: m.tint, color: m.color } : null, text: m.label, onclick: () => { draft.pri = lv; draw(); } });
      }));
      addBtn = h('button', { type: 'button', class: 'bcv-ph-composer__add', text: 'Add task', onclick: addTask });
      const card = U.el('bcv-ph-composer', [
        title, dateField, U.el('bcv-ph-composer__row', [courseSel, repeatSel]), until, pris,
        U.el('bcv-ph-composer__btns', [h('button', { type: 'button', class: 'bcv-ph-composer__cancel', text: 'Cancel', onclick: () => { Object.assign(draft, blank()); draw(); } }), addBtn]),
      ]);
      syncAdd();
      return card;
    }
    async function addTask() {
      if (!canAdd()) return;
      const dates = draftDates();
      const title = draft.title.trim();
      const courseId = draft.course || null;
      const every = draft.repeat;
      const level = draft.pri;
      draft.busy = true;
      draft.progress = '';
      draw();
      try {
        const notes = await store.createNotes(dates.map((d) => ({ title, todoDate: endOfDay(d).toISOString(), courseId })), {
          onEach: (k, n) => { if (n > 1) { draft.progress = `Adding ${k} of ${n}…`; const b = body.querySelector('.bcv-ph-composer__add'); if (b) b.textContent = draft.progress; } },
        });
        const keys = notes.filter((n) => n && n.id !== undefined && n.id !== null).map((n) => `planner_note:${n.id}`);
        if (level && keys.length) { const patch = Object.fromEntries(keys.map((k) => [k, level])); Object.assign(pri, patch); pri = await store.mergePref('todoPriority', patch); }
        if (every && keys.length) { const series = `r${Date.now().toString(36)}`; const patch = Object.fromEntries(keys.map((k) => [k, { every, series }])); Object.assign(rep, patch); rep = await store.mergePref('todoRepeat', patch); }
        Object.assign(draft, blank());
        await reload();
        U.toast(keys.length > 1 ? `${keys.length} tasks added to your Canvas planner.` : 'Added to your Canvas planner.');
      } catch (e) {
        draft.busy = false;
        draft.progress = '';
        draw();
        U.toast(`Could not add the task: ${e.message}`, { error: true });
        if (dates.length > 1) reload(); // (some of a series may have landed before the refusal)
      }
    }

    // the first draw is the screen arriving (the groups stagger in); every draw after it is the
    // same list with one thing changed, and lands in place, still (ui.still)
    let drawn = false;
    const draw = () => (drawn ? U.still(paint) : paint());
    function paint() {
      closeSwipes();
      const all = visibleItems();
      const done = all.filter(isDone).length;
      const open = all.filter(isOpen);
      const realCourses = new Set(all.filter((i) => !i.custom).map((i) => i.courseId)).size; // a task of your own is not a course
      sub.textContent = `${open.length} open across ${U.plural(realCourses, 'course')}${all.some((i) => i.custom) ? ' · with your own tasks' : ''}`;
      const pct = all.length ? Math.round((done / all.length) * 100) : 0;
      const progress = U.el('bcv-ph-card bcv-ph-progress', [
        U.el('bcv-ph-progress__line', [U.text('bcv-ph-progress__pct', `${pct}%`, 'span'), U.text('bcv-ph-progress__note', `${done} of ${all.length} done`, 'span')]),
        all.length <= 24
          ? U.el('bcv-ph-progress__segs', all.map((it) => h('span', { class: `bcv-ph-progress__seg ${isDone(it) ? 'is-done' : ''}` })))
          : U.el('bcv-ph-progress__bar', h('span', { class: 'bcv-ph-progress__fill', style: { width: `${pct}%` } })),
      ]);
      const seg = U.seg([['date', 'Date'], ['priority', 'Priority'], ['course', 'Course']], group, (v) => { group = v; store.setPref('todoGroup', v); draw(); });
      const showRow = U.el('bcv-ph-card bcv-ph-switchrow', [
        U.text('bcv-ph-switchrow__t', showDone ? 'Showing completed' : 'Completed hidden', 'span'),
        U.switchEl(showDone, (on) => { showDone = on; store.setPref('todoShowDone', on); draw(); }, 'Show completed'),
      ]);
      const shown = all.filter((it) => showDone || isOpen(it));
      const groups = [];
      const block = (title, list, opts) => (list.length ? h('div', {}, [groupHead(title, U.plural(list.length, 'item')), listCard(list.map((it) => todoRow(it, opts)))]) : null);
      if (!shown.length) groups.push(listCard([emptyRow(showDone ? 'Nothing in the next seven days.' : 'Nothing to do in the next seven days.')]));
      else if (group === 'priority') {
        for (const lv of [3, 2, 1, 0]) groups.push(block(lv ? `${priMeta(lv).label} priority` : 'Unprioritised', shown.filter((it) => priOf(it) === lv).sort(byDate))); // empty buckets are dropped, never drawn
      } else if (group === 'course') {
        // a task given a course sits under that course; one without waits under My task, after the courses
        const by = new Map();
        const mine = [];
        for (const it of shown) {
          if (it.custom && !it.course) { mine.push(it); continue; }
          const k = courseOf(it);
          if (!by.has(k)) by.set(k, []);
          by.get(k).push(it);
        }
        for (const [k, list] of by) groups.push(block(k, list.sort(byDate), { withCourse: false }));
        if (mine.length) groups.push(block('My task', mine.sort(byDate), { withCourse: false }));
      } else {
        const days = new Map();
        for (const it of shown.sort(byDate)) {
          const d = U.dayDiff(it.date, now);
          const k = d < 0 ? 'Overdue' : d === 0 ? 'Today' : d === 1 ? 'Tomorrow' : d < 7 ? U.DAYS_LONG[it.date.getDay()] : U.fmtShort(it.date); // (past due, a task of your own past its day: Overdue, first)
          if (!days.has(k)) days.set(k, []);
          days.get(k).push(it);
        }
        for (const [k, list] of days) groups.push(block(k, list));
      }
      body.replaceChildren(...[enter(progress, 0), seg, showRow, composer(), ...groups.filter(Boolean).map((g, i) => enter(g, i + 1)), U.hint('Tap a task to edit it. Swipe left for quick actions. Priority is yours alone and never reaches Canvas.', 'bcv-ph-foot')]);
      drawn = true;
    }
    draw();
    return screen;
  }

  // ---- Grades ----------------------------------------------------------------------------------
  const NS = 'http://www.w3.org/2000/svg';
  const svgEl = (tag, attrs) => { const el = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, String(v)); return el; };
  const dashFor = (pct, r) => { const c = 2 * Math.PI * r; const f = (Math.max(0, Math.min(100, pct)) / 100) * c; return `${f.toFixed(1)} ${(c - f).toFixed(1)}`; };
  const CAT_R = [16, 10.5, 5];
  async function gpa(ctx) {
    const { app } = ctx;
    const dark = app.isDark();
    const G = BCV.screens.gpa;
    const screen = U.el('bcv-screen bcv-ph-screen');
    const body = U.el('bcv-ph-body');
    const titleEl = bigTitle('Grades', { below: 'every course counts equally' });
    screen.append(titleEl, body);
    body.append(U.loading('rows', 4));
    const [all, term, goalPref, hiddenPref, targetsPref, trackingPref, snapsPref, ownPref] = await Promise.all([store.courses().catch(() => null), store.currentTerm().catch(() => ''), store.pref('gpaGoal'), store.pref('gpaHidden'), store.pref('gradeTargets'), store.pref('gpaTracking'), store.pref('gpaSnapshots'), store.pref('gradeWeights'), G.loadScales?.().catch(() => null)]);
    // (2.99.140) each course's grading scale, where the student set one (its own, or theirs for every course), letters it
    const scaleFor = (c) => (G.scaleOf ? G.scaleOf(c.id) : G.SCALE);
    // (2.98.59) a course's own weights, set on its Grades tab: its score here is worked out by them, not Canvas's
    const ownW = ownPref && typeof ownPref === 'object' ? ownPref : {};
    const ownFor = (c) => (ownW[c.id] && typeof ownW[c.id] === 'object' && Object.keys(ownW[c.id]).length ? ownW[c.id] : null);
    if (!ctx.alive()) return screen;
    if (!all) {
      body.replaceChildren(U.errorBox('Your courses could not be loaded.'));
      return screen;
    }
    titleEl.querySelector('.bcv-ph-title__sub').textContent = `${term ? `${term} · ` : ''}every course counts equally`;
    const hidden = new Set(Array.isArray(hiddenPref) ? hiddenPref.map(String) : []);
    const currentAll = all.filter((c) => c.state === 'current');
    const starredAll = currentAll.filter((c) => c.favorite); // the one course list, chosen in setup
    const courseList = (starredAll.length ? starredAll : currentAll).filter((c) => !hidden.has(String(c.id)));
    // (E15) a goal never set (or set to 0) is none: the hero asks for one in neutral words rather than measure the term
    // against a 4.00 nobody chose; the stepper starts from 4.00, the setup's own starting point
    let goal = Number.isFinite(goalPref) && goalPref > 0 ? goalPref : null;
    const targets = targetsPref && typeof targetsPref === 'object' ? { ...targetsPref } : {};
    let whatIf = false; // nothing here is saved
    const whatIfVals = {};
    let expanded = null; // one course open at a time
    const groups = new Map();
    await Promise.all(courseList.map(async (c) => groups.set(c.id, await store.assignmentGroups(c.id).catch(() => null))));
    if (!ctx.alive()) return screen;
    const gmCache = new Map();
    const gmFor = (c) => {
      if (!gmCache.has(c.id)) gmCache.set(c.id, store.gradeModel(groups.get(c.id) || [], c, {}, false, dark, [], { ownWeights: ownFor(c) }));
      return gmCache.get(c.id);
    };
    const ownPct = (c) => { if (!ownFor(c)) return null; const t = gmFor(c).total; return t === null || t === undefined ? null : Number(t); };
    const gradedCount = (c) => {
      let graded = 0, total = 0;
      for (const g of groups.get(c.id) || []) for (const a of g.assignments || []) {
        if (a.published === false || !(Number(a.points_possible) > 0)) continue;
        total++;
        if (a.submission?.workflow_state === 'graded' && a.submission.score !== null && a.submission.score !== undefined) graded++;
      }
      return { graded, total };
    };
    const rowsFor = () => courseList.map((c) => {
      const op = ownPct(c); // (the student's own weights: their total and a letter from it, never Canvas's)
      const base = op !== null ? op : c.score !== null && c.score !== undefined ? Number(c.score) : null;
      const tried = whatIf && Number.isFinite(whatIfVals[c.id]);
      const pct = tried ? whatIfVals[c.id] : base;
      const scored = pct !== null;
      const S = scaleFor(c);
      const mine = tried || op !== null || !!G.hasScale?.(c.id); // (Simpl's letter from the scale, not Canvas's)
      const letter = scored ? (mine || !c.grade ? G.letterFor(pct, S)[0] : String(c.grade).replace(/-/g, '−')) : null;
      const pts = scored ? (mine ? G.letterFor(pct, S)[2] : G.pointsFor(c.grade, pct, S)) : null;
      return { c, scored, pct, letter, pts, tried, S, ...gradedCount(c) };
    });
    const termGpaOf = (rows) => { const s = rows.filter((r) => r.scored); return s.length ? s.reduce((a, r) => a + r.pts, 0) / s.length : null; };

    // ---- the hero: the term GPA (rolls in), the goal stepper, the bar, the distance to the goal ----
    const valueEl = U.text('bcv-ph-hero__gpa', '—', 'span');
    const goalVal = U.text('bcv-ph-hero__goalv', gpa2(goal), 'span');
    const barFill = h('span', { class: 'bcv-work__fill--grow' });
    const diffIcon = h('span', { class: 'bcv-ph-hero__diffic' });
    const diffText = U.text('bcv-ph-hero__diff', '', 'span');
    const goalNote = U.text('bcv-ph-hero__goalnote', '', 'span');
    let rolled = false;
    const saveGoal = () => store.setPref('gpaGoal', goal ?? 0).catch(() => {});
    const step = (by) => { goal = goal === null ? (by < 0 ? 3.95 : 4) : Math.max(0, Math.min(4, +(goal + by).toFixed(2))); if (goal === 0) goal = null; saveGoal(); paintHero(); };
    const setGoal = h('button', { type: 'button', class: 'bcv-ph-hero__set', text: 'Set a goal', title: 'Aim for a term GPA: 4.00 to start, − and + to change it', onclick: () => step(0.05) });
    const hero = U.el('bcv-ph-hero', [
      U.el('bcv-ph-hero__line', [valueEl, U.text('bcv-ph-hero__k', 'term GPA', 'span'), U.el('bcv-ph-hero__goal', [
        h('button', { type: 'button', class: 'bcv-ph-hero__step', text: '−', 'aria-label': 'Lower the goal', onclick: () => step(-0.05) }),
        goalVal,
        h('button', { type: 'button', class: 'bcv-ph-hero__step', text: '+', 'aria-label': 'Raise the goal', onclick: () => step(0.05) }),
      ])]),
      U.el('bcv-ph-hero__bar', barFill),
      U.el('bcv-ph-hero__foot', [diffIcon, diffText, setGoal, goalNote]),
    ]);
    function paintHero() {
      const rows = rowsFor();
      const g = termGpaOf(rows);
      if (!rolled && g !== null) { U.roll(valueEl, g, { decimals: 2 }); rolled = true; } else valueEl.textContent = gpa2(g);
      goalVal.textContent = goal === null ? '—' : gpa2(goal);
      barFill.style.width = `${g === null ? 0 : Math.round((g / 4) * 100)}%`;
      const diff = g === null || goal === null ? null : g - goal;
      // (E15) the goal is said once, in the stepper: the line under the bar says only how far off it the term is
      diffIcon.replaceChildren(U.svg(goal === null ? 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7.5a4.5 4.5 0 100 9 4.5 4.5 0 000-9zM12 11a1 1 0 100 2 1 1 0 000-2z' : diff === null || diff >= 0 ? 'M12 19V5M6 11l6-6 6 6' : 'M12 5v14M6 13l6 6 6-6', { size: 13, stroke: '#fff', width: 2.4 }));
      diffText.hidden = goal === null;
      setGoal.hidden = goal !== null;
      diffText.textContent = goal === null ? '' : diff === null ? 'no score to compare yet' : diff >= 0 ? `+${gpa2(diff)} above goal` : `${gpa2(Math.abs(diff))} below goal`; // (below says it: no minus sign doubling it)
      goalNote.textContent = whatIf ? 'what-if' : '';
    }

    // ---- one card per course: a disclosure that opens the category rings, the breakdown and the target ----
    function ringSvg(r, delay) {
      const c = r.c;
      const svg = svgEl('svg', { viewBox: '0 0 56 56', class: 'bcv-ph-ring__svg' });
      svg.append(svgEl('circle', { cx: 28, cy: 28, r: 22, fill: 'none', stroke: dark ? 'rgba(255,255,255,.1)' : 'rgba(120,120,128,.16)', 'stroke-width': 6 }));
      if (r.scored) svg.append(svgEl('circle', { cx: 28, cy: 28, r: 22, fill: 'none', stroke: c.color, 'stroke-width': 6, 'stroke-linecap': 'round', 'stroke-dasharray': dashFor(r.pct, 22), ...(delay === null ? {} : { class: 'bcv-ring--fill', style: `--bcv-delay: ${delay}ms` }) }));
      return svg;
    }
    function catRings(cats) {
      return cats.slice(0, CAT_R.length).map((ct, k) => {
        const svg = svgEl('svg', { viewBox: '0 0 56 56', class: 'bcv-ph-ring__svg bcv-ph-ring__cat' });
        svg.append(svgEl('circle', { cx: 28, cy: 28, r: CAT_R[k], fill: 'none', stroke: dark ? 'rgba(255,255,255,.1)' : 'rgba(120,120,128,.16)', 'stroke-width': 4.5 }));
        if (ct.pct !== null) svg.append(svgEl('circle', { cx: 28, cy: 28, r: CAT_R[k], fill: 'none', stroke: ct.color, 'stroke-width': 4.5, 'stroke-linecap': 'round', 'stroke-dasharray': dashFor(ct.pct, CAT_R[k]), class: 'bcv-ring--fill bcv-ring--fill-cat', style: `--bcv-delay: ${k * 80}ms` }));
        return svg;
      });
    }
    let entered = false;
    function card(r, i) {
      const c = r.c;
      const open = expanded === c.id;
      const cats = gmFor(c).legend;
      const ring = h('span', { class: 'bcv-ph-ring' }, [ringSvg(r, entered ? null : Math.min(i * 70, 320)), ...(open ? catRings(cats) : [])]);
      const head = h('button', { type: 'button', class: 'bcv-ph-gcard__hd', 'aria-expanded': open ? 'true' : 'false', onclick: () => { expanded = open ? null : c.id; drawList(); } }, [
        ring,
        U.el('bcv-ph-gcard__body', [
          U.text('bcv-ph-gcard__code bcv-ellip', c.shortName || c.name),
          U.text('bcv-ph-gcard__sub bcv-ellip', `${c.nickname ? c.originalName : (c.code && c.code !== c.name ? c.code : c.name)} · ${r.total ? `${r.graded} of ${r.total} graded` : 'nothing graded'}`),
          U.el('bcv-ph-gcard__line', [
            U.text('bcv-ph-gcard__pct', r.scored ? `${store.fmtPts(r.pct)}%` : 'N/A', 'span'),
            h('span', { class: 'bcv-ph-gcard__letter', style: r.scored ? { background: c.palette.tint, color: c.palette.text } : null, text: r.scored ? r.letter : 'no score' }),
            r.tried ? h('span', { class: 'bcv-ph-gcard__tried', text: 'what-if' }) : null,
          ]),
        ]),
        chev(open ? 'M6 15l6-6 6 6' : 'M6 9l6 6 6-6'),
      ]);
      const el = h('div', { class: `bcv-ph-gcard ${open ? 'is-open' : ''}`, dataset: { course: c.id } }, head);
      if (open) {
        const curIdx = G.targetIndex(targets[c.id]);
        const defIdx = r.scored ? r.S.indexOf(G.letterFor(r.pct, r.S)) : -1;
        const idx = G.snapIdx ? G.snapIdx(r.S, curIdx >= 0 ? curIdx : defIdx) : curIdx >= 0 ? curIdx : defIdx;
        const more = U.el('bcv-ph-gcard__more', [
          cats.length ? U.el('bcv-ph-cats', cats.slice(0, 4).map((ct) => U.el('bcv-ph-cat', [
            h('span', { class: 'bcv-ph-cat__dot', style: { background: ct.color } }),
            U.el('bcv-ph-cat__body', [
              U.el('bcv-ph-cat__line', [U.text('bcv-ph-cat__name bcv-ellip', ct.label, 'span'), U.text('bcv-ph-cat__w', ct.weightText || '', 'span'), U.text('bcv-ph-cat__pct', ct.value, 'span')]),
              h('span', { class: 'bcv-ph-cat__bar' }, h('span', { class: 'bcv-work__fill--grow', style: { width: `${Math.max(0, Math.min(100, ct.pct ?? 0))}%`, background: ct.color } })),
            ]),
          ]))) : U.text('bcv-ph-load__none', 'No graded groups yet.'),
          whatIf ? U.el('bcv-ph-whatif__row', [
            U.text('bcv-ph-whatif__k', 'What-if score', 'span'),
            h('input', { class: 'bcv-input bcv-ph-whatif__in', type: 'number', min: '0', max: '100', step: '0.1', inputmode: 'decimal', placeholder: r.scored ? String(r.pct) : '—', value: Number.isFinite(whatIfVals[c.id]) ? String(whatIfVals[c.id]) : '', 'aria-label': `What-if score for ${c.shortName || c.name}`, onchange: (e) => { const v = Number(e.target.value); if (e.target.value === '' || !Number.isFinite(v)) delete whatIfVals[c.id]; else whatIfVals[c.id] = Math.max(0, Math.min(100, v)); paintHero(); drawList(); } }),
            U.text('bcv-ph-whatif__u', '%', 'span'),
          ]) : null,
          r.scored ? U.el('bcv-ph-target', [
            U.text('bcv-ph-target__k', 'Target', 'span'),
            U.el('bcv-ph-target__seg', r.S.map((s, k) => (Number.isFinite(s[1]) ? h('button', { type: 'button', class: `bcv-ph-target__btn ${k === idx ? 'is-on' : ''}`, text: s[0], onclick: () => { targets[c.id] = s[0].replace(/−/g, '-'); store.setPref('gradeTargets', targets); drawList(); } }) : null)).filter(Boolean)),
          ]) : null,
        ]);
        el.append(more);
      }
      return entered ? el : enter(el, i);
    }
    const list = U.el('bcv-ph-glist');
    function drawList() {
      closeSwipes();
      const rows = rowsFor();
      list.replaceChildren(...(rows.length ? rows.map((r, i) => card(r, i)) : [emptyRow('No current courses.')]));
      entered = true;
    }
    // ---- the trend (2.98.36): the Grades page's own chart — the history its tracking keeps, a smooth
    // curve through every day, a finger on it reading out that day's GPA ----
    const tracking = !!(trackingPref && typeof trackingPref === 'object' && (trackingPref.since || Number.isFinite(trackingPref.priorGpa)));
    const snaps = Array.isArray(snapsPref) ? snapsPref.filter((x) => x && x.date && Number.isFinite(x.gpa)) : [];
    const trendCard = tracking && snaps.length >= 2 ? U.el('bcv-ph-card bcv-ph-trend', [
      U.el('bcv-ph-trend__head', [U.text('bcv-ph-kicker', 'Trend', 'span'), U.text('bcv-ph-trend__range', `${gpa2(G.MIN_Y)} – ${gpa2(G.MAX_Y)}${goal > 0 ? ' · dashed is your goal' : ''}`, 'span')]),
      ...G.trendChart(snaps, { goal: goal > 0 ? goal : null, animate: true, ticks: 4, minGap: 20 }),
      U.text('bcv-ph-trend__note', `${U.plural(snaps.length, 'snapshot')} · drag along the line for any day`),
    ]) : null;

    // ---- Item grades (2.98.35 on the Grades page): every graded assignment, by letter ----
    const itemSt = { band: 'all', more: false };
    const { items: gItems, counts: gCounts } = G.gradedItems(courseList, gmFor);
    const itemsHost = h('div');
    function paintItems() {
      const pick = itemSt.band === 'all' ? gItems : gItems.filter((it) => it.band === itemSt.band);
      const n = itemSt.more ? pick.length : Math.min(pick.length, 12);
      const rows = pick.slice(0, n).map(({ c, g, band, pct }) => h('a', { class: 'bcv-ph-row bcv-ph-irow', href: g.url || '#', onclick: (e) => { e.preventDefault(); if (g.url) openItem(app, g.url); } }, [
        h('span', { class: 'bcv-ph-irow__dot', style: { background: c.color } }),
        U.el('bcv-ph-row__body', [U.text('bcv-ph-row__title bcv-ellip', g.name), U.text('bcv-ph-row__sub bcv-ellip', `${c.shortName || c.name} · ${store.fmtPts(Math.round(pct * 10) / 10)}%`)]),
        U.bandChip(band),
        U.text('bcv-ph-row__right', `${store.fmtPts(g.earned)}/${store.fmtPts(g.possible)}`, 'span'),
        chev(),
      ]));
      const more = pick.length > n ? h('button', { type: 'button', class: 'bcv-ph-more', text: `Show all ${pick.length}`, onclick: () => { itemSt.more = true; paintItems(); } }) : null;
      itemsHost.replaceChildren(listCard(pick.length ? [...rows, more].filter(Boolean) : [emptyRow(`No ${itemSt.band} grades in your courses.`)]));
    }
    paintItems();
    const itemsBlock = gItems.length ? h('div', { class: 'bcv-ph-items' }, [
      groupHead('Item grades', 'by letter'),
      U.el('bcv-ph-bands', U.bandSlider(gCounts, itemSt.band, (b) => { itemSt.band = b; itemSt.more = false; paintItems(); })),
      itemsHost,
    ]) : null;

    const warn = U.el('bcv-ph-warn', [U.svg(IC.warn, { size: 19, stroke: '#ff453a', width: 2.2, style: { flex: 'none' } }), U.text('bcv-ph-warn__t', 'This is not your actual score.', 'span')]);
    const whatIfRow = U.el('bcv-ph-card bcv-ph-whatif', [
      h('div', { style: { flex: '1', minWidth: '0' } }, [U.text('bcv-ph-whatif__t', 'What-if scores'), U.text('bcv-ph-whatif__s', 'Test outcomes. Nothing is saved.')]),
      U.switchEl(false, (on) => { whatIf = on; if (!on) for (const k of Object.keys(whatIfVals)) delete whatIfVals[k]; warn.hidden = !on; paintHero(); drawList(); }, 'What-if scores'),
    ]);
    warn.hidden = true;
    paintHero();
    drawList();
    body.replaceChildren(...[enter(hero, 0, 380), trendCard, whatIfRow, warn, list, itemsBlock].filter(Boolean), U.hint('Term GPA is computed here from the scores Canvas reports, on a 4.0 scale with every course counting equally. It is not your school’s official GPA. Tap a course for its category rings and target.', 'bcv-ph-foot'));
    return screen;
  }

  // ---- Calendar --------------------------------------------------------------------------------
  async function calendar(ctx) {
    const { app } = ctx;
    const dark = app.isDark();
    const now = new Date();
    const screen = U.el('bcv-screen bcv-ph-screen');
    const body = U.el('bcv-ph-body');
    const titleEl = h('h1', { class: 'bcv-ph-h1' });
    const nav = U.el('bcv-ph-calnav', [
      h('button', { type: 'button', class: 'bcv-ph-calnav__btn', 'aria-label': 'Previous', onclick: () => shift(-1) }, U.svg('M15 5l-7 7 7 7', { size: 16, stroke: 'var(--bcv-blue)', width: 2.2 })),
      h('button', { type: 'button', class: 'bcv-ph-calnav__btn', 'aria-label': 'Next', onclick: () => shift(1) }, U.svg(CHEV, { size: 16, stroke: 'var(--bcv-blue)', width: 2.2 })),
    ]);
    const segWrap = h('div');
    screen.append(U.el('bcv-ph-title bcv-ph-title--cal', [h('div', { class: 'bcv-ph-title__text' }, titleEl), nav]), U.el('bcv-ph-calseg', segWrap), body);
    body.append(U.loading('rows', 4));
    let view = await store.pref('calViewPhone', 'month');
    if (!['week', 'month', 'list'].includes(view)) view = 'month';
    let anchor = new Date(now.getFullYear(), now.getMonth(), 1);
    let weekStart = U.startOfWeek(now);
    let selected = U.startOfDay(now);
    const wantCourse = ctx.route.params.get('include_contexts');
    const [contexts, plannerItems] = await Promise.all([store.calendarContexts().catch(() => []), store.planner().catch(() => [])]);
    const submittedIds = new Set(plannerItems.filter((it) => it.submitted).map((it) => `${it.type}:${it.raw?.plannable_id}`));
    let chosen = await store.selectedContexts(contexts);
    if (wantCourse && contexts.some((c) => c.code === wantCourse) && !chosen.includes(wantCourse)) chosen = [...chosen.slice(0, 9), wantCourse];
    const ctxMap = new Map(contexts.map((c) => [c.code, c]));
    let events = [];
    let loadedKey = null;
    let notice = null;

    const sundayStart = (d) => U.addDays(U.startOfDay(d), -U.startOfDay(d).getDay());
    function range() {
      if (view === 'month') { const s = sundayStart(anchor); return [s, U.addDays(s, 42)]; }
      if (view === 'week') return [weekStart, U.addDays(weekStart, 7)];
      return [U.startOfDay(now), U.addDays(U.startOfDay(now), 21)];
    }
    function shift(dir) {
      if (view === 'month') anchor = new Date(anchor.getFullYear(), anchor.getMonth() + dir, 1);
      else if (view === 'week') weekStart = U.addDays(weekStart, 7 * dir);
      else return;
      load();
    }
    function normalize(raw) {
      const out = [];
      for (const e of raw) {
        const cc = ctxMap.get(e.context_code) || null;
        const a = e.assignment || null;
        const isAssignment = e.type === 'assignment' || !!a;
        // an all-day event is a day, not an instant: Canvas names the day (all_day_date); its start_at
        // is that day's midnight in the maker's zone, which is the evening before in another
        const allDay = !isAssignment && !!e.all_day && /^\d{4}-\d{2}-\d{2}$/.test(String(e.all_day_date || ''));
        const date = allDay ? (([y, mo, d]) => new Date(y, mo - 1, d))(e.all_day_date.split('-').map(Number)) : U.parse(isAssignment ? (a?.due_at || e.start_at) : e.start_at);
        if (!date) continue;
        const sub = a?.submission;
        const submitted = !!(sub && (sub.submitted_at || sub.workflow_state === 'graded' || sub.workflow_state === 'submitted')) || (a && (submittedIds.has(`assignment:${a.id}`) || (a.quiz_id && submittedIds.has(`quiz:${a.quiz_id}`))));
        const excused = !!sub?.excused;
        const types = a?.submission_types || [];
        const submittable = !!types.length && !types.some((t) => t === 'none' || t === 'on_paper' || t === 'not_graded' || t === 'external_tool');
        const kind = !isAssignment ? (e.appointment_group_id ? 'Appointment' : 'Event') : types.includes('online_quiz') || a?.is_quiz_assignment ? 'Quiz' : types.includes('discussion_topic') ? 'Discussion' : 'Assignment';
        const pal = U.palette(cc?.color || '#8e8e93', dark);
        // an event that has happened is struck through; an assignment only once it is handed in — one
        // past its due date with nothing in is missing work, and says so
        out.push({ id: String(e.id), title: e.title || a?.name || 'Untitled', date, allDay: !!e.all_day && !isAssignment, isAssignment, kind, done: isAssignment ? submitted || excused : date < now, missing: isAssignment && date < now && !submitted && !excused && (submittable || !!sub?.missing), excused, points: a?.points_possible ?? null, location: e.location_name || '', color: pal.text, dot: cc?.color || '#8e8e93', contextName: cc?.name || e.context_name || '', url: e.html_url || a?.html_url || '/calendar' });
      }
      return out.sort(byDate);
    }
    async function load() {
      titleEl.textContent = view === 'list' ? 'Upcoming' : view === 'week' ? `${U.MONTHS[weekStart.getMonth()]} ${weekStart.getDate()} – ${U.addDays(weekStart, 6).getDate()}` : `${U.MONTHS_LONG[anchor.getMonth()]}${anchor.getFullYear() !== now.getFullYear() ? ` ${anchor.getFullYear()}` : ''}`;
      nav.hidden = view === 'list';
      segWrap.replaceChildren(U.seg([['week', 'Week'], ['month', 'Month'], ['list', 'List']], view, (v) => { view = v; store.setPref('calViewPhone', v); load(); }));
      const [s, e] = range();
      const key = `${s.getTime()}:${e.getTime()}:${chosen.join(',')}`;
      if (loadedKey !== key) {
        let res;
        try { res = await store.calendarEvents(s, e, chosen); } catch (err) { res = { error: err }; }
        if (!ctx.alive()) return;
        notice = null;
        if (res.error) {
          events = [];
          notice = `Calendar events could not be loaded: ${res.error.message}`;
        } else {
          events = normalize(Array.isArray(res) ? res : (res.events || []));
          if (!chosen.length) notice = 'No calendars are selected. Turn one on under Calendars.';
        }
        loadedKey = key;
      }
      draw();
    }
    const eventsOn = (d) => events.filter((ev) => U.sameDay(ev.date, d));
    const evRow = (ev) => h('a', { class: `bcv-ph-ev ${ev.done ? 'is-done' : ''}`, href: ev.url, onclick: (e) => { e.preventDefault(); app.go(ev.url); } }, [
      h('span', { class: 'bcv-ph-ev__bar', style: { background: ev.dot } }),
      U.el('bcv-ph-ev__body', [
        U.text('bcv-ph-ev__title bcv-ellip', ev.title, 'span'),
        // the course, what it is, what it is worth, where it is — the same facts as the desktop's agenda
        U.text('bcv-ph-ev__sub bcv-ellip', [ev.contextName, ev.kind, ev.points !== null && ev.points !== undefined ? `${store.fmtPts(ev.points)} pts` : '', ev.location].filter(Boolean).join(' · '), 'span'),
      ]),
      ev.missing ? U.statusBadge({ word: 'Missing', kind: 'bad' }) : ev.excused ? U.statusBadge({ word: 'Excused', kind: 'muted' }) : null,
      U.text('bcv-ph-ev__time', ev.allDay ? 'All day' : U.fmtTime(ev.date), 'span'),
    ]);
    const dayBlock = (d, rel = '') => {
      const evs = eventsOn(d);
      return h('div', {}, [groupHead(`${U.DAYS_LONG[d.getDay()]} ${d.getDate()}`, `${rel}${U.plural(evs.length, 'item')}`), listCard(evs.length ? evs.map(evRow) : [emptyRow('Nothing on this day.')])]);
    };
    function monthGrid() {
      const s = sundayStart(anchor);
      const cells = [];
      for (let i = 0; i < 42; i++) {
        const d = U.addDays(s, i);
        const off = d.getMonth() !== anchor.getMonth();
        const isToday = U.sameDay(d, now);
        const isSel = U.sameDay(d, selected);
        const dots = [...new Set(eventsOn(d).map((ev) => ev.dot))].slice(0, 3);
        cells.push(h('button', { type: 'button', class: `bcv-ph-day ${off ? 'is-off' : ''} ${isToday ? 'is-today' : ''} ${isSel ? 'is-selected' : ''}`, 'aria-label': `${U.MONTHS_LONG[d.getMonth()]} ${d.getDate()}`, onclick: () => { selected = d; draw(); } }, [
          h('span', { class: 'bcv-ph-day__n', text: String(d.getDate()) }),
          h('span', { class: 'bcv-ph-day__dots' }, dots.map((c) => h('span', { style: { background: c } }))),
        ]));
      }
      return U.el('bcv-ph-cal', [U.el('bcv-ph-cal__dows', ['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((x) => U.text('bcv-ph-cal__dow', x, 'span'))), U.el('bcv-ph-cal__grid', cells)]);
    }
    function calendarsRow() {
      return h('button', { type: 'button', class: 'bcv-ph-linkrow', onclick: () => openSheet({
        title: 'Calendars', label: 'Calendars', note: 'Your courses are on; the rest are off until you turn one on. Canvas shows at most 10 calendars at once.',
        body: (() => {
          // the favourite courses first, on by default; the personal calendar, other courses and groups under their own heading
          const own = store.ownContexts(contexts);
          const ownSet = new Set(own.map((c) => c.code));
          const other = contexts.filter((c) => !ownSet.has(c.code));
          const srow = (c) => U.el('bcv-ph-srow bcv-ph-srow--static', [
            h('span', { class: 'bcv-ph-srow__bar', style: { background: c.color } }),
            U.el('bcv-ph-srow__body', [U.text('bcv-ph-srow__label bcv-ellip', c.name)]),
            U.switchEl(chosen.includes(c.code), async (on) => {
              if (on && chosen.length >= 10) { U.toast('Canvas shows at most 10 calendars at once. Turn one off first.', { error: true }); return; }
              chosen = on ? [...chosen, c.code] : chosen.filter((x) => x !== c.code);
              await store.setSelectedContexts(chosen);
              load();
            }, `Show ${c.name}`),
          ]);
          return U.el('bcv-ph-sheet__list', [...own.map(srow), other.length ? U.text('bcv-ph-sheet__sub', 'Other calendars') : null, ...other.map(srow)]);
        })(),
      }) }, [U.svg(IC.cal, { size: 15, stroke: 'var(--bcv-ink2)', width: 1.9 }), h('span', { text: `Calendars · ${chosen.length} of ${contexts.length} shown` }), chev()]);
    }
    function draw() {
      const parts = [notice ? U.el('bcv-ph-notice', notice) : null];
      if (view === 'month') parts.push(monthGrid(), dayBlock(selected, U.sameDay(selected, now) ? 'Today · ' : ''));
      else if (view === 'week') for (let i = 0; i < 7; i++) parts.push(dayBlock(U.addDays(weekStart, i), U.sameDay(U.addDays(weekStart, i), now) ? 'Today · ' : ''));
      else {
        const days = new Map();
        for (const ev of events) {
          const k = U.startOfDay(ev.date).getTime();
          if (!days.has(k)) days.set(k, []);
          days.get(k).push(ev);
        }
        if (!days.size) parts.push(listCard([emptyRow('Nothing in the next three weeks.')]));
        for (const [k] of days) parts.push(dayBlock(new Date(k), U.sameDay(new Date(k), now) ? 'Today · ' : U.dayDiff(new Date(k), now) === 1 ? 'Tomorrow · ' : ''));
      }
      parts.push(calendarsRow());
      body.replaceChildren(...parts.filter(Boolean).map((p, i) => enter(p, i)));
    }
    await load();
    return screen;
  }

  // ---- course: chip row (sub-tabs) and home ---------------------------------------------------
  /** The course's tabs as a scrolling chip row, on every course screen, Home included (Home also
   *  lists them at its end, with their counts). The chip for the screen you are on is brought into
   *  view: Files or Modules sit far to the right, and a row that opens scrolled to Home hides where you are. */
  function courseChips(app, tabs, activeId) {
    const row = U.el('bcv-ph-chips', tabs.map((t) => h('button', {
      type: 'button', class: `bcv-ph-tab ${t.id === activeId ? 'is-active' : ''} ${t.external ? 'is-ext' : ''}`, dataset: { tab: t.id }, onclick: () => { if (t.id !== activeId) app.go(t.href); },
    }, [h('span', { text: t.label }), t.external ? U.svg(EXT, { size: 11, width: 2, style: { flex: 'none' } }) : null])));
    let frames = 0;
    const center = () => {
      // (the row is made before the screen's data is in, and put on the page after: waited for, a few seconds at most)
      if (!row.isConnected || !row.clientWidth) { if (++frames < 300) requestAnimationFrame(center); return; }
      const a = row.querySelector('.bcv-ph-tab.is-active');
      if (!a || row.scrollWidth <= row.clientWidth) return;
      const r = row.getBoundingClientRect(), q = a.getBoundingClientRect();
      row.scrollLeft += (q.left + q.width / 2) - (r.left + r.width / 2);
    };
    requestAnimationFrame(center);
    return row;
  }

  const isQuizA = (a) => !!(a.is_quiz_assignment || a.quiz_id || (a.submission_types || []).includes('online_quiz'));
  const submittedA = (a) => { const s = a.submission || {}; return !!(s.submitted_at || ['submitted', 'graded', 'pending_review'].includes(s.workflow_state)); };
  const dueText = (d) => {
    const diff = U.dayDiff(d);
    if (diff === 0) return `${new Date().getHours() >= 17 ? 'tonight' : 'today'} ${U.fmtTime(d)}`;
    if (diff === 1) return `tomorrow ${U.fmtTime(d)}`;
    if (diff > 1 && diff < 7) return `${U.DAYS_LONG[d.getDay()]} ${U.fmtTime(d)}`;
    return U.fmtAt(d);
  };

  async function courseHome(ctx, shell) {
    const { app } = ctx;
    const c = shell.course;
    const b = U.el('bcv-body bcv-ph-body bcv-ph-body--course');
    b.append(U.loading('rows', 4));
    const [asg, anns] = await Promise.all([store.assignments(c.id).catch(() => null), store.announcements(c.id, { kind: shell.kind }).catch(() => null)]);
    if (!ctx.alive()) return b;
    const list = (asg || []).filter((a) => a.published !== false);
    // every piece of work still open — past due included, with its Missing flag, rather than dropped after a day
    const open = list.filter((a) => !submittedA(a) && !a.submission?.excused && !(a.submission_types || []).some((t) => ['none', 'on_paper', 'not_graded'].includes(t)))
      .sort((x, y) => (U.parse(x.due_at)?.getTime() || Infinity) - (U.parse(y.due_at)?.getTime() || Infinity));
    const turned = list.filter(submittedA).sort((x, y) => (U.parse(y.submission?.submitted_at)?.getTime() || 0) - (U.parse(x.submission?.submitted_at)?.getTime() || 0)).slice(0, 5);
    const kindOf = (a) => (isQuizA(a) ? 'Quiz' : (a.submission_types || []).includes('discussion_topic') ? 'Discussion' : 'Assignment');
    const hrefOf = (a) => (isQuizA(a) && a.quiz_id ? `${c.url}/quizzes/${a.quiz_id}` : `${c.url}/assignments/${a.id}`);

    const workRowA = (a) => {
      const st = store.workStatus(a); // (Missing, Opens …, Closed: said on the row; plain open work carries nothing)
      return h('a', { class: 'bcv-ph-row', href: hrefOf(a), onclick: (e) => { e.preventDefault(); openItem(app, hrefOf(a)); } }, [
        h('span', { class: 'bcv-ph-row__tile', style: { background: c.palette.tint } }, U.svg(isQuizA(a) ? IC.bolt : IC.doc, { size: 15, stroke: c.palette.text, width: 1.9 })),
        U.el('bcv-ph-row__body', [U.text('bcv-ph-row__title bcv-ellip', a.name), U.text('bcv-ph-row__sub bcv-ellip', `${kindOf(a)} · ${a.points_possible !== null && a.points_possible !== undefined ? `${store.fmtPts(a.points_possible)} pts` : 'no points'}${a.due_at ? ` · ${dueText(U.parse(a.due_at))}` : ''}`)]),
        st.kind && st.kind !== 'good' ? U.statusBadge(st) : null,
        chev(),
      ]);
    };
    const doneRowA = (a) => h('a', { class: 'bcv-ph-row is-done', href: hrefOf(a), onclick: (e) => { e.preventDefault(); openItem(app, hrefOf(a)); } }, [
      circleBox(true),
      U.el('bcv-ph-row__body', [U.text('bcv-ph-row__title bcv-ellip', a.name), U.text('bcv-ph-row__sub bcv-ellip', `${kindOf(a)} · submitted${a.submission?.submitted_at ? ` ${U.fmtAt(a.submission.submitted_at)}` : ''}${a.submission?.workflow_state === 'graded' && a.submission.score !== null && a.submission.score !== undefined ? ` · ${store.fmtPts(a.submission.score)}/${a.points_possible ?? '–'}` : ''}`)]),
      chev(),
    ]);

    // everything else the course has, as a grouped list (the course's own tabs)
    const unread = anns ? anns.filter((a) => a.read_state === 'unread').length : 0;
    const tabIcon = { announcements: IC.bell, assignments: IC.doc, discussions: IC.disc, grades: IC.chart, people: IC.people, pages: IC.page, files: IC.folder, quizzes: IC.bolt, modules: IC.modules, syllabus: IC.page };
    const links = (shell.tabs || []).filter((t) => t.id !== 'home').map((t) => h('a', { class: 'bcv-ph-row bcv-ph-row--link', href: t.href, dataset: { tab: t.id }, onclick: (e) => { e.preventDefault(); app.go(t.href); } }, [
      h('span', { class: 'bcv-ph-row__tile bcv-ph-row__tile--fill' }, U.svg(t.external ? EXT : (tabIcon[t.id] || IC.page), { size: 14, stroke: 'var(--bcv-ink2)', width: 1.9 })),
      U.text('bcv-ph-row__title bcv-ph-row__title--500 bcv-ellip', t.label),
      t.id === 'announcements' && unread ? h('span', { class: 'bcv-ph-badge bcv-ph-badge--grey', text: String(unread) }) : null,
      t.id === 'grades' && c.score !== null && c.score !== undefined ? U.text('bcv-ph-row__right', `${store.fmtPts(c.score)}%`, 'span') : null,
      t.external ? U.svg(EXT, { size: 13, stroke: 'var(--bcv-ink3)', width: 2, style: { flex: 'none' } }) : chev(),
    ]));

    // the front page or syllabus, folded: a first look, then the page itself (no separate reader on the phone)
    let front = null;
    let frontText = '';
    const view = c.defaultView;
    if (view === 'syllabus' || view === 'wiki' || !view) {
      const fp = view === 'syllabus' ? null : await store.frontPage(c.id, { kind: shell.kind }).catch(() => null);
      const htmlBody = view === 'syllabus' ? await store.syllabus(c.id).catch(() => '') : fp?.body || '';
      if (!ctx.alive()) return b;
      const title = view === 'syllabus' ? 'Syllabus' : 'Front page';
      const href = view === 'syllabus' ? `${c.url}/assignments/syllabus` : fp?.url ? `${c.url}/pages/${fp.url}` : `${c.url}/wiki`;
      frontText = htmlToText(htmlBody || '', 12000);
      if (frontText.trim()) {
        const excerpt = frontText.replace(/\s+/g, ' ').trim();
        front = U.el('bcv-ph-card bcv-ph-front', [
          U.text('bcv-ph-kicker', title, 'span'),
          U.text('bcv-ph-front__text bcv-pretty', excerpt.length > 220 ? `${excerpt.slice(0, 220).trim()}…` : excerpt),
          h('button', { type: 'button', class: 'bcv-ph-btn bcv-ph-btn--sm', text: 'Open', onclick: () => app.go(href) }),
        ]);
      }
    }

    b.replaceChildren(...[
      open.length ? enter(h('div', {}, [groupHead('Open work', U.plural(open.length, 'item')), listCard(open.map(workRowA))]), 0) : null, // (every item the head counts: none held back)
      turned.length ? enter(h('div', {}, [groupHead('Turned in'), listCard(turned.map(doneRowA))]), 1) : null,
      links.length ? enter(listCard(links, 'bcv-ph-links'), 2) : null,
      front ? enter(front, 3) : null,
      !asg ? U.errorBox('The assignment list could not be loaded.') : null,
    ].filter(Boolean));
    return b;
  }

  // ---- assignment (the item page): handing in lives here, on the same scroll ------------------
  /** The rubric button that sits with Submit assignment, because how the marks are decided belongs
   *  next to the decision to hand work in. It opens the same grid the desktop shows beside the
   *  assignment; on a phone that grid is a sheet, where it has the screen to itself.
   *  A fresh button each call: it goes in the submit block's own row, or on the page when there is
   *  no block to put it in (an assignment with nothing to submit still has a rubric). */
  function rubricButton(a, s, { cls = 'bcv-sb__btn', label = 'Rubric' } = {}) {
    const CS = BCV.screens.course;
    if (!a.rubric?.length) return null;
    const title = a.rubric_settings?.title || 'Rubric';
    return h('button', {
      type: 'button', class: `${cls} bcv-rubbtn`, 'aria-label': `${label}: ${title}`,
      onclick: () => CS.openRubric(a, s),
    }, [U.svg(IC.sheet, { size: 14, stroke: 'currentColor', width: 1.9 }), h('span', { text: label })]);
  }

  /** The mark, as the phone's version of the desktop chip: it sits in the title's row, it carries the
   *  number and nothing else, and pressing it is the way in to every attempt and the thread. Where
   *  Canvas has marked but not posted, there is no number to carry — only the fact that one is held. */
  function gradeChip(ctx, c, a, s, { posted, held, status }) {
    const handed = !posted && !held && !!(s.submitted_at || s.excused);
    if (!posted && !held && !handed) return null;
    const pc = a.points_possible ? `${Math.round((Number(s.score) / Number(a.points_possible)) * 100)}%` : (s.grade ? String(s.grade) : '');
    return h('button', {
      type: 'button', class: `bcv-ph-grade ${held ? 'bcv-ph-grade--held' : ''} ${handed ? 'bcv-ph-grade--sub' : ''}`,
      'aria-label': 'Submission details and comments',
      onclick: () => BCV.screens.courseDetail.openMark(ctx, c, a, s),
    }, [
      h('span', { class: 'bcv-ph-grade__body' }, posted ? [
        h('span', { class: 'bcv-ph-grade__v' }, [
          h('span', { class: 'bcv-ph-grade__score', text: store.fmtPts(s.score) }),
          h('span', { class: 'bcv-ph-grade__of', text: `/ ${a.points_possible ?? '—'}` }),
        ]),
        U.text('bcv-ph-grade__side', [pc, s.graded_at ? U.fmtAt(s.graded_at) : 'Marked'].filter(Boolean).join(' · '), 'span'),
      ] : handed ? [
        // handed in and waiting: the same chip, and the same way in to what was handed in
        U.text('bcv-ph-grade__held', status, 'span'),
        U.text('bcv-ph-grade__side', [s.submitted_at ? U.fmtAt(s.submitted_at) : null, s.attempt ? `Attempt ${s.attempt}` : null].filter(Boolean).join(' · ') || 'Nothing to hand in', 'span'),
      ] : [
        U.text('bcv-ph-grade__held', 'Not yet posted', 'span'),
        U.text('bcv-ph-grade__side', 'Not released yet', 'span'),
      ]),
      chev(),
    ]);
  }

  /** The assignment's facts as one wrapping row, never a table: Canvas's own fields, and no fact at
   *  all where Canvas has no value — an assignment with no unlock date must not claim one. */
  const phFacts = (pairs) => U.el('bcv-ph-facts', pairs.filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => h('span', { class: 'bcv-ph-fact' }, [h('b', { text: `${k} ` }), String(v)])));

  async function assignment(ctx, shell, { a, s, types, available, isTool, toolNewTab, toolLaunch, nativeSubmit, canvasOnly, attemptsLeft, status, posted, held, slot, fill }) {
    const { app } = ctx;
    const c = shell.course;
    const CS = BCV.screens.course;
    const nativeHref = (path) => `${path}${path.includes('?') ? '&' : '?'}bcv=native`;
    const b = U.el('bcv-body bcv-ph-body bcv-ph-body--item', null, { dataset: { bcvTitle: a.name } });
    const graded = s.workflow_state === 'graded' && s.score !== null && s.score !== undefined;
    // the submission block sits at the end of the page for what this app hands in itself; the tool
    // and Canvas-only cases keep one big button
    const embeds = nativeSubmit && !isTool;
    const primary = isTool
      ? { label: s.submitted_at || (s.attempt || 0) > 0 ? 'Continue assignment' : 'Start assignment', go: () => (BCV.exttool ? BCV.exttool.open({ title: a.name, url: toolLaunch, newTab: toolLaunch }) : window.open(toolLaunch, '_blank', 'noopener')) }
      : canvasOnly ? { label: s.submitted_at ? 'Resubmit in Canvas' : 'Submit in Canvas', go: () => app.go(nativeHref(`${c.url}/assignments/${a.id}`)) } : null;
    const block = embeds ? await BCV.screens.submit.render(ctx, c, { embed: true, a, sub: s, back: { href: `${c.url}/assignments`, label: 'Assignments' }, title: 'Submit work', aside: () => rubricButton(a, s) }) : null;
    if (!ctx.alive()) return b;
    b.append(...[
      h('span', { class: 'bcv-ph-chip bcv-ph-chip--course', style: { background: c.palette.tint, color: c.palette.text }, text: c.shortName || c.name }),
      // The title and the mark share the phone's first row exactly as they do on the desktop: the
      // mark is the answer the page is opened for, and the way in to what is behind it. Ungraded,
      // the chip is absent and the title has the row to itself.
      U.el('bcv-ph-item__head', [
        h('h1', { class: 'bcv-ph-item__title bcv-pretty', text: a.name }),
        gradeChip(ctx, c, a, s, { posted, held, status }),
      ]),
      phFacts([
        ['Due', a.due_at ? dueText(U.parse(a.due_at)) : 'No due date'],
        ['Points', a.points_possible ?? '—'],
        ['Submitting', types],
        ['Available', available],
        ['Attempts', BCV.screens.courseDetail.attemptsFact(a, s)],
      ]),
      // The banner is what is true where there is no chip: not handed in, and Canvas says it is
      // missing. Handed in (marked or not), the chip above carries the state and is the way in.
      status === 'Missing' && !s.submitted_at ? U.el('bcv-ph-banner bcv-ph-banner--warn', [U.svg(IC.warn, { size: 20, stroke: 'var(--bcv-red-text)', width: 2.2, style: { flex: 'none' } }), h('div', {}, [U.text('bcv-ph-banner__t', 'Missing'), U.text('bcv-ph-banner__s', 'Canvas marked this as missing')])]) : null,
      // and the rubric keeps its own button, where the marks are decided rather than reported
      graded ? rubricButton(a, s, { cls: 'bcv-ph-bigbtn', label: 'See breakdown' }) : null,
      U.el('bcv-ph-card bcv-ph-instr', [U.text('bcv-ph-kicker', 'Instructions', 'span'), a.description ? CS.prose(a.description, { cls: 'bcv-ph-prose' }) : U.text('bcv-ph-load__none', 'No description.'), types ? U.text('bcv-ph-instr__note', `Accepts ${types}`) : null]),
      primary ? h('button', { type: 'button', class: 'bcv-ph-bigbtn is-primary', text: primary.label, onclick: primary.go }) : null,
      // where Canvas asks for a mark rather than work, the mark is the page's action (drawn when
      // the item's module answers; the page does not wait for it)
      (() => { const el = slot('bcv-ph-doneslot'); fill(el, ({ modItem }) => BCV.screens.courseDetail.doneButton(ctx, c, a, modItem, { cls: 'bcv-ph-bigbtn bcv-ph-done', primary: !embeds && !primary })); return el; })(),
      // no submit block to put it in (an external tool, a Canvas-only hand-in, nothing to submit at
      // all): the rubric still gets a button, where the block's own would have been
      block ? null : rubricButton(a, s, { cls: 'bcv-ph-bigbtn' }),
      a.quiz_id ? h('button', { type: 'button', class: 'bcv-ph-bigbtn', text: 'Open quiz', onclick: () => app.go(`${c.url}/quizzes/${a.quiz_id}`) }) : null,
      a.discussion_topic?.id ? h('button', { type: 'button', class: 'bcv-ph-bigbtn', text: 'Open discussion', onclick: () => app.go(`${c.url}/discussion_topics/${a.discussion_topic.id}`) }) : null,
      // Only where there is no chip to open: comments carry the attempt they belong to, and the sheet
      // is the one place that filters them. An unfiltered list beside it shows a first draft's
      // feedback as feedback on the final hand-in.
      !posted && !held && !s.submitted_at && !s.excused && (s.submission_comments || []).length ? h('div', {}, [groupHead('Comments'), listCard(s.submission_comments.map((cm) => U.el('bcv-ph-comment', [U.el('bcv-ph-comment__head', [U.text('bcv-ph-comment__who', cm.author_name || cm.author?.display_name || 'Comment', 'span'), U.text('bcv-ph-comment__when', U.fmtAt(cm.created_at), 'span')]), U.commentBody(cm, 'bcv-ph-comment__body bcv-pretty')])))]) : null,
      block,
      // the assignments either side, last: where to go once this one is read or handed in
      (() => { const el = slot('bcv-ph-navslot'); fill(el, ({ nav }) => BCV.screens.courseDetail.navRow(app, c, nav, 'bcv-ph-nav')); return el; })(),
    ].filter(Boolean));
    if (block && ctx.route.params.get('bcv') === 'submit') for (const ms of [80, 600]) setTimeout(() => block.scrollIntoView({ block: 'start' }), ms);
    return b;
  }

  BCV.phone = { active, tabbar, topbar, paintChrome, afterRender, accountSheet, openSheet, courseChips, courseHome, assignment, screens: { dashboard: today, courses, todo, gpa, calendar, notifications } };
})();
