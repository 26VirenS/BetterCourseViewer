/* What changed in each release: the data behind the What's New page (content/app/whatsnew.js),
 * newest first. Every release ships its entry here — the suite fails when the newest entry is not
 * the manifest's version. A note is a kind (new | improved | fixed), a title of two to five plain
 * words (22 characters at most) — the page shows the title alone, one line per change — an icon
 * path, and a short plain line (60 at most; kept for the record and the row's tooltip, never on
 * the page; the suite holds both limits). Write it short: the fewest plain words that say what
 * changed, no clause you can cut, no cleverness, nothing internal. If it does not change what the
 * student sees, leave it out. Nothing is fetched: the notes travel with the build. */
(function () {
  const P = {
    sparkle: 'M12 3l1.9 4.1L18 9l-4.1 1.9L12 15l-1.9-4.1L6 9l4.1-1.9z',
    phone: 'M8 3h8a1 1 0 011 1v16a1 1 0 01-1 1H8a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2',
    layers: 'M12 4l8 4-8 4-8-4zM4 12l8 4 8-4M4 16l8 4 8-4',
    toggle: 'M3 12a5 5 0 015-5h8a5 5 0 010 10H8a5 5 0 01-5-5zM16 9.5v5',
    check: 'M20 6L9 17l-5-5',
    list: 'M5 6h14M5 12h14M5 18h9',
    scroll: 'M6 4h9v16H6zM18 7v10',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7zM12 15a3 3 0 100-6 3 3 0 000 6z',
    steps: 'M4 19h16M7 16V9M12 16V5M17 16v-4',
    pic: 'M4 5h16v14H4zM4 15l4-4 4 4 3-3 5 5',
    pen: 'M4 20h4l10-10-4-4L4 16zM13 7l4 4',
    arrows: 'M4 12h16M10 6l-6 6 6 6M14 6l6 6-6 6',
    clip: 'M21 11l-9 9a5 5 0 01-7-7l9-9a3 3 0 014 4l-9 9a1 1 0 01-2-2l8-8',
    clock: 'M12 5a8 8 0 100 16 8 8 0 000-16zM12 9v4l3 2',
    tool: 'M14.5 3.5a5 5 0 0 0-6 6l-5 5V20h4l5-5a5 5 0 0 0 6-6l-3 3-3-3z',
    pin: 'M9 4h6l-1 5 3 3v2H7v-2l3-3zM12 14v6',
    cal: 'M5 6h14v14H5zM5 10h14M9 3v4M15 3v4',
    lock: 'M7 11V8a5 5 0 0110 0v3M5 11h14v10H5z',
  };
  self.BCV_WHATS_NEW = [
    { version: '2.99.138', date: '2026-11-03', notes: [
      { kind: 'new', title: 'More Details', body: 'Extra assignment info sits in a panel under the due date.', icon: P.layers },
    ] },
    { version: '2.99.137', date: '2026-11-02', notes: [
      { kind: 'fixed', title: 'Hand In Grows in Place', body: 'It opens from its button; the due date slides down.', icon: P.clip },
    ] },
    { version: '2.99.136', date: '2026-11-01', notes: [
      { kind: 'improved', title: 'Due Date Stays in View', body: 'Handing in no longer covers the title or due date.', icon: P.clip },
      { kind: 'improved', title: 'Never a Dead End', body: 'Errors offer Try Again and Open in Canvas.', icon: P.arrows },
      { kind: 'improved', title: 'Search Stays Put', body: 'The search box sits in the top bar on every screen.', icon: P.pin },
      { kind: 'improved', title: 'One Way to Write Time', body: 'Every time reads like 11:59 PM, in your own clock.', icon: P.clock },
    ] },
    { version: '2.99.135', date: '2026-11-01', notes: [
      { kind: 'new', title: 'Send From Your Phone', body: 'Photos and files from your phone land in your hand-in.', icon: P.phone },
      { kind: 'fixed', title: 'Grades Match Canvas', body: 'Dropped scores and weighted totals add up as Canvas does.', icon: P.check },
    ] },
    { version: '2.99.134', date: '2026-11-01', notes: [
      { kind: 'fixed', title: 'No False Warning', body: 'Simpl no longer says Safari is running an old copy.', icon: P.check },
    ] },
    { version: '2.99.133', date: '2026-11-01', notes: [
      { kind: 'improved', title: 'Any Version, Any Time', body: 'Developer: roll the Mac app back to any version.', icon: P.check },
    ] },
    { version: '2.99.132', date: '2026-10-30', notes: [
      { kind: 'improved', title: 'Two Dashboard Views', body: 'The List or Recent activity: the course cards are gone.', icon: P.list },
      { kind: 'new', title: 'This Way to the Look', body: 'After setup, an arrow points to the Appearance bar.', icon: P.sparkle },
    ] },
    { version: '2.99.131', date: '2026-10-30', notes: [
      { kind: 'fixed', title: 'Steadier Sheets', body: 'On a phone, a gentle pull no longer closes a sheet.', icon: P.check },
    ] },
    { version: '2.99.130', date: '2026-10-30', notes: [
      { kind: 'new', title: 'A Better Tour', body: 'A short, hands-on tour of what Simpl can do.', icon: P.sparkle },
      { kind: 'improved', title: 'Unplan in the Month', body: 'Drag a plan in the month back onto To Do to unplan it.', icon: P.cal },
    ] },
    { version: '2.99.129', date: '2026-10-29', notes: [
      { kind: 'improved', title: "This Week's Betas", body: 'Everything from the betas since 2.99.104, for everyone.', icon: P.sparkle },
    ] },
    { version: '2.99.128', date: '2026-10-29', notes: [
      { kind: 'improved', title: 'Quiet Colour', body: 'Silent mode keeps colour where it means something.', icon: P.eye },
    ] },
    { version: '2.99.127', date: '2026-10-29', notes: [
      { kind: 'improved', title: 'Silent Everywhere', body: 'Silent mode stays on across the app, in black and white.', icon: P.eye },
    ] },
    { version: '2.99.126', date: '2026-10-28', notes: [
      { kind: 'new', title: 'Strike It Out', body: 'In Silent mode, press a task to strike it out.', icon: P.check },
      { kind: 'improved', title: 'A Quiet Sidebar', body: 'Silent mode turns the sidebar black and words only.', icon: P.eye },
    ] },
    { version: '2.99.125', date: '2026-10-28', notes: [
      { kind: 'new', title: 'Silent Mode', body: 'A black, quiet Dashboard: only what comes next.', icon: P.eye },
    ] },
    { version: '2.99.124', date: '2026-10-28', notes: [
      { kind: 'new', title: 'Calendar Accounts', body: 'Sign in to iCloud Calendar right from Sync.', icon: P.cal },
    ] },
    { version: '2.99.123', date: '2026-10-28', notes: [
      { kind: 'improved', title: 'Simulate an Update', body: 'Developer tools replay an update from any older version.', icon: P.arrows },
    ] },
    { version: '2.99.122', date: '2026-10-27', notes: [
      { kind: 'fixed', title: 'Course Colours Show', body: 'Course names keep their colours over a sidebar photo.', icon: P.check },
      { kind: 'fixed', title: 'Plan Menus on Top', body: "The Repeat and Alert menus open over a plan's editor.", icon: P.check },
    ] },
    { version: '2.99.121', date: '2026-10-27', notes: [
      { kind: 'fixed', title: 'Word Counter Fixed', body: "The Word Counter's text box is ready to type in at once.", icon: P.check },
    ] },
    { version: '2.99.120', date: '2026-10-26', notes: [
      { kind: 'new', title: 'To Do Meets Calendar', body: 'Your tasks and your week, together in one tab.', icon: P.cal },
    ] },
    { version: '2.99.119', date: '2026-10-26', notes: [
      { kind: 'improved', title: 'Photo Options First', body: 'Click a card or the sidebar for its options, then Upload.', icon: P.pic },
    ] },
    { version: '2.99.118', date: '2026-10-26', notes: [
      { kind: 'new', title: 'Colour Each Card', body: 'Give any card or the sidebar a colour of its own.', icon: P.pic },
    ] },
    { version: '2.99.117', date: '2026-10-26', notes: [
      { kind: 'new', title: 'Click a Card to Upload', body: 'In Appearance, click any card or the sidebar for a photo.', icon: P.pic },
      { kind: 'improved', title: 'Controls Round Photos', body: "Zoom, Ink and Done sit around the photo you're placing.", icon: P.pic },
    ] },
    { version: '2.99.116', date: '2026-10-26', notes: [
      { kind: 'new', title: 'School Tools Built In', body: "Simpl's bar works on Alta, McGraw Hill and more.", icon: P.tool },
    ] },
    { version: '2.99.115', date: '2026-10-26', notes: [
      { kind: 'improved', title: "Agenda's Own Month", body: 'In Agenda, pick its days on the month on the left.', icon: P.cal },
      { kind: 'improved', title: 'A Plain Tick', body: 'Handed-in work shows a simple tick, not a badge.', icon: P.check },
      { kind: 'improved', title: 'One Copy at a Time', body: 'Opening a pinned tool in full folds its small copy.', icon: P.pin },
    ] },
    { version: '2.99.114', date: '2026-10-26', notes: [
      { kind: 'new', title: 'Group Your Tasks', body: 'Drop a task onto a plan to work on them together.', icon: P.layers },
      { kind: 'new', title: 'Back to To Do', body: 'Drag a plan or a grouped task onto To Do to unplan it.', icon: P.arrows },
    ] },
    { version: '2.99.113', date: '2026-10-26', notes: [
      { kind: 'new', title: 'Plans Are Events', body: 'Edit a plan: its name, time, repeat, alert and notes.', icon: P.cal },
      { kind: 'improved', title: 'Beside the Item', body: 'Popups on the calendar open next to what you pressed.', icon: P.layers },
      { kind: 'new', title: 'Pull to Lengthen', body: 'Pull a plan’s bottom edge to make it longer.', icon: P.arrows },
    ] },
    { version: '2.99.112', date: '2026-10-25', notes: [
      { kind: 'new', title: 'To Do & Calendar', body: 'To Do and the calendar are now one tab.', icon: P.cal },
      { kind: 'new', title: 'Pinch the Week', body: 'Pinch the hours to see more or less of the day.', icon: P.arrows },
      { kind: 'improved', title: 'Five or Seven Days', body: 'Press Week again to show 5 or 7 days.', icon: P.cal },
      { kind: 'improved', title: 'Peek Past the Hours', body: 'Events above or below the view wait at its edge.', icon: P.eye },
      { kind: 'improved', title: 'The Page Holds Still', body: 'Only the calendar and To Do scroll.', icon: P.layers },
    ] },
    { version: '2.99.111', date: '2026-10-25', notes: [
      { kind: 'fixed', title: 'Frosted Popups', body: 'Popups blur the page behind them in Chrome again.', icon: P.layers },
    ] },
    { version: '2.99.110', date: '2026-10-25', notes: [
      { kind: 'new', title: 'Plan From To Do', body: 'Drag work from To Do beside the week onto a time.', icon: P.cal },
      { kind: 'new', title: 'Your Simpl Calendar', body: 'Your work and plans in Apple, Google or Outlook.', icon: P.cal },
      { kind: 'improved', title: 'Sealed and Private', body: 'Only your private link can open your Simpl calendar.', icon: P.lock },
    ] },
    { version: '2.99.109', date: '2026-10-25', notes: [
      { kind: 'improved', title: 'Week by the Hour', body: 'The week shows each event at its time, with a line for now.', icon: P.cal },
      { kind: 'new', title: 'Drag Plans to Move', body: 'On the week, drag a plan to another time or day.', icon: P.clock },
      { kind: 'improved', title: 'Calmer Time Picker', body: 'Plan times are grouped by day, the day said once.', icon: P.clock },
    ] },
    { version: '2.99.108', date: '2026-10-25', notes: [
      { kind: 'new', title: 'Place Your Photo', body: 'A photo opens on its card: drag, zoom and set it there.', icon: P.pic },
      { kind: 'improved', title: 'Solid Photo Borders', body: 'Words on a photo with Ink off have a solid white edge.', icon: P.pic },
    ] },
    { version: '2.99.107', date: '2026-10-25', notes: [
      { kind: 'new', title: 'Calendar Sync', body: 'Your work in Apple, Google or Outlook, and theirs in Simpl.', icon: P.cal },
      { kind: 'new', title: 'Pull to Plan', body: 'Pull work to the right to plan a free time for it.', icon: P.clock },
    ] },
    { version: '2.99.106', date: '2026-10-25', notes: [
      { kind: 'new', title: 'Simpl Community', body: 'Put on themes students made, or share yours, in Appearance.', icon: P.sparkle },
    ] },
    { version: '2.99.105', date: '2026-10-25', notes: [
      { kind: 'new', title: 'Photos Without Ink', body: 'Ink off shows a photo as it is, its words bordered in white.', icon: P.pic },
    ] },
    { version: '2.99.104', date: '2026-10-23', notes: [
      { kind: 'improved', title: 'Quiet Updates', body: 'The Safari app updates in the background, out of sight.', icon: P.sparkle },
    ] },
    { version: '2.99.103', date: '2026-10-23', notes: [
      { kind: 'improved', title: "This week's betas", body: 'Everything from the betas since 2.99.92, for everyone.', icon: P.sparkle },
    ] },
    { version: '2.99.102', date: '2026-10-23', notes: [
      { kind: 'improved', title: 'Pick the Assignment', body: '/open on a tool now lists its assignments to choose from.', icon: P.tool || P.check },
    ] },
    { version: '2.99.101', date: '2026-10-22', notes: [
      { kind: 'improved', title: 'Cleaner Announcements', body: 'Announcements open as on the Mac; no extra headers.', icon: P.bell || P.check },
    ] },
    { version: '2.99.100', date: '2026-10-22', notes: [
      { kind: 'improved', title: 'Blur Behind Rubric', body: 'The page behind the rubric is blurred again.', icon: P.eye },
    ] },
    { version: '2.99.99', date: '2026-10-22', notes: [
      { kind: 'fixed', title: 'Rubric Dims Fully', body: 'The dim behind the rubric now reaches the bottom.', icon: P.check },
    ] },
    { version: '2.99.98', date: '2026-10-22', notes: [
      { kind: 'fixed', title: 'Apps Stay in Simpl', body: 'The apps no longer switch to the school\'s own pages.', icon: P.check },
    ] },
    { version: '2.99.97', date: '2026-10-22', notes: [
      { kind: 'improved', title: 'No Dim Behind Popups', body: 'Popups no longer darken or blur the page behind them.', icon: P.eye },
    ] },
    { version: '2.99.96', date: '2026-10-22', notes: [
      { kind: 'new', title: 'Hand In from Phone', body: 'Scan a code to hand in with your phone’s camera.', icon: P.phone },
    ] },
    { version: '2.99.95', date: '2026-10-22', notes: [
      { kind: 'new', title: 'Appointments in apps', body: 'The Mac and Windows apps can reserve office hours too.', icon: P.clock },
    ] },
    { version: '2.99.94', date: '2026-10-22', notes: [
      { kind: 'improved', title: 'Quiz page for everyone', body: 'The new quiz page, out of beta.', icon: P.sparkle },
    ] },
    { version: '2.99.93', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Cleaner quiz page', body: 'Laid out like an assignment: Begin and details on the right.', icon: P.layers },
    ] },
    { version: '2.99.92', date: '2026-10-21', notes: [
      { kind: 'improved', title: "This week's betas", body: 'Everything from the betas since 2.99.68, for everyone.', icon: P.sparkle },
    ] },
    { version: '2.99.91', date: '2026-10-21', notes: [
      { kind: 'fixed', title: 'Apps quick again', body: 'The Mac and iPhone apps run at full speed again.', icon: P.check },
    ] },
    { version: '2.99.90', date: '2026-10-21', notes: [
      { kind: 'fixed', title: 'Pinned tools open', body: 'In Safari a pinned tool\'s panel shows again.', icon: P.pin },
      { kind: 'fixed', title: 'Smooth search return', body: 'Search keeps its pill shape on the way back.', icon: P.check },
      { kind: 'improved', title: 'Calmer search glide', body: 'Search moves at its earlier, gentler pace.', icon: P.sparkle },
    ] },
    { version: '2.99.89', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Courses always listed', body: 'Your courses stay on the sidebar; the hover menu is gone.', icon: P.list },
    ] },
    { version: '2.99.88', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Snappier search', body: 'Search opens and grows with a quick ease-out.', icon: P.sparkle },
    ] },
    { version: '2.99.87', date: '2026-10-21', notes: [
      { kind: 'fixed', title: 'Tidier quiz page', body: 'One title, with Canvas page and the timer beside it.', icon: P.check },
    ] },
    { version: '2.99.86', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Rounder corners', body: "Cards, buttons and boxes use Apple's continuous corners.", icon: P.check },
    ] },
    { version: '2.99.85', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Hex code in the wheel', body: "The colour's code sits in the middle, where Done was.", icon: P.check },
    ] },
    { version: '2.99.84', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Spotlight-style search', body: "Search is Spotlight's shape now, and a little narrower.", icon: P.check },
    ] },
    { version: '2.99.83', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Quizzes open the quiz', body: "A quiz's assignment opens the quiz's own page.", icon: P.check },
      { kind: 'improved', title: 'Quiz page, not a popup', body: 'A quiz opens as a page in the app, not over it.', icon: P.check },
    ] },
    { version: '2.99.82', date: '2026-10-21', notes: [
      { kind: 'new', title: 'Equation Balancer', body: 'Balances any chemical equation as you type.', icon: P.check },
      { kind: 'new', title: 'Molar Mass & Moles', body: 'Molar mass, conversions, yields and formulas.', icon: P.check },
    ] },
    { version: '2.99.81', date: '2026-10-21', notes: [
      { kind: 'new', title: 'Statistics', body: 'Describe data, regression, z and t-tests.', icon: P.check },
      { kind: 'new', title: 'Matrix Calculator', body: 'Determinant, inverse, RREF and eigenvalues.', icon: P.check },
    ] },
    { version: '2.99.80', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Squircle Counters', body: 'The counters have Apple’s smooth corners.', icon: P.check },
    ] },
    { version: '2.99.79', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Tools in Sections', body: 'Study, Math & science, Files and Chemistry.', icon: P.check },
      { kind: 'improved', title: 'Pin With a Press', body: 'Every tool has a pin at its corner.', icon: P.check },
      { kind: 'new', title: 'Unit Converter', body: 'Lengths, weights, temperatures and more.', icon: P.check },
      { kind: 'new', title: 'Word Counter', body: 'Words, characters, reading time.', icon: P.check },
    ] },
    { version: '2.99.78', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Two Quiz Layouts', body: 'Side by side, or scroll every question in the middle.', icon: P.check },
      { kind: 'improved', title: 'Review Side by Side', body: 'Your answers on the left, Submit on the right.', icon: P.check },
      { kind: 'fixed', title: 'Formulas in Review', body: 'A formula no longer shows its code beside it.', icon: P.check },
    ] },
    { version: '2.99.77', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Colour Wheel Is Back', body: 'Any colour in Appearance opens the round picker.', icon: P.check },
      { kind: 'improved', title: 'Counters in Your Hue', body: 'With a theme colour, the counters are its shades.', icon: P.check },
      { kind: 'improved', title: 'Find Appointment', body: 'The button keeps its name on smaller windows.', icon: P.check },
      { kind: 'improved', title: 'Agenda Range Beside', body: 'The range picker sits beside the agenda.', icon: P.check },
    ] },
    { version: '2.99.76', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Wider Sidebar', body: 'The sidebar has a little more room.', icon: P.check },
      { kind: 'improved', title: 'Shorter Counter Boxes', body: 'A box shows two and a half items, then scrolls.', icon: P.check },
      { kind: 'improved', title: 'Even Previews', body: 'Every preview is one compact size.', icon: P.check },
      { kind: 'improved', title: 'Clearer Selection', body: 'The chosen tab in a switch stands out in dark.', icon: P.check },
    ] },
    { version: '2.99.75', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Clearer First Page', body: 'The page after install says Open your courses page.', icon: P.steps },
    ] },
    { version: '2.99.74', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Appearance in Setup', body: 'Setup ends over your Dashboard, then picks your sidebar.', icon: P.check },
      { kind: 'new', title: 'Sidebar in Appearance', body: 'Choose one sidebar or two, with a live preview.', icon: P.check },
    ] },
    { version: '2.99.73', date: '2026-10-21', notes: [
      { kind: 'fixed', title: 'Tools in Popups Fixed', body: 'Tools sit by a popup\'s buttons, never over what it shows.', icon: P.check },
    ] },
    { version: '2.99.72', date: '2026-10-21', notes: [
      { kind: 'improved', title: 'Counter Boxes Polished', body: 'Tinted like the Mac, smoother open, tools stay put.', icon: P.check },
      { kind: 'improved', title: 'Tools in Popups', body: 'Pinned tools sit in a popup\'s head, by its buttons.', icon: P.check },
    ] },
    { version: '2.99.71', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Submit as ZIP', body: 'Two or more files: Submit as ZIP sits beside Submit.', icon: P.check },
    ] },
    { version: '2.99.70', date: '2026-10-20', notes: [
      { kind: 'new', title: 'Hand In as a .zip', body: 'Hand in a folder, or several files, as one .zip.', icon: P.check },
    ] },
    { version: '2.99.69', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Mac-Style Counters', body: 'Counter boxes float, fit their list and fold as on Mac.', icon: P.check },
    ] },
    { version: '2.99.68', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Tidier Skyline', body: 'Four windows across each tower; the rest hide.', icon: P.check },
    ] },
    { version: '2.99.67', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Quiz Intro Popup', body: "A quiz's intro opens as a large popup, as on Mac.", icon: P.check },
    ] },
    { version: '2.99.66', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Previews as Popups', body: 'Previews open as a card by the item, not a side panel.', icon: P.check },
    ] },
    { version: '2.99.65', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Simpl in White', body: 'The Simpl name up top is one solid color.', icon: P.check },
    ] },
    { version: '2.99.64', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Simpl Up Top', body: 'The sidebar now opens with the Simpl logo and name.', icon: P.check },
    ] },
    { version: '2.99.63', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'The Real Logo', body: 'The icon is now drawn from the official artwork.', icon: P.check },
    ] },
    { version: '2.99.62', date: '2026-10-20', notes: [
      { kind: 'improved', title: 'Courses in Color', body: 'Courses sit under All Courses, named in their color.', icon: P.check },
    ] },
    { version: '2.99.61', date: '2026-10-20', notes: [
      { kind: 'new', title: 'A New Look', body: 'Simpl has a new icon: a bold S with a blue dot.', icon: P.check },
    ] },
    { version: '2.99.60', date: '2026-10-19', notes: [
      { kind: 'new', title: 'Appearance on the Page', body: 'Theme and photos right on your Dashboard, as on Mac.', icon: P.check },
      { kind: 'improved', title: 'All Courses Is Back', body: 'All Courses sits up top, your courses under it.', icon: P.check },
    ] },
    { version: '2.99.59', date: '2026-10-19', notes: [
      { kind: 'improved', title: 'Smoother Sidebar', body: "A course's sections slide open and shut.", icon: P.check },
      { kind: 'improved', title: 'Tools Over Popups', body: 'Pinned tools move aside while a popup is open.', icon: P.pin },
    ] },
    { version: '2.99.58', date: '2026-10-19', notes: [
      { kind: 'fixed', title: 'Quiz Feedback', body: "A quiz's See Feedback opens its marked answers.", icon: P.check },
    ] },
    { version: '2.99.57', date: '2026-10-19', notes: [
      { kind: 'improved', title: 'Sidebar Tidies Up', body: "Leaving a course folds its sections away.", icon: P.check },
    ] },
    { version: '2.99.56', date: '2026-10-19', notes: [
      { kind: 'fixed', title: 'Quiz Page Fixed', body: "A quiz's intro opens on the quiz's own page.", icon: P.check },
    ] },
    { version: '2.99.55', date: '2026-10-19', notes: [
      { kind: 'improved', title: 'Quizzes Like the Mac', body: 'A quiz opens on its intro; New Attempt starts it.', icon: P.check },
    ] },
    { version: '2.99.54', date: '2026-10-19', notes: [
      { kind: 'improved', title: 'Widgets Open on Click', body: 'A pinned tool opens under its pin, as on the Mac.', icon: P.pin },
    ] },
    { version: '2.99.53', date: '2026-10-19', notes: [
      { kind: 'improved', title: 'Laid Out Like the Mac', body: 'The top bar, sidebar and assignments match the Mac.', icon: P.layers },
    ] },
    { version: '2.99.52', date: '2026-10-19', notes: [
      { kind: 'improved', title: 'Back and Forward', body: 'In the top bar, with Previous and Next; no popup.', icon: P.layers },
    ] },
    { version: '2.99.51', date: '2026-10-19', notes: [
      { kind: 'improved', title: 'See Feedback', body: 'Your work beside the comments; Your Work comes first.', icon: P.layers },
    ] },
    { version: '2.99.50', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Mac-style assignments', body: 'Grade ring, details and comments laid out as on Mac.', icon: P.layers },
    ] },
    { version: '2.99.49', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Tidier header', body: 'The search box sits under the views; long names fit.', icon: P.layers },
    ] },
    { version: '2.99.48', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Wide Dashboard', body: 'Six counters in a row, grades and workload beside the list.', icon: P.layers },
    ] },
    { version: '2.99.47', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Mac-style Inbox', body: 'One list of conversations, each with its sender\u2019s picture.', icon: P.list },
    ] },
    { version: '2.99.46', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Course card shortcuts', body: 'Grades, Work, Modules, Files and News on each course card.', icon: P.layers },
    ] },
    { version: '2.99.45', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Notification icons', body: 'Each alert led by its kind\u2019s coloured tile, as on the Mac.', icon: P.sparkle },
    ] },
    { version: '2.99.44', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Mac-style calendar', body: 'One ruled month, items by course bars, a missing count.', icon: P.layers },
    ] },
    { version: '2.99.43', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'To Do summary', body: 'A ring of what is done and what is overdue, as on the Mac.', icon: P.check },
    ] },
    { version: '2.99.42', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Mac-style course pages', body: 'Section titles, assignment rows and Home announcements.', icon: P.layers },
    ] },
    { version: '2.99.41', date: '2026-10-18', notes: [
      { kind: 'improved', title: 'Dashboard like the Mac', body: 'A greeting, coloured counters and Coming up, as on the Mac.', icon: P.layers },
    ] },
    { version: '2.99.40', date: '2026-10-18', notes: [
      { kind: 'new', title: 'GeoGebra Calculator', body: 'The Calculator is GeoGebra: graphs, CAS, 3D and more.', icon: P.tool },
    ] },
    { version: '2.99.39', date: '2026-10-17', notes: [
      { kind: 'new', title: 'One sidebar', body: 'A course opens its sections under it, as in the Mac app.', icon: P.list },
    ] },
    { version: '2.99.38', date: '2026-10-17', notes: [
      { kind: 'new', title: 'Beta updates', body: 'The Mac app can get new versions early, as betas.', icon: P.arrows },
    ] },
    { version: '2.99.37', date: '2026-10-17', notes: [
      { kind: 'improved', title: 'Cards like the Mac app', body: 'A counter\u2019s list and previews look as they do on the Mac.', icon: P.list },
    ] },
    { version: '2.99.36', date: '2026-10-17', notes: [
      { kind: 'improved', title: 'Grades by category', body: 'A course\u2019s grades are listed under each of its categories.', icon: P.list },
    ] },
    { version: '2.99.35', date: '2026-10-15', notes: [
      { kind: 'improved', title: 'Always up to date', body: 'The Mac app now always installs updates by itself.', icon: P.arrows },
      { kind: 'improved', title: 'Earlier versions stay', body: 'In the Mac app, a version put back stays until a newer one.', icon: P.pin },
    ] },
    { version: '2.99.34', date: '2026-10-14', notes: [
      { kind: 'fixed', title: 'No Canvas banners', body: "Canvas's own notices no longer cover Simpl.", icon: P.eye },
      { kind: 'improved', title: 'Tools by provider', body: 'External tools grouped by their site, like Macmillan.', icon: P.layers },
    ] },
    { version: '2.99.33', date: '2026-10-14', notes: [
      { kind: 'improved', title: 'Screens open at once', body: 'Pages are read ahead, so most open with no wait.', icon: P.sparkle },
      { kind: 'improved', title: 'Smoother page changes', body: 'One smooth move from one screen to the next.', icon: P.arrows },
    ] },
    { version: '2.99.32', date: '2026-10-12', notes: [
      { kind: 'improved', title: 'Smoother exits', body: 'Sets, pins, dropdowns and widgets leave, not vanish.', icon: P.arrows },
      { kind: 'improved', title: 'Sections slide open', body: 'Idle courses, quiz options and scales slide, not jump.', icon: P.layers },
      { kind: 'improved', title: 'Flashcards tick', body: 'A finished round draws its tick, as a quiz does.', icon: P.check },
      { kind: 'fixed', title: 'Files in replies', body: 'A reply that is a file shows the file.', icon: P.clip },
    ] },
    { version: '2.99.31', date: '2026-10-10', notes: [
      { kind: 'fixed', title: 'Finished quizzes', body: 'A Brightspace quiz you finished shows as done.', icon: P.check },
      { kind: 'fixed', title: 'Brightspace To Do', body: 'To Do lists your Brightspace work again.', icon: P.list },
    ] },
    { version: '2.99.30', date: '2026-10-09', notes: [
      { kind: 'fixed', title: 'Tool assignments', body: 'A tool’s assignment is no longer called closed.', icon: P.check },
    ] },
    { version: '2.99.29', date: '2026-10-09', notes: [
      { kind: 'improved', title: 'Square counters', body: 'A wide Dashboard shows its six counters in a row.', icon: P.layers },
    ] },
    { version: '2.99.28', date: '2026-10-09', notes: [
      { kind: 'fixed', title: 'Module check marks', body: 'A module counts as done only once all its work is.', icon: P.check },
    ] },
    { version: '2.99.27', date: '2026-10-09', notes: [
      { kind: 'new', title: 'Your grading scale', body: 'Set each letter’s cutoff to match your instructor.', icon: P.steps },
    ] },
    { version: '2.99.26', date: '2026-10-09', notes: [
      { kind: 'improved', title: 'Rubric ring first', body: 'Every rubric opens on the ring. Grid is one click away.', icon: P.layers },
    ] },
    { version: '2.99.25', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'Updates every 2 hours', body: 'Simpl now looks for updates every two hours.', icon: P.clock },
    ] },
    { version: '2.99.24', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'One answer or many', body: 'Quizzes show round options for one answer, boxes for many.', icon: P.check },
    ] },
    { version: '2.99.23', date: '2026-10-08', notes: [
      { kind: 'new', title: 'Brightspace in apps', body: 'The iPhone and Mac apps now work on Brightspace too.', icon: P.sparkle },
      { kind: 'new', title: 'Brightspace alerts', body: 'New-activity alerts read Brightspace news and grades.', icon: P.clock },
      { kind: 'new', title: 'Find your Brightspace', body: 'On iPhone and Mac, search your school’s name to find it.', icon: P.steps },
      { kind: 'fixed', title: 'Handed-in files open', body: 'On Brightspace, the files you handed in now open.', icon: P.clip },
      { kind: 'fixed', title: 'Brightspace Mark done', body: 'It opens the topic’s Brightspace page, which takes it.', icon: P.check },
    ] },
    { version: '2.99.22', date: '2026-10-08', notes: [
      { kind: 'new', title: 'Brightspace support', body: 'Simpl now works on Brightspace (D2L) too.', icon: P.sparkle },
      { kind: 'fixed', title: 'No stray “null” word', body: 'Setup and Grade needed no longer show the word null.', icon: P.check },
    ] },
    { version: '2.99.21', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'More schools built in', body: 'Chrome: 494 schools’ own Canvas sites start by themselves.', icon: P.sparkle },
    ] },
    { version: '2.99.20', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'Smoother in Safari', body: 'Springs run on the GPU now, at your screen’s full rate.', icon: P.sparkle },
      { kind: 'fixed', title: 'Back stays one line', body: 'A long name beside Previous / Next is cut, not wrapped.', icon: P.check },
      { kind: 'improved', title: 'Blur follows the box', body: 'Switching tabs, the blur round it glides with the box.', icon: P.layers },
      { kind: 'improved', title: 'No Immersive Reader', body: 'The reader button is gone from the course header.', icon: P.check },
    ] },
    { version: '2.99.19', date: '2026-10-08', notes: [
      { kind: 'fixed', title: 'Fact boxes read whole', body: 'The small line under Due, Points and more is no longer cut.', icon: P.check },
    ] },
    { version: '2.99.18', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'Links open in the app', body: 'On iPhone, every Canvas link opens its own screen.', icon: P.arrows },
    ] },
    { version: '2.99.17', date: '2026-10-08', notes: [
      { kind: 'new', title: 'Previous and Next', body: 'On every quiz, page and discussion, not just work.', icon: P.arrows },
      { kind: 'improved', title: 'Walks your modules', body: 'Opened from Modules, Next goes to the next item.', icon: P.list },
    ] },
    { version: '2.99.16', date: '2026-10-08', notes: [
      { kind: 'new', title: 'How the class did', body: 'A box plot by your grade; hover it for the numbers.', icon: P.steps },
      { kind: 'improved', title: 'Comments on a press', body: 'The grade card opens small; Comments widens it.', icon: P.layers },
    ] },
    { version: '2.99.15', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'A snugger grade card', body: 'Sized to what it holds, over the page; comment on a press.', icon: P.layers },
    ] },
    { version: '2.99.14', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'The button grows', body: 'Submit grows out of its middle into the panel.', icon: P.sparkle },
      { kind: 'improved', title: 'Marks on your work', body: 'Handed-in files open in Canvas’s viewer, with its notes.', icon: P.pen },
    ] },
    { version: '2.99.13', date: '2026-10-08', notes: [
      { kind: 'new', title: 'A new assignment page', body: 'Facts at a glance; one button grows into the hand-in.', icon: P.layers },
      { kind: 'improved', title: 'Sideways grade card', body: 'Your grade on the left, comments on the right.', icon: P.steps },
    ] },
    { version: '2.99.12', date: '2026-10-08', notes: [
      { kind: 'new', title: 'Modules remember', body: 'Only the module you last opened starts open.', icon: P.list },
      { kind: 'improved', title: 'Bigger, brighter rings', body: 'The grade card’s ring is larger, in the score’s colour.', icon: P.steps },
    ] },
    { version: '2.99.11', date: '2026-10-08', notes: [
      { kind: 'improved', title: 'Smooth grade rings', body: 'The grade card uses the app’s own grade and rubric rings.', icon: P.steps },
    ] },
    { version: '2.99.10', date: '2026-10-08', notes: [
      { kind: 'fixed', title: 'Tool grades open here', body: 'Hovering a tool or quiz grade opens its card, not a page.', icon: P.check },
      { kind: 'improved', title: 'A new grade card', body: 'A score ring, dates and attempts; the ring opens the rubric.', icon: P.layers },
    ] },
    { version: '2.99.9', date: '2026-10-07', notes: [
      { kind: 'new', title: 'New-activity alerts', body: 'On iPhone: posts, grades and messages while closed.', icon: P.sparkle },
    ] },
    { version: '2.99.8', date: '2026-10-07', notes: [
      { kind: 'new', title: 'Due-date reminders', body: 'On iPhone: alerts before work is due, even when closed.', icon: P.clock },
    ] },
    { version: '2.99.7', date: '2026-10-07', notes: [
      { kind: 'improved', title: 'Calmer lists', body: 'Dismissing or ticking no longer replays the list.', icon: P.list },
      { kind: 'improved', title: 'Instant search keys', body: 'Search opened with / or ⌘K is simply there.', icon: P.sparkle },
      { kind: 'improved', title: 'Switches slide', body: 'Switches and buttons respond under your finger.', icon: P.toggle },
      { kind: 'improved', title: 'Things move, not jump', body: 'Months, modules, stars and replies slide into place.', icon: P.arrows },
      { kind: 'new', title: 'A beat for handing in', body: 'Handing in shows a tick where your work landed.', icon: P.check },
    ] },
    { version: '2.99.6', date: '2026-10-07', notes: [
      { kind: 'new', title: 'Settings, built in', body: 'Grades, history and data in the app’s own Settings.', icon: P.toggle },
      { kind: 'new', title: 'Review before submit', body: 'Check every answer before you hand in a quiz.', icon: P.check },
      { kind: 'fixed', title: 'Start sign-in over', body: 'A stuck school sign-in can start again.', icon: P.arrows },
    ] },
    { version: '2.99.5', date: '2026-10-07', notes: [
      { kind: 'new', title: 'Pull up, next question', body: 'Pick an answer or pull up; hold to submit.', icon: P.list },
      { kind: 'new', title: 'Swipe to hand in', body: 'Swipe right on work to hand in or see feedback.', icon: P.arrows },
      { kind: 'improved', title: 'Follows your iPhone', body: 'Light or dark now matches your phone’s setting.', icon: P.eye },
      { kind: 'improved', title: 'Buttons at the bottom', body: 'Hand In and Reply sit where the tab bar was.', icon: P.layers },
      { kind: 'fixed', title: 'Formulas read right', body: 'Readable in dark mode and on the quiz review.', icon: P.check },
    ] },
    { version: '2.99.4', date: '2026-10-07', notes: [
      { kind: 'improved', title: 'Smoother boxes', body: 'Counters and grades open without dropping frames.', icon: P.layers },
      { kind: 'improved', title: 'Search glides', body: 'The floating search moves smoothly, even when busy.', icon: P.sparkle },
      { kind: 'improved', title: 'To Do closes gaps', body: 'Ticked rows leave and the rest slide up.', icon: P.list },
      { kind: 'new', title: 'A tick to celebrate', body: 'Handing in or finishing a quiz draws a check.', icon: P.check },
      { kind: 'improved', title: 'Gentler Reduce Motion', body: 'Things fade instead of moving, never cut.', icon: P.eye },
    ] },
    { version: '2.99.3', date: '2026-10-07', notes: [
      { kind: 'new', title: 'Quizzes on iPhone', body: 'Every question kind, flags, the clock and your feedback.', icon: P.list },
      { kind: 'new', title: 'Tools open on iPhone', body: 'External tools open in a sheet of their own.', icon: P.tool },
      { kind: 'new', title: 'iPhone setup', body: 'Pick your courses and goals in a few quick steps.', icon: P.steps },
      { kind: 'improved', title: 'Rings within rings', body: 'Each course shows its groups; what-if has a switch.', icon: P.eye },
      { kind: 'improved', title: 'Hand In fits the bar', body: 'As big as the tab bar; the rubric opens in a sheet.', icon: P.clip },
    ] },
    { version: '2.99.2', date: '2026-10-06', notes: [
      { kind: 'new', title: 'iPhone: courses inside', body: 'Announcements, modules, discussions, Inbox and Groups.', icon: P.layers },
      { kind: 'new', title: 'Hand in on iPhone', body: 'Text, a link, or files from Files and Photos.', icon: P.clip },
      { kind: 'improved', title: 'iPhone grade rings', body: 'Press a ring for its grades and what-if scores.', icon: P.steps },
      { kind: 'fixed', title: 'iPhone lines line up', body: 'Titles sit beside your picture; dividers line up.', icon: P.check },
    ] },
    { version: '2.99.1', date: '2026-10-06', notes: [
      { kind: 'fixed', title: 'Rubric pill lets go', body: 'It always folds away once the pointer leaves the button.', icon: P.check },
      { kind: 'improved', title: 'Smoother Rubric pill', body: 'It grows and folds on a spring, turning round mid-way.', icon: P.toggle },
      { kind: 'improved', title: 'iPhone: four tabs', body: 'Calendar opens from Today and To Do; no More tab.', icon: P.layers },
    ] },
    { version: '2.99', date: '2026-10-06', notes: [
      { kind: 'new', title: 'A real iPhone app', body: "Apple's own tab bar, screens and sheets over Canvas.", icon: P.sparkle },
      { kind: 'new', title: 'Liquid Glass bars', body: 'The bars and buttons wear iOS 26 glass.', icon: P.layers },
      { kind: 'new', title: 'Taps you can feel', body: 'Ticks, switches and swipes tap back on the iPhone.', icon: P.toggle },
    ] },
    { version: '2.98.103', date: '2026-10-06', notes: [
      { kind: 'improved', title: 'Rubric pill floats in', body: 'Its colours float in round the pill, all at once.', icon: P.toggle },
    ] },
    { version: '2.98.102', date: '2026-10-06', notes: [
      { kind: 'improved', title: 'Snappier widgets', body: 'Pinned widgets open quicker and without stutter.', icon: P.layers },
      { kind: 'fixed', title: 'No stray widgets', body: 'A widget no longer pops open as the row slides.', icon: P.pin },
      { kind: 'improved', title: 'Tools open quicker', body: "A tool's card gets it ready as you point at it.", icon: P.tool },
    ] },
    { version: '2.98.101', date: '2026-10-06', notes: [
      { kind: 'improved', title: 'Rubric pill, smoother', body: 'It grows to the right; its colours blend like the ring.', icon: P.toggle },
    ] },
    { version: '2.98.100', date: '2026-10-06', notes: [
      { kind: 'improved', title: 'Rubric pill on hover', body: 'Hovering it grows a pill with the points, not a ring.', icon: P.toggle },
    ] },
    { version: '2.98.99', date: '2026-10-06', notes: [
      { kind: 'new', title: 'A new file viewer', body: 'PDFs open here: zoom, go to a page, turn and find.', icon: P.scroll },
      { kind: 'new', title: 'Word files open here', body: 'A Word file opens as a PDF made on this device.', icon: P.pen },
      { kind: 'improved', title: 'Zoom pictures and text', body: 'Pictures zoom, turn and drag; text can be larger.', icon: P.pic },
    ] },
    { version: '2.98.98', date: '2026-10-06', notes: [
      { kind: 'fixed', title: 'One search highlight', body: 'The mouse moves the same highlight the arrow keys do.', icon: P.check },
      { kind: 'improved', title: 'Rubrics open as a ring', body: 'The grid comes back only if you left the last one on it.', icon: P.layers },
    ] },
    { version: '2.98.97', date: '2026-10-06', notes: [
      { kind: 'new', title: 'Cards open on hover', body: 'Rest the mouse on a Dashboard card to open it.', icon: P.eye },
    ] },
    { version: '2.98.96', date: '2026-10-05', notes: [
      { kind: 'fixed', title: 'Past courses, really', body: 'Concluded courses now show under Past.', icon: P.list },
      { kind: 'fixed', title: 'Page text readable', body: 'Page text always stands out from what is behind it.', icon: P.eye },
    ] },
    { version: '2.98.95', date: '2026-10-05', notes: [
      { kind: 'new', title: 'Rubric grid switch', body: 'A switch turns the rubric ring into a grid and back.', icon: P.toggle },
      { kind: 'improved', title: 'Clearer rubric text', body: 'Rubric words sit on dark bands, easier to read.', icon: P.eye },
      { kind: 'fixed', title: 'Past courses show', body: 'Past lists every past course Canvas lists.', icon: P.list },
      { kind: 'fixed', title: 'Page buttons fixed', body: "A page's own buttons look as they do on Canvas.", icon: P.layers },
    ] },
    { version: '2.98.94', date: '2026-10-05', notes: [
      { kind: 'improved', title: 'Next 7 days', body: 'The week card counts the next 7 days, from today.', icon: P.clock },
    ] },
    { version: '2.98.93', date: '2026-10-05', notes: [
      { kind: 'improved', title: 'Windows fade in', body: 'Skyline windows fade in place, no bounce.', icon: P.sparkle },
    ] },
    { version: '2.98.92', date: '2026-10-05', notes: [
      { kind: 'improved', title: 'Faster Dashboard', body: 'Overdue, Graded and the skyline show up right away.', icon: P.clock },
    ] },
    { version: '2.98.91', date: '2026-10-05', notes: [
      { kind: 'improved', title: 'Uncounted work in grey', body: 'Work that does not count is grey, at the bottom.', icon: P.layers },
      { kind: 'improved', title: 'Windows fly in', body: 'Each window flies in from its tower\u2019s top-left corner.', icon: P.sparkle },
    ] },
    { version: '2.98.90', date: '2026-10-05', notes: [
      { kind: 'new', title: 'A grades skyline', body: 'Each course is a tower; each assignment a lit window.', icon: P.layers },
    ] },
    { version: '2.98.89', date: '2026-10-05', notes: [
      { kind: 'improved', title: 'A wider rubric ring', body: 'The ring is now nearly as wide as the Rubric button.', icon: P.eye },
    ] },
    { version: '2.98.88', date: '2026-10-05', notes: [
      { kind: 'improved', title: 'A bigger mini ring', body: 'The ring on the Rubric button is a little bigger.', icon: P.eye },
    ] },
    { version: '2.98.87', date: '2026-10-04', notes: [
      { kind: 'improved', title: 'Rubric becomes a ring', body: 'Hover the Rubric button to see your points in a ring.', icon: P.eye },
      { kind: 'fixed', title: 'No quit-Safari note', body: 'The app no longer asks you to quit Safari after an update.', icon: P.check },
    ] },
    { version: '2.98.86', date: '2026-10-04', notes: [
      { kind: 'new', title: 'Rubric at a glance', body: 'Hover the Rubric button to see a small ring.', icon: P.eye },
    ] },
    { version: '2.98.85', date: '2026-10-04', notes: [
      { kind: 'improved', title: 'A hands-on ring tour', body: 'Try the rubric ring yourself, one step at a time.', icon: P.steps },
    ] },
    { version: '2.98.84', date: '2026-10-04', notes: [
      { kind: 'improved', title: 'A calmer rubric ring', body: 'The ring bends less as it shows your marks.', icon: P.sparkle },
      { kind: 'improved', title: 'Part marks in amber', body: 'Part marks are yellow or orange; red is for few.', icon: P.check },
    ] },
    { version: '2.98.83', date: '2026-10-04', notes: [
      { kind: 'new', title: 'A tour of the ring', body: 'The first rubric you open shows how its ring works.', icon: P.steps },
      { kind: 'improved', title: 'Tidier criterion names', body: 'Short names on the ring never end on a joining word.', icon: P.pen },
    ] },
    { version: '2.98.82', date: '2026-10-03', notes: [
      { kind: 'new', title: 'Grades in colour', body: 'A marked rubric ring turns green, orange or red.', icon: P.sparkle },
      { kind: 'improved', title: 'Boxes open in place', body: 'A counter opens from its own side of the row.', icon: P.layers },
    ] },
    { version: '2.98.81', date: '2026-10-03', notes: [
      { kind: 'fixed', title: 'The blur stays', body: 'The page stays blurred behind boxes in Safari.', icon: P.eye },
    ] },
    { version: '2.98.80', date: '2026-10-03', notes: [
      { kind: 'fixed', title: 'Search shade stays', body: 'The shade behind search no longer fades away in Safari.', icon: P.eye },
    ] },
    { version: '2.98.79', date: '2026-10-03', notes: [
      { kind: 'fixed', title: 'The dim is back', body: 'Boxes dim and blur the page behind them again in Safari.', icon: P.eye },
    ] },
    { version: '2.98.78', date: '2026-10-03', notes: [
      { kind: 'improved', title: 'A smoother ring', body: 'Its edges and colours flow on with no steps.', icon: P.sparkle },
      { kind: 'new', title: 'Back up to the ring', body: 'The bar runs up into a little ring: press it.', icon: P.arrows },
      { kind: 'improved', title: 'Clearer search', body: 'A soft shade sits behind the search box and results.', icon: P.eye },
      { kind: 'improved', title: 'Smoother everywhere', body: 'Less work each frame, and none in hidden tabs.', icon: P.layers },
    ] },
    { version: '2.98.77', date: '2026-10-03', notes: [
      { kind: 'new', title: 'Back to the ring', body: 'A Ring button sits beside each criterion’s name.', icon: P.arrows },
      { kind: 'improved', title: 'A livelier ring', body: 'Heavier criteria are thicker; a hover swells one.', icon: P.sparkle },
      { kind: 'new', title: 'Where you are, lit', body: 'Scroll mode marks the question you are reading.', icon: P.list },
      { kind: 'improved', title: 'The page holds still', body: 'Nothing scrolls behind a box, sheet or the ring.', icon: P.pin },
      { kind: 'improved', title: 'Crisp at any zoom', body: 'Thin lines and PDF pages stay sharp at any zoom.', icon: P.eye },
    ] },
    { version: '2.98.76', date: '2026-10-03', notes: [
      { kind: 'new', title: 'The rubric is a ring', body: 'Each criterion is a slice, sized by its points.', icon: P.sparkle },
      { kind: 'new', title: 'Open a slice', body: 'It unrolls into a bar with every level beside it.', icon: P.steps },
      { kind: 'improved', title: 'Focus on the ring', body: 'The page dims and blurs around it; no card.', icon: P.eye },
    ] },
    { version: '2.98.75', date: '2026-10-03', notes: [
      { kind: 'fixed', title: 'Smooth card closing', body: 'A counter no longer vanishes as its box folds back.', icon: P.layers },
    ] },
    { version: '2.98.74', date: '2026-10-03', notes: [
      { kind: 'improved', title: 'Zoom photos out', body: 'Theme photos zoom out to half size, and still move.', icon: P.pic },
    ] },
    { version: '2.98.73', date: '2026-10-03', notes: [
      { kind: 'new', title: 'Glass counter boxes', body: 'A Dashboard counter opens into the search’s glass.', icon: P.layers },
      { kind: 'improved', title: 'Card steps away', body: 'The counter hides behind its box while it is open.', icon: P.eye },
      { kind: 'improved', title: 'Softer search blur', body: 'The search glass blurs the page behind it less.', icon: P.sparkle },
      { kind: 'improved', title: 'Lighter without blur', body: 'Chrome without graphics acceleration does less work.', icon: P.steps },
    ] },
    { version: '2.98.72', date: '2026-10-03', notes: [
      { kind: 'improved', title: 'Fainter glass edge', body: 'The search glass keeps only a faint line at its edge.', icon: P.sparkle },
    ] },
    { version: '2.98.71', date: '2026-10-03', notes: [
      { kind: 'improved', title: 'Switches slide', body: 'The highlight in Cards | List and the like glides across.', icon: P.toggle },
      { kind: 'improved', title: 'Search back in place', body: 'On the Dashboard the search sits in its header again.', icon: P.pin },
      { kind: 'improved', title: 'Softer glass edges', body: 'The search glass’s edge light is much more subtle.', icon: P.sparkle },
    ] },
    { version: '2.98.70', date: '2026-10-03', notes: [
      { kind: 'new', title: 'Search in the top bar', body: 'The search box sits at the top left on every page.', icon: P.pin },
      { kind: 'improved', title: 'Liquid Glass edges', body: 'The search glass catches the light along its edges.', icon: P.sparkle },
      { kind: 'improved', title: 'Import shows in purple', body: 'Last right picks, on the exact same questions only.', icon: P.eye },
    ] },
    { version: '2.98.69', date: '2026-10-02', notes: [
      { kind: 'new', title: 'Files as a grid', body: 'Search Files (⌘3) shows each file as a tile, by kind.', icon: P.layers },
      { kind: 'improved', title: 'Lighter search glass', body: 'No borders, a softer blur, and the page stays sharp.', icon: P.eye },
    ] },
    { version: '2.98.68', date: '2026-10-02', notes: [
      { kind: 'improved', title: 'Spotlight glass', body: 'Search floats on smoky glass, the page softly blurred.', icon: P.sparkle },
    ] },
    { version: '2.98.67', date: '2026-10-02', notes: [
      { kind: 'fixed', title: 'Muted quizzes hidden', body: 'Quiz results Canvas holds back stay hidden here too.', icon: P.eye },
    ] },
    { version: '2.98.66', date: '2026-10-02', notes: [
      { kind: 'fixed', title: 'Menus stay on screen', body: 'A menu opened by the screen’s edge no longer runs past it.', icon: P.check },
    ] },
    { version: '2.98.65', date: '2026-10-02', notes: [
      { kind: 'improved', title: 'Instant search', body: 'Your courses’ work is kept ready: results as you type.', icon: P.sparkle },
      { kind: 'improved', title: 'Results glide in', body: 'Rows slide, fade and settle like Spotlight as you type.', icon: P.arrows },
    ] },
    { version: '2.98.64', date: '2026-10-01', notes: [
      { kind: 'fixed', title: 'All feedback pages new', body: 'Links to a grade or comment open Simpl’s feedback.', icon: P.check },
      { kind: 'improved', title: 'Hover to see a mark', body: 'Rest on the Graded pill and its box opens.', icon: P.eye },
    ] },
    { version: '2.98.63', date: '2026-10-01', notes: [
      { kind: 'fixed', title: 'Tool bar sits above', body: 'A tool’s own header and footer stay clear of the bar.', icon: P.layers },
    ] },
    { version: '2.98.62', date: '2026-10-01', notes: [
      { kind: 'new', title: 'Stay logged in', body: 'The iPhone app signs you in to your school by itself.', icon: P.check },
      { kind: 'improved', title: 'Sheets drag like iOS', body: 'Pull a sheet up to grow it, down to put it away.', icon: P.layers },
      { kind: 'improved', title: 'Files in the viewer', body: 'Files open in the iPhone’s own viewer, in a sheet.', icon: P.clip },
      { kind: 'fixed', title: 'Course moves fixed', body: 'Back and swipe agree; no zoom on a double tap.', icon: P.arrows },
    ] },
    { version: '2.98.61', date: '2026-09-30', notes: [
      { kind: 'new', title: 'Hide the tool bar', body: 'Tuck the bar away on a tool; a small tab brings it back.', icon: P.eye },
    ] },
    { version: '2.98.60', date: '2026-09-30', notes: [
      { kind: 'fixed', title: 'Old quiz attempts open', body: 'A tool attempt opens through Canvas, not "Invalid launch".', icon: P.check },
    ] },
    { version: '2.98.59', date: '2026-09-30', notes: [
      { kind: 'new', title: 'Your own grade weights', body: 'Type the syllabus weights per group; the total follows.', icon: P.steps },
      { kind: 'fixed', title: 'Bar only on tool tabs', body: 'A tab opened beside a tool no longer wears its bar.', icon: P.tool },
    ] },
    { version: '2.98.58', date: '2026-09-30', notes: [
      { kind: 'new', title: 'Tasks with a course', body: 'Give a task of your own a course; it wears its colour.', icon: P.layers },
      { kind: 'new', title: 'Repeating tasks', body: 'Daily, weekly, every two weeks or monthly, until a date.', icon: P.clock },
      { kind: 'improved', title: 'Own tasks in the list', body: 'They sit with the day\'s work, not in a group on top.', icon: P.list },
    ] },
    { version: '2.98.57', date: '2026-09-30', notes: [
      { kind: 'fixed', title: 'Box controls in dark', body: 'Preview, the reply field and Send wear the app\'s own look.', icon: P.pen },
    ] },
    { version: '2.98.56', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Smoother openings', body: 'The mark box and search pill start and land as they were.', icon: P.sparkle },
    ] },
    { version: '2.98.55', date: '2026-09-29', notes: [
      { kind: 'new', title: 'Marks open in place', body: 'The grade or Submitted chip grows into a box on the page.', icon: P.layers },
    ] },
    { version: '2.98.54', date: '2026-09-29', notes: [
      { kind: 'new', title: 'Search floats up', body: 'The search box lifts to the centre, Spotlight-style.', icon: P.sparkle },
      { kind: 'new', title: 'Search by kind', body: 'Courses, Work, Files or Actions: ⌘1 to ⌘4 narrow it.', icon: P.list },
    ] },
    { version: '2.98.53', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Blur on the press', body: 'The page blurs the moment a counter is pressed.', icon: P.eye },
    ] },
    { version: '2.98.52', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Themes drawn to fit', body: 'Each theme draws the sidebar, counters and header to shape.', icon: P.pic },
      { kind: 'improved', title: 'Simpler drawings', body: 'The drawn scenes carry fewer, larger shapes.', icon: P.pen },
    ] },
    { version: '2.98.51', date: '2026-09-29', notes: [
      { kind: 'new', title: 'Move and zoom photos', body: 'Drag a photo on the preview to place it, and zoom it.', icon: P.pic },
      { kind: 'improved', title: 'Add photo opens files', body: 'Every Add photo badge opens your files straight away.', icon: P.pic },
      { kind: 'fixed', title: 'Preview matches page', body: 'The preview crops, sizes and icons match the real page.', icon: P.eye },
    ] },
    { version: '2.98.50', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Smaller counter boxes', body: 'A counter opens into a box a third shorter.', icon: P.layers },
      { kind: 'fixed', title: 'Counters back to size', body: 'The six counters are their old height again.', icon: P.check },
    ] },
    { version: '2.98.49', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Shorter counters', body: 'The six counters are a third shorter.', icon: P.layers },
      { kind: 'improved', title: 'Focus starts at once', body: 'The blur and dim begin the moment you click.', icon: P.eye },
    ] },
    { version: '2.98.48', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Cards pull into focus', body: 'The page blurs and dims onto the card, not at once.', icon: P.eye },
    ] },
    { version: '2.98.47', date: '2026-09-29', notes: [
      { kind: 'fixed', title: 'Card words land right', body: 'The glide starts and ends on the card in short windows.', icon: P.check },
    ] },
    { version: '2.98.46', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Cards open smoother', body: 'The number and title glide into the box.', icon: P.layers },
      { kind: 'fixed', title: 'Blur arrives with dim', body: 'The page blurs the moment it darkens.', icon: P.eye },
    ] },
    { version: '2.98.45', date: '2026-09-29', notes: [
      { kind: 'new', title: 'Cards open in place', body: 'A card grows into a tall list right where it is.', icon: P.layers },
      { kind: 'improved', title: 'Preview slides out', body: 'Pick an item and the box widens to show it.', icon: P.eye },
      { kind: 'fixed', title: 'Tour keeps Simpl on', body: 'Picking a length early no longer turns it off.', icon: P.check },
      { kind: 'improved', title: 'Stray clicks held', body: 'Only what the tour asks for can be clicked.', icon: P.steps },
    ] },
    { version: '2.98.44', date: '2026-09-29', notes: [
      { kind: 'new', title: 'Tour pins a tool', body: 'Open Tools and drag one you like to the top.', icon: P.pin },
      { kind: 'improved', title: 'No skipping the tour', body: 'Each step needs the real action.', icon: P.steps },
      { kind: 'improved', title: 'Clearer, darker tour', body: 'Simpler words, a stronger dim and blur.', icon: P.eye },
      { kind: 'fixed', title: 'Courses step works', body: 'Hover Courses and its panel opens in the tour.', icon: P.check },
    ] },
    { version: '2.98.43', date: '2026-09-29', notes: [
      { kind: 'new', title: 'A guided tour', body: 'Your own page, lit one part at a time.', icon: P.steps },
      { kind: 'improved', title: 'Try each step', body: 'Do it yourself; the tour moves on once you have.', icon: P.check },
      { kind: 'fixed', title: 'What-if closes at once', body: 'Close works first press after typing a score.', icon: P.check },
    ] },
    { version: '2.98.42', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Clearer Appearance', body: 'Light, dark and auto as cards; a clear preview.', icon: P.eye },
      { kind: 'new', title: 'Two new themes', body: 'Peaks and City, and richer drawn scenes.', icon: P.pic },
      { kind: 'improved', title: 'Photos easier to add', body: 'Tiles for the sidebar, counters and header.', icon: P.pic },
    ] },
    { version: '2.98.41', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Profile & settings', body: 'Your photo, name and settings in one place.', icon: P.layers },
      { kind: 'improved', title: 'Tidier switch list', body: 'The off list is narrower and lined up right.', icon: P.toggle },
    ] },
    { version: '2.98.40', date: '2026-09-29', notes: [
      { kind: 'fixed', title: 'Glass on Chrome fixed', body: 'Solid panels, and a real blur behind sheets.', icon: P.eye },
    ] },
    { version: '2.98.39', date: '2026-09-29', notes: [
      { kind: 'improved', title: 'Uses less memory', body: 'Finished animations free their memory.', icon: P.layers },
    ] },
    { version: '2.98.38', date: '2026-09-28', notes: [
      { kind: 'new', title: 'What-if assignments', body: 'Add a made-up assignment to any category to test.', icon: P.pen },
      { kind: 'fixed', title: 'Cleaner Details rows', body: 'Assignment rows in Details read cleanly again.', icon: P.check },
    ] },
    { version: '2.98.37', date: '2026-09-28', notes: [
      { kind: 'new', title: 'Search on phone', body: 'Today has the search box and every command.', icon: P.sparkle },
    ] },
    { version: '2.98.36', date: '2026-09-28', notes: [
      { kind: 'improved', title: 'Smoother grade curve', body: 'Point at the trend line to read any day.', icon: P.steps },
      { kind: 'new', title: 'Six counters on phone', body: 'Phone Today shows Overdue, Tomorrow and Graded.', icon: P.list },
      { kind: 'new', title: 'Item grades on phone', body: 'Phone Grades lists your work by letter.', icon: P.layers },
    ] },
    { version: '2.98.35', date: '2026-09-28', notes: [
      { kind: 'new', title: 'Grades by letter', body: 'Slide to A, B, C, D or F to list that work.', icon: P.steps },
      { kind: 'new', title: 'Item grades', body: 'Every graded assignment, all courses, on Grades.', icon: P.list },
    ] },
    { version: '2.98.34', date: '2026-09-28', notes: [
      { kind: 'new', title: 'Highlight a group', body: 'Press a grade group to light up its ring and work.', icon: P.layers },
    ] },
    { version: '2.98.33', date: '2026-09-27', notes: [
      { kind: 'fixed', title: 'Answers stay saved', body: 'Every answer reaches Canvas, checked before you submit.', icon: P.check },
      { kind: 'fixed', title: 'Marks match points', body: 'An answer given full points shows as correct.', icon: P.eye },
      { kind: 'improved', title: 'Back to the quiz', body: 'Leaving feedback returns to the quiz, not the course.', icon: P.arrows },
    ] },
    { version: '2.98.32', date: '2026-09-27', notes: [
      { kind: 'improved', title: 'Tidier report button', body: 'Pinned tools step aside while it opens.', icon: P.pin },
    ] },
    { version: '2.98.31', date: '2026-09-27', notes: [
      { kind: 'improved', title: 'Blanks read as gaps', body: 'Feedback shows a blank as a gap, not its name.', icon: P.pen },
    ] },
    { version: '2.98.30', date: '2026-09-27', notes: [
      { kind: 'new', title: 'Formula questions', body: 'Answer formula questions here, to the places asked.', icon: P.pen },
      { kind: 'new', title: 'File upload questions', body: 'Upload a file for a quiz question without leaving.', icon: P.clip },
    ] },
    { version: '2.98.29', date: '2026-09-27', notes: [
      { kind: 'improved', title: 'One header, every page', body: 'Pick one header photo in step one; every page wears it.', icon: P.layers },
      { kind: 'improved', title: 'Clearer photo hints', body: 'A slower, labelled cursor shows what takes a photo.', icon: P.steps },
      { kind: 'new', title: 'Upload your own photo', body: 'Upload leads the bar, or drop a picture on the preview.', icon: P.pic },
      { kind: 'improved', title: 'Look bar moved', body: 'Light, Dark and System float at the foot of the preview.', icon: P.toggle },
      { kind: 'improved', title: 'Sample preview', body: 'The preview shows made-up courses, not yours.', icon: P.eye },
    ] },
    { version: '2.98.28', date: '2026-09-27', notes: [
      { kind: 'new', title: 'Points per question', body: 'A quiz question shows the points it is worth.', icon: P.check },
      { kind: 'improved', title: 'Notifications drop in', body: 'Messages float down from the top as a pill.', icon: P.pin },
      { kind: 'improved', title: 'Bigger card previews', body: 'Card sheets preview wide; done items sit below in grey.', icon: P.layers },
      { kind: 'fixed', title: 'Sidebar stays put', body: 'The sidebar never scrolls away with the page.', icon: P.scroll },
      { kind: 'improved', title: 'Full-screen quizzes', body: 'The top bar slides away during a quiz.', icon: P.eye },
    ] },
    { version: '2.98.27', date: '2026-09-27', notes: [
      { kind: 'new', title: 'Clearer quiz feedback', body: 'Questions beside a rail you can jump around with J and K.', icon: P.list },
      { kind: 'fixed', title: 'Points per question', body: 'Each question shows its points, like 2 / 4, not 2 / 0.', icon: P.check },
      { kind: 'fixed', title: 'Equations in feedback', body: 'Formulas in a question show instead of blank gaps.', icon: P.pen },
    ] },
    { version: '2.98.26', date: '2026-09-27', notes: [
      { kind: 'fixed', title: 'Feedback shows answers', body: 'Matching and dropdown answers show after submitting.', icon: P.check },
    ] },
    { version: '2.98.25', date: '2026-09-27', notes: [
      { kind: 'fixed', title: 'Matching answers save', body: 'Picking a match no longer fails with an error.', icon: P.check },
    ] },
    { version: '2.98.24', date: '2026-09-27', notes: [
      { kind: 'new', title: 'Side-by-side quizzes', body: 'Questions left, controls right, text sized like Canvas.', icon: P.layers },
      { kind: 'fixed', title: 'Quiz buttons readable', body: 'Blue quiz buttons now show white text.', icon: P.check },
    ] },
    { version: '2.98.23', date: '2026-09-27', notes: [
      { kind: 'improved', title: 'Colored tool pins', body: 'Pinned tools are colored dots with dark icons.', icon: P.pin },
      { kind: 'fixed', title: 'Videos show in pages', body: 'Embedded videos keep their size and their picture.', icon: P.pic },
      { kind: 'improved', title: 'Wider bug report page', body: 'The report page uses a wide window side by side.', icon: P.layers },
    ] },
    { version: '2.98.22', date: '2026-09-27', notes: [
      { kind: 'fixed', title: 'No freeze on updates', body: 'A tab open during an update reloads itself, no spinning.', icon: P.check },
    ] },
    { version: '2.98.21', date: '2026-09-27', notes: [
      { kind: 'improved', title: 'A fuller switch', body: 'The switch is its colour edge to edge, like the purple one.', icon: P.toggle },
    ] },
    { version: '2.98.20', date: '2026-09-27', notes: [
      { kind: 'improved', title: 'Where to report a bug', body: 'A quick look at the purple button, and what it sends.', icon: P.eye },
    ] },
    { version: '2.98.19', date: '2026-09-26', notes: [
      { kind: 'new', title: 'Report a bug', body: 'The purple button beside the switch sends us a report.', icon: P.pen },
      { kind: 'new', title: 'Errors have codes', body: 'Each error ends in a short code to quote in a report.', icon: P.list },
      { kind: 'improved', title: 'Red opens on hover', body: 'Point at red to see how long; no press needed.', icon: P.toggle },
    ] },
    { version: '2.98.18', date: '2026-09-26', notes: [
      { kind: 'new', title: 'Off for a while', body: 'Red asks how long: this page, 30 min to a day, or for good.', icon: P.clock },
      { kind: 'improved', title: 'Green on, red off', body: 'The switch is two colours now: green on, red off.', icon: P.toggle },
      { kind: 'fixed', title: 'Themes hold still', body: 'The ready-made themes no longer flash in and out.', icon: P.check },
    ] },
    { version: '2.98.17', date: '2026-09-26', notes: [
      { kind: 'fixed', title: 'Handed in, not overdue', body: 'Late work you handed in no longer counts as overdue.', icon: P.check },
    ] },
    { version: '2.98.16', date: '2026-09-26', notes: [
      { kind: 'fixed', title: 'Updates keep Chrome on', body: 'An update asks Chrome for nothing new, so it stays on.', icon: P.check },
    ] },
    { version: '2.98.15', date: '2026-09-25', notes: [
      { kind: 'improved', title: 'After an update, a tab', body: 'Where to accept Chrome’s permissions, and why they’re asked.', icon: P.pin },
    ] },
    { version: '2.98.14', date: '2026-09-25', notes: [
      { kind: 'improved', title: 'Chrome asks for less', body: 'The Chrome build no longer asks to read browsing history.', icon: P.toggle },
    ] },
    { version: '2.98.13', date: '2026-09-25', notes: [
      { kind: 'improved', title: 'Away Refresh, opt-in', body: 'Off for everyone now; the switch under General turns it on.', icon: P.toggle },
    ] },
    { version: '2.98.12', date: '2026-09-25', notes: [
      { kind: 'fixed', title: 'Hand-in box stays put', body: 'Convert to PDF? asks over the box instead of closing it.', icon: P.check },
    ] },
    { version: '2.98.11', date: '2026-09-25', notes: [
      { kind: 'improved', title: 'The bar keeps up', body: 'A tool’s whole domain allowed at once, or every site, once.', icon: P.pin },
    ] },
    { version: '2.98.10', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'Updates finish cleanly', body: 'A Safari still on an old copy after an update says so.', icon: P.tool },
    ] },
    { version: '2.98.9', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Break, one press away', body: 'A Focus | Break switch and an Open button on the island.', icon: P.clock },
      { kind: 'improved', title: 'Capsules in step', body: 'Every pin opens over the island’s half second, smoother.', icon: P.toggle },
    ] },
    { version: '2.98.8', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'The display, typeset', body: 'The line is the equation itself, in the pin’s panel too.', icon: P.pen },
    ] },
    { version: '2.98.7', date: '2026-09-24', notes: [
      { kind: 'new', title: 'LaTeX in calculator', body: 'Every sum typeset as an equation, its LaTeX a press away.', icon: P.pen },
    ] },
    { version: '2.98.6', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Quicker What’s new', body: 'A line per change, up at once, Done to close.', icon: P.sparkle },
      { kind: 'fixed', title: 'Clean previews', body: 'A long announcement ends with … not “[truncated]”.', icon: P.eye },
    ] },
    { version: '2.98.5', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'Graded is not overdue', body: 'Work marked without a hand-in no longer counts as overdue.', icon: P.check },
      { kind: 'fixed', title: 'Locked work left off', body: 'Past-due work you can no longer open stays off Overdue.', icon: P.clock },
      { kind: 'fixed', title: 'Clearing overdue rows', body: 'The X clears a row you had cleared and put back before.', icon: P.list },
    ] },
    { version: '2.98.4', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Smoother motion', body: 'Every move a touch slower and drawn finer, never rushed.', icon: P.arrows },
      { kind: 'improved', title: 'Wikipedia switch', body: 'A real switch in the box, there while you are typing.', icon: P.toggle },
    ] },
    { version: '2.98.3', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Say it in plain words', body: 'Type “/start today’s quiz” or “what’s due tomorrow”.', icon: P.sparkle },
      { kind: 'new', title: 'Tools inside work', body: '/open lists the tool an assignment uses, by its name.', icon: P.tool },
      { kind: 'improved', title: 'Shorter command titles', body: 'A command’s list is headed by a few words, not a line.', icon: P.list },
    ] },
    { version: '2.98.2', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Motion on springs', body: 'Every sheet, menu and screen moves like a real thing.', icon: P.arrows },
      { kind: 'improved', title: 'Cut short, not snapped', body: 'Close a sheet mid-way and it turns back from there.', icon: P.toggle },
      { kind: 'fixed', title: 'Centred toasts', body: 'A toast sits in the middle of the window again.', icon: P.check },
    ] },
    { version: '2.98.1', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Hold to switch it off', body: 'Hold the Away Refresh pill and it never reloads again.', icon: P.clock },
      { kind: 'new', title: 'Away Refresh switch', body: 'Under General in Settings: on or off, any time.', icon: P.toggle },
    ] },
    { version: '2.98.0', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'Back on solid ground', body: 'The springs and corners of 2.96–2.97 are pulled until right.', icon: P.check },
    ] },
    { version: '2.95.0', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Where work stands', body: 'Missing, Late, Excused, Graded: the same words on every row.', icon: P.list },
      { kind: 'improved', title: 'Nothing left blank', body: 'Grades, quizzes, modules, files, inbox: every field shown.', icon: P.eye },
      { kind: 'new', title: 'Deeper commands', body: '/open, /assignment, /quiz, /due and more, with a why-not.', icon: P.sparkle },
      { kind: 'fixed', title: 'To Do holds still', body: 'Rows no longer flash in and out; a redraw lands in place.', icon: P.check },
    ] },
    { version: '2.94.0', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Zoom in, zoom out', body: 'Every screen fits from 50% to 200%, and with OS scaling.', icon: P.eye },
      { kind: 'improved', title: 'Steadier layout', body: 'Popups, menus and panels place themselves, on screen.', icon: P.pin },
      { kind: 'improved', title: 'One layout rule', body: 'A laptop zoomed to 200% gets the phone layout, live.', icon: P.toggle },
    ] },
    { version: '2.93.0', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Smoother motion', body: 'Sheets and menus ease out; rows and cards press in.', icon: P.arrows },
      { kind: 'fixed', title: 'Tidier corners', body: 'Welcome text centred, quiz search full width, upload arrow.', icon: P.eye },
      { kind: 'fixed', title: 'Canvas pages on phones', body: 'The To Do column sits under the page, not over it.', icon: P.steps },
    ] },
    { version: '2.92.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Widgets of your own', body: 'Tools → Add a widget: one HTML file becomes a tool.', icon: P.layers },
      { kind: 'new', title: 'Four starters', body: 'A countdown, a notes pad, a unit converter, a word counter.', icon: P.list },
      { kind: 'new', title: 'Safe by design', body: 'A widget runs in a sandbox: no page, no session, no network.', icon: P.check },
    ] },
    { version: '2.91.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Search does things', body: 'Type / for commands: submit, download, convert, open…', icon: P.sparkle },
      { kind: 'new', title: 'Hand in from the box', body: '/submit opens the assignment’s hand-in block over the page.', icon: P.pen },
      { kind: 'improved', title: 'Instant results', body: 'From the first letter, the top hit chosen as you type.', icon: P.list },
      { kind: 'new', title: '/ from any screen', body: 'Press / or ⌘K anywhere: the Dashboard opens on the box.', icon: P.arrows },
      { kind: 'new', title: 'Sums in the box', body: '2*(3+4) or 15% of 80: the answer appears, Enter copies it.', icon: P.tool },
    ] },
    { version: '2.90.0', date: '2026-09-24', notes: [
      { kind: 'improved', title: 'Lighter pages', body: 'A page parses far less code; the rest loads when used.', icon: P.sparkle },
      { kind: 'improved', title: 'Photos, as needed', body: 'A tab reads only the pictures its own screen shows.', icon: P.pic },
      { kind: 'improved', title: 'Less busy work', body: 'Fewer writes and watchers; warm-ups one at a time.', icon: P.clock },
    ] },
    { version: '2.89.0', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'Dropped scores count', body: 'A drop-lowest rule is applied to the total and the rings.', icon: P.steps },
      { kind: 'fixed', title: 'All-day events', body: 'An all-day event sits on its own day, not the day before.', icon: P.clock },
      { kind: 'fixed', title: 'Inbox names', body: 'A conversation is named after the other people in it.', icon: P.list },
      { kind: 'fixed', title: 'Alerts in order', body: 'Overdue first, then due soon, graded, feedback, news.', icon: P.check },
      { kind: 'fixed', title: 'Reply to an entry', body: 'Reply-to can be cancelled; the reply lands where you chose.', icon: P.pen },
      { kind: 'fixed', title: 'Sheets and moves', body: 'A sheet left open closes when the screen changes under it.', icon: P.layers },
      { kind: 'fixed', title: 'iPhone app start', body: 'The app’s background script loads on the phone again.', icon: P.tool },
      { kind: 'improved', title: 'A lighter build', body: 'Old screens and styles nobody could reach are gone.', icon: P.sparkle },
    ] },
    { version: '2.88.0', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'The search box', body: 'No stray white field inside the pill any more.', icon: P.check },
    ] },
    { version: '2.87.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Past points, charted', body: 'Add a day (or a term) and a GPA in GPA settings.', icon: P.steps },
      { kind: 'improved', title: 'The trend, whole', body: 'Eight points spread across all of it, not the last week.', icon: P.clock },
    ] },
    { version: '2.86.0', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'CSV upload, on Safari', body: 'The file is read before the picker is cleared.', icon: P.check },
    ] },
    { version: '2.85.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Grades, on the Mac', body: 'The app’s window has the Grades section now.', icon: P.list },
      { kind: 'new', title: 'Download CSV', body: 'Your record, and this term’s courses, as one file.', icon: P.steps },
    ] },
    { version: '2.84.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Events open a sheet', body: 'When, place, details; un-reserve an appointment.', icon: P.eye },
      { kind: 'new', title: 'Upload, on the page', body: 'The Grades page’s settings take the transcript CSV too.', icon: P.steps },
    ] },
    { version: '2.83.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Upload your transcript', body: 'A CSV of past courses in Settings → Grades sets your record.', icon: P.steps },
    ] },
    { version: '2.82.0', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'Your classes only', body: 'Sections you are not in no longer show as course numbers.', icon: P.check },
    ] },
    { version: '2.81.0', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'The bar over a tool', body: 'Comes back after a reload. Blocked? Press the Simpl icon.', icon: P.layers },
      { kind: 'new', title: 'Keep the bar here', body: 'The popup asks the browser once for the tool’s site.', icon: P.check },
      { kind: 'improved', title: 'Appearance, expanded', body: 'Light, Dark or Personalize, off the sidebar button.', icon: P.toggle },
      { kind: 'improved', title: 'Appointments, tidier', body: 'The class first; a day opens to its hours, not pills.', icon: P.list },
      { kind: 'fixed', title: 'Calendar head fits', body: 'Its buttons shorten on a narrower window, no wrapped row.', icon: P.arrows },
    ] },
    { version: '2.80.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Find appointment', body: 'Office hours and sign-ups: a sheet of times to reserve.', icon: P.clock },
      { kind: 'improved', title: 'Month, uncluttered', body: 'Only the time you reserve goes on the calendar.', icon: P.eye },
    ] },
    { version: '2.79.0', date: '2026-09-24', notes: [
      { kind: 'fixed', title: 'Search box, tidied', body: 'One pill, level with the view switcher.', icon: P.check },
      { kind: 'fixed', title: 'Pages and files found', body: 'Every starred course is asked, a few at a time.', icon: P.pic },
      { kind: 'new', title: 'Wikipedia, a switch', body: 'The W beside the box turns it off, or on again.', icon: P.toggle },
      { kind: 'improved', title: 'Updates, every 4 hours', body: 'The Mac app checks four times a day, not hourly.', icon: P.clock },
    ] },
    { version: '2.78.0', date: '2026-09-24', notes: [
      { kind: 'new', title: 'Search everything', body: 'One box on the Dashboard: all of Canvas, and Wikipedia.', icon: P.sparkle },
      { kind: 'new', title: 'Shown once', body: 'A pointer at the box the first time, on black.', icon: P.eye },
    ] },
    // invite: the invitation again (whatsnew.js), for anyone who has not tried a theme yet; the notes wait in Settings
    { version: '2.77.0', date: '2026-09-23', invite: true, notes: [
      { kind: 'new', title: 'A cursor shows the way', body: 'It presses the sidebar and two counters, once.', icon: P.eye },
      { kind: 'improved', title: 'Try a theme, again', body: 'The invitation comes back for anyone who has not.', icon: P.pic },
    ] },
    { version: '2.76.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Personalize, laid out', body: 'A larger preview, the ready-made themes down its right.', icon: P.layers },
      { kind: 'improved', title: 'Continue at the foot', body: 'A bar at the bottom of the screen, on any device.', icon: P.arrows },
    ] },
    { version: '2.75.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Scenes redrawn', body: 'Ridges, waves, trees and dunes, in clean lines.', icon: P.pen },
      { kind: 'new', title: 'A drawing per card', body: 'Every counter and header wears its own variation.', icon: P.pic },
      { kind: 'fixed', title: 'Picker in place', body: 'The colour picker opens on the Custom swatch.', icon: P.tool },
      { kind: 'improved', title: 'Continue in view', body: 'The first screen fits shorter windows.', icon: P.arrows },
    ] },
    // invite: the first page after this update shows the theme invitation (whatsnew.js) in the notes' place; the notes wait in Settings
    { version: '2.74.0', date: '2026-09-23', invite: true, notes: [
      { kind: 'new', title: 'Try a theme', body: 'This update invites you to pick one, or a colour.', icon: P.pic },
      { kind: 'new', title: 'Themes, pointed out', body: 'After Personalize, the Appearance button is shown.', icon: P.eye },
    ] },
    { version: '2.73.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Appearance opens it', body: 'The sidebar’s Appearance button opens the editor.', icon: P.toggle },
      { kind: 'improved', title: 'Account panel, trimmed', body: 'Canvas’s own settings, and a link to Simpl’s.', icon: P.list },
      { kind: 'improved', title: 'What’s new in Settings', body: 'Settings → General opens it again.', icon: P.sparkle },
    ] },
    { version: '2.72.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Inked, tone on tone', body: 'Outlines a shade lighter than the ground they sit on.', icon: P.pen },
    ] },
    { version: '2.71.0', date: '2026-09-23', notes: [
      { kind: 'new', title: 'Photos, inked', body: 'Drawn in two inks: your colour and its complement.', icon: P.pen },
      { kind: 'improved', title: 'Scenes, inked too', body: 'Dusk, Ocean, Forest and Sand come as outlines and shapes.', icon: P.pic },
    ] },
    { version: '2.70.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Photos, a hint', body: 'Washed heavily in the look’s ground, its ink over them.', icon: P.pic },
      { kind: 'improved', title: 'Wide windows', body: 'The page fills a zoomed-out window instead of a band.', icon: P.arrows },
    ] },
    { version: '2.69.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Lighter on memory', body: 'Photos blur as pictures, not filters; Desmos lets go.', icon: P.tool },
      { kind: 'improved', title: 'Bolder colour', body: 'The greys take more of your colour.', icon: P.pen },
      { kind: 'improved', title: 'Photos washed', body: 'Darker on the dark look, lighter on the light.', icon: P.pic },
      { kind: 'improved', title: 'Sidebar reads', body: 'A soft halo behind the words, a hover you can see.', icon: P.eye },
      { kind: 'improved', title: 'Solid sheets', body: 'A counter’s sheet is solid, not glass.', icon: P.layers },
      { kind: 'improved', title: 'Clearer pins', body: 'The tray’s glyphs are bigger and brighter.', icon: P.sparkle },
      { kind: 'fixed', title: 'Selection ring', body: 'A photo choice shows its whole ring.', icon: P.check },
    ] },
    { version: '2.68.0', date: '2026-09-23', notes: [
      { kind: 'fixed', title: 'Sidebar photo stays', body: 'The photo holds still while the sidebar scrolls.', icon: P.pin },
      { kind: 'improved', title: 'Appearance', body: 'The sidebar’s switch just says Appearance.', icon: P.toggle },
      { kind: 'new', title: 'Default, ready-made', body: 'A tile that puts everything back: Regular, no photos.', icon: P.sparkle },
    ] },
    { version: '2.67.0', date: '2026-09-23', notes: [
      { kind: 'new', title: 'Ready-made looks', body: 'Dusk, Ocean, Forest, Sand: a colour and scenes at once.', icon: P.sparkle },
      { kind: 'improved', title: 'Drawn scenes, crisp', body: 'The four scenes are drawn as vectors: sharp at any size.', icon: P.pic },
      { kind: 'improved', title: 'A soft cast of colour', body: 'The greys take a little of your colour, so nothing jars.', icon: P.pen },
      { kind: 'improved', title: 'Frosted controls', body: 'Over a photo, buttons and rows are frosted glass.', icon: P.layers },
      { kind: 'fixed', title: 'Photo to the top', body: 'A header photo runs on up under the widgets’ bar.', icon: P.pin },
    ] },
    { version: '2.66.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Windows text', body: 'Segoe UI on Windows, so titles and numbers sit right.', icon: P.pen },
      { kind: 'improved', title: 'Bar over tools', body: 'On a school’s own Canvas too, asking once for a tool’s site.', icon: P.layers },
      { kind: 'fixed', title: 'Page titles', body: 'Calendar and Inbox titles are the size of the rest.', icon: P.check },
    ] },
    { version: '2.65.0', date: '2026-09-23', notes: [
      { kind: 'new', title: 'Personalize', body: 'A new look step: colour, course colours and page photos.', icon: P.sparkle },
      { kind: 'improved', title: 'A round colour picker', body: 'Pick a hue on the ring, then its saturation and depth.', icon: P.pen },
      { kind: 'improved', title: 'Shorter setup', body: 'Four steps, then Continue to appearance.', icon: P.steps },
    ] },
    { version: '2.64.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'Blur in its own colour', body: 'A photo fades into a colour of its own, not black or white.', icon: P.pic },
      { kind: 'fixed', title: 'Depth slider', body: 'Dragging Depth no longer trips the Theme step in Safari.', icon: P.check },
    ] },
    { version: '2.63.0', date: '2026-09-23', notes: [
      { kind: 'fixed', title: 'Headers stay put', body: 'A header with a photo sits at the top again, and sticks.', icon: P.pin },
      { kind: 'fixed', title: 'The × on a photo', body: 'Taking a photo off a counter works in Safari too.', icon: P.check },
    ] },
    { version: '2.62.0', date: '2026-09-23', notes: [
      { kind: 'improved', title: 'A preview to scale', body: 'The theme’s Dashboard is the real page, made small.', icon: P.eye },
      { kind: 'improved', title: 'A tidier colour picker', body: 'The wheel and swatches take less room on the step.', icon: P.layers },
    ] },
    { version: '2.61.0', date: '2026-09-23', notes: [
      { kind: 'new', title: 'A colour wheel', body: 'Pick your colour on a wheel; sliders are one press away.', icon: P.pen },
      { kind: 'new', title: 'Colour your courses', body: 'A setup step gives each course its colour.', icon: P.sparkle },
      { kind: 'new', title: 'Photos on headers', body: 'Any page title can carry a photo, blurred towards it.', icon: P.pic },
      { kind: 'improved', title: 'A shade per row', body: 'Under a theme, each sidebar row wears its own shade.', icon: P.layers },
      { kind: 'improved', title: 'Titles in your colour', body: 'Page titles take the colour you chose.', icon: P.pen },
      { kind: 'improved', title: 'A roomier setup', body: 'Every step is larger, with a note to scroll for more.', icon: P.scroll },
    ] },
    { version: '2.60.0', date: '2026-09-23', notes: [
      { kind: 'new', title: 'Themes', body: 'Your own colour, and photos on the counters and sidebar.', icon: P.pic },
      { kind: 'new', title: 'Readable colours only', body: 'A picker that stops at colours you can read, day and night.', icon: P.eye },
      { kind: 'improved', title: 'See what you handed in', body: 'The chip by the title opens your work before it is graded.', icon: P.clip },
    ] },
    { version: '2.59.0', date: '2026-09-22', notes: [
      { kind: 'improved', title: 'Sidebar to the top', body: 'The widgets’ bar now sits beside it, over the page alone.', icon: P.layers },
      { kind: 'fixed', title: 'Quick flashcard marks', body: 'Fast presses each mark their own card, none twice.', icon: P.check },
    ] },
    { version: '2.58.0', date: '2026-09-22', notes: [
      { kind: 'new', title: 'A new Simpl switch', body: 'Hover the disc: Activate, Deactivate and Turn off drop down.', icon: P.toggle },
      { kind: 'new', title: 'Widgets get a bar', body: 'The switch and your pins sit in a strip above the page.', icon: P.pin },
      { kind: 'fixed', title: 'No flash between steps', body: 'The welcome stays black from one pointer to the next.', icon: P.eye },
      { kind: 'fixed', title: 'Arrows on their rows', body: 'A pointer at a sidebar row now sits level with it.', icon: P.arrows },
      { kind: 'improved', title: 'Course page, up top', body: 'The button to the course’s Grades page now sits by the X.', icon: P.arrows },
      { kind: 'fixed', title: 'What-if banner sized', body: 'The red note in Details no longer fills the column.', icon: P.check },
      { kind: 'fixed', title: 'One solid trend line', body: 'The line no longer breaks into dashes on the Mac.', icon: P.steps },
      { kind: 'fixed', title: 'Clean trend labels', body: 'No mark drawn through the numbers under the line.', icon: P.check },
    ] },
    { version: '2.57.0', date: '2026-09-22', notes: [
      { kind: 'new', title: 'What-if on Grades', body: 'Try scores in a course’s Details and see the total move.', icon: P.pen },
      { kind: 'improved', title: 'Details, side by side', body: 'Breakdown on the left, assignments on the right, one size.', icon: P.layers },
      { kind: 'improved', title: 'A wider calendar', body: 'The calendars moved behind a button; the month has the room.', icon: P.arrows },
      { kind: 'new', title: 'Preview from the grid', body: 'Press an assignment on the calendar to read it there.', icon: P.eye },
      { kind: 'new', title: 'Due tomorrow', body: 'A dashboard card for tomorrow’s work, in place of classes.', icon: P.clock },
      { kind: 'improved', title: 'Sheets hold still', body: 'A card’s list opens at one size and stays there.', icon: P.list },
      { kind: 'new', title: 'Pick a look in setup', body: 'Setup now asks light, dark or automatic.', icon: P.toggle },
      { kind: 'fixed', title: 'Widgets blur on Chrome', body: 'The glass behind a pinned tool frosts the page again.', icon: P.sparkle },
    ] },
    { version: '2.56.0', date: '2026-09-22', notes: [
      { kind: 'new', title: 'Your pins go with you', body: 'The pinned tools sit in the bar on a tool’s own tab.', icon: P.pin },
    ] },
    { version: '2.55.0', date: '2026-09-22', notes: [
      { kind: 'improved', title: 'Tools get a whole tab', body: 'A tool opens in its own tab, with our bar on top.', icon: P.layers },
      { kind: 'new', title: 'The X brings you back', body: 'It closes the tool and returns to your Canvas tab.', icon: P.arrows },
      { kind: 'fixed', title: 'Sign-ins just work', body: 'Nothing is taken from a tool while it signs you in.', icon: P.check },
      { kind: 'fixed', title: 'Matching saves again', body: 'A pick that Canvas used to refuse now goes through.', icon: P.list },
    ] },
    { version: '2.54.0', date: '2026-09-22', notes: [
      { kind: 'fixed', title: 'Blanks sit in the line', body: 'A dropdown fills the gap it was written into.', icon: P.pen },
      { kind: 'fixed', title: 'Every blank counts', body: 'A question is answered once no blank is left.', icon: P.check },
    ] },
    { version: '2.53.0', date: '2026-09-22', notes: [
      { kind: 'improved', title: 'Sign-ins finish first', body: 'A tool’s window runs to the end before it is brought back.', icon: P.clock },
      { kind: 'new', title: 'It says when to wait', body: 'The bar goes red while a tool is signing in somewhere else.', icon: P.eye },
    ] },
    { version: '2.52.0', date: '2026-09-22', notes: [
      { kind: 'improved', title: 'No tool is given up on', body: 'A slow one is waited for, not pushed into a tab.', icon: P.clock },
    ] },
    { version: '2.51.0', date: '2026-09-22', notes: [
      { kind: 'improved', title: 'No tab at all', body: 'A window a tool opens is taken before the browser makes one.', icon: P.layers },
    ] },
    { version: '2.50.1', date: '2026-09-22', notes: [
      { kind: 'fixed', title: 'Catching in Safari', body: 'Safari was never told a tab had opened. Now it is.', icon: P.layers },
    ] },
    { version: '2.50.0', date: '2026-09-22', notes: [
      { kind: 'fixed', title: 'Only Canvas is added', body: 'A tool’s own site is no longer taken for your Canvas.', icon: P.check },
      { kind: 'improved', title: 'Catching windows', body: 'More ways to catch one, for browsers that say less.', icon: P.layers },
    ] },
    { version: '2.49.0', date: '2026-09-21', notes: [
      { kind: 'new', title: 'Windows tools open', body: 'A window a tool opens for itself lands in a popup.', icon: P.layers },
      { kind: 'improved', title: 'Every quiz taken here', body: 'A quiz that seals its questions no longer opens on Canvas.', icon: P.check },
      { kind: 'fixed', title: 'Discussions in order', body: 'Ordered by the date each row shows, newest activity first.', icon: P.list },
      { kind: 'improved', title: 'Longer to open', body: 'A tool has ten seconds to open before it is given a tab.', icon: P.clock },
    ] },
    { version: '2.48.1', date: '2026-09-21', notes: [
      { kind: 'new', title: 'A tool over a tool', body: 'One opened from another goes on top, then hands back.', icon: P.layers },
      { kind: 'improved', title: 'Dark is for the framed', body: 'Only a popup holding another site goes dark.', icon: P.eye },
    ] },
    { version: '2.48.0', date: '2026-09-21', notes: [
      { kind: 'new', title: 'Framed tools go dark', body: 'A school tool opens dark, bar and page alike.', icon: P.eye },
      { kind: 'new', title: 'A sun for light', body: 'Press the sun in its bar to turn the pair light again.', icon: P.sparkle },
      { kind: 'improved', title: 'Desmos goes dark too', body: 'The graphing calculator is turned over to match.', icon: P.tool },
    ] },
    { version: '2.47.2', date: '2026-09-21', notes: [
      { kind: 'fixed', title: 'Pins show their icons', body: 'The panel’s blur was covering them.', icon: P.eye },
      { kind: 'new', title: 'A widget over a tool', body: 'The green light opens a tool over the one already up.', icon: P.layers },
      { kind: 'improved', title: 'The X keeps to itself', body: 'The red unpin dot shows only on its own corner.', icon: P.pin },
      { kind: 'fixed', title: 'Loose widgets stay put', body: 'One pulled out no longer folds when you hover another pin.', icon: P.pin },
      { kind: 'fixed', title: 'Pins press again', body: 'A press on a folded pin no longer starts pulling it out.', icon: P.pin },
    ] },
    { version: '2.47.1', date: '2026-09-21', notes: [
      { kind: 'improved', title: 'Widgets redesigned', body: 'Blurred, rounder, one box each: the pins are panels now.', icon: P.layers },
      { kind: 'new', title: 'Pull a widget out', body: 'Drag the bar under it and it stays where you put it.', icon: P.pin },
      { kind: 'improved', title: 'Easier to read', body: 'The welcome’s grey lines are larger and brighter.', icon: P.eye },
      { kind: 'improved', title: 'Stuck tools get a tab', body: 'One that has not opened in five seconds opens in a tab.', icon: P.clock },
    ] },
    { version: '2.47.0', date: '2026-09-21', notes: [
      { kind: 'improved', title: 'The welcome, again', body: 'See it again in Settings replays it; the old tour is gone.', icon: P.eye },
      { kind: 'improved', title: 'Updates land at once', body: 'After an update, your open Canvas tabs load again.', icon: P.arrows },
      { kind: 'fixed', title: 'The app’s switches act', body: 'In the Mac app, the two switches ask first, then do it.', icon: P.toggle },
    ] },
    { version: '2.46.0', date: '2026-09-21', notes: [
      { kind: 'improved', title: 'A fuller welcome', body: 'The black screen now points out Grades, Courses and Tools.', icon: P.eye },
    ] },
    { version: '2.45.1', date: '2026-09-21', notes: [
      { kind: 'improved', title: 'A cleaner table', body: 'Elements lose their outlines: the colour alone marks each.', icon: P.layers },
    ] },
    { version: '2.45.0', date: '2026-09-21', notes: [
      { kind: 'improved', title: 'Algebraic calculator', body: 'Type the whole sum and it is worked out as you go.', icon: P.tool },
    ] },
    { version: '2.44.2', date: '2026-09-20', notes: [
      { kind: 'new', title: 'Safari finds Canvas', body: 'Let it see every website once and your Canvas is found.', icon: P.sparkle },
      { kind: 'fixed', title: 'Updates find home', body: 'On a Mac, an update goes into Applications when it must.', icon: P.arrows },
    ] },
    { version: '2.44.1', date: '2026-09-20', notes: [
      { kind: 'new', title: 'A first screen', body: 'The Mac app opens on a welcome, and a button for Safari.', icon: P.sparkle },
      { kind: 'fixed', title: 'The app finds its home', body: 'Opened from Downloads, it offers to move to Applications.', icon: P.tool },
      { kind: 'improved', title: 'Smoother pins', body: 'A pinned tool opens under the pointer without a stutter.', icon: P.pin },
    ] },
    { version: '2.44.0', date: '2026-09-20', notes: [
      { kind: 'new', title: 'Settings in the app', body: 'On a Mac it is set up from its app; Safari follows.', icon: P.tool },
      { kind: 'new', title: 'The app updates itself', body: 'It checks every hour and installs a new version itself.', icon: P.arrows },
    ] },
    { version: '2.43.1', date: '2026-09-20', notes: [
      { kind: 'improved', title: 'A small periodic table', body: 'Hover its pin for the whole table, small; press to open.', icon: P.layers },
    ] },
    { version: '2.43.0', date: '2026-09-20', notes: [
      { kind: 'new', title: 'Setup finds Canvas', body: 'Install, open your Canvas, and setup begins there.', icon: P.sparkle },
      { kind: 'improved', title: 'A shorter first page', body: 'The page after install says Open your Canvas, then closes.', icon: P.steps },
    ] },
    { version: '2.42.0', date: '2026-09-20', notes: [
      { kind: 'improved', title: 'Groups open faster', body: 'The Groups list and a group’s page land sooner.', icon: P.clock },
      { kind: 'new', title: 'Reload a tool', body: 'A tool’s bar has Reload, for a sign-in gone in circles.', icon: P.arrows },
      { kind: 'improved', title: 'A quieter tool bar', body: 'A tool’s full-screen bar shows its name and nothing more.', icon: P.layers },
    ] },
    { version: '2.41.1', date: '2026-09-20', notes: [
      { kind: 'fixed', title: 'A stray “null”', body: 'The PDF annotator no longer shows “nullnull” on its home.', icon: P.check },
    ] },
    { version: '2.41.0', date: '2026-09-20', notes: [
      { kind: 'new', title: 'Periodic table', body: 'Every element with its facts, and a search across them.', icon: P.layers },
    ] },
    { version: '2.40.0', date: '2026-09-20', notes: [
      { kind: 'improved', title: 'Tools fill the screen', body: 'A tool’s popup fills the screen but for its bar.', icon: P.layers },
      { kind: 'improved', title: 'Start assignment', body: 'An assignment done in a tool opens it over the page.', icon: P.check },
      { kind: 'improved', title: 'Fewer Open in Canvas', body: 'Gone from tools and files; kept where it matters.', icon: P.toggle },
    ] },
    { version: '2.39.1', date: '2026-09-20', notes: [
      { kind: 'improved', title: 'A wider calculator', body: 'The Calculator takes more of the page, with bigger keys.', icon: P.steps },
      { kind: 'improved', title: 'Desmos pin', body: 'The pin opens the big graphing calculator, or desmos.com.', icon: P.sparkle },
    ] },
    { version: '2.39.0', date: '2026-09-20', notes: [
      { kind: 'new', title: 'Tools open over pages', body: 'Campus tools and module links open in a popup; pins stay.', icon: P.layers },
      { kind: 'new', title: 'Calculator on its own', body: 'The scientific calculator is a tool of its own now.', icon: P.steps },
      { kind: 'improved', title: 'Graphing pin', body: 'The pin swells into a small Desmos that keeps its graph.', icon: P.sparkle },
    ] },
    { version: '2.38.0', date: '2026-09-20', notes: [
      { kind: 'new', title: 'The Cite pin, a panel', body: 'Paste a link, cite this page, pick the style.', icon: P.pin },
    ] },
    { version: '2.37.1', date: '2026-09-20', notes: [
      { kind: 'fixed', title: 'Cite, laid out', body: 'Style and source sit on one row across the popup.', icon: P.list },
    ] },
    { version: '2.37.0', date: '2026-09-20', notes: [
      { kind: 'improved', title: 'Sharper image to text', body: 'PaddleOCR now: sharper on scans, with Chinese and Japanese.', icon: P.eye },
      { kind: 'improved', title: 'Merge & split redrawn', body: 'Every page a thumbnail: drag them in, or pull them out.', icon: P.layers },
    ] },
    { version: '2.36.0', date: '2026-09-19', notes: [
      { kind: 'new', title: 'Draw and type on PDFs', body: 'A pen, text boxes, underline, six colours, undo and redo.', icon: P.pen },
      { kind: 'improved', title: 'Citation generator', body: 'Source types as tiles, missing fields as chips, tidier.', icon: P.list },
      { kind: 'improved', title: 'The Cite pin', body: 'A plain button now: press it and the generator opens.', icon: P.pin },
      { kind: 'fixed', title: 'Away Refresh waits', body: 'No reload while a tool, a preview or a hand-in is open.', icon: P.clock },
      { kind: 'fixed', title: 'New Quizzes count', body: 'A quiz in a frame Canvas launches is never reloaded.', icon: P.check },
      { kind: 'improved', title: 'No pins in a quiz', body: 'The pinned tools are put away while a quiz attempt is going.', icon: P.pin },
    ] },
    { version: '2.35.1', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'The switch, shown', body: 'Its black screen comes back once, redrawn as a slider.', icon: P.toggle },
      { kind: 'improved', title: 'Merge & split icon', body: 'The card wears a page with a cut line across it.', icon: P.layers },
    ] },
    { version: '2.35.0', date: '2026-09-19', notes: [
      { kind: 'new', title: 'Grade needed', body: 'What you need on the final to hit your goal.', icon: P.steps },
      { kind: 'new', title: 'Merge & split PDFs', body: 'Join PDFs into one, or cut one into parts, on this device.', icon: P.layers },
      { kind: 'new', title: 'PDF annotator', body: 'Highlight, box and pin notes on a PDF, kept per file.', icon: P.pen },
      { kind: 'new', title: 'Image to text', body: 'Read the words off a picture. Nothing is uploaded.', icon: P.pic },
      { kind: 'improved', title: 'A real calculator', body: 'The calculator pin now opens a scientific calculator.', icon: P.tool },
      { kind: 'fixed', title: 'Pin fields on Canvas', body: 'The Cite pin’s field is no longer white and square.', icon: P.pin },
      { kind: 'improved', title: 'The lock in red-orange', body: 'The switch’s locked stop is red-orange now.', icon: P.toggle },
    ] },
    { version: '2.34.0', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'Just the slider', body: 'The switch opens into the slider alone.', icon: P.toggle },
    ] },
    { version: '2.33.0', date: '2026-09-19', notes: [
      { kind: 'new', title: 'How the switch works', body: 'A short show, once: point, press a side, drag the knob.', icon: P.toggle },
      { kind: 'new', title: 'Quick menus on pins', body: 'Point at a pinned tool: cite, work out, convert, study.', icon: P.pin },
      { kind: 'improved', title: 'Learn remembers', body: 'Wrong cards come back soon, learned ones in a day.', icon: P.layers },
      { kind: 'new', title: 'Share a set', body: 'Share sends the set as a CSV; Import CSV adds it.', icon: P.arrows },
    ] },
    { version: '2.32.0', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'The switch folds', body: 'A small disc with the mark. Point at it and it opens.', icon: P.toggle },
    ] },
    { version: '2.31.0', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'New look switch', body: 'A white knob with a tick, a dash or a lock in it.', icon: P.toggle },
    ] },
    { version: '2.30.0', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'Bigger look switch', body: 'The slider grows under the pointer. Press a side to set.', icon: P.toggle },
    ] },
    { version: '2.29.0', date: '2026-09-19', notes: [
      { kind: 'new', title: 'Three-way look switch', body: 'Press for stock Canvas; drag it left to lock Simpl off.', icon: P.toggle },
    ] },
    { version: '2.28.0', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'Word into a PDF', body: 'Where only PDF is allowed, the picker takes Word too.', icon: P.arrows },
    ] },
    { version: '2.27.0', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'Timer opens on hover', body: 'Point at the pinned timer and it opens, like the switch.', icon: P.pin },
    ] },
    { version: '2.26.0', date: '2026-09-19', notes: [
      { kind: 'improved', title: 'Timer scale', body: 'The marker stays put. Drag the scale to set the minutes.', icon: P.clock },
      { kind: 'new', title: 'Set and go', body: 'The pinned timer opens a small scale and a Start button.', icon: P.pin },
    ] },
    { version: '2.25.0', date: '2026-09-19', notes: [
      { kind: 'new', title: 'Convert to hand in', body: 'A file of the wrong type is converted here to one it takes.', icon: P.arrows },
      { kind: 'fixed', title: 'One Away Refresh', body: 'Coming back to a tab shows one pill, never a stack of them.', icon: P.clock },
      { kind: 'fixed', title: 'Tool grades', body: 'A grade a tool passes back shows without a reload.', icon: P.check },
      { kind: 'fixed', title: 'Safari: Open works', body: 'A preview’s Open goes through without a reload.', icon: P.check },
    ] },
    { version: '2.24.0', date: '2026-09-19', notes: [
      { kind: 'new', title: 'Flashcards', body: 'Flashcards, Learn, Test and Match, stars, paste to add.', icon: P.layers },
      { kind: 'improved', title: 'Simpler Tools', body: 'Every tool says what it does in a few plain words.', icon: P.tool },
    ] },
    { version: '2.23.0', date: '2026-09-18', notes: [
      { kind: 'new', title: 'Word ⇄ PDF here', body: 'Word to PDF and back here, formatting kept.', icon: P.arrows },
      { kind: 'new', title: 'Pass/Fail courses', body: 'A switch per course in setup; it stays out of the GPA.', icon: P.toggle },
      { kind: 'improved', title: 'Install arrow', body: 'The arrow after install points at the puzzle piece itself.', icon: P.steps },
    ] },
    { version: '2.22.1', date: '2026-09-18', notes: [
      { kind: 'fixed', title: 'Access codes', body: 'The code goes with every answer, and is asked again.', icon: P.check },
    ] },
    { version: '2.22.0', date: '2026-09-18', notes: [
      { kind: 'new', title: 'Quizzes with a code', body: 'A quiz that needs an access code asks for it first.', icon: P.check },
      { kind: 'new', title: 'Surveys', body: 'Surveys and graded surveys are taken here.', icon: P.list },
      { kind: 'improved', title: 'Fresh on return', body: 'Come back to a tab and it reads Canvas again.', icon: P.arrows },
      { kind: 'improved', title: 'Written answers', body: 'Essay answers keep their paragraphs and lists.', icon: P.pen },
      { kind: 'improved', title: 'Graded means done', body: 'Work that already has a grade is never shown as due.', icon: P.check },
    ] },
    { version: '2.21.0', date: '2026-09-18', notes: [
      { kind: 'new', title: 'Real conversions', body: 'Paste a CloudConvert key and Word, PDF and slides convert.', icon: P.arrows },
    ] },
    { version: '2.20.0', date: '2026-09-18', notes: [
      { kind: 'improved', title: 'After install', body: 'A splash, an arrow to the button, then where to go.', icon: P.steps },
      { kind: 'improved', title: 'One button', body: 'The timer’s pin is its live activity. It morphs.', icon: P.toggle },
    ] },
    { version: '2.19.0', date: '2026-09-18', notes: [
      { kind: 'improved', title: 'Focus timer', body: 'Set the minutes on a scale, like the phone’s timer card.', icon: P.clock },
      { kind: 'improved', title: 'Live activity', body: 'A small dial beside the switch. Press it to see the count.', icon: P.toggle },
    ] },
    { version: '2.18.0', date: '2026-09-18', notes: [
      { kind: 'improved', title: 'Focus timer', body: 'A new dial, session dots, Skip, and smoother motion.', icon: P.clock },
      { kind: 'new', title: 'Live at the top right', body: 'A running timer sits next to the switch, not in the sidebar.', icon: P.toggle },
      { kind: 'improved', title: 'Tools in motion', body: 'Cards, popups and flashcards move as you use them.', icon: P.sparkle },
    ] },
    { version: '2.17.0', date: '2026-09-18', notes: [
      { kind: 'new', title: 'Tools', body: 'Citations, a timer, Desmos, a converter, flashcards.', icon: P.tool },
      { kind: 'new', title: 'Pin a tool', body: 'Drag a tool card to the top; it becomes a button.', icon: P.pin },
    ] },
    { version: '2.16.1', date: '2026-09-18', notes: [
      { kind: 'improved', title: 'Tips after setup', body: 'Continue waits a little longer.', icon: P.sparkle },
    ] },
    { version: '2.16.0', date: '2026-09-18', notes: [
      { kind: 'new', title: 'Tips after setup', body: 'Two quick tips replace the tour after setup.', icon: P.sparkle },
    ] },
    { version: '2.15.3', date: '2026-09-18', notes: [
      { kind: 'improved', title: 'Setup', body: 'You pick your courses yourself, then the page reloads.', icon: P.steps },
    ] },
    { version: '2.15.2', date: '2026-09-18', notes: [
      { kind: 'fixed', title: 'Mark as done on pages', body: 'Pages in a module that ask for a mark have the button too.', icon: P.check },
    ] },
    { version: '2.15.1', date: '2026-09-18', notes: [
      { kind: 'new', title: 'Preview attachments', body: 'Attached files have a Preview button.', icon: P.eye },
    ] },
    { version: '2.15.0', date: '2026-09-18', notes: [
      { kind: 'new', title: 'Clear overdue items', body: 'Press the X next to an overdue item to clear it.', icon: P.check },
      { kind: 'improved', title: 'Shorter install page', body: 'Three quick steps, a line each.', icon: P.pic },
    ] },
    { version: '2.14.3', date: '2026-09-18', notes: [
      { kind: 'improved', title: 'Timer hand', body: 'The hand now turns from the center.', icon: P.clock },
    ] },
    { version: '2.14.2', date: '2026-09-18', notes: [
      { kind: 'improved', title: 'Rounder timer hand', body: 'Thicker at the base, rounded at both ends.', icon: P.clock },
    ] },
    { version: '2.14.1', date: '2026-09-17', notes: [
      { kind: 'improved', title: 'New timer look', body: 'The countdown now looks like the iPhone timer.', icon: P.clock },
    ] },
    { version: '2.14.0', date: '2026-09-17', notes: [
      { kind: 'new', title: 'Away Refresh', body: 'Back after a while? The page refreshes in 3 seconds.', icon: P.clock },
      { kind: 'improved', title: 'Cleaner Persistent', body: 'The extra text under it is gone.', icon: P.toggle },
    ] },
    { version: '2.13.3', date: '2026-09-17', notes: [
      { kind: 'improved', title: 'Simpler What’s new', body: 'Just a list of changes and one button.', icon: P.sparkle },
      { kind: 'fixed', title: 'Shows once', body: 'Skipped a few updates? You see one screen, once.', icon: P.layers },
    ] },
    { version: '2.13.2', date: '2026-09-17', notes: [
      { kind: 'improved', title: 'A smaller switch', body: 'Hover to see the name and Persistent.', icon: P.toggle },
    ] },
    { version: '2.13.1', date: '2026-09-17', notes: [
      { kind: 'fixed', title: 'Blue dot fixed', body: 'The dot after “Simpl” is in the right spot on Windows.', icon: P.sparkle },
    ] },
    { version: '2.13.0', date: '2026-09-17', notes: [
      { kind: 'new', title: 'Persistent on hover', body: 'Hover the top-right switch to turn Persistent on or off.', icon: P.toggle },
      { kind: 'fixed', title: 'Mark as done', body: 'Now shows for discussions and quizzes in modules.', icon: P.check },
    ] },
    { version: '2.12.2', date: '2026-09-17', notes: [
      { kind: 'fixed', title: 'Fresh grades', body: 'Grades always load fresh from Canvas.', icon: P.check },
    ] },
    { version: '2.12.1', date: '2026-09-17', notes: [
      { kind: 'fixed', title: 'Grades from tools', body: 'Grades posted by tools show up without a reload.', icon: P.check },
    ] },
    { version: '2.12.0', date: '2026-09-17', notes: [
      { kind: 'new', title: 'What’s new screen', body: 'See what changed after each update.', icon: P.sparkle },
      { kind: 'new', title: 'Earlier versions', body: 'Older updates are at the bottom of the list.', icon: P.layers },
    ] },
    { version: '2.11.0', date: '2026-09-17', notes: [
      { kind: 'new', title: 'Top-right switch', body: 'Turn the Simpl Courses look on or off on any page.', icon: P.toggle },
      { kind: 'new', title: 'Persistent', body: 'Keep the look on or off across every page.', icon: P.check },
      { kind: 'improved', title: 'Open in stock Canvas', body: 'Changes only this page unless Persistent is on.', icon: P.eye },
    ] },
    { version: '2.10.1', date: '2026-09-17', notes: [
      { kind: 'improved', title: 'Classes pre-selected', body: 'Setup ticks courses named like MATH 021.', icon: P.check },
      { kind: 'improved', title: 'Course list scrollbar', body: 'The setup course list always shows a scrollbar.', icon: P.scroll },
    ] },
    { version: '2.10.0', date: '2026-09-17', notes: [
      { kind: 'new', title: 'New setup', body: 'Step by step, with previews and a summary.', icon: P.steps },
      { kind: 'improved', title: 'Dashboard previews', body: 'Pick Cards, List or Activity from small previews.', icon: P.pic },
    ] },
    { version: '2.9.1', date: '2026-09-17', notes: [
      { kind: 'improved', title: 'Install page', body: 'Each step now has a picture.', icon: P.pic },
    ] },
    { version: '2.7.5', date: '2026-09-16', notes: [
      { kind: 'fixed', title: 'Faster assignments', body: 'Assignment pages open without waiting for buttons.', icon: P.clock },
    ] },
    { version: '2.7.3', date: '2026-09-16', notes: [
      { kind: 'new', title: 'Hide completed', body: 'Hide finished work on the Dashboard list.', icon: P.list },
    ] },
    { version: '2.7.2', date: '2026-09-16', notes: [
      { kind: 'new', title: 'Assignment feedback', body: 'Press the grade to see score, comments and attempts.', icon: P.pen },
      { kind: 'new', title: 'Mark as done', body: 'The button is right on the assignment page.', icon: P.check },
      { kind: 'new', title: 'Previous and Next', body: 'Jump between assignments from the page.', icon: P.arrows },
    ] },
    { version: '2.7.1', date: '2026-09-16', notes: [
      { kind: 'fixed', title: 'Phone attachments', body: 'Attachments now open instead of a 404.', icon: P.clip },
    ] },
  ];
})();
