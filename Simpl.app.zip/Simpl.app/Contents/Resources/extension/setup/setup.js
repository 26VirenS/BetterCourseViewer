/* The page after install (Safari and Chrome): black, the way the welcome on the page is — a splash,
 * then the one thing to do: Open your courses page. Setup will begin there. Nothing to press: the setup
 * runs over the Canvas page on its own (content/app/setup.js opens over the first signed-in Canvas
 * page until it is done), and this page closes itself the moment it has begun. The school's own
 * Canvas address is found by itself (content/sniff.js) on any site the extension may look at:
 * Chrome's build may look at every site from the start; Safari has to be told, so its page carries
 * one press that asks for every website at once (Safari's own prompt), and the line about Safari
 * asking for a site at a time for whoever says no. */
(async function () {
  const BCV = self.BCV;
  const api = BCV.api;
  const { h } = BCV.utils;
  const safari = /apple/i.test(navigator.vendor || '') && !/chrome|crios|edg/i.test(navigator.userAgent);
  const SPLASH = 1600; // the wordmark holds this long before the words
  const SHEET = '<svg viewBox="22.9 22.4 75 75" width="100%" height="100%"><path d="M50.55 24.94L50.27 25.03L46.73 25.11L46.23 25.29L44.82 25.39L44.32 25.57L43.28 25.64L42.95 25.84L42.19 25.91L41.86 26.11L41.05 26.20L40.77 26.38L40.45 26.39L39.36 26.76L39.09 26.94L38.55 27.03L38.32 27.20L37.18 27.57L34.61 28.91L32.18 30.57L30.07 32.50L28.15 34.82L28.00 35.21L27.57 35.68L27.18 36.57L26.77 37.01L26.56 37.50L26.58 37.73L26.01 38.86L26.03 39.09L25.68 39.82L25.08 42.55L25.03 44.27L24.84 45.64L25.03 46.77L25.11 48.68L25.29 49.18L25.39 50.32L25.56 50.55L25.65 51.09L25.84 51.36L26.19 52.59L27.03 54.27L28.41 56.34L30.02 58.05L31.55 59.36L32.41 59.93L32.76 60.05L34.05 61.02L36.68 62.30L36.91 62.29L38.86 63.12L39.09 63.11L40.50 63.67L44.64 64.63L44.86 64.76L51.91 66.11L55.45 66.92L56.05 67.21L56.27 67.20L56.86 67.49L57.09 67.47L57.68 67.76L57.91 67.74L59.05 68.30L59.27 68.29L59.55 68.55L59.82 68.56L60.19 68.91L61.05 69.30L62.32 70.50L62.92 71.27L63.47 72.36L63.56 72.91L63.75 73.18L63.79 76.00L63.38 77.32L63.39 77.55L63.13 78.09L62.16 79.55L61.30 80.41L59.86 81.47L58.23 82.29L56.86 82.65L56.59 82.84L55.85 82.91L55.05 83.15L53.82 83.21L53.32 83.39L49.23 83.39L46.50 83.03L43.92 82.32L43.18 81.92L42.91 81.92L42.64 81.65L42.36 81.64L42.09 81.38L41.82 81.37L40.67 80.50L40.28 80.36L38.82 78.91L38.23 78.17L37.12 75.95L37.02 75.09L36.84 74.86L36.83 74.55L36.68 74.40L23.77 74.39L23.55 74.44L23.47 74.64L23.47 75.36L23.66 75.91L23.75 77.32L23.92 77.77L24.01 78.64L24.21 78.95L24.29 79.73L24.50 80.09L24.57 80.86L25.56 82.73L25.67 83.32L26.10 83.82L26.47 84.55L27.82 86.39L29.86 88.50L30.59 88.95L31.45 89.82L32.49 90.32L33.68 91.22L34.23 91.49L34.45 91.47L34.77 91.76L35.00 91.74L35.41 91.91L36.77 92.62L39.95 93.67L44.09 94.49L44.55 94.47L47.05 94.84L49.59 94.89L54.68 94.84L55.45 94.66L58.64 94.32L59.39 94.09L60.14 94.02L60.36 93.85L61.18 93.76L61.45 93.57L62.23 93.50L63.41 93.01L63.95 92.93L64.36 92.69L64.82 92.64L68.59 90.74L69.91 89.76L70.23 89.65L72.15 88.00L73.77 86.27L74.23 85.55L74.91 84.85L75.59 83.38L76.02 82.91L77.30 79.45L77.85 76.73L77.83 75.73L77.98 74.50L77.93 71.27L77.75 70.77L77.66 69.64L77.49 69.18L77.38 68.27L77.20 68.00L76.84 66.64L75.73 64.42L74.64 62.80L73.03 61.09L72.46 60.73L71.77 60.05L71.10 59.64L70.67 59.23L69.68 58.77L69.27 58.39L67.05 57.28L66.64 57.10L66.41 57.12L65.27 56.56L65.05 56.58L64.41 56.26L62.82 55.74L62.59 55.76L59.82 54.92L57.59 54.51L57.36 54.38L48.95 52.76L45.56 51.77L44.14 51.20L42.50 50.38L42.04 49.95L41.65 49.82L40.18 48.36L39.85 47.86L39.30 46.77L39.02 44.59L39.12 44.23L39.11 43.50L39.40 42.64L39.38 42.41L40.41 40.44L41.47 39.27L42.09 38.76L42.41 38.65L42.91 38.21L44.50 37.41L44.95 37.35L45.36 37.12L46.23 37.02L46.45 36.85L47.59 36.75L48.14 36.56L51.00 36.47L53.82 36.66L55.87 37.14L56.77 37.44L57.95 38.03L58.23 38.04L58.56 38.36L59.41 38.76L60.43 39.59L61.27 40.44L62.08 41.50L62.65 42.64L62.76 43.23L62.93 43.45L63.20 44.50L63.27 45.32L63.41 45.49L76.45 45.52L76.65 45.41L76.57 43.77L76.39 43.23L76.30 41.59L76.10 41.27L75.52 38.95L75.30 38.59L74.92 37.45L74.36 36.33L73.00 34.16L71.64 32.53L69.32 30.33L68.92 30.18L68.45 29.75L68.10 29.64L67.67 29.23L67.28 29.09L66.85 28.68L64.64 27.57L61.18 26.29L58.36 25.63L55.41 25.19Z" fill="#fff"/><circle cx="89.73" cy="87.0" r="7.56" fill="#0A84FF"/></svg>';

  const root = document.getElementById('splash');
  document.documentElement.classList.add('is-splash');
  let current = null;
  let splashTimer = 0; // the splash moving on by itself
  /** The next screen in, the last one out. */
  function show(el) {
    clearTimeout(splashTimer);
    const old = current;
    if (old) { old.classList.add('is-leaving'); setTimeout(() => old.remove(), 300); }
    current = el;
    root.append(el);
  }

  // ---- the two screens -------------------------------------------------------------------------
  function splash() {
    return h('div', { class: 'splash__stage splash__stage--word', dataset: { stage: 'splash' } }, [
      h('div', { class: 'splash__brand' }, [
        h('span', { class: 'mark mark--splash', 'aria-hidden': 'true', html: SHEET }),
        h('span', { class: 'splash__word', text: 'Simpl.' }),
      ]),
    ]);
  }
  function go() {
    // Safari lets an extension look at a site only once it is told it may. One press here asks for
    // every website at once (Safari's own prompt); allowed, the school's Canvas is then recognised by
    // itself, wherever it is. Refused, Safari asks for a site at a time, from its toolbar button.
    const note = safari ? h('p', { class: 'splash__note' }, ['Safari asks once whether Simpl Courses may see every website. That is how it recognises your school’s Canvas; on other sites it does nothing.']) : null;
    const find = safari ? h('button', { type: 'button', class: 'splash__btn', text: 'Let Simpl Courses find it' }) : null;
    if (find) {
      find.addEventListener('click', () => {
        // permissions.request() has to be called within the press itself: nothing awaited before it
        let asked;
        try { asked = Promise.resolve(api.permissions.request({ origins: ['*://*/*'] })); } catch (e) { asked = Promise.reject(e); }
        const aSiteAtATime = () => note.replaceChildren('Not allowed. When Safari asks on your Canvas, press the ', h('b', { text: 'Simpl Courses' }), ' button in the toolbar and choose ', h('b', { text: 'Always Allow on This Website' }), '.');
        asked.then((ok) => {
          if (!ok) { aSiteAtATime(); return; }
          find.hidden = true;
          note.replaceChildren('Done. Open your Canvas courses page, at whatever address your school uses, and setup begins there.');
        }, aSiteAtATime);
      });
    }
    return h('div', { class: `splash__stage splash__stage--go${safari ? ' is-safari' : ''}`, dataset: { stage: 'go' } }, [
      h('div', { class: 'splash__text' }, [
        h('h1', { class: 'splash__title', text: 'Open your courses page' }),
        h('p', { class: 'splash__hint', text: 'Setup will begin there.' }),
        find,
        note,
      ]),
    ]);
  }

  // a press anywhere on the splash moves it along
  show(splash());
  const onward = () => { if (current?.dataset.stage === 'splash') show(go()); };
  splashTimer = setTimeout(onward, SPLASH);
  root.addEventListener('click', onward);
  await api.storage.local.set({ 'setup:offered': true }).catch(() => {});

  // The setup beginning on a Canvas tab (the card leaves a note in storage as it opens) is the end
  // of this page: it asks the background to close its tab (a page cannot close a tab it did not
  // open itself). The same when the setup is finished, for a page left open past it.
  const closeMe = () => { try { Promise.resolve(api.runtime.sendMessage({ type: 'closeSetupTab' })).catch(() => {}); } catch { /* stays open */ } };
  try {
    api.storage.onChanged.addListener((changes, area) => {
      if (area && area !== 'local') return;
      if ((changes['setup:begun'] && changes['setup:begun'].newValue) || (changes['setup:done'] && changes['setup:done'].newValue)) closeMe();
    });
  } catch { /* no storage events: the page stays until it is closed */ }
})();
