/* Grades (sidebar): every current course's Canvas score on one page, a term
 * GPA on the plain 4.0 scale (every course counts equally — Canvas publishes
 * no credit weighting), an optional cumulative GPA and a daily history the
 * page keeps itself once tracking is on, one card per course whose ring
 * opens into the group breakdown, a Details sheet with the course's own
 * grade page, target grades with the arithmetic behind them, and a few
 * honest stats. None of it is the registrar's GPA, and the page says where
 * every number came from. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  const { h } = BCV.utils;
  const U = BCV.ui;
  const IC = BCV.IC;
  const store = BCV.store;

  const SCALE = [['A+', 97, 4], ['A', 93, 4], ['A−', 90, 3.7], ['B+', 87, 3.3], ['B', 83, 3], ['B−', 80, 2.7], ['C+', 77, 2.3], ['C', 73, 2], ['C−', 70, 1.7], ['D', 60, 1], ['F', 0, 0]];
  const OLD_SCALE = ['A', 'A−', 'B+', 'B', 'B−', 'C+', 'C', 'C−', 'D', 'F']; // targets saved before A+ existed were indices into this
  const POINTS = { 'A+': 4, A: 4, 'A-': 3.7, 'B+': 3.3, B: 3, 'B-': 2.7, 'C+': 2.3, C: 2, 'C-': 1.7, 'D+': 1.3, D: 1, 'D-': 0.7, F: 0 };
  const DEFAULT_GOAL = 4; // where the goal's stepper starts while none is set (the setup's own starting point)
  const TARGET = 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7.5a4.5 4.5 0 100 9 4.5 4.5 0 000-9zM12 11a1 1 0 100 2 1 1 0 000-2z'; // (a goal not set yet: no arrow up or down)
  const norm = (g) => String(g || '').replace(/−/g, '-').toUpperCase().trim();
  /** A saved target (a letter, or an index into the scale before A+) → its index on SCALE, or -1. */
  const targetIndex = (t) => {
    const letter = Number.isInteger(t) ? OLD_SCALE[t] : typeof t === 'string' ? t : null;
    return letter ? SCALE.findIndex((s) => norm(s[0]) === norm(letter)) : -1;
  };
  const letterFor = (pct, scale = SCALE) => scale.find((s) => pct >= s[1]) || scale[scale.length - 1];
  // (2.99.27) a course's own grading scale, as its instructor set it (the syllabus's cutoffs): the student's entry, kept
  // per course in gradeScales ({ [course]: { 'A+': 97, A: 93, … } }); a letter left out keeps the standard cutoff. F is
  // always 0. Read with each screen that letters a score (loadScales); the same letters in the same order as SCALE.
  // (2.99.140) a letter taken off the scale is saved as null: its cutoff is Infinity, never reached, so the letter under it
  // runs up to the next one kept (the scale keeps SCALE's length and order, so an index into one is an index into the
  // other). Under '*', the student's own scale for every course that has none of its own.
  let scales = {};
  const ALL = '*';
  const live = (s) => Number.isFinite(s[1]);
  const scaleFrom = (own) => SCALE.map(([l, min, pts]) => {
    const k = norm(l);
    const v = own[k];
    return [l, k === 'F' ? 0 : v === null ? Infinity : typeof v === 'number' && Number.isFinite(v) ? v : min, pts];
  });
  const ownOf = (cid) => { const o = cid != null ? scales[String(cid)] : null; return o && typeof o === 'object' ? o : null; };
  /** The scale that letters a course's score: its own, else the student's scale for every course, else the standard. */
  const scaleOf = (cid) => { const own = ownOf(cid) || ownOf(ALL); return own ? scaleFrom(own) : SCALE; };
  /** A scale of the student's letters the course (its own, or theirs for every course): Simpl's letter, never Canvas's. */
  const hasScale = (cid) => !!(ownOf(cid) || ownOf(ALL));
  const ownScaleOf = (cid) => !!ownOf(cid); // (the course's very own, not the one for every course)
  const loadScales = async () => {
    const v = await store.pref('gradeScales', {}).catch(() => ({}));
    scales = v && typeof v === 'object' ? v : {};
    return scales;
  };
  /** A course's scale saved ({ letter: min% or null }), or let go (null): the standard again (or the one for every
   *  course). Cutoffs must fall letter by letter. cid '*': the scale for every course. */
  const setScale = async (cid, map) => {
    await loadScales();
    const all = { ...scales };
    if (map) all[String(cid)] = map; else delete all[String(cid)];
    scales = all;
    await store.setPref('gradeScales', all);
    return scaleOf(cid);
  };
  /** (2.99.140) What is wrong with a scale ({ letter: min% or null }), or ''. Each letter kept a cutoff from 0 to 100,
   *  each under the one kept above it; at least one letter kept besides F. */
  const scaleError = (map) => {
    let last = Infinity, kept = 0;
    for (const [l] of SCALE) {
      const k = norm(l);
      if (k === 'F' || map[k] === null) continue;
      const v = map[k];
      if (typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 100) return `${l} needs a percentage from 0 to 100.`;
      if (v >= last) return `${l}’s cutoff must be lower than the letter above it.`;
      last = v;
      kept++;
    }
    return kept ? '' : 'Keep at least one letter above F.';
  };
  /** (2.99.140) An index on a scale moved onto a letter kept: itself, else the nearest kept above it, else below. */
  const snapIdx = (S, i) => {
    if (i < 0 || live(S[i])) return i;
    for (let j = i - 1; j >= 0; j--) if (live(S[j])) return j;
    for (let j = i + 1; j < S.length; j++) if (live(S[j])) return j;
    return S.length - 1;
  };
  /** The next letter kept from i, a step down (d 1) or up (d −1); i itself at the end. */
  const stepIdx = (S, i, d) => { for (let j = i + d; j >= 0 && j < S.length; j += d) if (live(S[j])) return j; return i; };
  const isPassFail = (t) => typeof t === 'string' && /^p\s*\/\s*f$/i.test(t.trim()); // the setup's Pass/Fail switch, saved in place of a letter
  // Canvas's own letter when the course publishes one, else the standard scale
  const pointsFor = (letter, pct, scale = SCALE) => (norm(letter) in POINTS ? POINTS[norm(letter)] : letterFor(pct, scale)[2]);
  const gpa2 = (n) => (n === null || n === undefined ? '—' : n.toFixed(2));
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const shortCode = (c) => (c.shortName || c.name).replace(/^[A-Z]\d{2}-/, '');
  const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const GEAR = 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-2.9 1.2v.2a2 2 0 11-4 0v-.1a1.7 1.7 0 00-2.9-1.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00-1.2-2.9H3a2 2 0 110-4h.2a1.7 1.7 0 001.2-2.9l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 002.9-1.2V3a2 2 0 114 0v.2a1.7 1.7 0 002.9 1.2l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 001.2 2.9H21a2 2 0 110 4h-.2a1.7 1.7 0 00-1.4 1z';
  const TREND = 'M4 17l5-6 4 3 6-8';
  const EYE_OFF = 'M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6zM4 4l16 16';
  const MIN_Y = 2.4, MAX_Y = 4.0;
  const LOWER_BY = 10; // the "if ungraded work lands lower" what-if: every remaining score 10 points under today's
  const NS = 'http://www.w3.org/2000/svg';
  const RING_R = 22; // the 56px course ring
  const CAT_R = [16, 10.5, 5]; // nested group rings inside it
  const svgEl = (tag, attrs) => {
    const el = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, String(v));
    return el;
  };
  const dashFor = (pct, r) => {
    const c = 2 * Math.PI * r;
    const f = (clamp(pct, 0, 100) / 100) * c;
    return `${f.toFixed(1)} ${(c - f).toFixed(1)}`;
  };

  // ---- the trend ------------------------------------------------------------------------------
  /** A curve through points, smooth and monotone (Fritsch–Carlson): it bends between the points and
   *  never swings past one, so a flat stretch stays flat and a peak is where the snapshot is. */
  function smoothPath(p) {
    const f = (v) => v.toFixed(2);
    if (!p.length) return '';
    if (p.length === 1) return `M${f(p[0].x)},${f(p[0].y)}`;
    const n = p.length;
    const dx = [], m = [];
    for (let i = 0; i < n - 1; i++) { dx[i] = p[i + 1].x - p[i].x || 1e-6; m[i] = (p[i + 1].y - p[i].y) / dx[i]; }
    const t = [m[0]];
    for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
    t[n - 1] = m[n - 2];
    for (let i = 0; i < n - 1; i++) {
      if (m[i] === 0) { t[i] = 0; t[i + 1] = 0; continue; }
      const a = t[i] / m[i], b = t[i + 1] / m[i], q = a * a + b * b;
      if (q > 9) { const k = 3 / Math.sqrt(q); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; }
    }
    let d = `M${f(p[0].x)},${f(p[0].y)}`;
    for (let i = 0; i < n - 1; i++) {
      const h3 = dx[i] / 3;
      d += `C${f(p[i].x + h3)},${f(p[i].y + t[i] * h3)} ${f(p[i + 1].x - h3)},${f(p[i + 1].y - t[i + 1] * h3)} ${f(p[i + 1].x)},${f(p[i + 1].y)}`;
    }
    return d;
  }
  /** Up to `n` indices spread across a history — the first and the last always — so a point added
   *  from a past term keeps its place under the chart as the days pile up after it. */
  const spreadIdx = (len, n = 8) => {
    if (len <= n) return [...Array(len).keys()];
    const idx = new Set();
    for (let i = 0; i < n; i++) idx.add(Math.round((i * (len - 1)) / (n - 1)));
    return [...idx].sort((a, b) => a - b);
  };
  const snapLabel = (s) => {
    const thisYear = String(new Date().getFullYear());
    return s.date === dayKey() ? 'Today' : `${U.fmtShort(`${s.date}T12:00:00`)}${s.date.slice(0, 4) === thisYear ? '' : ` ’${s.date.slice(2, 4)}`}`;
  };
  let trendSeq = 0;
  /** The trend (2.98.36: the Grades page's Trend card and the phone's Grades): a smooth curve through
   *  every snapshot, a soft fill under it, the goal dashed across; under it `ticks` dates spread over
   *  the whole (the first and today always). The point under the pointer — a mouse hovering, a finger
   *  dragging, the arrow keys once it has focus — shows as a dot on the curve with its date and GPA
   *  over it. Returns [chart, axis]. */
  function trendChart(snaps, { goal = null, animate = false, ticks = 8, minGap = 9 } = {}) {
    const yAt = (v) => 92 - ((clamp(v, MIN_Y, MAX_Y) - MIN_Y) / (MAX_Y - MIN_Y)) * 84;
    const xAt = (i) => 7 + i * (86 / Math.max(1, snaps.length - 1));
    const pts = snaps.map((s, i) => ({ x: xAt(i), y: yAt(s.gpa), s }));
    const svg = svgEl('svg', { viewBox: '0 0 100 100', preserveAspectRatio: 'none', 'aria-hidden': 'true' });
    const gid = `bcv-trend-fill-${++trendSeq}`;
    const defs = svgEl('defs', {});
    const grad = svgEl('linearGradient', { id: gid, x1: '0', y1: '0', x2: '0', y2: '1' });
    grad.append(svgEl('stop', { offset: '0', 'stop-color': '#0a84ff', 'stop-opacity': '.2' }), svgEl('stop', { offset: '1', 'stop-color': '#0a84ff', 'stop-opacity': '0' }));
    defs.append(grad);
    svg.append(defs);
    if (goal !== null) svg.append(svgEl('line', { x1: '0', y1: yAt(goal).toFixed(2), x2: '100', y2: yAt(goal).toFixed(2), stroke: '#5856d6', 'stroke-width': '1.5', 'stroke-dasharray': '4 4', 'vector-effect': 'non-scaling-stroke', opacity: '.8', class: 'bcv-gpa__goalline' }));
    const d = smoothPath(pts);
    const first = pts[0], last = pts[pts.length - 1];
    // on entry the curve is revealed from left to right (a clip sliding open: a dash the line's length
    // would stay a dash pattern in Safari, which does not scale it) and the fill rises under it
    svg.append(
      svgEl('path', { d: `${d}L${last.x.toFixed(2)},100L${first.x.toFixed(2)},100Z`, fill: `url(#${gid})`, stroke: 'none', class: `bcv-gpa__area ${animate ? 'bcv-gpa__area--in' : ''}` }),
      svgEl('path', { d, fill: 'none', stroke: '#0a84ff', 'stroke-width': '3', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'vector-effect': 'non-scaling-stroke', class: `bcv-gpa__curve ${animate ? 'bcv-gpa__line--draw' : ''}` }),
    );
    // today's point stays marked; every other shows when it is pointed at
    const nowDot = h('span', { class: `bcv-gpa__pt ${animate ? 'bcv-gpa__pt--in' : ''}`, style: { left: `${last.x.toFixed(2)}%`, top: `${last.y.toFixed(2)}%`, '--bcv-delay': '1250ms' } });
    const guide = h('span', { class: 'bcv-gpa__guide', hidden: true });
    const dot = h('span', { class: 'bcv-gpa__hdot', hidden: true });
    const tipV = U.text('bcv-gpa__tip-v', '', 'span');
    const tipL = U.text('bcv-gpa__tip-l', '', 'span');
    const tip = h('span', { class: 'bcv-gpa__tip', hidden: true, role: 'status' }, [tipV, tipL]);
    const chart = U.el('bcv-gpa__chart', [svg, guide, nowDot, dot, tip], {
      tabindex: '0',
      'aria-label': `GPA trend, ${snaps.length} snapshots: ${gpa2(first.s.gpa)} on ${snapLabel(first.s)} to ${gpa2(last.s.gpa)} ${snapLabel(last.s) === 'Today' ? 'today' : `on ${snapLabel(last.s)}`}. Arrow keys step through them.`,
    });
    let at = -1;
    let hideT = 0;
    const show = (i) => {
      clearTimeout(hideT);
      i = clamp(i, 0, pts.length - 1);
      if (i === at && !tip.hidden) return; // (the pointer still nearest the same point: nothing to move)
      at = i;
      const p = pts[at];
      const ch = chart.clientHeight || 92; // (read before anything is written: no layout forced mid-frame)
      for (const e of [guide, dot, tip]) e.hidden = false;
      guide.style.left = `${p.x}%`;
      dot.style.left = `${p.x}%`;
      dot.style.top = `${p.y}%`;
      tip.style.left = `${p.x}%`;
      tip.style.top = `${p.y}%`;
      tip.classList.toggle('is-left', p.x < 16);
      tip.classList.toggle('is-right', p.x > 84);
      tip.classList.toggle('is-below', (p.y / 100) * ch < 52); // (near the top: the label hangs under the point, not over the card's heading)
      tipV.textContent = gpa2(p.s.gpa);
      tipL.textContent = snapLabel(p.s);
      chart.dataset.at = String(at);
    };
    const hide = () => { at = -1; for (const e of [guide, dot, tip]) e.hidden = true; delete chart.dataset.at; };
    const nearest = (clientX) => {
      const r = chart.getBoundingClientRect();
      const x = ((clientX - r.left) / r.width) * 100;
      let best = 0;
      for (let i = 1; i < pts.length; i++) if (Math.abs(pts[i].x - x) < Math.abs(pts[best].x - x)) best = i;
      return best;
    };
    let touching = false;
    chart.addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse' || touching) show(nearest(e.clientX)); });
    chart.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse' && document.activeElement !== chart) hide(); });
    chart.addEventListener('pointerdown', (e) => { if (e.pointerType === 'mouse') return; touching = true; show(nearest(e.clientX)); });
    const lift = () => { if (!touching) return; touching = false; hideT = setTimeout(hide, 1800); }; // (a finger lifted: the reading stays a moment, then goes)
    chart.addEventListener('pointerup', lift);
    chart.addEventListener('pointercancel', lift);
    chart.addEventListener('focus', () => { if (at < 0) show(pts.length - 1); });
    chart.addEventListener('blur', hide);
    chart.addEventListener('keydown', (e) => {
      const to = e.key === 'ArrowLeft' ? at - 1 : e.key === 'ArrowRight' ? at + 1 : e.key === 'Home' ? 0 : e.key === 'End' ? pts.length - 1 : null;
      if (e.key === 'Escape') { hide(); return; }
      if (to === null) return;
      e.preventDefault();
      show(to < 0 ? 0 : to);
    });
    // the dates under it: spread over the whole, the first and today always, and none crowding the one before
    const dated = [];
    for (const i of spreadIdx(pts.length, ticks)) {
      if (dated.length && pts[i].x - pts[dated[dated.length - 1]].x < minGap) {
        if (i !== pts.length - 1) continue;
        if (dated.length > 1) dated.pop(); // (today keeps its place; the one before it gives way)
      }
      dated.push(i);
    }
    const axis = U.el('bcv-gpa__axis', dated.map((i) => h('span', { class: 'bcv-gpa__tick', style: { left: `${pts[i].x.toFixed(2)}%` } }, [U.text('bcv-gpa__tick-v', gpa2(pts[i].s.gpa), 'span'), U.text('bcv-gpa__tick-l', snapLabel(pts[i].s), 'span')])));
    return [chart, axis];
  }

  /** Points earned and still to come in a course, and what the remaining work
   *  must average to land a target. Counts only work that moves the final
   *  grade (no 0-point or "not counted" items), and follows the course's
   *  group weights when it uses them. */
  function courseMath(groupsRaw, weighted, own = null) {
    const isGraded = (a) => a.submission?.workflow_state === 'graded' && a.submission.score !== null && a.submission.score !== undefined;
    const byOwn = !!(own && Object.keys(own).length); // (2.98.59: the student's own weights, from the syllabus, in place of Canvas's)
    const groups = (groupsRaw || []).map((g) => {
      const items = (g.assignments || []).filter((a) => a.published !== false && !a.omit_from_final_grade && Number(a.points_possible) > 0 && !a.submission?.excused);
      const tot = items.reduce((s, a) => s + Number(a.points_possible), 0);
      const earned = items.filter(isGraded).reduce((s, a) => s + Number(a.submission.score), 0);
      const rem = items.filter((a) => !isGraded(a)).reduce((s, a) => s + Number(a.points_possible), 0);
      return { weight: byOwn ? (Number(own[String(g.id)]) || 0) : (Number(g.group_weight) || 0), tot, earned, rem };
    }).filter((g) => g.tot > 0);
    const share = (g) => (weighted || byOwn ? g.weight : g.tot);
    const W = groups.reduce((s, g) => s + share(g), 0);
    // final = base + slope × (fraction scored on the remaining work)
    const base = W > 0 ? groups.reduce((s, g) => s + share(g) * (g.earned / g.tot), 0) / W : 0;
    const slope = W > 0 ? groups.reduce((s, g) => s + share(g) * (g.rem / g.tot), 0) / W : 0;
    return {
      known: groups.length > 0,
      earned: groups.reduce((s, g) => s + g.earned, 0),
      remaining: groups.reduce((s, g) => s + g.rem, 0),
      needed: (targetPct) => (slope > 0 ? ((targetPct / 100 - base) / slope) * 100 : null), // % of the remaining points
      project: (fraction) => (base + slope * Math.max(0, Math.min(1, fraction))) * 100, // the course's final % when the remaining work scores this fraction
      slope,
    };
  }

  // ---- the screen's own placeholder (E34) ------------------------------------------------------------------------
  /** The header, as the page draws it: Grades, and under it `sub` (a placeholder bar the sub's size while it loads). */
  const headOf = (sub) => U.el('bcv-head', U.el('bcv-head__in', U.el('bcv-head__row', h('div', {}, [h('h1', { class: 'bcv-h1', text: 'Grades' }), sub]))));
  /** The page's shapes while it loads, as it will stand: the GPA card and what stands beside it — the trend with
   *  tracking on, else the two stats and the slim tracking card — Momentum and the stats under them with tracking on,
   *  the course cards' title, then the cards. Read from what this tab already holds: nothing waited for. */
  function skeletonParts(tracking = !!store.prefNow?.('gpaTracking')) {
    const b = (cls) => h('span', { class: `bcv-skel__b ${cls}` });
    const stat = () => U.el('bcv-gpa__skstat', [b('bcv-skel__l2'), b('bcv-skel__l3'), b('bcv-skel__l1')]);
    return U.el('bcv-skel bcv-gpa__skel', [
      U.el('bcv-gpa__top', [
        b('bcv-gpa__skhero'),
        tracking ? b('bcv-gpa__sktrend') : U.el('bcv-gpa__side', [stat(), stat(), b('bcv-gpa__sktrack')]),
      ]),
      tracking ? U.el('bcv-gpa__stats', [stat(), stat(), stat()]) : null,
      b('bcv-gpa__sktitle'),
      U.loading('cards', 6),
    ].filter(Boolean), { 'aria-hidden': 'true', role: 'presentation' });
  }
  /** What the app shows while the page loads (app.js, after 150ms): the real header at once, the page's shapes under it. */
  function skeleton() {
    const sub = h('div', { class: 'bcv-head__sub bcv-skel bcv-gpa__sksub', 'aria-hidden': 'true' }, h('span', { class: 'bcv-skel__b' }));
    return U.el('bcv-screen bcv-screen--gpa bcv-screen--skel bcv-screen--skelhead', [headOf(sub), U.el('bcv-body bcv-body--16', skeletonParts())], { style: { '--w': '1180px' }, 'aria-busy': 'true' });
  }

  async function render(ctx) {
    // a dense screen: fills the column up to the 1180px cap (mockup 7's layout notes)
    const screen = U.el('bcv-screen bcv-screen--gpa', null, { style: { '--w': '1180px' } });
    const sub = U.text('bcv-head__sub', 'Loading…');
    const body = U.el('bcv-body bcv-body--16');
    screen.append(headOf(sub), body);
    body.append(skeletonParts()); // the page's own shapes: the layout does not jump when the data lands

    introIfFirst(ctx.app).catch(() => {}); // the first opening: the tour's steps, waiting for the cards as they draw
    await loadScales(); // (2.99.27) each course's own grading scale, where entered
    const [all, term, trackingPref, goalPref, targetsPref, snapsPref, hiddenPref, whatIfPref, ownPref] = await Promise.all([
      store.courses({ maxAge: store.freshness.grades }).catch(() => null), store.currentTerm().catch(() => ''), // never a score older than the freshness: a tool may have posted one since
      store.pref('gpaTracking'), store.pref('gpaGoal'), store.pref('gradeTargets'), store.pref('gpaSnapshots'), store.pref('gpaHidden'), store.pref('whatIfScores', true), store.pref('gradeWeights'),
    ]);
    // (2.98.59) a course's own weights, set on its Grades tab: its score here is worked out by them, not Canvas's
    const ownW = ownPref && typeof ownPref === 'object' ? ownPref : {};
    const ownFor = (c) => (ownW[c.id] && typeof ownW[c.id] === 'object' && Object.keys(ownW[c.id]).length ? ownW[c.id] : null);
    if (!ctx.alive()) return screen;
    if (!all) {
      body.replaceChildren(U.errorBox('Your courses could not be loaded.'));
      return screen;
    }
    // the same list every screen follows: the favourites chosen in setup (every current course until one is starred)
    const currentCourses = all.filter((c) => c.state === 'current');
    const starredCourses = currentCourses.filter((c) => c.favorite);
    const courses = starredCourses.length ? starredCourses : currentCourses;
    const groupsBy = new Map();
    await Promise.all(courses.map(async (c) => groupsBy.set(c.id, await store.assignmentGroups(c.id).catch(() => null))));
    if (!ctx.alive()) return screen;

    // tracking is on with or without a record from before this term (the setup asks for none:
    // cumulative GPA fills in as snapshots accumulate); a goal never set (or set to 0) is no goal: the card asks for one,
    // in neutral words, rather than measure the term against a 4.00 nobody chose
    let tracking = trackingPref && typeof trackingPref === 'object' && (trackingPref.since || Number.isFinite(trackingPref.priorGpa))
      ? { ...trackingPref, priorGpa: Number.isFinite(trackingPref.priorGpa) ? trackingPref.priorGpa : null, priorCourses: Number.isFinite(trackingPref.priorCourses) ? trackingPref.priorCourses : 0 }
      : null;
    let goal = Number.isFinite(goalPref) ? goalPref : 0;
    const hasGoal = () => goal > 0;
    const hasPrior = () => !!tracking && Number.isFinite(tracking.priorGpa) && tracking.priorCourses > 0;
    const targets = targetsPref && typeof targetsPref === 'object' ? { ...targetsPref } : {};
    let snaps = Array.isArray(snapsPref) ? snapsPref : [];
    const hidden = new Set(Array.isArray(hiddenPref) ? hiddenPref.map(String) : []); // dropped from the overview and the GPA, reversible
    let infoOpen = null;
    let current = null; // the latest model, shared with the sheets
    let entered = false; // entry motion (mockup 11) plays on the first draw only: GPA rolls, the trend line draws, rings sweep
    const gmCache = new Map();
    /** The course's own grade model (rings, groups, weights, assignment rows), once per course. */
    const gmFor = (c) => {
      if (!gmCache.has(c.id)) gmCache.set(c.id, store.gradeModel(groupsBy.get(c.id) || [], c, {}, false, ctx.dark, [], { ownWeights: ownFor(c) }));
      return gmCache.get(c.id);
    };
    /** The course's score under its own weights (null without them, or with nothing graded). */
    const ownPct = (c) => { if (!ownFor(c)) return null; const t = gmFor(c).total; return t === null || t === undefined ? null : Number(t); };
    const whatIfAllowed = whatIfPref !== false; // Settings → Grades → Show what-if scores
    const whatIfBy = new Map(); // courseId → { on, values, added, seq, addGroup }: a Details sheet's what-if, kept while the page lives

    // ---- the model: every number from a Canvas field or from user input ----------------
    function model() {
      const shown = courses.filter((c) => !hidden.has(String(c.id)));
      // a pass/fail course (the setup's switch, saved as P/F in place of a target letter) has no
      // letter to aim at and counts for nothing in the GPA; its score still shows
      const passFail = shown.filter((c) => isPassFail(targets[c.id]));
      const hasScore = (c) => (c.score !== null && c.score !== undefined) || ownPct(c) !== null;
      const scored = shown.filter((c) => hasScore(c) && !isPassFail(targets[c.id]));
      const unscored = shown.filter((c) => !hasScore(c) && !isPassFail(targets[c.id]));
      const rows = scored.map((c) => {
        const op = ownPct(c); // (the student's own weights: their total, and a letter from it, never Canvas's)
        const pct = op !== null ? op : Number(c.score);
        // (2.99.27) the course's own scale, where the student entered it, letters the score (over Canvas's letter)
        const S = scaleOf(c.id);
        const canvasLetter = op === null && !hasScale(c.id) ? c.grade : null;
        const letter = canvasLetter ? String(canvasLetter).replace(/-/g, '−') : letterFor(pct, S)[0];
        const pts = pointsFor(canvasLetter, pct, S);
        const m = courseMath(groupsBy.get(c.id), c.weighted, ownFor(c));
        const found = S.findIndex((s) => live(s) && norm(s[0]) === norm(letter));
        const defaultIdx = found >= 0 ? found : S.indexOf(letterFor(pct, S));
        const saved = targetIndex(targets[c.id]);
        const idx = snapIdx(S, clamp(saved >= 0 ? saved : defaultIdx, 0, S.length - 1)); // (2.99.140: a letter taken off the scale aims at the next one up)
        const target = S[idx];
        const needed = m.known ? m.needed(target[1]) : null;
        const met = needed === null ? pct >= target[1] : needed <= 0;
        const reachable = needed === null ? met : needed <= 100;
        return { c, pct, letter, pts, m, idx, target, needed, met, reachable, S };
      });
      const n = rows.length;
      const termGpa = n ? rows.reduce((s, r) => s + r.pts, 0) / n : null;
      // the range's low end: the remaining work of each course landing LOWER_BY points under its
      // current score (a course with nothing left to grade stays where it is)
      const lowGpa = n ? rows.reduce((s, r) => s + pointsFor(null, r.m.known && r.m.slope > 0 ? r.m.project(Math.max(0, r.pct - LOWER_BY) / 100) : r.pct, r.S), 0) / n : null;
      const cum = hasPrior() && termGpa !== null ? (tracking.priorGpa * tracking.priorCourses + termGpa * n) / (tracking.priorCourses + n) : null;
      // on-time: every submitted, dated assignment across the shown courses; Canvas's own `late` flag decides
      let submitted = 0, onTime = 0;
      for (const c of shown) for (const g of groupsBy.get(c.id) || []) for (const a of g.assignments || []) {
        const s = a.submission;
        if (!s?.submitted_at || !a.due_at) continue;
        submitted++;
        if (!s.late) onTime++;
      }
      const today = dayKey();
      const prev = [...snaps].reverse().find((s) => s.date !== today) || null;
      return { rows, unscored, passFail, n, shownCount: shown.length, hiddenList: courses.filter((c) => hidden.has(String(c.id))), termGpa, lowGpa, cum, submitted, onTime, prev };
    }
    const courseLabel = (m) => `${U.plural(m.shownCount, 'course')} · ${m.n} with grades so far`;
    const needText = (r) => (!r.m.known ? 'Target maths needs the course’s assignment list'
      : r.met ? 'Target already secured'
        : r.needed === null ? 'Not reachable — nothing left to grade'
          : r.reachable ? `Needs ${Math.max(0, Math.round(r.needed))}% of the remaining ${store.fmtPts(r.m.remaining)} pts`
            : `Not reachable — would need ${Math.round(r.needed)}%`);
    const needClass = (r) => (r.met ? 'bcv-gpa__need--met' : !r.reachable ? 'bcv-gpa__need--no' : '');

    /** One snapshot a day while tracking is on; today's is kept current. */
    async function snapshot(m) {
      if (!tracking || m.termGpa === null) return;
      const today = dayKey();
      const cur = snaps.find((s) => s.date === today);
      const scores = Object.fromEntries(m.rows.map((r) => [r.c.id, r.pct]));
      if (cur) {
        if (cur.gpa === m.termGpa) return;
        Object.assign(cur, { gpa: m.termGpa, scores });
      } else snaps.push({ date: today, gpa: m.termGpa, scores });
      snaps = snaps.slice(-400);
      await store.setPref('gpaSnapshots', snaps);
    }

    let goalKept = Number.isFinite(goalPref); // (a goal never set stays unset: nothing is written for it until one is chosen)
    const save = () => { if (hasGoal()) goalKept = true; return Promise.all([store.setPref('gpaTracking', tracking), goalKept ? store.setPref('gpaGoal', goal) : null, store.setPref('gradeTargets', targets)]).catch(() => {}); };
    const saveHidden = () => store.setPref('gpaHidden', [...hidden]);

    // ---- pieces ----------------------------------------------------------------------------
    /** A GPA figure that rolls to its value on entry and is printed as-is on every later draw. */
    const gpaFigure = (cls, value, seed) => {
      const el = U.text(cls, gpa2(value), 'span');
      if (!entered && value !== null && value !== undefined) U.roll(el, value, { decimals: 2, seed });
      return el;
    };
    function hero(m) {
      const goalMet = hasGoal() && m.termGpa !== null && m.termGpa >= goal;
      const gap = !hasGoal() || m.termGpa === null ? null : Math.abs(m.termGpa - goal);
      return U.el('bcv-gpa__hero', [
        U.el('bcv-gpa__hero-head', [
          U.text('bcv-gpa__kicker', `Term GPA${term ? ` · ${term}` : ''}`, 'span'),
          h('button', { type: 'button', class: 'bcv-gpa__gear', title: 'GPA settings', 'aria-label': 'GPA settings', onclick: (e) => openSettings(m, { from: e.currentTarget }) }, U.svg(GEAR, { size: 15, stroke: '#fff', width: 1.9 })),
        ]),
        U.el('bcv-gpa__big', [gpaFigure('bcv-gpa__value', m.termGpa, 0), U.text('bcv-gpa__of', 'of 4.00', 'span')]),
        U.text('bcv-gpa__hero-note', m.shownCount ? `${courseLabel(m)} · computed from your ${BCV.lms.name} scores` : 'No current course to score'),
        U.el('bcv-gpa__hero-foot', [
          tracking
            ? h('div', {}, [
              U.el('bcv-gpa__line', [U.text('bcv-gpa__line-k', 'Cumulative', 'span'), gpaFigure('bcv-gpa__line-v', hasPrior() ? m.cum : m.termGpa, 1.3)]),
              U.text('bcv-gpa__hero-sub', hasPrior() ? `${gpa2(tracking.priorGpa)} across ${U.plural(tracking.priorCourses, 'course')} before this term${tracking.record?.name ? ` · from ${tracking.record.name}` : ''}` : 'This term so far; add your record before this term in settings, or upload a CSV of past courses there'),
            ])
            : null, // (E16: tracking off, the cumulative line waits on it; the one ask to turn it on is the History card beside)
          U.el('bcv-gpa__line', [U.text('bcv-gpa__line-k bcv-gpa__line-k--sm', `If ungraded work lands ${LOWER_BY} pts lower`, 'span'), U.text('bcv-gpa__line-v bcv-gpa__line-v--sm', m.termGpa === null ? '—' : `${gpa2(m.lowGpa)} – ${gpa2(m.termGpa)}`, 'span')]),
          // (E15) no goal set: a neutral ask that opens the settings at the goal, never "below your goal"
          hasGoal() ? U.el('bcv-gpa__goal', [
            U.svg(goalMet ? 'M5 13l4 4L19 7' : 'M12 5v14M6 13l6 6 6-6', { size: 16, stroke: '#fff', width: 2.1, style: { flex: 'none' } }),
            h('div', { style: { flex: '1', minWidth: '0' } }, [
              U.text('bcv-gpa__goal-h', gap === null ? 'No score to compare yet' : goalMet ? `+${gpa2(gap)} above your goal` : `${gpa2(gap)} below your goal`),
              U.text('bcv-gpa__goal-s', `Goal ${gpa2(goal)} · set it in settings`),
            ]),
          ]) : h('button', { type: 'button', class: 'bcv-gpa__goal bcv-gpa__goal--set', onclick: (e) => openSettings(m, { from: e.currentTarget }) }, [
            U.svg(TARGET, { size: 16, stroke: '#fff', width: 2, style: { flex: 'none' } }),
            h('div', { style: { flex: '1', minWidth: '0' } }, [
              U.text('bcv-gpa__goal-h', 'Set a goal'),
              U.text('bcv-gpa__goal-s', 'The term GPA you are aiming for, and how far off it you are'),
            ]),
            U.svg(IC.chevron, { size: 13, stroke: 'rgba(255,255,255,.8)', width: 2.2, style: { flex: 'none' } }),
          ]),
        ]),
      ]);
    }

    function trend() {
      const enough = tracking && snaps.length >= 2;
      let chart = null;
      if (enough) {
        // (2.98.36) a smooth curve through every snapshot; the point under the pointer reads out
        const thisYear = String(new Date().getFullYear());
        const drawn = trendChart(snaps, { goal: hasGoal() ? goal : null, animate: !entered });
        const dated = drawn[1].childElementCount;
        chart = [
          ...drawn,
          h('p', { class: 'bcv-gpa__note bcv-pretty', text: `${U.plural(snaps.length, 'snapshot')} since ${U.fmtShort(`${snaps[0].date}T12:00:00`)}${snaps[0].date.slice(0, 4) === thisYear ? '' : ` ${snaps[0].date.slice(0, 4)}`}${snaps.length > dated ? `, ${dated} dated below` : ''} — point at the line for any day. ${BCV.lms.name} keeps no grade history; past points can be added in settings.` }),
        ];
      } else {
        chart = [U.el('bcv-gpa__empty', [
          U.svg(TREND, { size: 22, stroke: 'var(--bcv-ink3)', width: 1.8 }),
          h('span', { class: 'bcv-pretty', text: 'One snapshot so far. The line appears with the second — on the next day you open this page, or a past point added in settings.' }), // (drawn with tracking on alone: off, trackCard stands in)
        ])];
      }
      return U.el('bcv-gpa__trend', [
        U.el('bcv-gpa__trend-head', [U.text('bcv-gpa__stat-label', 'Trend', 'span'), U.text('bcv-gpa__trend-range', `${gpa2(MIN_Y)} – ${gpa2(MAX_Y)}${hasGoal() ? ' · dashed line is your goal' : ''}`, 'span')]),
        ...chart,
      ]);
    }

    /** The stat cards: Momentum (with tracking on: it compares snapshots), On-time submissions, Grade mix. */
    function statCards(m) {
      const momentum = tracking && m.prev && m.termGpa !== null ? m.termGpa - m.prev.gpa : null;
      const best = [...m.rows].sort((a, b) => b.pct - a.pct)[0];
      const worst = [...m.rows].sort((a, b) => a.pct - b.pct)[0];
      const card = (key, label, icon, color, value, note, extra = null, info = null) => U.el('bcv-gpa__stat', [
        U.el('bcv-gpa__stat-head', [
          U.svg(icon, { size: 14, stroke: color, width: 1.9, style: { flex: 'none' } }),
          U.text('bcv-gpa__stat-label', label, 'span'),
          info ? h('button', { type: 'button', class: 'bcv-gpa__info', title: info, 'aria-label': `About ${label}`, text: 'i', onclick: () => { infoOpen = infoOpen === key ? null : key; draw(); } }) : null,
        ]),
        info && infoOpen === key ? U.el('bcv-gpa__pop', [h('div', { class: 'bcv-pretty', text: info }), h('button', { type: 'button', text: 'Got it', onclick: () => { infoOpen = null; draw(); } })]) : null,
        extra,
        value !== null ? U.text('bcv-gpa__stat-value', value, 'span') : null,
        U.text('bcv-gpa__stat-note bcv-pretty', note, 'span'),
      ]);
      return [
        tracking ? card('momentum', 'Momentum', IC.chart, momentum !== null && momentum < 0 ? '#ff453a' : '#34c759',
          momentum === null ? '—' : `${momentum >= 0 ? '+' : ''}${gpa2(momentum)}`,
          !tracking ? 'Turn on tracking to compare snapshots' : !m.prev ? 'Needs a second snapshot, on another day' : `Change since the ${U.fmtShort(`${m.prev.date}T12:00:00`)} snapshot`,
          null, `Momentum is today’s term GPA minus the GPA in the last daily snapshot this page saved. Positive means your scores moved up since then. It needs at least two snapshots, and it only changes when a score in ${BCV.lms.name} changes.`) : null,
        card('ontime', 'On-time submissions', IC.clock, '#0a84ff', m.submitted ? `${Math.round((m.onTime / m.submitted) * 100)}%` : '—', m.submitted ? `${m.onTime} of ${m.submitted} submitted before the due time` : 'Nothing submitted yet'),
        card('mix', 'Grade mix', IC.check, '#5856d6', null,
          best ? `Highest ${shortCode(best.c)} at ${best.pct}% · lowest ${shortCode(worst.c)} at ${worst.pct}%` : 'No scores yet',
          m.rows.length ? U.el('bcv-gpa__chips', [...m.rows].sort((a, b) => b.pct - a.pct).map((r) => h('span', { class: 'bcv-gpa__chip', title: `${shortCode(r.c)} · ${r.pct}%` }, [
            h('span', { class: 'bcv-gpa__chip-l', style: { background: r.c.palette.tint, color: r.c.palette.text }, text: r.letter }),
            U.text('bcv-gpa__chip-p', `${r.pct}%`, 'span'),
          ]))) : null),
      ].filter(Boolean).map((el, i) => U.enter(el, i, 50));
    }
    const stats = (m) => U.el('bcv-gpa__stats', statCards(m));
    /** (E16) Tracking off: the trend and the momentum, which both need the page's own daily record, folded into one slim
     *  card — the page's one ask to turn tracking on — rather than an empty chart, an empty stat, a banner and a line in
     *  the GPA card all asking the same. */
    function trackCard(m) {
      return U.el('bcv-gpa__track', [
        U.el('bcv-gpa__track-head', [
          U.svg(TREND, { size: 15, stroke: 'var(--bcv-blue)', width: 2, style: { flex: 'none' } }),
          U.text('bcv-gpa__stat-label', 'Trend and momentum', 'span'),
        ]),
        U.text('bcv-gpa__track-text bcv-pretty', `${BCV.lms.name} keeps no GPA history. With tracking on, this page saves a snapshot a day: the trend, the change since the last one, and a cumulative GPA.`, 'p'),
        U.btn('Turn on tracking', { kind: 'primary', cls: 'bcv-btn--fill36 bcv-gpa__track-btn', onClick: (e) => openSettings(m, { wantTracking: true, from: e.currentTarget }) }),
      ]);
    }

    // ---- course cards ------------------------------------------------------------------------
    const ringTrack = () => (ctx.dark ? 'rgba(255,255,255,.1)' : 'rgba(120,120,128,.16)');
    /** One thin ring per graded group (three at most), nested inside the course ring; each
     *  sweeps in as it mounts (on hover, in the Details sheet), 90ms apart. */
    /** `pick`: each group's ring is that group's (U.groupPicker), pressed to pick the group out. */
    function catCircles(cats, pick = false) {
      const out = [];
      const mark = (ct) => (pick ? { 'data-group': ct.id, 'data-pick': ct.id } : {});
      cats.slice(0, CAT_R.length).forEach((ct, k) => {
        out.push(svgEl('circle', { cx: 28, cy: 28, r: CAT_R[k], fill: 'none', stroke: ringTrack(), 'stroke-width': 4.5, ...mark(ct) }));
        if (ct.pct !== null) out.push(svgEl('circle', { cx: 28, cy: 28, r: CAT_R[k], fill: 'none', stroke: ct.color, 'stroke-width': 4.5, 'stroke-linecap': 'round', 'stroke-dasharray': dashFor(ct.pct, CAT_R[k]), class: 'bcv-ring--fill bcv-ring--fill-cat', style: `--bcv-delay: ${k * 90}ms`, ...mark(ct) }));
      });
      return out;
    }
    /** The ring (drawn at 82px on the cards, 62px in the Details sheet): the course total, plus the
     *  group rings nested inside when expanded. `delay` (ms) sweeps the course arc in from empty;
     *  null draws it at its value at once. */
    function ringSvg(c, pct, cats, expanded, delay = null, pick = false) {
      const svg = svgEl('svg', { viewBox: '0 0 56 56', class: 'bcv-gpa__ringsvg' });
      const total = pick ? { 'data-group': 'total' } : {}; // (the course's own ring steps back when a group is picked out)
      svg.append(svgEl('circle', { cx: 28, cy: 28, r: RING_R, fill: 'none', stroke: ringTrack(), 'stroke-width': 6, ...total }));
      if (pct !== null) svg.append(svgEl('circle', { cx: 28, cy: 28, r: RING_R, fill: 'none', stroke: c.color, 'stroke-width': 6, 'stroke-linecap': 'round', 'stroke-dasharray': dashFor(pct, RING_R), ...(delay === null ? {} : { class: 'bcv-ring--fill', style: `--bcv-delay: ${delay}ms` }), ...total }));
      if (expanded) svg.append(...catCircles(cats, pick));
      return svg;
    }
    const catRow = (ct) => U.el('bcv-gpa__cat', [h('span', { class: 'bcv-gpa__catdot', style: { background: ct.color } }), U.text('bcv-gpa__catname bcv-ellip', ct.label, 'span'), U.text('bcv-gpa__catpct', ct.value, 'span')]);

    /** One card per course. Hovering the ring alone (not the card) opens the group
     *  breakdown in place; the ring column is a fixed box so nothing shifts. The
     *  ring is built once and only its group circles come and go, so the node under
     *  the pointer is never removed and mouseleave always fires. */
    function courseCard(r, i = 0) {
      const c = r.c;
      const ungraded = !!r.ungraded;
      const pf = !!r.passFail;
      const pct = ungraded ? null : r.pct;
      const cats = gmFor(c).legend; // groups with graded work, in Canvas's order (weighted first)
      let hover = false;
      const card = U.el('bcv-gpa__card', null, { dataset: { course: c.id } });
      const svg = ringSvg(c, pct, [], false, entered ? null : Math.min(i * 70, 380)); // rings sweep in 70ms apart down the grid
      const catsG = svgEl('g', { class: 'bcv-gpa__cats' });
      svg.append(catsG);
      const letter = h('span', { class: 'bcv-gpa__ringletter', style: { color: ungraded ? 'var(--bcv-ink3)' : c.palette.text }, text: ungraded ? 'N/A' : pf ? 'P/F' : r.letter });
      const ringWrap = h('div', { class: 'bcv-gpa__ringwrap' }, [svg, letter]);
      const ringBox = h('div', { class: 'bcv-gpa__ringbox', title: cats.length ? 'Hover for the group breakdown' : null }, ringWrap);
      const info = h('div', { class: 'bcv-gpa__cinfo' });
      const hideSlot = h('div', { class: 'bcv-gpa__hideslot' }, h('button', { type: 'button', class: 'bcv-gpa__hide', title: 'Hide this course', 'aria-label': `Hide ${c.shortName || c.name} from the GPA`, onclick: () => hideCourse(c) }, U.svg(EYE_OFF, { size: 14, stroke: 'currentColor', width: 1.9 })));
      const targetChip = ungraded
        ? h('span', { class: 'bcv-gpa__cchip bcv-gpa__cchip--na', text: 'No grade yet' })
        : pf ? h('span', { class: 'bcv-gpa__cchip bcv-gpa__cchip--na', text: 'Pass/Fail' })
          : h('span', { class: 'bcv-gpa__cchip', style: { background: c.palette.tint, color: c.palette.text }, text: `Target ${r.target[0]}` });
      ringBox.addEventListener('mouseenter', () => { if (!hover && cats.length) { hover = true; paint(); } });
      ringBox.addEventListener('mouseleave', () => { if (hover) { hover = false; paint(); } });
      card.append(
        U.el('bcv-gpa__ctop', [ringBox, info, hideSlot]),
        h('div', {}, [
          U.el('bcv-gpa__cbar', [
            h('div', { class: 'bcv-gpa__cfill', style: { width: `${ungraded ? 0 : clamp(pct, 0, 100)}%`, background: c.color } }),
            ungraded || pf ? null : h('span', { class: 'bcv-gpa__bartick', title: `Target ${r.target[0]}`, style: { left: `${Math.min(100, r.target[1])}%` } }), // (its own name: the trend's axis ticks are .bcv-gpa__tick)
          ]),
          // (no score from Canvas: the teacher hides the total, or nothing is marked yet — said which)
          U.text(`bcv-gpa__need bcv-pretty ${ungraded || pf ? '' : needClass(r)}`, ungraded ? (c.hideFinal ? 'The teacher hides the total — no score to project from' : 'Nothing graded yet — no score to project from') : pf ? 'Pass/Fail — no letter to aim at' : needText(r)),
          U.text('bcv-gpa__cnote', ungraded ? (c.hideFinal ? `${BCV.lms.name} sends no score while the total is hidden, so it counts for nothing here` : `${BCV.lms.name} has not computed a score, so it counts for nothing here`) : pf ? 'Counts for nothing in the GPA' : ownFor(c) ? `By your own weights${r.m.known ? ` · ${store.fmtPts(r.m.earned)} pts earned so far` : ''}` : r.m.known ? `${store.fmtPts(r.m.earned)} pts earned so far` : `Score as ${BCV.lms.name} reports it`),
        ]),
        U.el('bcv-gpa__cfoot', [
          targetChip,
          h('button', { type: 'button', class: 'bcv-gpa__details', onclick: (e) => openDetail(c, e.currentTarget) }, ['Details', U.svg(IC.chevron, { size: 13, stroke: 'var(--bcv-blue)', width: 2.1 })]),
        ]),
      );
      let leaving = null; // the timer that clears the group rings once they have swept back out
      function paint() {
        card.classList.toggle('is-hover', hover);
        clearTimeout(leaving);
        leaving = null;
        if (hover) {
          // the ring keeps its size: the group rings nest inside it and sweep in (a sweep-out
          // still under way is simply replaced by a fresh sweep-in)
          letter.hidden = true;
          letter.classList.remove('is-back');
          catsG.replaceChildren(...catCircles(cats));
        } else if (catsG.childElementCount) {
          // the pointer left: the rings sweep back out from wherever they have got to, last in
          // first out, their tracks fading with them; the letter returns once they have gone
          const fills = [...catsG.querySelectorAll('.bcv-ring--fill-cat')];
          const n = fills.length;
          fills.forEach((el, k) => {
            el.style.strokeDasharray = getComputedStyle(el).strokeDasharray;
            el.style.setProperty('--bcv-delay', `${(n - 1 - k) * 60}ms`);
            el.classList.add('bcv-ring--unfill');
          });
          for (const t of catsG.querySelectorAll('circle:not(.bcv-ring--fill-cat)')) t.classList.add('bcv-ring--track-out');
          const total = U.reducedMotion() ? 0 : (n ? (n - 1) * 60 : 0) + 270; // (each sweep back is .25s)
          leaving = setTimeout(() => {
            leaving = null;
            catsG.replaceChildren();
            letter.hidden = false;
            letter.classList.add('is-back');
          }, total);
        } else {
          letter.hidden = false;
        }
        info.replaceChildren(hover
          ? U.el('bcv-gpa__bygroup', [
            U.el('bcv-gpa__bygroup-head', [U.text('bcv-gpa__kicker2', 'By group', 'span'), U.text('bcv-gpa__bygroup-pct', `${store.fmtPts(pct)}%`, 'span')]),
            ...cats.slice(0, 4).map(catRow),
          ])
          : U.el('bcv-gpa__cbody', [
            U.text('bcv-gpa__ccode bcv-ellip', c.shortName || c.name),
            U.text('bcv-gpa__cname bcv-ellip', c.nickname ? c.originalName : (c.code || c.name)),
            U.el('bcv-gpa__cscore', [U.text('bcv-gpa__cpct', ungraded ? 'N/A' : `${store.fmtPts(pct)}%`, 'span'), U.text('bcv-gpa__cpts', ungraded || pf ? 'no GPA' : `${r.pts.toFixed(1)} GPA`, 'span')]), // (grade points, not assignment points: said so)
          ]));
        hideSlot.hidden = hover;
        targetChip.hidden = hover && !ungraded;
      }
      paint();
      return card;
    }
    function courseGrid(m) {
      const cards = [...m.rows, ...m.passFail.map((c) => (c.score === null || c.score === undefined ? { c, ungraded: true, passFail: true } : { c, passFail: true, pct: Number(c.score) })), ...m.unscored.map((c) => ({ c, ungraded: true }))];
      return h('div', {}, [
        U.el('bcv-group__head', [U.h2('All courses'), U.text('bcv-group__sub bcv-ml-auto', 'Hover a ring for the group breakdown', 'span')]),
        cards.length ? U.el('bcv-gpa__grid', cards.map((r, i) => U.enter(courseCard(r, i), i, 55))) : U.emptyCard(m.hiddenList.length ? 'Every course is hidden.' : 'No current courses.'),
      ]);
    }
    /** Item grades: every graded assignment across the courses shown, by letter — the slider lists one
     *  letter's work alone, course by course in the cards' order, each course's by due date. */
    const itemSt = { band: 'all', more: false };
    const ITEMS_AT_ONCE = 12;
    function itemGrades() {
      const { items, counts } = gradedItems(courses.filter((c) => !hidden.has(String(c.id))), gmFor);
      if (!items.length) return null;
      const host = h('div');
      const paint = () => {
        const pick = itemSt.band === 'all' ? items : items.filter((it) => it.band === itemSt.band);
        const n = itemSt.more ? pick.length : Math.min(pick.length, ITEMS_AT_ONCE);
        const rows = pick.slice(0, n).map(({ c, g, band, pct }) => U.row([
          h('span', { class: 'bcv-dot bcv-dot--7', style: { background: c.color }, title: c.shortName || c.name }),
          U.el('bcv-row__body', [
            U.text('bcv-grade__name bcv-pretty', g.name),
            U.text('bcv-row__sub', [c.shortName || c.name, g.group, `${store.fmtPts(Math.round(pct * 10) / 10)}%`].join(' · ')),
          ]),
          U.bandChip(band, `${store.fmtPts(Math.round(pct * 10) / 10)}% · ${band}`),
          h('span', { class: 'bcv-grade__score', text: `${g.grade ? `${g.grade} · ` : ''}${store.fmtPts(g.earned)} / ${store.fmtPts(g.possible)}` }),
          g.url ? U.chev() : null,
        ], { href: g.url || null, cls: 'bcv-gpa__item' }));
        const more = pick.length > n ? h('button', { type: 'button', class: 'bcv-gpa__itemsmore', text: `Show all ${pick.length}`, onclick: () => { itemSt.more = true; paint(); } }) : null;
        host.replaceChildren(pick.length ? U.card([...rows, more].filter(Boolean), 'bcv-card--list') : U.emptyCard(`No ${itemSt.band} grades in your courses.`));
      };
      paint();
      return h('div', { class: 'bcv-gpa__items' }, [
        U.el('bcv-group__head', [U.h2('Item grades'), U.text('bcv-group__sub bcv-ml-auto', 'Every graded assignment, by letter', 'span')]),
        U.el('bcv-gr__bandrow', [U.bandSlider(counts, itemSt.band, (b) => { itemSt.band = b; itemSt.more = false; paint(); })]),
        host,
      ]);
    }
    function hiddenTray(m) {
      if (!m.hiddenList.length) return null;
      return U.el('bcv-gpa__tray', [
        U.text('bcv-gpa__kicker2', 'Hidden · not counted in GPA', 'span'),
        ...m.hiddenList.map((c) => h('button', { type: 'button', class: 'bcv-gpa__traychip', title: `Show ${c.shortName || c.name} again`, onclick: () => showCourse(c) }, [
          h('span', { class: 'bcv-gpa__traydot', style: { background: c.color } }),
          h('span', { text: c.shortName || c.name }),
          h('span', { class: 'bcv-gpa__trayshow', text: 'Show' }),
        ])),
      ]);
    }
    async function hideCourse(c) {
      hidden.add(String(c.id));
      await saveHidden();
      await refresh();
      U.toast(`${c.shortName || c.name} is hidden and not counted in the GPA. Show it again from the tray below.`);
    }
    async function showCourse(c) {
      hidden.delete(String(c.id));
      await saveHidden();
      await refresh();
    }

    // ---- details sheet: the course's own grade page, without leaving the overview ----------
    function openDetail(c, from = null) {
      document.querySelector('.bcv-sheet-ov')?.remove();
      const ov = U.el('bcv-sheet-ov', null, { role: 'dialog', 'aria-label': `${c.shortName || c.name} grade details` });
      const close = () => BCV.ui.dismiss(ov);
      ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
      ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
      const sheet = U.el('bcv-sheet bcv-gpa-detail');
      ov.append(sheet);
      // what-if scores, the course page's own (grades.js): the real scores loaded into fields, any of
      // them changed — or an assignment made up and put in a group — to test an outcome; nothing saved,
      // nothing sent. Kept per course while the page lives.
      const wf = whatIfBy.get(c.id) || { on: false, values: {}, added: [], seq: 0, addGroup: null };
      whatIfBy.set(c.id, wf);
      const wfCats = (groupsBy.get(c.id) || []).map((g) => ({ id: String(g.id), name: g.name, weight: Number(g.group_weight) || 0 })); // (the groups a made-up assignment can go into)
      if (!whatIfAllowed) wf.on = false;
      let focusId = null; // the field to put the caret back in after a repaint (a double-click on a score starts there)
      // a group picked out (U.groupPicker): pressing a group, its weight or its ring keeps it and its
      // assignments in view and steps the rest back; kept across repaints, Escape lets it go first
      const pickSt = { pick: null };
      const bandSt = { band: 'all' }; // the By letter slider's stop, kept across repaints
      let gmNow = null;
      const colorOf = (id) => gmNow?.legend.find((r) => r.id === id)?.color || gmNow?.weightBar.find((w) => w.id === id)?.color || null;
      const picker = U.groupPicker(sheet, pickSt, {
        onChange: (pick) => {
          const note = sheet.querySelector('.bcv-gpa-detail__picknote');
          if (!note) return;
          // in what-if mode the group pressed is the one a made-up assignment goes into
          const addSel = sheet.querySelector('.bcv-wfadd__group');
          if (pick && addSel && addSel.value !== pick && [...addSel.options].some((o) => o.value === pick)) { addSel.value = pick; addSel.dispatchEvent(new Event('change')); }
          const name = pick && gmNow ? (gmNow.legend.find((r) => r.id === pick)?.label ?? gmNow.ungraded.find((u) => u.id === pick)?.name) : null;
          if (!name) { note.replaceChildren(wf.on ? 'Change any score to test it' : 'Blue dot means graded'); return; }
          const n = gmNow.rows.filter((r) => r.groupId === pick).length;
          note.replaceChildren(h('button', { type: 'button', class: 'bcv-gr__pickchip', 'data-pick': '', style: { '--bcv-grp': colorOf(pick) || 'var(--bcv-ink3)' }, 'aria-label': `Showing ${name}; show every assignment` }, [
            h('span', { class: 'bcv-gr__pickdot' }),
            U.text('bcv-gr__pickname', `${name} · ${U.plural(n, 'assignment')}`, 'span'),
            U.text('bcv-gr__pickall', 'Show all', 'span'),
          ]));
        },
      });
      function bump(r, delta) {
        targets[c.id] = SCALE[stepIdx(r.S, r.idx, delta)][0].replace(/−/g, '-'); // saved as the letter (2.99.140: the next one kept)
        save();
        current = model();
        draw();
        paint();
        ov.focus(); // the stepper that had focus was just redrawn; keep Escape working
      }
      // a score typed, then a press elsewhere in the sheet (its X, a letter, another field): the field's
      // change comes with the press, and a repaint then would swap the thing pressed out from under the
      // pointer — its click lost. The repaint waits for the press to end (after its click).
      let pressing = false;
      let owed = false;
      const release = () => {
        if (!pressing) return;
        pressing = false;
        if (owed) setTimeout(() => { if (!owed) return; owed = false; if (ov.isConnected) paint(); }, 0);
      };
      ov.addEventListener('pointerdown', () => {
        pressing = true;
        document.addEventListener('pointerup', release, { capture: true, once: true });
        document.addEventListener('pointercancel', release, { capture: true, once: true });
      }, true);
      const repaint = () => { if (pressing) owed = true; else paint(); };
      function paint() {
        owed = false;
        const m = current || model();
        const r = m.rows.find((x) => x.c.id === c.id) || null; // null: no Canvas score yet, or a pass/fail course
        const pf = isPassFail(targets[c.id]);
        const pfPct = pf && c.score !== null && c.score !== undefined ? Number(c.score) : null;
        // with a what-if on, the sheet is drawn from the hypothetical model: greyed rings, the what-if total up top
        const gm = wf.on ? store.gradeModel(groupsBy.get(c.id) || [], c, wf.values, true, ctx.dark, wf.added, { ownWeights: ownFor(c) }) : gmFor(c);
        gmNow = gm;
        const cats = gm.legend;
        const hyp = wf.on && gm.total !== null && gm.total !== undefined ? gm.total : null;
        const shownPct = hyp !== null ? hyp : r ? r.pct : pfPct;
        // the way through to the course's own Grades page: a proper button, up by the X
        const go = U.btn('Open the course’s Grades page', { kind: 'primary', icon: IC.external, iconColor: '#fff', cls: 'bcv-gpa-detail__go', onClick: () => { close(); ctx.app.go(`${c.url}/grades`); } });
        const head = U.el('bcv-sheet__head bcv-gpa-detail__head', [
          h('div', { class: 'bcv-gpa-detail__ring' }, ringSvg(c, shownPct, cats, true, null, true)),
          U.el('bcv-sheet__titles', [
            U.text('bcv-gpa-detail__title bcv-ellip', c.shortName || c.name),
            U.text('bcv-gpa-detail__name', c.nickname ? c.originalName : (c.code || c.name)),
            U.el('bcv-gpa-detail__line', [
              U.text(`bcv-gpa-detail__pct ${hyp !== null ? 'is-hyp' : ''}`, shownPct !== null && shownPct !== undefined ? `${store.fmtPts(shownPct)}%` : 'N/A', 'span'),
              hyp !== null
                ? h('span', { class: 'bcv-gpa-detail__letter is-hyp', text: `${letterFor(hyp, scaleOf(c.id))[0]} · what-if` })
                : h('span', { class: 'bcv-gpa-detail__letter', style: r || pfPct !== null ? { background: c.palette.tint, color: c.palette.text } : null, text: r ? r.letter : pf ? 'Pass/Fail' : 'No grade yet' }),
              r ? U.el('bcv-gpa-detail__target', [
                U.text('bcv-gpa-detail__tlabel', 'Target', 'span'),
                h('button', { type: 'button', class: 'bcv-gpa-detail__step', text: '−', 'aria-label': 'Lower the target', disabled: stepIdx(r.S, r.idx, 1) === r.idx || null, onclick: () => bump(r, 1) }),
                h('span', { class: 'bcv-gpa-detail__tval', style: { background: c.palette.tint, color: c.palette.text }, text: `${r.target[0]} · ${r.target[1]}%` }),
                h('button', { type: 'button', class: 'bcv-gpa-detail__step', text: '+', 'aria-label': 'Raise the target', disabled: stepIdx(r.S, r.idx, -1) === r.idx || null, onclick: () => bump(r, -1) }),
              ]) : null,
            ]),
          ]),
          go,
          h('button', { type: 'button', class: 'bcv-sheet__close', 'aria-label': 'Close', onclick: close }, U.svg(IC.close, { size: 13, stroke: 'var(--bcv-ink2)', width: 2.3 })),
        ]);
        const groupRows = cats.map((ct) => U.el('bcv-gpa-detail__grow', [
          h('span', { class: 'bcv-gpa__catdot bcv-gpa__catdot--9', style: { background: ct.color } }),
          U.text('bcv-gpa-detail__gname bcv-pretty', ct.label, 'span'),
          h('span', { class: 'bcv-gpa-detail__gbar' }, h('span', { style: { width: `${clamp(ct.pct ?? 0, 0, 100)}%`, background: ct.color } })),
          U.text('bcv-gpa-detail__gweight', ct.weightText, 'span'),
          U.text('bcv-gpa-detail__gpct', ct.value, 'span'),
        ], U.groupAttrs(ct.id, ct.color, { pick: true, name: ct.label })));
        const ungradedRows = gm.ungraded.map((u) => U.el('bcv-gpa-detail__grow bcv-gpa-detail__grow--ungraded', [
          h('span', { class: 'bcv-gpa__catdot bcv-gpa__catdot--9 bcv-gpa__catdot--empty' }),
          U.text('bcv-gpa-detail__gname bcv-pretty', u.name, 'span'),
          h('span', { class: 'bcv-gpa-detail__gbar' }),
          U.text('bcv-gpa-detail__gweight', u.weightText ? `${u.weightText} of grade · nothing graded` : 'nothing graded', 'span'),
          U.text('bcv-gpa-detail__gpct', '—', 'span'),
        ], U.groupAttrs(u.id, null, { pick: true, name: u.name })));
        const byGroup = U.el('bcv-gpa-detail__sec', [
          U.text('bcv-gpa__kicker2', 'By group', 'span'),
          ...groupRows, ...ungradedRows,
          groupRows.length || ungradedRows.length ? null : U.text('bcv-gpa-detail__note', 'No assignment groups in this course.'),
          U.text(`bcv-gpa-detail__need bcv-pretty ${r ? needClass(r) : ''}`, r ? needText(r) : 'Nothing graded yet — no score to project from'),
        ]);
        const weights = gm.weighted
          ? U.el('bcv-gpa-detail__sec bcv-gpa-detail__sec--line', [
            U.el('bcv-gpa-detail__hrow', [U.text('bcv-gpa__kicker2', 'How the grade is weighted', 'span'), U.text('bcv-gpa-detail__hsub', `${gm.weightSum}% of final grade`, 'span')]),
            gm.weightBar.length ? U.el('bcv-wbar', gm.weightBar.map((w) => { const ga = U.groupAttrs(w.id, w.color, { pick: true, name: w.name }); return h('div', { ...ga, class: `bcv-wbar__seg ${w.graded ? '' : 'bcv-wbar__seg--ungraded'}`, style: { ...ga.style, flex: `${w.weight} 1 0`, background: w.color || '' }, title: `${w.name} · ${w.weight}%` }); })) : U.text('bcv-gpa-detail__note', 'No assignment group carries weight yet.'),
            U.el('bcv-gpa-detail__legend', gm.weightBar.map((w) => U.el('bcv-gpa-detail__lg', [h('span', { class: `bcv-wbar__dot ${w.graded ? '' : 'bcv-wbar__dot--ungraded'}`, style: { background: w.color || '' } }), U.text('bcv-gpa-detail__lgtext', `${w.name} ${w.weight}% · ${w.graded ? 'graded' : 'nothing graded'}`, 'span')], U.groupAttrs(w.id, w.color, { pick: true, name: w.name })))),
            gm.weightNote ? U.text('bcv-gpa-detail__note bcv-pretty', gm.weightNote) : null,
          ])
          : U.el('bcv-gpa-detail__sec bcv-gpa-detail__sec--line', [
            U.text('bcv-gpa__kicker2', 'How the grade is weighted', 'span'),
            U.text('bcv-gpa-detail__note bcv-pretty', 'This course does not weight its groups — the total is points earned over points possible.'),
          ]);
        const whatIfBtn = whatIfAllowed ? h('button', { type: 'button', class: `bcv-whatif-btn ${wf.on ? 'is-on' : ''}`, text: wf.on ? 'Exit what-if mode' : 'Try what-if scores', onclick: () => { wf.on = !wf.on; focusId = null; paint(); } }) : null;
        const banner = wf.on ? U.el('bcv-banner bcv-banner--sm', [
          U.svg(IC.warn, { size: 20, stroke: 'var(--bcv-red)', width: 2, style: { flex: 'none' } }),
          h('div', { style: { flex: '1', minWidth: '160px' } }, [U.text('bcv-banner__title', 'This is not your actual score.'), U.text('bcv-banner__sub', 'Your real scores are loaded in; change any of them, or add an assignment to a category, to test an outcome. Nothing is saved or sent.')]),
          U.btn('Clear all', { kind: 'danger', onClick: () => { wf.values = {}; wf.added = []; focusId = null; paint(); } }),
        ]) : null;
        // a row's score: the number, or — with the what-if on — a field with the number in it
        const scoreOf = (g) => {
          if (!wf.on) {
            const el = U.text('bcv-gpa-detail__ascore', `${g.earned === null ? '—' : store.fmtPts(g.earned)} / ${store.fmtPts(g.possible)}`, 'span');
            if (whatIfAllowed) {
              el.title = 'Double-click to test a what-if score';
              el.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); }); // the first half of the double-click must not open the row
              el.addEventListener('dblclick', () => { wf.on = true; focusId = g.id; paint(); });
            }
            return el;
          }
          const input = h('input', { type: 'text', inputmode: 'decimal', placeholder: '—', class: `bcv-whatif__input ${g.hypothetical ? 'is-hyp' : ''}`, dataset: { wf: g.id }, 'aria-label': `What-if score for ${g.name}`, value: wf.values[g.id] === undefined ? (g.earned === null ? '' : String(g.earned)) : wf.values[g.id] });
          input.addEventListener('focus', () => input.select());
          input.addEventListener('change', () => { wf.values[g.id] = input.value.replace(/[^0-9.]/g, ''); focusId = null; repaint(); });
          input.addEventListener('keydown', (e) => { if (e.key === 'Enter') input.blur(); });
          const wrap = U.el('bcv-whatif', [input, U.text('bcv-whatif__possible', `/ ${store.fmtPts(g.possible)}`, 'span')]);
          wrap.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); }); // typing a what-if is not opening the row
          return wrap;
        };
        // every row opens the assignment it is a line about, the same as on the course's own Grades
        // page: a grade is the start of a question, and the answer is on that page. Each graded one
        // wears its letter (U.gradeBand), and the By letter slider lists one letter's work alone.
        const arows = gm.rows.map((g) => {
          const band = U.gradeBand(g.effective, g.possible, g.gradingType);
          return h(g.url ? 'a' : 'div', {
            class: `bcv-gpa-detail__arow ${g.url ? 'is-link' : ''}`,
            href: g.url || null,
            'data-group': g.groupId, // (the group it counts toward: picked out with it)
            'data-band': band || '',
            style: { ...(g.url ? { color: 'inherit' } : {}), '--bcv-grp': colorOf(g.groupId) || 'var(--bcv-ink3)' },
            onclick: g.url ? () => close() : null, // the sheet belongs to the page being left
          }, [
            h('span', { class: 'bcv-gpa__catdot', style: { background: g.earned !== null ? '#0a84ff' : 'transparent' } }),
            U.el('bcv-gpa-detail__abody', [
              h('div', { class: 'bcv-gpa-detail__aname bcv-pretty' }, [g.name, g.added ? U.badge('What-if', 'red', 'bcv-badge--xs') : null]),
              U.text('bcv-gpa-detail__agroup', g.added ? `${g.group} · made up to test` : `${g.group}${g.badge ? ` · ${g.badge}` : ''}`),
            ]),
            U.bandChip(band, band ? `${store.fmtPts(Math.round((g.effective / g.possible) * 1000) / 10)}% · ${band}` : null),
            scoreOf(g),
            g.added ? U.whatIfRemove(g.name, () => { wf.added = wf.added.filter((x) => x.id !== g.id); delete wf.values[g.id]; paint(); }) : null,
            g.url ? U.chev() : null,
          ]);
        });
        const counts = {};
        for (const r of arows) if (r.dataset.band) counts[r.dataset.band] = (counts[r.dataset.band] || 0) + 1;
        const listEl = U.el('bcv-gpa-detail__list');
        const fillList = () => {
          const band = bandSt.band;
          const shown = band === 'all' ? arows : arows.filter((r) => r.dataset.band === band);
          listEl.replaceChildren(...(shown.length ? shown : [U.text('bcv-gpa-detail__note', `No ${band} grades in this course${wf.on ? ' with these what-if scores' : ''}.`)]));
        };
        fillList();
        // what-if: an assignment made up and put in a group of the student's choosing, counted there like the rest
        const adder = wf.on && wfCats.length ? U.whatIfAdder(wfCats, {
          group: wf.addGroup ?? pickSt.pick, weighted: gm.weighted, n: wf.seq + 1,
          onGroup: (id) => { wf.addGroup = id; },
          onAdd: ({ groupId, name, score, possible }) => {
            wf.seq += 1;
            const id = `wf-${wf.seq}`;
            wf.added.push({ id, groupId, name, possible });
            wf.values[id] = String(score);
            wf.addGroup = groupId;
            bandSt.band = 'all'; // (the new row in view, whatever letter it lands on)
            paint();
            sheet.querySelector('.bcv-wfadd__name')?.focus(); // (ready for the next)
          },
        }) : null;
        const list = U.el('bcv-gpa-detail__sec bcv-gpa-detail__sec--line', [
          U.el('bcv-gpa-detail__hrow', [U.text('bcv-gpa__kicker2', 'Assignments', 'span'), U.text('bcv-gpa-detail__hsub bcv-gpa-detail__picknote', wf.on ? 'Change any score to test it' : 'Blue dot means graded', 'span'), whatIfBtn]),
          Object.keys(counts).length ? U.el('bcv-gr__bandrow', [
            U.text('bcv-gr__bandlbl', 'By letter', 'span'),
            U.bandSlider(counts, bandSt.band, (b) => { bandSt.band = b; fillList(); picker.apply(); }),
          ]) : null,
          banner,
          adder,
          gm.rows.length ? listEl : U.text('bcv-gpa-detail__note', 'No assignments in this course.'),
        ]);
        // one steady size, the scrolling inside it: the breakdown and the weights on the left with the
        // way to the course's page under them, the assignments on the right (one column when narrow).
        // A repaint (a what-if typed, a target stepped) keeps each side where it was scrolled to.
        const scrolled = ['.bcv-gpa-detail__cols', '.bcv-gpa-detail__col--left', '.bcv-gpa-detail__col--right'].map((sel) => [sel, sheet.querySelector(sel)?.scrollTop || 0]);
        sheet.replaceChildren(head, U.el('bcv-sheet__list bcv-gpa-detail__body', U.el('bcv-gpa-detail__cols', [
          U.el('bcv-gpa-detail__col bcv-gpa-detail__col--left', [byGroup, weights, scaleSection(c, () => { current = model(); draw(); paint(); })]),
          U.el('bcv-gpa-detail__col bcv-gpa-detail__col--right', [list]),
        ])));
        for (const [sel, top] of scrolled) if (top) { const el = sheet.querySelector(sel); if (el) el.scrollTop = top; }
        picker.apply();
        if (focusId !== null) {
          sheet.querySelector(`.bcv-whatif__input[data-wf="${focusId}"]`)?.focus();
          focusId = null;
        }
        if (ov.isConnected && !ov.contains(document.activeElement)) ov.focus(); // whatever had focus was just redrawn; keep Escape working
      }
      paint();
      document.body.append(ov);
      U.morphFrom(sheet, from); // the sheet grows out of the Details button
      ov.tabIndex = -1;
      ov.focus();
    }

    // ---- settings sheet ----------------------------------------------------------------------
    /** Do the numbers in the fields still say what the file's rows said? (then the rows stay with them) */
    const rowsMatch = (rec, g, n) => { const sum = BCV.recordCsv?.summarize?.(rec.courses || []); return !!sum && Math.abs(sum.gpa - g) < 0.0005 && sum.courses === n; };
    function openSettings(m, { wantTracking = false, from = null } = {}) {
      document.querySelector('.bcv-sheet-ov')?.remove();
      const ov = U.el('bcv-sheet-ov', null, { role: 'dialog', 'aria-label': 'GPA settings' });
      let pendingGoal = hasGoal() ? goal : DEFAULT_GOAL;
      let goalTouched = hasGoal(); // (no goal yet: the stepper's 4.00 is a starting point, kept only once it is stepped)
      let on = !!tracking || wantTracking;
      const priorGpa = h('input', { class: 'bcv-input bcv-gpa-set__input', id: 'bcv-gpa-prior', type: 'number', min: '0', max: '4', step: '0.01', placeholder: '3.42', value: hasPrior() ? String(tracking.priorGpa) : '' });
      const priorN = h('input', { class: 'bcv-input bcv-gpa-set__input', id: 'bcv-gpa-prior-n', type: 'number', min: '1', max: '200', step: '1', placeholder: '8', value: hasPrior() ? String(tracking.priorCourses) : '' });
      const goalVal = U.text('bcv-gpa-set__val', gpa2(pendingGoal), 'span');
      const goalGap = U.text('bcv-gpa-set__s bcv-pretty', '');
      const syncGoal = () => {
        goalVal.textContent = gpa2(pendingGoal);
        goalGap.textContent = !goalTouched ? 'No goal yet: step to the term GPA you are aiming for' : m.termGpa === null ? 'Set the term GPA you are aiming for' : m.termGpa >= pendingGoal ? `You are ${gpa2(m.termGpa - pendingGoal)} above this goal` : `You are ${gpa2(pendingGoal - m.termGpa)} below this goal`;
      };
      syncGoal();
      // Upload CSV: a CSV of past courses (lib/record-csv.js says what it reads) fills the two fields in
      // and, kept through Done, travels with them as the record's rows; a file that cannot be read says so
      let pendingRecord = tracking?.record || null; // the rows behind the numbers in the fields, if a file gave them
      const fromNote = U.text('bcv-gpa-set__s bcv-pretty bcv-gpa-set__from', '');
      const sayFrom = () => { fromNote.textContent = pendingRecord?.name
        ? `From ${pendingRecord.name}: ${U.plural(pendingRecord.courses?.length || 0, 'course')}${Number.isFinite(pendingRecord.credits) ? `, ${pendingRecord.credits} credits (the GPA credit-weighted)` : ''}${pendingRecord.skipped ? `, ${U.plural(pendingRecord.skipped, 'row')} skipped (no letter grade)` : ''}. Numbers typed over these replace it.`
        : 'Or upload a CSV of your past courses — a header row, then course, grade, and credits and term if you have them — and these fill in from it. Letters, percentages and 4.0 points all read; P/NP and W are skipped.'; };
      sayFrom();
      const csvInput = h('input', { type: 'file', accept: '.csv,text/csv,text/plain', hidden: true, class: 'bcv-gpa-set__csvfile' });
      csvInput.addEventListener('change', async () => {
        const file = csvInput.files?.[0];
        if (!file) return;
        let rec;
        try {
          const text = await BCV.recordCsv.readText(file); // (read first: Safari lets go of the file once the input is cleared)
          if (/^\s*(\ufeff)?date\s*,\s*term_gpa/i.test(text)) { // a history export dropped here is a history: past points for the chart
            const added = await putHistory(BCV.recordCsv.history(text));
            U.toast(added ? `${U.plural(added, 'point')} added to the chart (that file is a history, not a record of courses).` : 'That file is a history, and every day in it is on the chart already.');
            return;
          }
          rec = BCV.recordCsv.record(text, file.name);
        } catch (err) {
          U.toast(BCV.recordCsv.explain(err), { error: true });
          return;
        } finally {
          csvInput.value = '';
        }
        priorGpa.value = String(rec.priorGpa);
        priorN.value = String(rec.priorCourses);
        pendingRecord = rec.record;
        sayFrom();
        U.toast(`${gpa2(rec.priorGpa)} across ${U.plural(rec.priorCourses, 'course')} read from ${file.name}. Press Done to keep it.`);
      });
      // ---- History: past points for the trend, by hand or from a CSV ----
      // Tracking keeps one snapshot a day from the day it is turned on; what came before it — last
      // term's GPA, a figure from a transcript — can be put on the chart here: a day (or a term) and a
      // GPA, or a CSV of them (lib/record-csv.js history). A day already recorded is replaced by the
      // one typed, kept as it is on an import.
      const pointDate = h('input', { class: 'bcv-input bcv-gpa-set__input bcv-gpa-set__date', id: 'bcv-gpa-point-date', type: 'date', max: dayKey() });
      const pointGpa = h('input', { class: 'bcv-input bcv-gpa-set__input', id: 'bcv-gpa-point-gpa', type: 'number', min: '0', max: '4', step: '0.01', placeholder: '3.60' });
      const histNote = U.text('bcv-gpa-set__s bcv-pretty bcv-gpa-set__hist', '');
      const sayHist = () => { histNote.textContent = snaps.length ? `${U.plural(snaps.length, 'point')} on the chart, since ${U.fmtShort(`${snaps[0].date}T12:00:00`)}${snaps[0].date.slice(0, 4) === String(new Date().getFullYear()) ? '' : ` ${snaps[0].date.slice(0, 4)}`}.` : 'No points yet.'; };
      sayHist();
      let histTouched = false; // a point added or imported: the chart is drawn again when the sheet goes, Done or not
      const putHistory = async (rows, { replace = false } = {}) => {
        const r = BCV.recordCsv.mergeHistory(snaps, rows, { replace });
        snaps = r.snaps.slice(-400);
        await store.setPref('gpaSnapshots', snaps);
        histTouched = true;
        sayHist();
        return r.added;
      };
      const addPoint = async () => {
        const date = BCV.recordCsv.dayOf(pointDate.value);
        const g = BCV.recordCsv.gpaOf(pointGpa.value);
        if (!date || g === null) { U.toast('Give the point a day and a GPA from 0 to 4.', { error: true }); (date ? pointGpa : pointDate).focus(); return; }
        if (date > dayKey()) { U.toast('A past point: pick a day that has been.', { error: true }); pointDate.focus(); return; }
        await putHistory([{ date, gpa: g }], { replace: true });
        pointGpa.value = '';
        U.toast(`${gpa2(g)} on ${U.fmtShort(`${date}T12:00:00`)} is on the chart.`);
      };
      pointGpa.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addPoint(); } });
      const histInput = h('input', { type: 'file', accept: '.csv,text/csv,text/plain', hidden: true, class: 'bcv-gpa-set__histfile' });
      histInput.addEventListener('change', async () => {
        const file = histInput.files?.[0];
        if (!file) return;
        let rows;
        try { rows = BCV.recordCsv.history(await BCV.recordCsv.readText(file)); } catch (err) { U.toast(String(err?.message) === 'not history' ? 'That file needs a date and a GPA a line (a term such as Fall 2025 counts as a date).' : BCV.recordCsv.explain(err), { error: true }); return; } finally { histInput.value = ''; }
        const added = await putHistory(rows);
        U.toast(added ? `${U.plural(added, 'point')} added to the chart.` : 'Nothing new: every day in that file is on the chart already.');
      });
      const histBody = U.el('bcv-gpa-set__fields', [
        h('label', { class: 'bcv-gpa-set__field bcv-gpa-set__field--date' }, [h('span', { text: 'A day (or a term)' }), pointDate]),
        h('label', { class: 'bcv-gpa-set__field' }, [h('span', { text: 'GPA then' }), pointGpa]),
        U.el('bcv-gpa-set__csv', [
          U.el('bcv-gpa-set__csvbtns', [
            U.btn('Add point', { kind: 'sm', cls: 'bcv-gpa-set__addpt', onClick: addPoint }),
            U.btn('Import CSV', { kind: 'sm', cls: 'bcv-gpa-set__histbtn', onClick: () => histInput.click() }),
          ]),
          histInput,
          histNote,
        ]),
      ]);
      const trackBody = U.el('bcv-gpa-set__fields', [
        h('label', { class: 'bcv-gpa-set__field' }, [h('span', { text: 'GPA before this term' }), priorGpa]),
        h('label', { class: 'bcv-gpa-set__field' }, [h('span', { text: 'Courses it covers' }), priorN]),
        U.el('bcv-gpa-set__csv', [
          U.el('bcv-gpa-set__csvbtns', [
            U.btn('Upload CSV', { kind: 'sm', cls: 'bcv-gpa-set__csvbtn', onClick: () => csvInput.click() }),
            // Download CSV: the record's rows and this term's courses with the letters Canvas shows now, in the
            // shape Upload CSV reads — next term's record is this file, brought back
            U.btn('Download CSV', { kind: 'sm', cls: 'bcv-gpa-set__dlbtn', onClick: () => {
              const rows = [...(pendingRecord?.courses || []), ...m.rows.map((r) => ({ term: term || 'This term', course: r.c.name, grade: r.letter, credits: null }))];
              if (!rows.length) { U.toast('Nothing to download yet.', { error: true }); return; }
              const a = h('a', { href: URL.createObjectURL(new Blob([BCV.recordCsv.csv(rows)], { type: 'text/csv' })), download: 'simpl-courses-record.csv', hidden: true });
              document.body.append(a);
              a.click();
              setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
            } }),
          ]),
          csvInput,
          fromNote,
        ]),
      ]);
      trackBody.hidden = !on;
      const trackSwitch = U.switchEl(on, (v) => { on = v; trackBody.hidden = !on; }, 'Track GPA over time');
      // (2.99.140) the student's own grading scale, for every course without one of its own: the bar, under a switch
      let usualOn = !!ownOf(ALL), usualTouched = false;
      const usualBar = scaleBar(scaleOf(ALL), { onChange: () => { usualTouched = true; } });
      const usualBody = U.el('bcv-gpa-set__scale', [usualBar.el]);
      usualBody.hidden = !usualOn;
      const usualSwitch = U.switchEl(usualOn, (v) => { usualOn = v; usualBody.hidden = !v; usualTouched = true; }, 'Use my own grading scale');
      const close = () => { BCV.ui.dismiss(ov); if (histTouched) { histTouched = false; refresh(); } };
      const done = async () => {
        const usualMap = usualTouched && usualOn ? usualBar.map() : null;
        const usualBad = usualMap ? scaleError(usualMap) : '';
        if (usualBad) { U.toast(usualBad, { error: true }); return; }
        if (goalTouched) goal = clamp(pendingGoal, 0, 4);
        if (on) {
          // the record before this term is optional: without it, cumulative fills in from snapshots
          const blank = !priorGpa.value.trim() && !priorN.value.trim();
          const g = Number(priorGpa.value), n = Math.round(Number(priorN.value));
          if (!blank && (!Number.isFinite(g) || g < 0 || g > 4 || !(n >= 1))) {
            U.toast('Enter your GPA before this term (0–4) and how many courses it covers, or leave both blank.', { error: true });
            priorGpa.focus();
            return;
          }
          // the rows of a CSV — uploaded here or in Settings — stay with the numbers they gave; numbers typed over them are the record now
          const fromFile = pendingRecord && rowsMatch(pendingRecord, g, n);
          const keepRecord = !blank && fromFile ? { record: pendingRecord } : {};
          tracking = blank ? { priorGpa: null, priorCourses: 0, since: tracking?.since || dayKey() } : { priorGpa: g, priorCourses: n, since: tracking?.since || dayKey(), ...keepRecord };
        } else tracking = null;
        if (usualTouched) { if (usualMap) await setScale(ALL, usualMap); else if (ownOf(ALL)) await setScale(ALL, null); }
        await save();
        histTouched = false;
        close();
        await refresh();
      };
      ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
      ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
      ov.append(U.el('bcv-sheet bcv-gpa-set', [
        U.el('bcv-sheet__head', [
          h('div', { style: { flex: '1', minWidth: '0' } }, [U.text('bcv-sheet__title', 'GPA settings'), U.text('bcv-sheet__desc bcv-pretty', `Term GPA is the plain average of your course letter grades on a 4.0 scale — ${BCV.lms.name} publishes no credit weighting, so nothing here is guessed.`)]),
          h('button', { type: 'button', class: 'bcv-sheet__close', 'aria-label': 'Close', onclick: close }, U.svg(IC.close, { size: 13, stroke: 'var(--bcv-ink2)', width: 2.3 })),
        ]),
        U.el('bcv-sheet__list', [
          U.el('bcv-gpa-set__sec bcv-gpa-set__sec--tint', [
            U.el('bcv-gpa-set__body', [U.text('bcv-gpa-set__k', 'Term GPA goal'), goalGap]),
            U.el('bcv-gpa-set__ctl', [
              h('button', { type: 'button', class: 'bcv-gpa-set__step', text: '−', 'aria-label': 'Lower the goal', onclick: () => { pendingGoal = goalTouched ? clamp(+(pendingGoal - 0.05).toFixed(2), 0, 4) : DEFAULT_GOAL - 0.05; goalTouched = true; syncGoal(); } }),
              goalVal,
              h('button', { type: 'button', class: 'bcv-gpa-set__step', text: '+', 'aria-label': 'Raise the goal', onclick: () => { pendingGoal = clamp(+(pendingGoal + 0.05).toFixed(2), 0, 4); goalTouched = true; syncGoal(); } }),
            ]),
          ]),
          U.el('bcv-gpa-set__sec', [
            U.el('bcv-gpa-set__body', [U.text('bcv-gpa-set__k', 'Track GPA over time'), U.text('bcv-gpa-set__s bcv-pretty', `${BCV.lms.name} stores no GPA and no history. With your record before this term, this page shows a cumulative GPA and keeps one snapshot a day from now on.`)]),
            trackSwitch,
            trackBody,
          ]),
          U.el('bcv-gpa-set__sec', [
            U.el('bcv-gpa-set__body', [U.text('bcv-gpa-set__k', 'My grading scale'), U.text('bcv-gpa-set__s bcv-pretty', `Letter every course by your school’s cutoffs, not ${BCV.lms.name}’s. A course’s own scale, set on its Details, comes first.`)]),
            usualSwitch,
            usualBody,
          ]),
          U.el('bcv-gpa-set__sec bcv-gpa-set__sec--hist', [
            U.el('bcv-gpa-set__body', [U.text('bcv-gpa-set__k', 'Past points on the trend'), U.text('bcv-gpa-set__s bcv-pretty', 'The chart holds one snapshot a day from the day tracking came on. Put what came before it on the chart too: a day (or a term’s end) and the GPA you had then, or a CSV of dates and GPAs.')]),
            histBody,
          ]),
        ]),
        U.el('bcv-gpa-set__foot', [
          h('span', { text: m.shownCount ? `${courseLabel(m)} · every course counts equally` : 'No current course to score' }),
          U.btn('Done', { kind: 'primary', cls: 'bcv-btn--fill36', onClick: done }),
        ]),
      ]));
      document.body.append(ov);
      U.morphFrom(ov.firstElementChild, from); // out of the gear, or the banner's button
      ov.tabIndex = -1;
      if (wantTracking) priorGpa.focus(); else ov.focus();
    }

    async function resetTracking() {
      if (!window.confirm('Forget your prior GPA and every snapshot this page has saved?')) return;
      tracking = null;
      snaps = [];
      await Promise.all([save(), store.setPref('gpaSnapshots', [])]);
      await refresh();
    }

    // ---- draw --------------------------------------------------------------------------------
    async function refresh() {
      current = model();
      await snapshot(current);
      if (ctx.alive()) draw();
    }
    function draw() {
      const m = current || model();
      sub.textContent = `${term ? `${term} · ` : ''}${m.shownCount ? courseLabel(m) : 'no current courses'}`;
      body.replaceChildren(...[
        // tracking on: the hero and the trend, the stats under them; off (E16): the hero, and beside it the two stats that
        // need no history with the one slim card that asks for tracking — no empty chart, no empty Momentum
        tracking
          ? U.el('bcv-gpa__top', [U.enter(hero(m), 1, 40, 400), U.enter(trend(), 1, 110, 400)]) // hero, then trend
          : U.el('bcv-gpa__top', [U.enter(hero(m), 1, 40, 400), U.el('bcv-gpa__side', [...statCards(m), U.enter(trackCard(m), 2, 50)])]),
        tracking ? stats(m) : null,
        courseGrid(m),
        hiddenTray(m),
        itemGrades(),
        U.el('bcv-gpa__foot', [
          h('p', { class: 'bcv-pretty', text: tracking
            ? `Course scores come straight from ${BCV.lms.name}. GPA, targets and history are computed here from the standard 4.0 scale and the prior record you entered — your school’s official GPA may differ.`
            : `Course scores and target maths come straight from ${BCV.lms.name}. Term GPA is the plain 4.0-scale average of your courses — your school’s official GPA may differ.` }),
          tracking ? h('button', { type: 'button', class: 'bcv-gpa__linkbtn', text: 'Reset setup', onclick: resetTracking }) : null,
        ]),
      ].filter(Boolean));
      entered = true;
    }

    await refresh();
    return screen;
  }

  /** What the screen asks for first — the course list, then each followed course's assignment
   *  groups — so a press on Grades lands from the memo. The same list render() settles on. */
  async function prefetch() {
    const all = await store.courses().catch(() => null);
    if (!all) return;
    const currentCourses = all.filter((c) => c.state === 'current');
    const starredCourses = currentCourses.filter((c) => c.favorite);
    await Promise.all((starredCourses.length ? starredCourses : currentCourses).map((c) => store.assignmentGroups(c.id).catch(() => {})));
  }

  // ---- the first opening: the guided tour's Grades steps ---------------------------------------
  // The first time this page opens, the tour (welcome.js) walks the two things that are not obvious
  // from looking at it, on the page itself: a card's ring hovered for its breakdown, and what-if
  // scores tried in a course's Details. Once, then never again (a flag in the extension's storage,
  // the way Tools' is; the setup's tour sets it too when it has walked them).
  // A phone's Grades is another screen, and the app has its own first launch: neither sees it.
  const INTRO_KEY = 'welcome:grades';
  async function introIfFirst(app) {
    if (!BCV.welcome || BCV.phone?.active?.() || self.BCVBridge?.native || BCV.welcome.active() || BCV.setup?.active?.()) return false;
    try {
      const f = await BCV.api.storage.local.get(INTRO_KEY);
      if (f && f[INTRO_KEY]) return false;
    } catch { return false; }
    BCV.welcome.cover();
    await BCV.welcome.open(app, ['gradeHover', 'whatIf'], { onDone: () => BCV.api.storage.local.set({ [INTRO_KEY]: true }).catch(() => {}) });
    return true;
  }

  /** Every graded assignment across the courses given, with its letter (U.gradeBand), course by course
   *  in the order given, each course's by due date; and how many hold each letter. The Grades page's
   *  Item grades and the phone's. */
  function gradedItems(courses, gmFor) {
    const items = [];
    for (const c of courses) {
      for (const g of gmFor(c).rows) {
        const band = U.gradeBand(g.earned, g.possible, g.gradingType);
        if (band) items.push({ c, g, band, pct: (g.earned / g.possible) * 100 });
      }
    }
    const counts = {};
    for (const it of items) counts[it.band] = (counts[it.band] || 0) + 1;
    return { items, counts };
  }

  /** (2.99.27) The course's grading scale, as its instructor set it: a cutoff per letter, entered from the syllabus;
   *  Save keeps it (letters, targets and Grade needed follow it), Standard scale lets it go. (2.99.140) Set on the bar
   *  (scaleBar), where a letter the course does not give can be taken off and put back. */
  function scaleSection(c, changed) {
    const S = scaleOf(c.id);
    const own = ownScaleOf(c.id);
    const usual = !!ownOf(ALL); // (the student's scale for every course: what the course falls back to)
    const open = { on: own };
    const status = U.text('bcv-gpa-detail__hsub', own ? 'Your instructor’s scale' : usual ? 'Your scale for every course' : 'The standard scale', 'span');
    const err = U.text('bcv-scale__err', '', 'div');
    const bar = scaleBar(S, { onChange: () => { err.textContent = ''; } });
    const save = U.btn('Save scale', { kind: 'primary', onClick: async () => {
      const map = bar.map();
      const bad = scaleError(map);
      if (bad) { err.textContent = bad; return; }
      err.textContent = '';
      await setScale(c.id, map);
      U.toast(`Saved ${c.shortName || c.name}’s grading scale.`);
      changed();
    } });
    const reset = U.btn(usual ? 'Use your usual scale' : 'Standard scale', { onClick: async () => { await setScale(c.id, null); U.toast(usual ? 'Back to your scale for every course.' : 'Back to the standard scale.'); changed(); } });
    const editor = U.el('bcv-scale__editor', [
      U.text('bcv-gpa-detail__note', 'Slide each letter to the lowest percentage it takes, as your syllabus or instructor sets it.'),
      bar.el, err, U.el('bcv-scale__actions', [own ? reset : null, save]),
    ]);
    const fold = U.collapsible(editor, open.on, 'bcv-scale__fold'); // (Edit slides it open, Hide shut)
    const toggle = h('button', { type: 'button', class: 'bcv-scale__toggle', 'aria-expanded': String(open.on), text: open.on ? 'Hide' : 'Edit', onclick: () => { open.on = !open.on; fold.setOpen(open.on); toggle.textContent = open.on ? 'Hide' : 'Edit'; toggle.setAttribute('aria-expanded', String(open.on)); } });
    return U.el('bcv-gpa-detail__sec bcv-gpa-detail__sec--line bcv-scale', [
      U.el('bcv-gpa-detail__hrow', [U.text('bcv-gpa__kicker2', 'Grading scale', 'span'), status, toggle]),
      fold,
    ]);
  }

  /** (2.99.140) A grading scale as a bar the student slides. Left to right it runs from `lo` (50%, or lower when a letter
   *  starts lower) to 100%: a stretch in each kept letter's colour from its cutoff up to the next letter's, F under the
   *  lowest, and on each cutoff a handle with its letter on a flag (above the bar and below it in turn, so neighbours
   *  stay apart). A handle slides along the bar, held between the letters on either side, in half points (arrow keys
   *  the same, Shift or Page Up/Down five at a time; the field under the bar takes any figure). Dragged up or down off
   *  the bar, Remove, or Delete takes its letter off the scale — the letter under it then runs up to the next one kept —
   *  and it waits under the bar, where a tap puts it back (at its usual cutoff when that still fits, else halfway
   *  between its neighbours). bar.map(): { letter: min% or null } as it stands; onChange after each change. */
  function scaleBar(S, { onChange = null } = {}) {
    const letters = SCALE.filter(([l]) => norm(l) !== 'F').map(([l]) => l); // A+ … D as shown (A−, not A-)
    const std = Object.fromEntries(SCALE.map(([l, min]) => [l, min]));
    const cut = Object.fromEntries(letters.map((l) => { const s = S.find((x) => x[0] === l); return [l, s && Number.isFinite(s[1]) ? s[1] : s ? null : std[l]]; }));
    const kept = () => letters.filter((l) => cut[l] !== null);
    const OFF = 40; // px a handle goes up or down off the bar before letting go takes its letter off
    const fig = (v) => String(+Number(v).toFixed(2)); // 90, 89.5, 89.45
    const tone = (l) => (l.endsWith('+') ? 'is-plus' : l.endsWith('−') ? 'is-minus' : '');
    let lo = 50, sel = null, drag = null;
    const floorOf = () => { const k = kept(); const low = k.length ? cut[k[k.length - 1]] : 60; return clamp(Math.floor((low - 10) / 10) * 10, 0, 50); };
    const xOf = (v) => ((clamp(v, lo, 100) - lo) / (100 - lo)) * 100;
    /** Where a kept letter may go: over the letter kept under it, under the one kept over it (or 100 at the top). */
    const room = (l) => {
      const k = kept(), i = k.indexOf(l);
      const up = i > 0 ? cut[k[i - 1]] : null, down = i >= 0 && i < k.length - 1 ? cut[k[i + 1]] : null;
      return { up, down, min: down === null ? 0 : down + 0.5, max: up === null ? 100 : up - 0.5 };
    };
    const range = (l) => { const { up } = room(l); return up === null ? 'to 100%' : `to under ${fig(up)}%`; };

    const track = h('div', { class: 'bcv-sbar__track', 'aria-hidden': 'true' });
    const ticks = h('div', { class: 'bcv-sbar__ticks', 'aria-hidden': 'true' });
    const lane = h('div', { class: 'bcv-sbar__lane' }, [track, ticks]);
    const field = h('input', { type: 'text', inputmode: 'decimal', class: 'bcv-sbar__in', autocomplete: 'off' });
    const chip = U.text('bcv-sbar__chip', '', 'span');
    const span = U.text('bcv-sbar__range', '', 'span');
    const rm = h('button', { type: 'button', class: 'bcv-sbar__rm', text: 'Remove' });
    const pick = U.el('bcv-sbar__pick', [chip, U.text('bcv-sbar__from', 'from', 'span'), U.el('bcv-sbar__field', [field, U.text('bcv-sbar__pct', '%', 'span')]), span, rm]);
    const idle = U.text('bcv-sbar__idle', 'Pick a letter on the bar to type its cutoff.', 'span');
    const info = U.el('bcv-sbar__info', [idle, pick]);
    const tray = U.el('bcv-sbar__tray');
    const hint = U.text('bcv-sbar__hint', 'Drag a letter off the bar to take it off the scale.');
    const root = h('div', { class: 'bcv-sbar', role: 'group', 'aria-label': 'Grading scale' }, [lane, info, tray, hint]);
    const knobs = new Map();
    const changed = () => onChange?.(map());
    const map = () => Object.fromEntries(letters.map((l) => [norm(l), cut[l]]));

    function render(fresh = null) {
      lo = floorOf();
      const k = kept();
      for (const kn of knobs.values()) kn.remove();
      knobs.clear();
      k.forEach((l, i) => {
        const kn = h('button', {
          type: 'button', role: 'slider', class: `bcv-sbar__knob bcv-band--${l[0]} ${i % 2 ? 'is-down' : 'is-up'} ${l === fresh ? 'is-new' : ''}`,
          'aria-label': `${l} cutoff`, 'aria-valuemin': '0', 'aria-valuemax': '100', dataset: { letter: norm(l) },
        }, [h('span', { class: 'bcv-sbar__flag', text: l }), h('span', { class: 'bcv-sbar__stem' }), h('span', { class: 'bcv-sbar__dot' })]);
        knobs.set(l, kn);
        lane.append(kn);
      });
      track.replaceChildren(...[...k, 'F'].map((l) => h('span', { class: `bcv-sbar__seg bcv-band--${l[0]} ${tone(l)}`, dataset: { letter: norm(l) } })));
      const tickAt = [];
      for (let v = lo; v <= 100; v += 10) tickAt.push(v);
      ticks.replaceChildren(...tickAt.map((v) => h('span', { class: 'bcv-sbar__tick', style: { left: `${xOf(v)}%` }, text: `${v}%` })));
      if (sel && cut[sel] === null) sel = null;
      place();
      paintTray();
      paintInfo();
    }
    /** Every handle and stretch where its cutoff puts it (a drag moves only these). */
    function place() {
      const k = kept();
      [...k, 'F'].forEach((l, i) => {
        const seg = track.children[i];
        if (!seg) return;
        const from = l === 'F' ? lo : cut[l];
        const to = l === 'F' ? (k.length ? cut[k[k.length - 1]] : 100) : i > 0 ? cut[k[i - 1]] : 100;
        seg.style.left = `${xOf(from)}%`;
        seg.style.width = `${Math.max(0, xOf(to) - xOf(from))}%`;
      });
      for (const [l, kn] of knobs) {
        kn.style.left = `${xOf(cut[l])}%`;
        kn.setAttribute('aria-valuenow', String(cut[l]));
        kn.setAttribute('aria-valuetext', `${l} from ${fig(cut[l])}% ${range(l)}`);
        kn.classList.toggle('is-sel', l === sel);
      }
    }
    function paintInfo() {
      idle.hidden = !!sel;
      pick.hidden = !sel;
      if (!sel) return;
      chip.textContent = sel;
      chip.className = `bcv-sbar__chip bcv-band--${sel[0]}`;
      if (document.activeElement !== field) field.value = fig(cut[sel]);
      field.setAttribute('aria-label', `Lowest percentage for ${sel}`);
      span.textContent = range(sel);
      rm.disabled = kept().length <= 1;
      rm.setAttribute('aria-label', `Take ${sel} off the scale`);
    }
    function paintTray() {
      const gone = letters.filter((l) => cut[l] === null);
      tray.hidden = !gone.length;
      tray.replaceChildren(...(gone.length ? [U.text('bcv-sbar__trayk', 'Not on the scale', 'span'), ...gone.map((l) => h('button', {
        type: 'button', class: `bcv-sbar__add bcv-band--${l[0]}`, dataset: { letter: norm(l) }, 'aria-label': `Put ${l} back on the scale`, onclick: () => add(l),
      }, [U.svg(IC.plus, { size: 10, width: 2.6 }), h('span', { text: l })]))] : []));
    }
    function select(l) { sel = l; place(); paintInfo(); }
    function set(l, v) {
      if (cut[l] === v) return;
      cut[l] = v;
      if (floorOf() !== lo) { render(); knobs.get(l)?.focus({ preventScroll: true }); } else { place(); paintInfo(); }
      changed();
    }
    function remove(l) {
      if (cut[l] === null) return;
      if (kept().length <= 1) { U.toast('Keep at least one letter above F.', { error: true }); return; }
      const k = kept(), i = k.indexOf(l);
      cut[l] = null;
      sel = null;
      render();
      changed();
      (knobs.get(k[i + 1]) || knobs.get(k[i - 1]))?.focus({ preventScroll: true });
    }
    function add(l) {
      const above = letters.slice(0, letters.indexOf(l)).reverse().find((x) => cut[x] !== null);
      const below = letters.slice(letters.indexOf(l) + 1).find((x) => cut[x] !== null);
      const up = above ? cut[above] : null, down = below ? cut[below] : 0;
      const fits = (v) => v > down && (up === null ? v <= 100 : v < up);
      const mid = ((up === null ? 100 : up) + down) / 2;
      const v = [std[l], Math.round(mid * 2) / 2, +mid.toFixed(2)].find(fits);
      if (v === undefined) { U.toast(`No room for ${l} between ${above || 'the top'} and ${below || 'F'}.`, { error: true }); return; }
      cut[l] = v;
      sel = l;
      render(l);
      changed();
      knobs.get(l)?.focus({ preventScroll: true });
    }

    // a handle: pressed, it is the one picked; dragged sideways it sets its cutoff, held where its grab was; dragged off
    // the bar it says so, and letting go there takes its letter off
    lane.addEventListener('pointerdown', (e) => {
      const kn = e.target.closest('.bcv-sbar__knob');
      if (!kn || e.button !== 0) return;
      e.preventDefault();
      const l = [...knobs].find(([, x]) => x === kn)?.[0];
      if (!l) return;
      kn.focus({ preventScroll: true });
      select(l);
      const r = lane.getBoundingClientRect();
      drag = { kn, l, r, grab: e.clientX - (r.left + (xOf(cut[l]) / 100) * r.width), y0: e.clientY, off: false };
      try { kn.setPointerCapture(e.pointerId); } catch {}
      kn.classList.add('is-drag');
      root.classList.add('is-dragging');
    });
    lane.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const { kn, l, r } = drag;
      const dy = clamp(e.clientY - drag.y0, -OFF - 16, OFF + 16); // (just past the line: the fold above clips no further)
      const off = Math.abs(dy) > OFF && kept().length > 1;
      kn.style.setProperty('--dy', `${dy}px`);
      if (off !== drag.off) {
        drag.off = off;
        kn.classList.toggle('is-off', off);
        hint.textContent = off ? `Let go to take ${l} off the scale.` : 'Drag a letter off the bar to take it off the scale.';
      }
      if (off) return;
      const { min, max } = room(l);
      if (min > max) return;
      const v = clamp(Math.round((lo + ((e.clientX - drag.grab - r.left) / r.width) * (100 - lo)) * 2) / 2, min, max);
      if (v !== cut[l]) { cut[l] = v; place(); paintInfo(); changed(); }
    });
    const end = () => {
      if (!drag) return;
      const { kn, l, off } = drag;
      drag = null;
      kn.classList.remove('is-drag', 'is-off');
      kn.style.removeProperty('--dy');
      root.classList.remove('is-dragging');
      hint.textContent = 'Drag a letter off the bar to take it off the scale.';
      if (off) remove(l);
      else if (floorOf() !== lo) { render(); knobs.get(l)?.focus({ preventScroll: true }); } // (a letter brought low: the bar reaches further down)
    };
    lane.addEventListener('pointerup', end);
    lane.addEventListener('pointercancel', end);
    lane.addEventListener('focusin', (e) => { const kn = e.target.closest('.bcv-sbar__knob'); const l = kn && [...knobs].find(([, x]) => x === kn)?.[0]; if (l && l !== sel) select(l); });
    lane.addEventListener('keydown', (e) => {
      const kn = e.target.closest('.bcv-sbar__knob');
      const l = kn && [...knobs].find(([, x]) => x === kn)?.[0];
      if (!l) return;
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); remove(l); return; }
      const { min, max } = room(l);
      const by = e.shiftKey || e.key === 'PageUp' || e.key === 'PageDown' ? 5 : 0.5;
      const to = e.key === 'ArrowRight' || e.key === 'ArrowUp' || e.key === 'PageUp' ? cut[l] + by
        : e.key === 'ArrowLeft' || e.key === 'ArrowDown' || e.key === 'PageDown' ? cut[l] - by
        : e.key === 'Home' ? min : e.key === 'End' ? max : null;
      if (to === null) return;
      e.preventDefault();
      if (min <= max) set(l, clamp(Math.round(to * 2) / 2, min, max));
    });
    // the field: any figure between the letters on either side, taken on Enter or as it loses focus
    const take = () => {
      if (!sel || field.value.trim() === fig(cut[sel])) return;
      const v = Number(String(field.value).replace(/[^0-9.]/g, ''));
      const { up, down } = room(sel);
      const ok = field.value.trim() !== '' && Number.isFinite(v) && v >= 0 && v <= 100 && (up === null || v < up) && (down === null || v > down);
      if (!ok) { U.toast(`${sel} needs a cutoff ${down === null ? 'from 0%' : `over ${fig(down)}%`} ${up === null ? 'up to 100%' : `and under ${fig(up)}%`}.`, { error: true }); field.value = fig(cut[sel]); return; }
      set(sel, +v.toFixed(2));
    };
    field.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); take(); } else if (e.key === 'Escape' && sel) { field.value = fig(cut[sel]); } });
    field.addEventListener('change', take);
    rm.addEventListener('click', () => { if (sel) remove(sel); });

    render();
    return { el: root, map, reset(S2) { for (const l of letters) { const s = S2.find((x) => x[0] === l); cut[l] = s && Number.isFinite(s[1]) ? s[1] : s ? null : std[l]; } sel = null; render(); changed(); } };
  }

  BCV.screens.gpa = { render, skeleton, courseMath, SCALE, letterFor, pointsFor, targetIndex, prefetch, trendChart, gradedItems, MIN_Y, MAX_Y, scaleOf, hasScale, ownScaleOf, loadScales, setScale, scaleError, snapIdx, stepIdx, scaleBar, ALL };
})();
