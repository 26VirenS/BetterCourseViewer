/* Course shell (header + tab pills from the tabs API) and the list tabs:
 * Home, Announcements, Assignments, Discussions, People, Pages, Files,
 * Quizzes, Modules, course stream. Grades and item detail views live in
 * grades.js and course-detail.js. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  const { h, htmlToText } = BCV.utils;
  const U = BCV.ui;
  const IC = BCV.IC;
  const store = BCV.store;

  const TAB_ICONS = { home: IC.book, announcements: IC.bell, assignments: IC.doc, discussions: IC.disc, grades: IC.chart, people: IC.people, pages: IC.page, files: IC.folder, quizzes: IC.bolt, modules: IC.modules, syllabus: IC.page, collaborations: IC.people, conferences: IC.video, outcomes: IC.chart, rubrics: IC.sheet, settings: IC.settings };
  const ROUTE_TAB = { announcement: 'announcements', assignment: 'assignments', syllabus: 'syllabus', discussion: 'discussions', page: 'pages', folder: 'files', file: 'files', quiz: 'quizzes', stream: 'home' };

  /** Sanitised, link-safe HTML from Canvas rich content. The wrapper wears Canvas's own class for
   *  rich content (user_content) too: a school's stylesheet and a page-design tool write their rules
   *  for what sits inside it — a row of buttons along the top of a front page, a coloured panel — and
   *  those reach the page here as they do on Canvas. */
  function prose(html, { cls = '' } = {}) {
    const wrap = U.el(`bcv-prose user_content ${cls}`);
    if (!html) return wrap;
    const doc = new DOMParser().parseFromString(String(html), 'text/html');
    doc.querySelectorAll('script, style, link, meta, object, embed').forEach((n) => n.remove());
    doc.querySelectorAll('*').forEach((n) => {
      for (const a of Array.from(n.attributes)) if (/^on/i.test(a.name)) n.removeAttribute(a.name);
    });
    // (as the browser reads an address: spaces before it dropped, tabs and newlines in it ignored — " java&#9;script:" runs too)
    const scripted = (v) => /^javascript:/i.test(String(v || '').replace(/[\u0000-\u0020]/g, ''));
    doc.querySelectorAll('a[href]').forEach((a) => {
      const href = a.getAttribute('href') || '';
      if (scripted(href)) a.removeAttribute('href');
      if (/^https?:/i.test(href) && !href.startsWith(location.origin)) {
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
      }
    });
    doc.querySelectorAll('iframe').forEach((f) => {
      // Safari stalls lazy iframes that start off-screen; let embeds load normally.
      f.removeAttribute('loading');
      f.removeAttribute('srcdoc'); // (a page written inline runs as this site, script and all)
      if (!f.getAttribute('src') && f.dataset.src) f.setAttribute('src', f.dataset.src);
      if (scripted(f.getAttribute('src'))) f.removeAttribute('src');
      f.setAttribute('allowfullscreen', '');
      if (!f.getAttribute('allow')) f.setAttribute('allow', 'fullscreen; microphone; camera; display-capture; autoplay; clipboard-write');
      // An embed its author gave a size to — Canvas's editor writes one on every video it puts in,
      // 320 × 240 in the frame's style — keeps it, as on Canvas, rather than being stretched to the
      // column and 420 tall; it scales down with its shape kept where the column is narrower.
      const px = (v) => { const m = /^\s*(\d+(?:\.\d+)?)(?:px)?\s*$/.exec(String(v || '')); return m ? Number(m[1]) : 0; };
      const w = px(f.style.width) || px(f.getAttribute('width'));
      const tall = px(f.style.height) || px(f.getAttribute('height'));
      if (w && tall) {
        f.classList.add('bcv-embed--sized');
        f.style.width = `${w}px`;
        f.style.height = 'auto';
        f.style.aspectRatio = `${w} / ${tall}`;
      }
      const src = f.getAttribute('src') || '';
      const open = h('a', { class: 'bcv-chip bcv-embed-open', href: src || '#', target: '_blank', rel: 'noopener', text: 'Open in new tab' });
      f.after(open);
    });
    wrap.append(...Array.from(doc.body.childNodes));
    fitMath(wrap);
    fitLinks(wrap);
    fitInk(wrap);
    return wrap;
  }

  // A link a teacher made into a button — a dark plate with white words, a row of them across the top
  // of a front page — wears the colours the page gives it, as on Canvas. Our link colour is for the
  // links in the text, and it outranks any class, so it used to paint those buttons' words in ours.
  // Every link starts out of our colour (bcv-ownlink); one that then shows the page's plain link
  // colour (a probe link's: Canvas's own, or the school's) takes ours back, and one the page colours
  // itself — by a class, a style, a design tool's theme — keeps it. Runs before fitInk, in the same
  // frame, so the ink pass reads the page's colour rather than ours.
  function fitLinks(wrap) {
    const links = Array.from(wrap.querySelectorAll('a:not([class*="bcv-"])')); // (not our own: the embed's Open in new tab)
    if (!links.length) return;
    for (const a of links) a.classList.add('bcv-ownlink');
    let tries = 0;
    const pass = () => {
      if (!wrap.isConnected) { if (tries++ < 10) requestAnimationFrame(pass); else for (const a of links) a.classList.remove('bcv-ownlink'); return; }
      const probe = h('a', { href: '#', class: 'bcv-ownlink', hidden: true, 'aria-hidden': 'true' });
      wrap.append(probe);
      const plain = getComputedStyle(probe).color;
      const own = links.map((a) => getComputedStyle(a).color !== plain);
      probe.remove();
      links.forEach((a, i) => { if (!own[i]) a.classList.remove('bcv-ownlink'); });
    };
    requestAnimationFrame(pass);
  }

  // Canvas does not typeset a formula on the page: it asks its equation service for a picture of one
  // and drops that in. What comes back is an SVG sized in points at the service's own idea of a text
  // size, so left alone it renders about half again too large and sits on the line like a picture
  // rather than like text — a fraction towers over the sentence holding it, pushing the words to the
  // bottom of the line. The shape is right, only the size is not, so the height is set from the
  // picture's own proportions in ems — a formula then follows the text it sits in at every size —
  // and the width is left to follow. A tall one (a limit over a fraction) is allowed four lines; a
  // small one is never shrunk below the text around it.
  const MATH_PT = 0.75; // points to CSS pixels, undone: the service sizes the picture in points
  const MATH_BASE = 16; // the text size it typesets for
  function fitMath(wrap) {
    for (const img of wrap.querySelectorAll('img.equation_image')) {
      img.removeAttribute('width'); // Canvas's own numbers are the picture's, not the line's
      img.removeAttribute('height');
      const fit = () => {
        if (!img.naturalHeight) return;
        const em = (img.naturalHeight * MATH_PT) / MATH_BASE;
        img.style.height = `${Math.min(Math.max(em, 1), 4).toFixed(3)}em`;
        img.style.width = 'auto';
      };
      if (img.complete) fit();
      else img.addEventListener('load', fit, { once: true });
    }
  }

  // Canvas pages carry their own colours — a school's page template, an author's coloured panel, a
  // page-design tool's theme — all written for Canvas's white page. On ours, what sits behind a
  // piece of text can be our card, a plate the page paints, or only part of what the page meant (a
  // theme's dark band, with the light card that held the words on Canvas missing), and the page's
  // ink can sink into any of them. So every piece of text the page colours itself is measured
  // against what is really behind it — the nearest background the page paints inside the text, or
  // else our card — and one that does not stand out from it by enough is given a colour that does:
  // its own hue and (most of) its saturation kept, only its lightness moved, so a dark red stays a
  // red. Our own ink on our own card is ours to colour and is left alone. Measured once the prose is on the
  // page, in both appearances, since the colour can come from the school's stylesheet as easily as
  // from the markup. In the dark appearance a plate the page paints light keeps dark ink
  // (bcv-onlight), and a formula on it is not turned over.
  const LIGHT_BG = 0.55; // a plate the page paints light enough to keep dark ink on (dark appearance)
  const MIN_CONTRAST = 3; // below this the words are hard to make out
  const AIM = 4.5; // what a colour that had to move is given: comfortable reading (WCAG's for body text)
  const rgbOf = (css) => {
    const m = /rgba?\(([^)]+)\)/.exec(css || '');
    if (m) {
      const [r, g, b, a = 1] = m[1].split(/[\s,/]+/).filter(Boolean).map(Number);
      return { r, g, b, a, lum: (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 };
    }
    const hex = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(css || '').trim());
    if (!hex) return null;
    const x = hex[1].length === 3 ? hex[1].replace(/./g, '$&$&') : hex[1];
    const [r, g, b] = [0, 2, 4].map((i) => parseInt(x.slice(i, i + 2), 16));
    return { r, g, b, a: 1, lum: (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 };
  };
  /** Relative luminance, as contrast is measured (WCAG). */
  const relLum = ({ r, g, b }) => {
    const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  const contrast = (a, b) => (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
  function hslOf({ r, g, b }) {
    const R = r / 255, G = g / 255, B = b / 255;
    const mx = Math.max(R, G, B), mn = Math.min(R, G, B), d = mx - mn;
    const l = (mx + mn) / 2;
    let h = 0;
    if (d) {
      h = mx === R ? ((G - B) / d) % 6 : mx === G ? (B - R) / d + 2 : (R - G) / d + 4;
      h *= 60;
      if (h < 0) h += 360;
    }
    return { h, s: d ? d / (1 - Math.abs(2 * l - 1)) : 0, l };
  }
  function rgbFromHsl(h, s, l) {
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1))));
    return { r: f(0), g: f(8), b: f(4) };
  }
  /** The colour moved to a lightness that reads on the plate behind it — lighter on a dark plate,
   *  darker on a light one — starting from its lightness turned over and going on until it reads. */
  function readable(c, plate) {
    const { h, s, l } = hslOf(c);
    const sat = Math.min(0.8, s); // capped: a moved colour should not glow
    const pl = relLum(plate);
    const up = contrast(pl, 1) >= contrast(pl, 0); // light words read better on this plate than dark ones
    let light = up ? Math.min(0.96, Math.max(0.72, 1 - l)) : Math.max(0.08, Math.min(0.32, 1 - l));
    for (let i = 0; i < 12 && contrast(relLum(rgbFromHsl(h, sat, light)), pl) < AIM; i++) light = up ? Math.min(0.98, light + 0.03) : Math.max(0.04, light - 0.03);
    return `hsl(${Math.round(h)}, ${Math.round(sat * 100)}%, ${Math.round(light * 100)}%)`;
  }
  const XHTML = 'http://www.w3.org/1999/xhtml';
  function fitInk(wrap) {
    let tries = 0;
    const pass = () => {
      if (!wrap.isConnected) { if (tries++ < 10) requestAnimationFrame(pass); return; }
      // every element that holds words of its own
      const holders = new Set();
      const tw = document.createTreeWalker(wrap, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (/\S/.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT) });
      while (tw.nextNode()) { const p = tw.currentNode.parentElement; if (p && p.namespaceURI === XHTML && !p.closest('.bcv-embed-open')) holders.add(p); }
      if (!holders.size) return;
      const dark = !!BCV.app?.isDark?.();
      const styles = new Map();
      const styleOf = (el) => { let st = styles.get(el); if (!st) { st = getComputedStyle(el); styles.set(el, st); } return st; };
      // what is behind the prose itself: the nearest of our own surfaces that is solid (a glass panel
      // lets the page under it show, so it does not count), else our card's colour
      let outer = null;
      for (let p = wrap.parentElement; p && p !== document.body && !outer; p = p.parentElement) { const bg = rgbOf(styleOf(p).backgroundColor); if (bg && bg.a > 0.5) outer = bg; }
      outer = outer || rgbOf(styleOf(wrap).getPropertyValue('--bcv-card')) || (dark ? { r: 28, g: 28, b: 30 } : { r: 255, g: 255, b: 255 });
      // the plate behind an element: the nearest background the page paints inside the prose (a
      // gradient by its first colour); a picture is one this cannot read, so its words are left as
      // the page set them
      const plates = new Map();
      const plateOf = (el) => {
        const seen = [];
        let found;
        for (let p = el; ; p = p.parentElement) {
          if (plates.has(p)) { found = plates.get(p); break; }
          seen.push(p);
          if (p === wrap.parentElement || !p) { found = outer; break; }
          const st = styleOf(p);
          const img = st.backgroundImage && st.backgroundImage !== 'none' ? st.backgroundImage : '';
          if (img && !/gradient/.test(img)) { found = null; break; }
          const bg = (img && rgbOf(img)) || rgbOf(st.backgroundColor); // (a gradient read by its first colour)
          if (bg && bg.a > 0.5) { found = bg; if (dark && bg.lum > LIGHT_BG) p.classList.add('bcv-onlight'); break; }
        }
        for (const p of seen) plates.set(p, found);
        return found;
      };
      const behind = new Map();
      for (const el of holders) behind.set(el, plateOf(el));
      // read every colour (after the light plates have their dark ink) before changing any
      const ours = styleOf(wrap).color;
      const fixes = [];
      for (const el of holders) {
        const plate = behind.get(el);
        if (!plate) continue;
        const colour = styleOf(el).color;
        const link = el.closest('a');
        const oursHere = colour === ours || (link && !link.classList.contains('bcv-ownlink') && styleOf(link).color === colour); // our ink, or our link colour
        if (oursHere && plate === outer) continue; // ours, on our own surface
        const c = rgbOf(colour);
        if (!c || c.a < 0.2) continue;
        const seen = c.a < 1 ? { r: c.r * c.a + plate.r * (1 - c.a), g: c.g * c.a + plate.g * (1 - c.a), b: c.b * c.a + plate.b * (1 - c.a) } : c;
        if (contrast(relLum(seen), relLum(plate)) >= MIN_CONTRAST) continue;
        fixes.push([el, readable(seen, plate)]);
      }
      for (const [el, colour] of fixes) el.style.setProperty('color', colour, 'important');
    };
    requestAnimationFrame(pass);
  }

  // A rubric criterion is not the flat pair of strings it looks like: its long description is Canvas
  // rich text (a criterion written as bullets arrives as "…page header<br/>• Lab title"), its
  // ratings are a list the assessment points into by id, and the score it was given is separate
  // again. Joined into one line, the markup showed as markup and every rating but one was dropped —
  // so the pieces are handed out whole here and drawn, not flattened, by both layouts.
  function rubricParts(cr, got) {
    const ratings = (cr?.ratings || []).filter((r) => r && (r.description || r.points !== null));
    const rated = got?.rating_id !== undefined && got?.rating_id !== null
      ? ratings.find((r) => String(r.id) === String(got.rating_id)) || null
      : null;
    const pts = (n) => (n === null || n === undefined ? '' : store.fmtPts(n));
    return {
      name: htmlToText(cr?.description || '', 300),
      long: htmlToText(cr?.long_description || '', 6000).trim() ? cr.long_description : null,
      ratings: ratings.map((r) => ({
        id: r.id,
        got: !!rated && String(r.id) === String(rated.id),
        text: htmlToText(r.description || '', 200) || 'Rating',
        value: r.points === null || r.points === undefined ? null : Number(r.points),
        pts: r.points === null || r.points === undefined ? '' : `${pts(r.points)} pts`,
        label: `${htmlToText(r.description || '', 200) || 'Rating'}${r.points === null || r.points === undefined ? '' : ` (${pts(r.points)})`}`,
      })),
      rated,
      comment: got?.comments ? `“${got.comments}”` : null,
      // graded: what it earned out of what it is worth; ungraded: what it is worth
      pts: got && got.points !== null && got.points !== undefined ? `${pts(got.points)} / ${pts(cr.points)}` : `${pts(cr?.points)} pts`,
    };
  }

  /** The rubric as the grid Canvas marks on: one row per criterion, its name and score on the first
   *  line, and every rating it offers as a cell across the row below — the rating the work was given
   *  filled in. A grid rather than a table because it has to hold at a sidebar's width and at a
   *  phone's: the rating cells reflow, nothing scrolls sideways. */
  // A rubric is read down and across at once — "what is this criterion, and what would each level of
  // it be worth?" — so the levels are columns, headed once, rather than repeated on every row. Canvas
  // does not name the levels: each criterion carries its own ratings, so they are ranked by points
  // (best first) and lined up by rank, and the names of the best-stocked criterion head the columns.
  // The top level reads green, nothing reads grey, and anything between reads amber.
  const RUB_ACCENT = ['#0a6cff', '#34c759', '#5856d6', '#ff9500', '#30b0c7', '#e71f63'];
  // by what the level is worth, not where it sits: the best is green, nothing at all is grey, and
  // everything between is amber — so a two-level 6/3 reads as full and partial, never as full and none
  const rubTier = (r, best) => {
    if (!r || r.value === null || r.value === undefined) return 'part';
    if (r.value === best) return 'full';
    return r.value === 0 ? 'none' : 'part';
  };
  function rubricGrid(rubric, assessment, { cls = '' } = {}) {
    const list = rubric || [];
    const parts = list.map((cr) => {
      const p = rubricParts(cr, (assessment || {})[cr.id]);
      // best first: the columns are levels, and a level is worth what it is worth
      p.ratings = p.ratings.slice().sort((a, b) => (b.value ?? -Infinity) - (a.value ?? -Infinity));
      return p;
    });
    const cols = Math.max(0, ...parts.map((p) => p.ratings.length));
    const heads = parts.find((p) => p.ratings.length === cols)?.ratings || [];
    const headBest = heads[0]?.value ?? null;
    const grid = U.el(`bcv-rubg ${cls}`, null, { style: { '--bcv-rubcols': String(cols) } });
    if (cols) {
      grid.append(U.el('bcv-rubg__head', [
        U.text('bcv-rubg__h', 'Criterion'),
        ...heads.map((r) => h('span', { class: `bcv-rubg__h bcv-rubg__h--${rubTier(r, headBest)} bcv-ellip`, title: r.text, text: r.text })),
      ]));
    }
    parts.forEach((p, n) => {
      const desc = p.long ? prose(p.long, { cls: 'bcv-prose--13 bcv-rubg__desc' }) : null;
      // a description only earns a button when it does not fit; measured once it is on the page
      const more = desc ? h('button', { type: 'button', class: 'bcv-rubg__more', hidden: true, onclick: () => {
        const open = desc.classList.toggle('is-open');
        more.textContent = open ? 'Less' : 'More';
      } }, 'More') : null;
      if (desc) {
        let tries = 0;
        const fit = () => {
          if (!desc.isConnected) { if (tries++ < 20) requestAnimationFrame(fit); return; }
          more.hidden = desc.scrollHeight <= desc.clientHeight + 1;
        };
        requestAnimationFrame(fit);
      }
      grid.append(U.el('bcv-rubg__row', [
        U.el('bcv-rubg__crit', [
          U.el('bcv-rubg__critline', [U.text('bcv-rubg__name', p.name), U.text('bcv-rubg__ptsv', p.pts, 'span')]),
          desc,
          more,
          p.comment ? U.text('bcv-rubg__note bcv-pretty', p.comment) : null,
          h('span', { class: 'bcv-rubg__accent', style: { background: RUB_ACCENT[n % RUB_ACCENT.length] } }),
        ]),
        ...Array.from({ length: cols }, (_, i) => {
          const r = p.ratings[i];
          if (!r) return U.el('bcv-rubg__cell bcv-rubg__cell--empty');
          return U.el(`bcv-rubg__cell bcv-rubg__cell--${rubTier(r, p.ratings[0]?.value ?? null)} ${r.got ? 'is-got' : ''}`, [
            U.text('bcv-rubg__cellpts', r.value === null || r.value === undefined ? '–' : store.fmtPts(r.value)),
            U.text('bcv-rubg__celltext', r.text),
          ]);
        }),
      ]));
    });
    return grid;
  }

  /** What the rubric is worth, and what it gave, from its own points rather than the assignment's. */
  function rubricScore(rubric, assessment) {
    const num = (v) => (v === null || v === undefined || v === '' ? null : Number(v));
    const worth = (rubric || []).reduce((n, cr) => n + (num(cr.points) || 0), 0);
    const marked = (rubric || []).filter((cr) => num((assessment || {})[cr.id]?.points) !== null);
    return {
      marked: marked.length > 0,
      text: marked.length
        ? `${store.fmtPts(marked.reduce((n, cr) => n + num(assessment[cr.id].points), 0))} / ${store.fmtPts(worth)}`
        : `${store.fmtPts(worth)} pts`,
    };
  }

  /** The rubric, however it was asked for (the button beside Submit assignment, See breakdown beside
   *  a grade): on the desktop the ring (content/app/rubric-ring.js, loaded on the first press), on a
   *  phone the grid as a bottom sheet. The grid as a dialog stays as the desktop's fallback, should
   *  the ring not load. */
  function openRubric(a, sub) {
    if (!BCV.phone?.active() && a?.rubric?.length) {
      const from = document.activeElement;
      const ring = () => BCV.rubricRing.open(a, sub, { from });
      if (BCV.rubricRing) { ring(); return; }
      BCV.lazy.load('rubric').then(ring).catch(() => rubricSheet(a, sub));
      return;
    }
    rubricSheet(a, sub);
  }
  /** A rubric button's morph (2.98.87): on the desktop, the pointer resting on it turns it into the ring in
   *  miniature with the points in the middle (rubric-ring.js morph, loaded on the first), and back as it leaves. */
  function rubricMorph(btn, a, sub) {
    if (!btn || !a?.rubric?.length) return btn;
    let timer = 0;
    btn.addEventListener('pointerenter', (e) => {
      if (e.pointerType !== 'mouse' || BCV.phone?.active()) return;
      clearTimeout(timer);
      timer = setTimeout(() => {
        const show = () => { if (btn.isConnected && btn.matches(':hover')) BCV.rubricRing.morph(btn, a, sub); };
        if (BCV.rubricRing) show(); else BCV.lazy.load('rubric').then(show).catch(() => {});
      }, 90);
    });
    btn.addEventListener('pointerleave', () => { clearTimeout(timer); timer = 0; BCV.rubricRing?.unmorph(btn); });
    return btn;
  }
  function rubricSheet(a, sub) {
    const assess = sub?.rubric_assessment || {};
    const title = a.rubric_settings?.title || 'Rubric';
    const score = rubricScore(a.rubric, assess);
    const worth = score.text.split(' / ').pop().replace(' pts', '');
    const note = score.marked ? `Marked ${score.text} · ${a.rubric.length === 1 ? '1 criterion' : `${a.rubric.length} criteria`}`
      : `Not yet graded · shown before you submit`;
    const foot = score.marked ? 'One level is marked per criterion; the points beside each name are what it was given.'
      : 'Your instructor marks one level per criterion. Totals appear here once grades post.';
    const grid = rubricGrid(a.rubric, assess);
    // the badge is the rubric's own total, which is not always the assignment's
    const badge = U.el('bcv-rubg__badge', [U.text('bcv-rubg__badgen', worth), U.text('bcv-rubg__badgeu', 'pts')]);
    if (BCV.phone?.active()) {
      BCV.phone.openSheet({ label: 'Rubric', title, note, cls: 'bcv-ph-sheet--rub', body: U.el('bcv-rubsheet', [grid, U.text('bcv-rubg__foot bcv-pretty', foot)]) });
      return;
    }
    document.querySelector('.bcv-sheet-ov')?.remove();
    const ov = U.el('bcv-sheet-ov', null, { role: 'dialog', 'aria-label': 'Rubric' });
    const close = () => BCV.ui.dismiss(ov);
    ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
    ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    ov.append(U.el('bcv-sheet bcv-sheet--rub', [
      U.el('bcv-sheet__head bcv-sheet__head--rub', [
        badge,
        h('div', { style: { flex: '1', minWidth: '0' } }, [U.text('bcv-sheet__title', title), U.text('bcv-sheet__desc', note)]),
        h('button', { type: 'button', class: 'bcv-sheet__close', 'aria-label': 'Close', onclick: close }, U.svg(IC.close, { size: 13, stroke: 'var(--bcv-ink2)', width: 2.3 })),
      ]),
      U.el('bcv-rubsheet', grid),
      U.text('bcv-rubg__foot bcv-pretty', foot),
    ]));
    document.body.append(ov);
    ov.tabIndex = -1;
    ov.focus();
  }

  function linksFrom(html, max = 4) {
    if (!html) return [];
    const doc = new DOMParser().parseFromString(String(html), 'text/html');
    const out = [];
    const seen = new Set();
    for (const a of doc.querySelectorAll('a[href]')) {
      const text = a.textContent.trim().replace(/\s+/g, ' ');
      const href = a.getAttribute('href');
      if (!text || text.length > 28 || !href || seen.has(href) || /^(#|mailto:|javascript:)/i.test(href)) continue;
      seen.add(href);
      out.push({ text, href });
      if (out.length >= max) break;
    }
    return out;
  }

  function typeIcon(a) {
    const t = a.submission_types || [];
    // (2.99.42) with the word the Mac's rows lead with: Quiz, Discussion, Tool or Assignment
    if (a.is_quiz_assignment || a.quiz_id || t.includes('online_quiz')) return { icon: IC.bolt, quiz: true, kind: 'Quiz' };
    if (t.includes('discussion_topic') || a.discussion_topic) return { icon: IC.disc, quiz: false, kind: 'Discussion' };
    return { icon: IC.doc, quiz: false, kind: t.includes('external_tool') ? 'Tool' : 'Assignment' };
  }
  /** Whether the assignment already has a grade the student may see (marked, and posted — Canvas
   *  holds a mark back until the teacher posts it): then it is done, whatever its due date says. */
  const hasGrade = (a) => { const s = a?.submission || {}; return s.workflow_state === 'graded' && s.score !== null && s.score !== undefined && s.posted_at !== null; };
  /** "13/16 pts" once graded (a letter, pass/fail or percent grade as the grade itself), else what
   *  it is worth: "10 pts", or "no points". Never a dash standing in for a score. */
  function ptsLabel(a) {
    const s = a.submission || {};
    const poss = a.points_possible;
    const worth = poss === null || poss === undefined ? 'no points' : `${store.fmtPts(poss)} pts`;
    if (!hasGrade(a)) return worth;
    if (s.grade !== null && s.grade !== undefined && a.grading_type && a.grading_type !== 'points') return `${s.grade} · ${worth}`;
    return `${store.fmtPts(s.score)}/${poss ?? '–'} pts`;
  }
  /** Where the work stands, as a badge — the same words as the To Do list, the Dashboard and the
   *  search hub (store.workStatus): Missing, Late, Submitted, Graded (late), Excused, Opens …, Closed,
   *  On paper, Not submitted. */
  function statusBadge(a) {
    const st = store.workStatus(a);
    return U.statusBadge(st.graded ? { word: st.late ? 'Graded · late' : 'Graded', kind: 'good' } : st, '');
  }

  // The rail groups the context's own tabs the way the mockup does. Anything
  // internal that is not listed lands under Materials; external tools are
  // plain links under Campus tools.
  const RAIL_GROUPS = [
    ['Course', ['home', 'announcements', 'assignments', 'discussions', 'quizzes', 'grades', 'modules']],
    ['Materials', ['pages', 'files', 'syllabus', 'rubrics', 'outcomes']],
    ['People', ['people', 'groups', 'collaborations', 'conferences', 'chat']],
  ];
  const EXT_ARROW = 'M9 6h9v9M18 6L7 17';

  /** Counts for the rail pills, each from one API field: unread
   *  announcements, and grades posted in the last seven days. */
  async function railCounts(shell) {
    const c = shell.course;
    const out = {};
    const [anns, asg] = await Promise.all([
      store.announcements(c.id, { kind: shell.kind }).catch(() => null),
      shell.kind === 'courses' ? store.assignments(c.id).catch(() => null) : null,
    ]);
    if (anns) out.announcements = anns.filter((a) => a.read_state === 'unread').length;
    if (asg) {
      const since = Date.now() - 7 * U.DAY;
      out.grades = asg.filter((a) => a.submission?.workflow_state === 'graded' && U.parse(a.submission.graded_at) > since && !a.submission.excused).length;
    }
    return out;
  }

  // ---- the tabs' first requests, made early ----------------------------------------------------
  // What each tab asks for first. It is started under a pointer resting on the tab's rail row (or on
  // any link to it), alongside the shell when it is the tab being opened (so the column and the rail
  // arrive together rather than one after the other), and at idle for every other tab once a course
  // has landed, and for each favourite course's home (app.js warmAround). This is the per-page memo the
  // tab would fill on its own, filled a moment sooner. `front: false` leaves a home's front page out:
  // a page read can count in Canvas as the student viewing it, so it is read ahead only for the course
  // on show, or under the pointer (app.js).
  const homeWarm = (id, kind, view, front) => {
    const main = view === 'modules' ? [store.modules(id)]
      : view === 'assignments' ? [store.assignments(id), store.assignmentGroups(id)]
        : view === 'syllabus' ? [store.syllabus(id)]
          : view === 'feed' ? [store.courseStream(id, { kind })]
            : front ? [store.frontPage(id, { kind })] : [];
    return [...main, store.courseTodo(id)];
  };
  const TAB_WARM = {
    // a group's home is its front page and stream; a course's is whatever its instructor chose as
    // the home view, read off the course list (the course's own record, until the list is here)
    home: (id, kind, { front = true } = {}) => {
      if (kind === 'groups') return [front ? store.frontPage(id, { kind }) : null, store.courseStream(id, { kind })];
      const view = (BCV.canvas.ready('courses:all') || []).find((c) => String(c.id) === id)?.default_view;
      if (view) return homeWarm(id, kind, view, front);
      return [store.course(id).then((c) => Promise.all(homeWarm(id, kind, c?.defaultView || 'wiki', front)))];
    },
    stream: (id, kind) => [store.courseStream(id, { kind })],
    announcements: (id, kind) => [store.announcements(id, { kind })],
    assignments: (id) => [store.assignments(id)],
    grades: (id) => [store.assignmentGroups(id)],
    discussions: (id, kind) => [store.discussions(id, { kind })],
    people: (id, kind) => [store.people(id, { kind }), kind === 'courses' ? store.sections(id) : null, kind === 'courses' ? store.courseGroups(id) : null],
    pages: (id, kind) => [store.pages(id, { kind })],
    files: (id, kind) => [store.rootFolder(id, { kind }).then((f) => (f ? store.folderContents(f.id) : null))],
    quizzes: (id) => [store.quizzes(id)],
    modules: (id) => [store.modules(id)],
    syllabus: (id) => [store.syllabus(id)],
  };
  const GROUP_TABS = ['home', 'stream', 'announcements', 'discussions', 'people', 'pages', 'files'];
  /** Starts a tab's first requests; resolves when they have answered (never rejects). */
  function warmTab(kind, id, tab, opts = {}) {
    const f = TAB_WARM[tab];
    if (!f || !id || (kind === 'groups' && !GROUP_TABS.includes(tab))) return Promise.resolve();
    try {
      return Promise.all(f(String(id), kind, opts).map((p) => (p ? Promise.resolve(p).catch(() => {}) : null)));
    } catch {
      return Promise.resolve(); // nothing to warm
    }
  }
  /** The tabs a course (or a group) can have read ahead, in the rail's order (app.js warmAround runs them one per idle moment). */
  const warmTabIds = (kind) => (kind === 'groups' ? GROUP_TABS : Object.keys(TAB_WARM));

  /** Header (back link, colour, title, pills) plus the
   *  grouped rail of the context's tabs, for courses and groups. */
  /** (2.99.42) With one sidebar, as the Mac lays a course's section out: the section's own name is the title (Assignments,
   *  Modules…), the course's name under it, and the term and the course's details left to its Home. Home, a page of
   *  the course and the two-sidebar layout keep the course's name as the title. */
  function sectionTitle(app, screen, shell, activeId) {
    const head = screen.querySelector('.bcv-head--course');
    const h1 = head?.querySelector('.bcv-course__title-row .bcv-h1');
    if (!h1) return;
    const c = shell.course;
    const tab = (shell.tabs || []).find((t) => t.id === activeId && !t.external);
    const section = shell.kind === 'courses' && app.oneBar?.() && !BCV.phone?.active() && tab && activeId !== 'home' ? tab.label : null;
    h1.textContent = section || c.name;
    head.classList.toggle('is-section', !!section);
    let of = head.querySelector('.bcv-course__of');
    if (section && !of) head.querySelector('.bcv-course__title-row').after(of = U.text('bcv-course__of bcv-ellip', ''));
    if (of) of.textContent = section ? c.name : '';
  }
  async function contextShell(ctx, shell, { backLabel, backHref, tabs, activeId, pills = [] }) {
    const { app } = ctx;
    const c = shell.course;
    const narrow = !!(await store.pref('courseSideCollapsed', false));
    // --bcv-rail-wash: the loading wash for a pressed rail row, the course colour at 20% (30% in dark), mockup 14
    const screen = U.el('bcv-screen bcv-screen--ctx', null, { style: { '--w': '1180px', '--bcv-rail-color': c.color, '--bcv-rail-tint': c.palette.tint, '--bcv-rail-text': c.palette.text, '--bcv-rail-wash': U.rgba(c.color, shell.dark ? 0.3 : 0.2) } });
    // Back leaves the course for the screen it was entered from (the Dashboard, To Do, a group…),
    // or the list it belongs to when there is nothing to come back from
    const inside = (e) => e.url === c.url || e.url.startsWith(`${c.url}/`) || e.url.startsWith(`${c.url}?`);
    const back = app.backTo ? app.backTo({ label: backLabel, href: backHref }, { skip: inside }) : { label: backLabel, href: backHref };
    if (!activeId || activeId === 'home') app.nameHere?.(c.shortName || c.name); // the next screen's Back names the course (or group) itself
    const head = U.el('bcv-head bcv-head--course', U.el('bcv-head__in', [
      h('button', { type: 'button', class: 'bcv-linkbtn bcv-ctx__back', onclick: () => { app.markBack?.(); app.go(back.href); } }, [U.svg(IC.back, { size: 14, stroke: 'var(--bcv-blue)', width: 2.1 }), back.label]),
      U.el('bcv-course__title-row', [
        shell.kind === 'courses'
          ? h('button', { type: 'button', class: 'bcv-dot bcv-dot--sq bcv-colorbtn', title: 'Change course colour', 'aria-label': 'Change course colour', style: { background: c.color }, onclick: (e) => U.colorMenu(e.currentTarget, c.color, async (hex) => {
            try {
              await store.setColor(c.id, hex);
              app.loadShellData({ force: true });
              app.render();
            } catch (err) {
              U.toast(`Could not change the colour: ${err.message}`, { error: true });
            }
          }) })
          : h('span', { class: 'bcv-dot bcv-dot--sq', style: { background: c.color } }),
        h('h1', { class: 'bcv-h1 bcv-h1--30', text: c.name }),
        ...pills.filter(Boolean),
      ]),
    ]));
    // (2.99.20: no Immersive Reader — the screens still note their body as shell.reader, which nothing reads now)
    // under the title: who teaches it, its code (or its real name under a nickname), the sections,
    // and the term's dates — the facts Canvas's own course page keeps in its header
    if (!BCV.phone?.active() && shell.kind === 'courses') {
      const termDates = c.termStart && c.termEnd ? `${U.fmtShort(c.termStart)} – ${U.fmtShort(c.termEnd)}` : null;
      const detail = [(c.teachers || []).join(', ') || null, c.nickname ? c.originalName : (c.code && c.code !== c.name ? c.code : null), ...(c.sections || []), termDates].filter(Boolean).join(' · ');
      if (detail) head.querySelector('.bcv-course__title-row').after(U.text('bcv-course__detail bcv-ellip', detail));
    }
    // on a phone the rail folds into a chip row under the title on the tabs below Home (Home lists
    // them instead), with one line of detail: the course code (or its real name), the term, the section
    if (BCV.phone?.active()) {
      const detail = [c.nickname ? c.originalName : (c.code && c.code !== c.name ? c.code : null), c.term, ...(c.sections || [])].filter(Boolean).join(' · ');
      if (detail) head.querySelector('.bcv-course__title-row').after(U.text('bcv-ph-head__sub bcv-ellip', detail));
      head.querySelector('.bcv-head__in').append(BCV.phone.courseChips(app, tabs, activeId)); // (Home too: every section a tap away at the top, not at the end of the open work)
    }

    // ---- rail --------------------------------------------------------------------
    const internal = tabs.filter((t) => !t.external);
    const external = tabs.filter((t) => t.external);
    const placed = new Set();
    const groups = RAIL_GROUPS.map(([title, ids]) => {
      const items = ids.map((id) => internal.find((t) => t.id === id)).filter(Boolean);
      items.forEach((t) => placed.add(t.id));
      return { title, items };
    });
    const rest = internal.filter((t) => !placed.has(t.id));
    if (rest.length) groups[1].items.push(...rest);
    const countEls = {};
    const item = (t) => {
      const active = t.id === activeId;
      const count = h('span', { class: 'bcv-rail__count' });
      countEls[t.id] = count;
      return h('button', {
        type: 'button',
        class: `bcv-rail__item ${active ? 'is-active' : ''}`,
        dataset: { tab: t.id, href: t.href }, // (the pointer resting on it, or the press, starts the tab's data loading: app.js wireIntent)
        title: t.label,
        onclick: () => { if (shell.railLoad === t.id) return; shell.markRail(t.id); app.go(t.href); }, // the pressed row fills until its column lands; a repeat press is a no-op
      }, [
        h('span', { class: 'bcv-rail__tile' }, U.svg(t.icon, { size: 20, width: 1.8 })), // the glyph in the course colour (mockup 11)
        h('span', { class: 'bcv-rail__label', text: t.label }),
        count,
      ]);
    };
    const rail = h('nav', { class: `bcv-rail ${narrow ? 'is-narrow' : ''}`, 'aria-label': `${c.name} menu` }, [
      ...groups.filter((g) => g.items.length).map((g) => U.enter(U.el('bcv-rail__group', [U.text('bcv-rail__title', g.title), U.el('bcv-rail__list', g.items.map(item))]))),
      external.length ? U.enter(U.el('bcv-rail__group bcv-rail__group--ext', [
        U.text('bcv-rail__title', 'Campus tools'),
        U.el('bcv-rail__list', external.map((t) => h('button', {
          type: 'button',
          class: `bcv-rail__ext ${t.id === activeId ? 'is-active' : ''}`,
          dataset: { tab: t.id },
          title: t.label,
          onclick: (e) => { if (BCV.exttool) BCV.exttool.openLink({ title: t.label, href: t.href, from: e.currentTarget }); else app.go(t.href); }, // (a tab of its own: this page stays where it is)
        }, [h('span', { class: 'bcv-rail__label', text: t.label }), U.svg(EXT_ARROW, { size: 12, width: 2, style: { flex: 'none' } })]))),
      ])) : null,
    ]);
    // the rail's own loading key (separate from the sidebar's): the row named fills with the course
    // colour; null clears it. A row already filling keeps its fill (the animation never restarts).
    shell.railLoad = null;
    shell.markRail = (id) => {
      shell.railLoad = id;
      for (const b of rail.querySelectorAll('.bcv-rail__item, .bcv-rail__ext')) {
        const on = !!id && b.dataset.tab === id;
        b.classList.toggle('is-loading', on);
        const fill = b.querySelector('.bcv-load');
        if (on && !fill) b.prepend(h('span', { class: 'bcv-load bcv-load--rail', 'aria-hidden': 'true' }));
        else if (!on && fill) fill.remove();
      }
    };
    let syncToggle = () => {};
    const toggle = h('button', { type: 'button', class: 'bcv-rail__toggle', onclick: () => {
      const on = rail.classList.toggle('is-narrow');
      store.setPref('courseSideCollapsed', on);
      syncToggle();
    } });
    syncToggle = () => {
      const on = rail.classList.contains('is-narrow');
      toggle.title = on ? 'Expand course menu' : 'Collapse course menu';
      toggle.setAttribute('aria-label', toggle.title);
      toggle.setAttribute('aria-expanded', on ? 'false' : 'true');
      toggle.replaceChildren(
        h('span', { class: 'bcv-rail__tile' }, U.svg(on ? IC.chevron : IC.back, { size: 13, width: 2.1 })),
        h('span', { class: 'bcv-rail__label', text: on ? 'Expand' : 'Collapse' }),
      );
    };
    syncToggle();
    rail.append(toggle);
    railCounts(shell).then((counts) => {
      if (!ctx.alive()) return;
      if (shell.kind === 'courses') ctx.app.setCourseNav?.({ id: shell.course.id, counts }); // (2.99.39: the sidebar's rows count as the rail's)
      for (const [id, n] of Object.entries(counts)) {
        const el = countEls[id];
        if (!el || !n) continue;
        el.textContent = String(n);
        el.closest('.bcv-rail__item')?.classList.add('has-count');
      }
    });

    const cmain = U.el('bcv-cmain');
    screen.append(head, U.el('bcv-cwrap', [rail, cmain]));
    // the rail starts just below the sticky header, whatever height the title wraps to (ui.watchLayout: measured as it lands and whenever it changes).
    // Set on the screen the head is in when measured: the callers move the children into a screen of their own, so this one is left behind.
    U.watchLayout(head, (r) => (head.parentElement || screen).style.setProperty('--bcv-chead', `${Math.round(r.height)}px`));
    sectionTitle(app, screen, shell, activeId);
    return { screen, content: cmain, head };
  }

  let liveShell = null; // { el, shell }: the course shell on screen, kept between the course's tabs
  async function render(ctx) {
    const { app, route } = ctx;
    const id = route.courseId;
    const dark = app.isDark();
    const screen = U.el('bcv-screen', null, { style: { '--w': '1180px' } });
    const head = U.el('bcv-head bcv-head--course');
    screen.append(head, U.el('bcv-body', U.loading()));
    head.append(U.el('bcv-head__in', U.loading()));

    warmTab('courses', id, route.tab); // the column's own data, in the same round trip as the tabs
    const [course, tabsRaw] = await Promise.all([store.course(id).catch(() => null), store.tabs(id).catch(() => [])]);
    if (!ctx.alive()) return screen;
    if (!course) {
      head.replaceChildren(U.el('bcv-head__in', h('h1', { class: 'bcv-h1 bcv-h1--30', text: 'Course' })));
      screen.lastChild.replaceChildren(U.errorBox('This course could not be loaded. You may not have access to it.'));
      return screen;
    }
    // (The quiz flow lives in the course's column: its intro and feedback sit under the header beside
    // the rail; an attempt folds the chrome away and takes the page — see the quiz screen.)
    // Handing work in on the phone: the submission flow takes the main column. On the desktop the
    // block lives inside the assignment page itself (mockup 11), so ?bcv=submit just scrolls to it.
    if (route.tab === 'assignment' && route.arg && route.params.get('bcv') === 'submit' && BCV.phone?.active()) return BCV.screens.submit.render(ctx, course);

    const tabs = (tabsRaw || []).filter((t) => !t.hidden && t.id !== 'settings').map((t) => {
      const external = t.type === 'external' || String(t.id).startsWith('context_external_tool');
      const path = (() => {
        try {
          return new URL(t.html_url || t.full_url, location.origin).pathname;
        } catch {
          return `/courses/${id}`;
        }
      })();
      return { id: t.id, label: t.label, href: path, external, icon: external ? IC.shield : (TAB_ICONS[t.id] || IC.page) };
    });
    if (!tabs.some((t) => t.id === 'home')) tabs.unshift({ id: 'home', label: 'Home', href: `/courses/${id}`, icon: IC.book });

    const activeId = (() => {
      const t = ROUTE_TAB[route.tab] || route.tab;
      if (tabs.some((x) => x.id === t)) return t;
      if (route.tab === 'tool') return tabs.find((x) => x.href === route.path)?.id || null;
      return tabs.find((x) => x.href !== `/courses/${id}` && route.path.startsWith(x.href))?.id || (route.tab === 'native' ? null : 'home');
    })();

    // Within one course the header and the rail stay put between its tabs: only the main column
    // changes hands (the rail's entrance plays once; its collapse state and its counts carry over).
    const kept = keptShell('courses', id, course, dark);
    const shell = kept ? liveShell.shell : { course, reader: null, dark, kind: 'courses' };
    shell.course = course; // (the kept shell carries the course as it is now: its score moves between tabs, and the Grades total with it)
    shell.tabs = tabs;
    shell.activeId = activeId;
    shell.reader = null;
    app.setCourseNav?.({ id, course, tabs, activeId }); // (2.99.39: one sidebar — the course's sections under its row there)
    let content;
    if (kept) {
      syncShell(ctx, kept, shell, activeId);
      content = kept.querySelector('.bcv-cmain');
      content.classList.add('is-loading'); // the old column dims until the new one lands
    } else {
      const { screen: shellEl, content: cmain } = await contextShell(ctx, shell, { backLabel: 'All Courses', backHref: '/courses', tabs, activeId, pills: [course.term ? h('span', { class: 'bcv-pill bcv-pill--term', text: course.term }) : null] });
      if (!ctx.alive()) return screen;
      screen.replaceChildren(...shellEl.childNodes);
      screen.className = shellEl.className;
      screen.style.cssText = shellEl.style.cssText;
      screen.dataset.bcvCtx = `courses:${id}`;
      liveShell = { el: screen, shell }; // (a reference of our own: an expando on the node does not survive the wrapper)
      content = cmain;
    }
    const out = kept || screen;
    shell.markRail?.(activeId); // the row for this tab fills while its column is fetched

    const B = BCV.screens.courseTabs;
    const D = BCV.screens.courseDetail;
    // Canvas's address for somebody else's mark (an observer's student): Canvas's own page, as asked
    if (route.uid && route.uid !== 'self') {
      const me = await store.me().catch(() => null);
      if (!ctx.alive()) return out;
      if (me?.id && String(me.id) !== String(route.uid)) {
        app.go(`${route.url}${route.url.includes('?') ? '&' : '?'}bcv=native`, { replace: true });
        return out;
      }
    }
    let el;
    switch (route.tab) {
      case 'home': el = await B.home(ctx, shell); break;
      case 'stream': el = await B.stream(ctx, shell); break;
      case 'announcements': el = await B.announcements(ctx, shell); break;
      case 'assignments': el = await B.assignments(ctx, shell); break;
      case 'discussions': el = await B.discussions(ctx, shell); break;
      case 'grades': el = await BCV.screens.grades.render(ctx, shell); break;
      case 'people': el = await B.people(ctx, shell); break;
      case 'pages': el = await B.pages(ctx, shell); break;
      case 'files': case 'folder': el = await B.files(ctx, shell); break;
      case 'file': el = await B.files(ctx, shell); if (ctx.alive() && route.arg) BCV.viewer?.open({ id: route.arg }, { context: course }); break; // a link to one file: the folder behind, the file in the viewer
      case 'quizzes': el = await B.quizzes(ctx, shell); break;
      case 'modules': el = await B.modules(ctx, shell); break;
      case 'announcement': el = await D.discussion(ctx, shell, { announcement: true }); break;
      case 'discussion': el = await D.discussion(ctx, shell, {}); break;
      // ?bcv=feedback is the mark's own screen, as it is for a quiz: the same route, a different view
      case 'assignment': el = route.params.get('bcv') === 'feedback' ? await BCV.screens.feedback.render(ctx, shell) : await D.assignment(ctx, shell); break;
      case 'syllabus': el = await D.syllabus(ctx, shell); break;
      case 'page': el = await D.page(ctx, shell); break;
      case 'quiz': el = await BCV.screens.quiz.render(ctx, course); break; // (2.99.55) a quiz opens on its intro, as on the Mac: no page of facts before it
      default: el = B.native(ctx, shell);
    }
    if (!ctx.alive()) return out;
    // within a kept shell the new column moves in as a screen would (app.js swap), the header and the rail holding still
    const put = () => { content.classList.remove('is-loading'); content.replaceChildren(el); };
    if (kept && ctx.swap) await ctx.swap(put, content); else put();
    shell.markRail?.(null);
    document.title = `${course.name} · ${app.siteName()}`;
    return out;
  }

  /** The shell already on screen, when it is this course's or group's and still current (the same
   *  appearance, colour and name); the phone's course screens are pushes of their own. */
  function keptShell(kind, id, course, dark) {
    if (BCV.phone?.active() || !liveShell) return null;
    const { el, shell } = liveShell;
    if (!el.isConnected || el.parentNode?.id !== 'bcv-main' || el.dataset.bcvCtx !== `${kind}:${id}` || shell.dark !== dark) return null;
    if (shell.course.color !== course.color || shell.course.name !== course.name) return null; // a new colour or nickname: the header is drawn again
    return el;
  }
  /** Remembers a freshly built shell as the one on screen, so the next tab within it is kept. */
  function holdShell(kind, id, el, shell) {
    el.dataset.bcvCtx = `${kind}:${id}`;
    liveShell = { el, shell };
  }
  /** The state object behind the kept shell — an expando on the node would not survive the
   *  wrapper, so it is held here. Only meaningful right after keptShell() has said yes. */
  const heldShell = () => liveShell?.shell || null;
  /** A kept shell follows the route: the active rail item, and counts read again. */
  function syncShell(ctx, screen, shell, activeId) {
    sectionTitle(ctx.app, screen, shell, activeId);
    for (const b of screen.querySelectorAll('.bcv-rail__item, .bcv-rail__ext')) b.classList.toggle('is-active', b.dataset.tab === activeId);
    railCounts(shell).then((counts) => {
      if (!ctx.alive()) return;
      if (shell.kind === 'courses') ctx.app.setCourseNav?.({ id: shell.course.id, counts }); // (2.99.39: the sidebar's rows count as the rail's)
      for (const b of screen.querySelectorAll('.bcv-rail__item')) {
        const n = counts[b.dataset.tab];
        const el = b.querySelector('.bcv-rail__count');
        if (!el || n === undefined) continue;
        el.textContent = n ? String(n) : '';
        b.classList.toggle('has-count', !!n);
      }
    });
  }

  // ---- tabs ------------------------------------------------------------------------------------
  const T = {};
  const body = (mod = 'bcv-body--18') => U.el(`bcv-body ${mod}`);

  T.native = (ctx, shell) => {
    const b = body('bcv-body--24');
    b.append(BCV.screens.native.block(ctx));
    return b;
  };

  T.home = async (ctx, shell) => {
    if (BCV.phone?.active()) return BCV.phone.courseHome(ctx, shell); // next up, open work, turned in, the rest as a list
    const { app } = ctx;
    const c = shell.course;
    const b = body('bcv-body--course-cols');
    const left = U.enter(h('div', { class: 'bcv-col', style: { flex: '1 1 440px' } })); // both columns arrive with the rail, on the same beat
    const right = U.enter(h('div', { class: 'bcv-col bcv-col--16', style: { flex: '1 1 300px' } }));
    b.append(left, right);
    left.append(U.loading());

    // right column: course links + course To Do
    right.append(U.card([
      linkRow('View Course Stream', IC.stream, `${c.url}?view=feed`),
      linkRow('View Course Calendar', IC.cal, `/calendar?include_contexts=course_${c.id}`),
      linkRow('View Course Notifications', IC.bell, `${c.url}/notifications`),
    ], 'bcv-card--list'));
    function linkRow(lbl, icon, href) {
      return U.row([U.svg(icon, { size: 15, stroke: 'var(--bcv-blue)', width: 1.8, style: { flex: 'none' } }), U.text('bcv-course-link', lbl, 'span'), U.chev()], { mod: 'bcv-row--p13-16', onClick: () => app.go(href) });
    }
    const todoCard = U.card(U.loading(), 'bcv-card--list');
    right.append(h('div', {}, [U.label('To Do'), todoCard]));
    store.courseTodo(c.id).then((items) => {
      if (!ctx.alive()) return;
      const list = (items || []).filter((t) => t.assignment || t.quiz || t.type);
      if (!list.length) {
        todoCard.replaceChildren(U.empty('Nothing to do right now.'));
        return;
      }
      todoCard.replaceChildren(...list.slice(0, 8).map((t) => {
        const a = t.assignment || t.quiz || {};
        const when = a.due_at ? U.fmtAt(a.due_at) : (a.todo_date ? U.fmtAt(a.todo_date) : '');
        const rowEl = U.row([
          h('a', { class: 'bcv-row__body', href: a.html_url || t.html_url || c.url, style: { color: 'inherit' } }, [U.text('bcv-row__title bcv-row__title--14 bcv-ellip', a.name || a.title || 'To do'), U.text('bcv-row__sub bcv-row__sub--115', when)]),
          U.iconbtn(IC.close, { size: 22, iconSize: 11, title: 'Ignore', onClick: async () => {
            rowEl.style.opacity = '.4';
            try {
              await store.ignoreTodo(t, c.id);
              rowEl.remove();
              if (!todoCard.children.length) todoCard.append(U.empty('Nothing to do right now.'));
            } catch (e) {
              rowEl.style.opacity = '';
              U.toast(`Could not ignore: ${e.message}`, { error: true });
            }
          } }),
        ], { mod: 'bcv-row--p12-16' });
        return rowEl;
      }));
    });

    // (2.99.42) as the Mac's Home: the course's latest announcements over what the instructor chose for it, with a way
    // to all of them; nothing at all where the course has none
    const annBlock = h('div', { class: 'bcv-home__ann' });
    const put = (el) => left.replaceChildren(annBlock, el);
    store.announcements(c.id, { kind: shell.kind }).then((list) => {
      if (!ctx.alive()) return;
      if (!list || !list.length) { annBlock.remove(); return; }
      annBlock.replaceChildren(
        U.el('bcv-group__head bcv-home__annhead', [U.h2('Announcements'), h('button', { type: 'button', class: 'bcv-linkbtn bcv-home__all', text: 'All Announcements', onclick: () => app.go(`${c.url}/announcements`) })]),
        U.card(list.slice(0, 3).map((a) => U.row([
          U.svg(TAB_ICONS.announcements, { size: 15, stroke: c.palette.text, width: 1.9, style: { flex: 'none' } }),
          U.dot(a.read_state === 'unread' ? '#0a84ff' : 'transparent', 'bcv-dot--7'),
          U.text(`bcv-row__title bcv-row__title--14 bcv-ellip bcv-home__anntitle ${a.read_state === 'unread' ? 'is-unread' : ''}`, a.title || 'Announcement', 'span'),
          U.text('bcv-row__when bcv-home__annwhen', [a.author?.display_name || a.user_name || null, U.fmtShort(a.posted_at || a.delayed_post_at)].filter(Boolean).join(' · '), 'span'),
        ], { mod: 'bcv-row--p12-16', onClick: () => app.go(`${c.url}/announcements/${a.id}`) })), 'bcv-card--list'),
      );
    }).catch(() => annBlock.remove());
    // left column: what the instructor chose as the home view
    const view = c.defaultView;
    if (view === 'modules') {
      put(await T.modulesBlock(ctx, shell));
    } else if (view === 'assignments') {
      put(await T.assignmentsBlock(ctx, shell));
    } else if (view === 'syllabus') {
      const html = await store.syllabus(c.id).catch(() => '');
      if (!ctx.alive()) return b;
      shell.reader = { title: 'Syllabus', html };
      put(U.card(U.el('bcv-front', [frontHead(IC.page, 'Syllabus'), prose(html), chips(html)]), 'bcv-card--22'));
    } else if (view === 'feed') {
      put(await T.streamBlock(ctx, shell));
    } else {
      const fp = await store.frontPage(c.id, { kind: shell.kind }).catch(() => null);
      if (!ctx.alive()) return b;
      if (fp && fp.body !== undefined) {
        shell.reader = { title: fp.title, html: fp.body };
        put(U.card(U.el('bcv-front', [frontHead(IC.doc, `Front page · ${fp.title}`), prose(fp.body || ''), chips(fp.body)]), 'bcv-card--22'));
      } else {
        put(await T.modulesBlock(ctx, shell));
      }
    }
    function frontHead(icon, lbl) {
      return U.el('bcv-front__head', [U.svg(icon, { size: 14, stroke: 'var(--bcv-ink3)', width: 1.9 }), U.text('bcv-label bcv-label--inline', lbl, 'span')]);
    }
    function chips(html) {
      const links = linksFrom(html);
      return links.length ? U.el('bcv-chips', links.map((l) => h('a', { class: 'bcv-chip', href: l.href, text: l.text }))) : null;
    }
    return b;
  };

  T.streamBlock = async (ctx, shell) => {
    const { app } = ctx;
    const c = shell.course;
    const [stream, seen] = await Promise.all([store.courseStream(c.id, { kind: shell.kind }).catch(() => null), store.streamSeen().catch(() => new Set())]);
    if (!stream) return U.emptyCard('The course stream could not be loaded.');
    if (!stream.length) return U.emptyCard('No recent activity in this course.');
    const KIND = { Announcement: [IC.bell, 'Announcement'], DiscussionTopic: [IC.disc, 'Discussion'], Submission: [IC.chart, 'Grade posted'], Message: [IC.doc, 'Notification'], Conversation: [IC.mail, 'Message'] };
    return U.card(stream.slice(0, 30).map((a) => {
      const [icon, kind] = KIND[a.type] || [IC.doc, a.type];
      const url = a.html_url || c.url;
      const rowEl = U.row([
        U.dot(a.read_state === false && !seen.has(String(a.id)) ? '#0a84ff' : 'transparent', 'bcv-act__dot'),
        U.tile(icon, { color: c.palette.text, tint: c.palette.tint, size: 32, iconSize: 16 }),
        U.el('bcv-row__body', [
          U.el('bcv-row__head', [U.text('bcv-act__title bcv-pretty', a.title || kind, 'span'), U.text('bcv-row__when', U.fmtShort(a.updated_at || a.created_at), 'span')]),
          U.text('bcv-act__kind', kind),
          U.text('bcv-row__preview bcv-row__preview--13 bcv-pretty', htmlToText(a.message || '', 160).replace(/\s+/g, ' ')),
        ]),
      ], { mod: 'bcv-row--p15 bcv-row--top', href: url });
      rowEl.addEventListener('click', (e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        store.markStreamSeen(a.id).catch(() => {}).then(() => app.go(url));
      });
      return rowEl;
    }), 'bcv-card--list');
  };
  T.stream = async (ctx, shell) => {
    const b = body();
    b.append(U.groupHead('Course stream', 'Recent activity in this course'), await T.streamBlock(ctx, shell));
    return b;
  };

  T.announcements = async (ctx, shell) => {
    const { app } = ctx;
    const c = shell.course;
    const b = body();
    let filter = 'all';
    let query = '';
    const listWrap = h('div');
    b.append(U.el('bcv-head__tools', [U.search('Search announcements', (q) => { query = q.toLowerCase(); draw(); }, 'bcv-search--200'), U.seg([['all', 'All'], ['unread', 'Unread']], filter, (v) => { filter = v; draw(); })]), listWrap);
    b.querySelector('.bcv-head__tools').style.marginTop = '0';
    listWrap.append(U.loading());
    const list = await store.announcements(c.id, { kind: shell.kind }).catch(() => null);
    if (!ctx.alive()) return b;
    function draw() {
      if (!list) return listWrap.replaceChildren(U.errorBox('Announcements could not be loaded.'));
      const items = list.filter((a) => (filter !== 'unread' || a.read_state === 'unread') && (!query || `${a.title} ${a.author?.display_name || ''} ${htmlToText(a.message || '')}`.toLowerCase().includes(query)));
      if (!items.length) return listWrap.replaceChildren(U.emptyCard(query ? 'No announcements match.' : filter === 'unread' ? 'No unread announcements.' : 'No announcements yet.'));
      listWrap.replaceChildren(U.card(items.map((a) => U.row([
        U.dot(a.read_state === 'unread' ? '#0a84ff' : 'transparent', 'bcv-act__dot'),
        U.avatar(a.author?.avatar_image_url, a.author?.display_name, 38),
        U.el('bcv-row__body', [
          U.el('bcv-row__head', [U.text('bcv-row__title bcv-pretty', a.title, 'span'), U.text('bcv-row__when', U.fmtAtUpper(a.posted_at || a.delayed_post_at), 'span')]),
          // who posted it as Canvas names them (never a word of ours standing in), which sections, and the comments under it
          U.text('bcv-row__sub bcv-row__sub--3', [a.author?.display_name || a.user_name || null, a.is_section_specific && a.sections?.length ? a.sections.map((s) => s.name).join(', ') : 'All sections', a.discussion_subentry_count ? `${U.plural(a.discussion_subentry_count, 'comment')}${a.unread_count ? ` · ${a.unread_count} new` : ''}` : null].filter(Boolean).join(' · ')),
          U.text('bcv-row__preview bcv-pretty', htmlToText(a.message || '', 180).replace(/\s+/g, ' ')),
        ]),
      ], { mod: 'bcv-row--p16 bcv-row--top', onClick: () => app.go(`${c.url}/announcements/${a.id}`) })), 'bcv-card--list'));
    }
    draw();
    return b;
  };

  T.assignmentsBlock = async (ctx, shell, { query = '', mode = 'date', enter = true } = {}) => {
    const { app } = ctx;
    const c = shell.course;
    const [list, groups] = await Promise.all([store.assignments(c.id).catch(() => null), mode === 'type' ? store.assignmentGroups(c.id).catch(() => null) : null]);
    if (!list) return U.emptyCard('Assignments could not be loaded.');
    const now = new Date();
    const q = query.toLowerCase();
    const items = list.filter((a) => !q || a.name.toLowerCase().includes(q));
    // the rows fade in one after another down the column, quickly (20ms apart, capped so a long
    // list never crawls) — on the first draw only; a search or a re-sort just redraws
    let n = 0;
    const row = (a) => {
      const { icon, quiz, kind } = typeIcon(a);
      const pal = quiz ? U.palette('#5856d6', shell.dark) : c.palette;
      const rowEl = U.row([
        U.tile(icon, { color: pal.text, tint: pal.tint }),
        U.el('bcv-row__body', [
          U.text('bcv-row__title bcv-row__title--145 bcv-ellip', a.name),
          // (2.99.42) as the Mac's rows read: the kind, the points, then when it is due (a grade ends "due", whatever the date)
          U.text('bcv-row__sub', `${kind} · ${ptsLabel(a)} · ${hasGrade(a) ? 'Graded' : a.due_at ? `Due ${U.fmtAt(a.due_at)}` : 'No due date'}`),
        ]),
        statusBadge(a),
        U.chev(),
      ], { onClick: () => app.go(quiz && a.quiz_id ? `${c.url}/quizzes/${a.quiz_id}` : `${c.url}/assignments/${a.id}`) });
      return enter ? U.enter(rowEl, n++, 20, 200) : rowEl;
    };
    const section = (title, sub, arr) => (arr.length ? h('div', {}, [U.groupHead(title, sub), U.card(arr.map(row), 'bcv-card--list')]) : null);
    if (mode === 'type' && groups) {
      const byId = new Map(items.map((a) => [String(a.id), a]));
      const parts = groups.map((g) => section(g.name, c.weighted ? `${Number(g.group_weight) || 0}% of grade` : U.plural((g.assignments || []).length, 'item'), (g.assignments || []).map((a) => byId.get(String(a.id))).filter(Boolean).sort((x, y) => (U.parse(x.due_at) || Infinity) - (U.parse(y.due_at) || Infinity))));
      return U.el('bcv-col', parts.filter(Boolean).length ? parts : [U.emptyCard('No assignments.')], { style: { gap: '22px' } });
    }
    const overdue = [], upcoming = [], undated = [], past = [];
    for (const a of items) {
      const due = U.parse(a.due_at);
      const s = a.submission || {};
      const done = s.submitted_at || s.workflow_state === 'graded' || s.excused;
      if (!due) undated.push(a);
      else if (hasGrade(a)) past.push(a); // graded is done: nothing is due once it has a grade, even before its date
      else if (due >= now) upcoming.push(a);
      else if (!done && (a.points_possible || 0) > 0 && !(a.submission_types || []).some((t) => ['none', 'on_paper', 'not_graded'].includes(t))) overdue.push(a);
      else past.push(a);
    }
    const byDue = (x, y) => (U.parse(x.due_at) || 0) - (U.parse(y.due_at) || 0);
    upcoming.sort(byDue); overdue.sort(byDue); past.sort((x, y) => byDue(y, x));
    const gradedN = past.filter((a) => a.submission?.workflow_state === 'graded').length;
    const parts = [
      // (2.99.42) the Mac's short heads, each with its count: "Upcoming 10"
      section('Overdue', String(overdue.length), overdue),
      section('Upcoming', String(upcoming.length), upcoming),
      section('Undated', String(undated.length), undated),
      section('Past', gradedN ? `${past.length} · ${gradedN} graded` : String(past.length), past),
    ].filter(Boolean);
    return U.el('bcv-col', parts.length ? parts : [U.emptyCard(q ? 'No assignments match.' : 'No assignments yet.')], { style: { gap: '22px' } });
  };
  T.assignments = async (ctx, shell) => {
    const b = body('bcv-body--22');
    let mode = 'date';
    let query = '';
    const wrap = h('div');
    b.append(U.el('bcv-head__tools', [U.search('Search assignments', (q) => { query = q; draw(); }, 'bcv-search--200'), U.seg([['date', 'Show by date'], ['type', 'Show by type']], mode, (v) => { mode = v; draw(); })]), wrap);
    b.querySelector('.bcv-head__tools').style.marginTop = '0';
    wrap.append(U.loading());
    let drawn = false; // the rows' entrance plays on the first draw; a search or re-sort just redraws
    async function draw() {
      const el = await T.assignmentsBlock(ctx, shell, { query, mode, enter: !drawn });
      if (!ctx.alive()) return;
      drawn = true;
      wrap.replaceChildren(el);
    }
    await draw();
    return b;
  };

  T.discussions = async (ctx, shell) => {
    const { app } = ctx;
    const c = shell.course;
    const b = body();
    let query = '';
    const wrap = h('div');
    // starting one is Canvas's own editor, with everything it offers: our shell stays over the page
    const newBtn = U.btn('New discussion', { kind: 'primary', icon: IC.plus, iconColor: '#fff', onClick: () => app.go(`${c.url}/discussion_topics/new`) });
    b.append(U.el('bcv-head__tools', [U.search('Search by title or author', (q) => { query = q.toLowerCase(); draw(); }, 'bcv-search--200'), U.text('bcv-group__sub', 'Ordered by recent activity', 'span'), h('div', { class: 'bcv-ml-auto' }, newBtn)]), wrap);
    b.querySelector('.bcv-head__tools').style.marginTop = '0';
    wrap.append(U.loading());
    const list = await store.discussions(c.id, { kind: shell.kind }).catch(() => null);
    if (!ctx.alive()) return b;
    function draw() {
      if (!list) return wrap.replaceChildren(U.errorBox('Discussions could not be loaded.'));
      const items = list.filter((d) => !query || `${d.title} ${d.author?.display_name || ''} ${d.user_name || ''}`.toLowerCase().includes(query));
      if (!items.length) return wrap.replaceChildren(U.emptyCard(query ? 'No discussions match.' : 'No discussions yet.'));
      // Ordered by recent activity here, not only in the ask: Canvas is sent order_by=recent_activity
      // but does not always honour it, and a list that came back by posting date reads as unsorted —
      // a topic whose last post is the newest of all sitting under ones posted a week before it. The
      // date sorted on is the date the row shows, so the order on screen is the order it reads.
      const when = (d) => Math.max(...[d.last_reply_at, d.posted_at, d.created_at].map((s) => U.parse(s)?.getTime() || 0));
      const byActivity = (a, z) => when(z) - when(a);
      const pinned = items.filter((d) => d.pinned); // (left as Canvas orders them: pinning is the instructor's own running order)
      const open = items.filter((d) => !d.pinned && !d.locked).sort(byActivity);
      const closed = items.filter((d) => !d.pinned && d.locked).sort(byActivity);
      const rowFor = (d) => {
        const unread = Number(d.unread_count) || 0;
        const replies = Number(d.discussion_subentry_count) || 0;
        const lastPost = d.last_reply_at && (U.parse(d.last_reply_at)?.getTime() || 0) >= (U.parse(d.posted_at)?.getTime() || 0);
        // the points a graded topic carries, a to-do date the teacher set, and the window: open until, or closed since
        const lockAt = U.parse(d.lock_at);
        const meta = [lastPost ? `Last post ${U.fmtAtUpper(d.last_reply_at)}` : `Posted ${U.fmtAtUpper(d.posted_at || d.created_at)}`, d.assignment?.points_possible !== null && d.assignment?.points_possible !== undefined ? `${store.fmtPts(d.assignment.points_possible)} pts` : null, d.assignment?.due_at ? `due ${U.fmtAtUpper(d.assignment.due_at)}` : d.todo_date ? `to do ${U.fmtAtUpper(d.todo_date)}` : null, lockAt ? (lockAt > new Date() ? `open until ${U.fmtAtUpper(d.lock_at)}` : `closed ${U.fmtShort(d.lock_at)}`) : null].filter(Boolean).join(' · ');
        return U.row([
          U.dot(unread > 0 || d.read_state === 'unread' ? '#0a84ff' : 'transparent'),
          U.tile(IC.disc, { color: 'var(--bcv-ink3)', tint: 'var(--bcv-fill2)' }),
          U.el('bcv-row__body', [U.text('bcv-row__title bcv-pretty', d.title), U.text('bcv-row__sub bcv-row__sub--3', meta)]),
          U.badge(`${unread} unread`, unread > 0 ? 'blue' : ''),
          U.badge(`${replies} ${replies === 1 ? 'reply' : 'replies'}`),
        ], { mod: 'bcv-row--p15', onClick: () => app.go(`${c.url}/discussion_topics/${d.id}`) });
      };
      const parts = [];
      if (pinned.length) parts.push(h('div', {}, [U.label('Pinned'), U.card(pinned.map(rowFor), 'bcv-card--list')]));
      parts.push(pinned.length || closed.length ? h('div', {}, [U.label('Discussions'), U.card(open.map(rowFor), 'bcv-card--list')]) : U.card(open.map(rowFor), 'bcv-card--list'));
      if (closed.length) parts.push(h('div', {}, [U.label('Closed for comments'), U.card(closed.map(rowFor), 'bcv-card--list')]));
      wrap.replaceChildren(U.el('bcv-col bcv-col--18', parts));
    }
    draw();
    return b;
  };

  T.people = async (ctx, shell) => {
    const c = shell.course;
    const b = body();
    let sub = ctx.route.sub === 'groups' ? 'groups' : 'everyone';
    let role = 'all';
    let query = '';
    const rolePill = U.pill('All roles', (e) => U.menu(e.currentTarget, [['all', 'All roles'], ['StudentEnrollment', 'Students'], ['TeacherEnrollment', 'Teachers'], ['TaEnrollment', 'TAs'], ['ObserverEnrollment', 'Observers'], ['DesignerEnrollment', 'Designers']].map(([k, l]) => ({ label: l, active: role === k, onSelect: () => { role = k; rolePill.textContent = l; draw(); } }))));
    const wrap = h('div');
    const segEl = U.seg([['everyone', 'Everyone'], ['groups', 'Groups']], sub, (v) => { sub = v; draw(); }, { wide: true });
    const isGroupCtx = shell.kind === 'groups';
    b.append(U.el('bcv-head__tools', [isGroupCtx ? null : segEl, U.search('Search people', (q) => { query = q.toLowerCase(); draw(); }, 'bcv-search--180'), isGroupCtx ? null : rolePill]), wrap);
    b.querySelector('.bcv-head__tools').style.marginTop = '0';
    wrap.append(U.loading());
    const isGroup = shell.kind === 'groups';
    const [users, sections, groups] = await Promise.all([store.people(c.id, { kind: shell.kind }).catch(() => null), isGroup ? [] : store.sections(c.id).catch(() => []), isGroup ? [] : store.courseGroups(c.id).catch(() => [])]);
    if (!ctx.alive()) return b;
    const secName = new Map((sections || []).map((s) => [String(s.id), s.name]));
    const roleOf = (u) => {
      const e = (u.enrollments || [])[0] || {};
      if (e.role && !/Enrollment$/.test(e.role)) return e.role; // (a role the school named itself — "Lab TA", "Tutor" — is shown as named)
      const t = e.type || e.role || '';
      return t.includes('Teacher') ? 'Teacher' : t.includes('Ta') ? 'TA' : t.includes('Observer') ? 'Observer' : t.includes('Designer') ? 'Designer' : 'Student';
    };
    function draw() {
      if (sub === 'groups') {
        const gs = (groups || []).filter((g) => !query || g.name.toLowerCase().includes(query));
        wrap.replaceChildren(gs.length ? U.card(gs.map((g) => U.row([
          U.tile(IC.people, { color: '#5856d6', tint: 'rgba(88,86,214,.16)' }),
          U.el('bcv-row__body', [U.text('bcv-row__title', g.name), U.text('bcv-row__sub', `${U.plural(g.members_count || 0, 'member')}${g.group_category?.name ? ` · ${g.group_category.name}` : ''}`)]),
          U.chev(),
        ], { mod: 'bcv-row--p15', href: `/groups/${g.id}` })), 'bcv-card--list') : U.emptyCard('No groups in this course.'));
        return;
      }
      if (!users) return wrap.replaceChildren(U.errorBox('People could not be loaded.'));
      const items = users.filter((u) => (role === 'all' || (u.enrollments || []).some((e) => e.type === role)) && (!query || (u.name || u.sortable_name || '').toLowerCase().includes(query)));
      if (!items.length) return wrap.replaceChildren(U.emptyCard('Nobody matches.'));
      wrap.replaceChildren(U.card(items.map((u) => U.row([
        U.avatar(u.avatar_url, u.name, 38),
        U.el('bcv-row__body', [U.text('bcv-row__title bcv-row__title--145 bcv-ellip', u.name || u.sortable_name), u.pronouns ? U.text('bcv-row__sub', u.pronouns) : null]), // (no dash where someone set no pronouns)
        U.text('bcv-people__sections', [...new Set((u.enrollments || []).map((e) => secName.get(String(e.course_section_id))).filter(Boolean))].join(' · '), 'span'),
        U.badge(isGroup ? 'Member' : roleOf(u)),
      ], { mod: 'bcv-row--p12', href: `${c.url}/users/${u.id}` })), 'bcv-card--list'));
    }
    draw();
    return b;
  };

  T.pages = async (ctx, shell) => {
    const { app } = ctx;
    const c = shell.course;
    const b = body();
    b.append(U.loading());
    const list = await store.pages(c.id, { kind: shell.kind }).catch(() => null);
    if (!ctx.alive()) return b;
    if (!list) return b.replaceChildren(U.errorBox('Pages could not be loaded.')) || b;
    const sorted = [...list].sort((x, y) => (y.front_page ? 1 : 0) - (x.front_page ? 1 : 0) || String(x.title).localeCompare(String(y.title)));
    b.replaceChildren(
      sorted.length ? U.card(sorted.map((p) => U.row([
        U.tile(IC.doc, { color: 'var(--bcv-blue)', tint: 'var(--bcv-blue-soft)' }),
        U.el('bcv-row__body', [
          h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' } }, [U.text('bcv-row__title', p.title, 'span'), p.front_page ? U.badge('Front page', 'green', 'bcv-badge--sm') : null]),
          U.text('bcv-row__sub bcv-row__sub--3', [p.created_at ? `Created ${U.fmtDateComma(p.created_at)}` : null, p.updated_at ? `last edited ${U.fmtDateComma(p.updated_at)}${p.last_edited_by?.display_name ? ` by ${p.last_edited_by.display_name}` : ''}` : null].filter(Boolean).join(' · ') || 'Page'), // (a page Canvas gives no dates for says nothing, not a bare "·")
        ]),
        U.chev(),
      ], { mod: 'bcv-row--p15', onClick: () => app.go(`${c.url}/pages/${p.url}`) })), 'bcv-card--list') : U.emptyCard('No pages published yet.'),
      U.hint(`This course has ${U.plural(sorted.length, 'published page')}. ${sorted.some((p) => p.front_page) ? 'The front page is what you see under Home.' : ''}`),
    );
    return b;
  };

  const FILE_KINDS = [
    [/pdf/, 'PDF', IC.doc, '#ff2d55'], [/spreadsheet|excel|csv/, 'Spreadsheet', IC.sheet, '#34c759'], [/presentation|powerpoint/, 'Slides', IC.sheet, '#ff9500'],
    [/word|document|rtf|text/, 'Document', IC.doc, '#0a84ff'], [/^image/, 'Image', IC.image, '#af52de'], [/^video/, 'Video', IC.video, '#5856d6'], [/^audio/, 'Audio', IC.audio, '#30b0c7'], [/zip|compressed/, 'Archive', IC.zip, '#8e8e93'],
  ];
  const fmtSize = (n) => (!n ? '—' : n < 1024 ? `${n} B` : n < 1048576 ? `${Math.round(n / 1024)} KB` : `${(n / 1048576).toFixed(1)} MB`);
  T.files = async (ctx, shell) => {
    const { app, route } = ctx;
    const c = shell.course;
    const b = body();
    let query = '';
    const wrap = h('div');
    b.append(U.el('bcv-head__tools', [U.search('Search files', (q) => { query = q.toLowerCase(); draw(); })]), wrap);
    b.querySelector('.bcv-head__tools').style.marginTop = '0';
    wrap.append(U.loading());
    let folder;
    try {
      folder = route.tab === 'folder' && route.arg ? await store.folderByPath(c.id, route.arg, { kind: shell.kind }) : await store.rootFolder(c.id, { kind: shell.kind });
      if (Array.isArray(folder)) folder = folder[folder.length - 1];
    } catch {
      folder = null;
    }
    if (!ctx.alive()) return b;
    if (!folder) return wrap.replaceChildren(U.errorBox('Files could not be loaded.')) || b;
    const contents = await store.folderContents(folder.id).catch(() => ({ folders: [], files: [] }));
    if (!ctx.alive()) return b;
    const crumbs = (folder.full_name || '').split('/').filter(Boolean);
    function draw() {
      const folders = contents.folders.filter((f) => !query || f.name.toLowerCase().includes(query));
      const files = contents.files.filter((f) => !query || (f.display_name || f.filename).toLowerCase().includes(query));
      const rows = [
        ...folders.map((f) => U.row([
          U.tile(IC.folder, { color: '#0a84ff', tint: 'var(--bcv-blue-soft)' }),
          U.el('bcv-row__body', [U.text('bcv-row__title bcv-row__title--145 bcv-ellip', f.name), U.text('bcv-row__sub', `Folder · modified ${U.fmtRecent(f.updated_at)}${f.locked || f.hidden ? ` · ${f.locked ? 'locked' : 'hidden'}` : ''}`)]),
          // what is in it, where Canvas says (files_count / folders_count), rather than a dash for a size
          U.text('bcv-files__size', [f.files_count ? U.plural(f.files_count, 'file') : null, f.folders_count ? U.plural(f.folders_count, 'folder') : null].filter(Boolean).join(' · ') || (f.files_count === 0 && f.folders_count === 0 ? 'empty' : ''), 'span'),
          U.chev(),
        ], { onClick: () => app.go(`${c.url}/files/folder/${f.full_name.split('/').slice(1).map(encodeURIComponent).join('/')}`) })),
        ...files.map((f) => {
          const kind = FILE_KINDS.find(([re]) => re.test(f['content-type'] || f.mime_class || '')) || [null, 'File', IC.doc, '#8e8e93'];
          const pal = U.palette(kind[3], shell.dark);
          // a file opens in the viewer over the page (its own Download and Open in Canvas are in
          // there), never in a new tab; the row is still a link to the file's page for a new-tab click
          const rowEl = U.row([
            U.tile(kind[2], { color: pal.text, tint: pal.tint }),
            // the kind, when it changed, who put it there (include[]=user), and a lock or a hidden mark where Canvas set one
            U.el('bcv-row__body', [U.text('bcv-row__title bcv-row__title--145 bcv-ellip', f.display_name || f.filename), U.text('bcv-row__sub', [kind[1], `modified ${U.fmtRecent(f.updated_at || f.modified_at)}`, f.user?.display_name ? `by ${f.user.display_name}` : null].filter(Boolean).join(' · '))]),
            f.locked || f.hidden || f.locked_for_user ? U.badge(f.locked_for_user || f.locked ? (f.unlock_at && U.parse(f.unlock_at) > new Date() ? `Opens ${U.fmtShort(f.unlock_at)}` : 'Locked') : 'Hidden', 'orange', 'bcv-badge--xs') : null,
            U.text('bcv-files__size', fmtSize(f.size), 'span'),
            U.chev(),
          ], { href: `${c.url}/files/${f.id}` });
          rowEl.addEventListener('click', (e) => {
            if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
            e.preventDefault();
            BCV.viewer.open(f, { context: c, from: rowEl });
          });
          return rowEl;
        }),
      ];
      wrap.replaceChildren(h('div', {}, [
        crumbs.length > 1 ? U.el('bcv-crumbs', crumbs.flatMap((name, i) => [i ? h('span', { text: '/' }) : null, i === crumbs.length - 1 ? h('span', { text: name }) : h('button', { type: 'button', text: i === 0 ? c.name : name, onclick: () => app.go(i === 0 ? `${c.url}/files` : `${c.url}/files/folder/${crumbs.slice(1, i + 1).map(encodeURIComponent).join('/')}`) })]).filter(Boolean)) : null,
        U.label(crumbs.length > 1 ? crumbs[crumbs.length - 1] : c.name),
        rows.length ? U.card(rows, 'bcv-card--list') : U.emptyCard(query ? 'No files match.' : 'This folder is empty.'),
      ]));
    }
    draw();
    return b;
  };

  T.quizzes = async (ctx, shell) => {
    const { app } = ctx;
    const c = shell.course;
    const b = body();
    let query = '';
    const wrap = h('div');
    b.append(U.el('bcv-head__tools', [U.search('Search quizzes', (q) => { query = q.toLowerCase(); draw(); })]), wrap); // (the same row as Files: the box spans it)
    wrap.append(U.loading());
    // the quizzes, and the course's assignments beside them: a quiz's score and state live on the
    // assignment behind it (the list Grades and Assignments already read), and New Quizzes are
    // assignments with no classic quiz at all
    const [list, asg] = await Promise.all([store.quizzes(c.id).catch(() => null), store.assignments(c.id).catch(() => [])]);
    if (!ctx.alive()) return b;
    const TYPES = [['assignment', 'Assignment quizzes'], ['practice_quiz', 'Practice quizzes'], ['graded_survey', 'Graded surveys'], ['survey', 'Surveys']];
    const assignmentOf = (q) => (asg || []).find((a) => String(a.id) === String(q.assignment_id) || (a.is_quiz_assignment && String(a.quiz_id) === String(q.id))) || null;
    const newQuizzes = (asg || []).filter((a) => a.is_quiz_lti_assignment);
    const attemptsOf = (q) => (q.allowed_attempts === -1 ? 'unlimited attempts' : q.allowed_attempts > 0 ? U.plural(q.allowed_attempts, 'attempt') : null);
    function draw() {
      if (!list) return wrap.replaceChildren(U.errorBox('Quizzes could not be loaded.'));
      const items = list.filter((q) => !query || q.title.toLowerCase().includes(query)).sort((x, y) => (U.parse(x.due_at) || Infinity) - (U.parse(y.due_at) || Infinity));
      const quizRow = (q) => {
        const a = assignmentOf(q);
        const st = a ? store.workStatus(a) : null;
        const bits = [q.due_at ? `Due ${U.fmtAt(q.due_at)}` : 'No due date', a && hasGrade(a) ? ptsLabel(a) : `${store.fmtPts(q.points_possible || 0)} pts`, q.question_count == null ? null : U.plural(q.question_count, 'question'), q.time_limit ? `${q.time_limit} min` : null, attemptsOf(q), q.has_access_code ? 'Access code' : null, q.require_lockdown_browser ? 'LockDown Browser' : null].filter(Boolean);
        return U.row([
          U.tile(IC.bolt, { color: '#7d7bef', tint: 'rgba(88,86,214,.16)' }),
          U.el('bcv-row__body', [U.text('bcv-row__title bcv-row__title--145', q.title), U.text('bcv-row__sub', bits.join(' · '))]),
          st ? U.statusBadge(st.graded ? { word: st.late ? 'Graded · late' : 'Graded', kind: 'good' } : st, '') : null, // (where you stand: taken, graded, missing — from the assignment behind the quiz)
          U.chev(),
        ], { onClick: () => app.go(`${c.url}/quizzes/${q.id}`) });
      };
      const parts = TYPES.map(([type, lbl]) => {
        const arr = items.filter((q) => (q.quiz_type || 'assignment') === type);
        return arr.length ? h('div', {}, [U.label(lbl), U.card(arr.map(quizRow), 'bcv-card--list')]) : null;
      }).filter(Boolean);
      // New Quizzes (a tool of Canvas's own): rows of their own, opened on the assignment page that launches them
      const lti = newQuizzes.filter((a) => !query || a.name.toLowerCase().includes(query)).sort((x, y) => (U.parse(x.due_at) || Infinity) - (U.parse(y.due_at) || Infinity));
      if (lti.length) parts.push(h('div', {}, [U.label('New Quizzes'), U.card(lti.map((a) => U.row([
        U.tile(IC.bolt, { color: '#7d7bef', tint: 'rgba(88,86,214,.16)' }),
        U.el('bcv-row__body', [U.text('bcv-row__title bcv-row__title--145', a.name), U.text('bcv-row__sub', `${a.due_at ? `Due ${U.fmtAt(a.due_at)}` : 'No due date'} · ${ptsLabel(a)}`)]),
        statusBadge(a),
        U.chev(),
      ], { onClick: () => app.go(`${c.url}/assignments/${a.id}`) })), 'bcv-card--list')]));
      wrap.replaceChildren(parts.length ? U.el('bcv-col bcv-col--18', parts) : U.emptyCard(query ? 'No quizzes match.' : 'No quizzes yet.'));
    }
    draw();
    return b;
  };

  const ITEM_ICON = { Assignment: IC.doc, Quiz: IC.bolt, Discussion: IC.disc, Page: IC.page, File: IC.folder, ExternalUrl: IC.link, ExternalTool: IC.shield };
  /** When a module next wants something: the soonest due date still ahead of it, else the last one
   *  that has gone by, else nothing at all (a module of pages and links). Sorting by it puts the work
   *  in the order it has to be done — what is coming first, what is finished after it. */
  function moduleDue(m) {
    const now = Date.now();
    let next = null, past = null;
    const see = (t) => {
      if (!t) return;
      const v = +t;
      if (v >= now) { if (next === null || v < next) next = v; } else if (past === null || v > past) past = v;
    };
    for (const it of m.items || []) see(U.parse(it.content_details?.due_at));
    // a locked module's unlock date sorts it among what is coming — but it is when the module opens,
    // not when anything in it is due, and the head says so (Opens, not Next due)
    const opensAt = m.state === 'locked' ? U.parse(m.unlock_at) : null;
    if (opensAt && +opensAt >= now && (next === null || +opensAt < next)) return { next: +opensAt, past, opens: true };
    return { next, past, opens: false };
  }
  /** What a module item asks for, in words: the requirement Canvas set on it (view it, hand it in,
   *  post, mark it done, a score to reach), or Done once it is met. */
  const requirementWord = (cr) => (!cr ? null : cr.completed ? 'Done' : ({ must_view: 'View to complete', must_submit: 'Hand in to complete', must_contribute: 'Post to complete', must_mark_done: 'Mark done to complete', min_score: `Score ${cr.min_score ?? ''} or more to complete`.replace(/\s+/g, ' ') }[cr.type] || null));

  T.modulesBlock = async (ctx, shell) => {
    const c = shell.course;
    const list = await store.modules(c.id).catch(() => null);
    if (!list) return U.emptyCard('Modules could not be loaded.');
    if (!list.length) return U.emptyCard('No modules yet.');
    // (2.99.12) Nothing opens by itself: the one module open is the one last opened here, per course — kept when it is
    // opened, let go when it is closed (closing it is saying so). Open all / Close all leave it as it was.
    const lastKey = `modLast:${c.id}`;
    let last = String((await store.pref(lastKey, '')) || '');
    const open = new Set(list.some((m) => String(m.id) === last) ? [last] : []);
    const remember = (id) => { last = id; store.setPref(lastKey, id); };
    const cards = list.map((m) => {
      const items = m.items || [];
      const req = items.filter((it) => it.completion_requirement);
      const done = req.filter((it) => it.completion_requirement.completed).length;
      // why a module is locked: the modules it waits for (by name), or the day it opens; a module
      // that must be done in order says so beside its count
      const prereqs = (m.prerequisite_module_ids || []).map((id) => list.find((x) => String(x.id) === String(id))?.name).filter(Boolean);
      const stateText = m.state === 'locked'
        ? `Locked${prereqs.length ? ` until ${prereqs.join(' and ')} ${prereqs.length > 1 ? 'are' : 'is'} complete` : m.unlock_at ? ` until ${U.fmtAt(m.unlock_at)}` : ''}`
        : `${req.length ? `${done} of ${req.length} requirements done` : U.plural(items.length, 'item')}${m.require_sequential_progress ? ' · in order' : ''}`;
      const itemsEl = U.el('bcv-module__items', items.map((it) => {
        if (it.type === 'SubHeader') return U.label(it.title, `bcv-module__item bcv-indent-${Math.min(it.indent || 0, 3)}`);
        const cd = it.content_details || {};
        // an item Canvas holds back (a prerequisite, a date) says why, in Canvas's own words
        const lockedWhy = cd.locked_for_user ? (String(cd.lock_explanation || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim() || 'Locked') : null;
        const sub = [cd.due_at ? `Due ${U.fmtAt(cd.due_at)}` : null, cd.points_possible ? `${store.fmtPts(cd.points_possible)} pts` : null, it.type === 'ExternalUrl' ? 'Link' : it.type === 'ExternalTool' ? 'External tool' : it.type === 'File' ? 'File' : it.type === 'Page' ? 'Page' : null, lockedWhy || requirementWord(it.completion_requirement)].filter(Boolean).join(' · ');
        const completed = it.completion_requirement?.completed;
        // the item's own address (Canvas's html_url is a /modules/items/N redirect, which only a page load can follow)
        const itemHref = (() => {
          const id = it.content_id;
          if (it.type === 'Assignment' && id) return `${c.url}/assignments/${id}`;
          if (it.type === 'Quiz' && id) return `${c.url}/quizzes/${id}`;
          if (it.type === 'Discussion' && id) return `${c.url}/discussion_topics/${id}`;
          if (it.type === 'Page' && it.page_url) return `${c.url}/pages/${it.page_url}`;
          if (it.type === 'File' && id) return `${c.url}/files/${id}`;
          return it.html_url || it.external_url || c.url;
        })();
        const rowEl = U.row([
          U.tile(ITEM_ICON[it.type] || IC.doc, { color: c.palette.text, tint: c.palette.tint }),
          U.el('bcv-row__body', [U.text('bcv-row__title bcv-row__title--145 bcv-ellip', it.title), sub ? U.text('bcv-row__sub', sub) : null]),
          it.completion_requirement ? h('span', { class: `bcv-circle ${completed ? 'is-done' : ''}`, title: requirementWord(it.completion_requirement) || (completed ? 'Done' : 'Not done'), style: { cursor: 'default' } }, completed ? U.svg('M6 12l4 4 8-8', { size: 12, stroke: '#fff', width: 2.4 }) : null) : null,
          U.chev(),
        ], { mod: `bcv-module__item bcv-indent-${Math.min(it.indent || 0, 3)}${lockedWhy ? ' bcv-row--done' : ''}`, href: itemHref });
        // a file in a module opens in the viewer over the page, like one in Files
        if (it.type === 'File' && it.content_id) rowEl.addEventListener('click', (e) => {
          if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
          e.preventDefault();
          BCV.viewer.open({ id: it.content_id }, { context: c, from: rowEl });
        });
        // a link or a tool in a module opens in a tab of its own, the site (or Canvas's launch of the tool) on it
        if ((it.type === 'ExternalUrl' || it.type === 'ExternalTool') && BCV.exttool) rowEl.addEventListener('click', (e) => {
          if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
          e.preventDefault();
          if (it.type === 'ExternalTool') BCV.exttool.open({ title: it.title, url: `${c.url}/external_tools/retrieve?display=borderless&url=${encodeURIComponent(it.external_url || '')}`, page: it.html_url ? (() => { try { return new URL(it.html_url, location.origin).pathname; } catch { return null; } })() : null, from: rowEl });
          else BCV.exttool.open({ title: it.title, url: it.external_url || it.html_url, newTab: it.external_url || it.html_url, from: rowEl, icon: IC.link });
        });
        return rowEl;
      }));
      // The items live in a collapsing grid row rather than behind [hidden], so opening and closing
      // is a slide: 0fr → 1fr takes the rows' own height with it, whatever that turns out to be, and
      // nothing has to be measured. (Reduced motion turns the transition off in the stylesheet.)
      const wrap = U.el('bcv-module__wrap', itemsEl);
      // when the module next wants something, on the head where it can be read without opening it
      const due = moduleDue(m);
      const dueText = due.opens ? `Opens ${U.whenShort(new Date(due.next))}` : due.next !== null ? `Next due ${U.whenShort(new Date(due.next))}` : due.past !== null ? `Last due ${U.fmtShort(new Date(due.past))}` : '';
      const head = h('button', { type: 'button', class: 'bcv-module__head', 'aria-expanded': String(open.has(String(m.id))) }, [
        U.svg(IC.chevron, { size: 15, stroke: 'var(--bcv-ink3)', width: 2, cls: 'bcv-module__toggle' }),
        U.text('bcv-module__name', m.name, 'span'),
        dueText ? h('span', { class: `bcv-module__due ${due.next !== null ? 'is-next' : ''}`, text: dueText }) : null,
        U.text('bcv-module__state', stateText, 'span'),
      ]);
      const card = U.card([head, wrap], `bcv-card--list bcv-module ${open.has(String(m.id)) ? 'bcv-module--open' : ''}`);
      card.dataset.date = due.next ?? '';
      card.dataset.past = due.past ?? '';
      card.dataset.pos = String(m.position ?? 0);
      card.setOpen = (on) => {
        card.classList.toggle('bcv-module--open', on);
        head.setAttribute('aria-expanded', String(on));
      };
      head.addEventListener('click', () => {
        const on = !card.classList.contains('bcv-module--open');
        card.setOpen(on);
        if (on) remember(String(m.id));
        else if (String(m.id) === last) remember('');
      });
      return card;
    });
    const col = U.el('bcv-col bcv-col--16');
    // Canvas's own order is the order the course was built in; by date is the order it has to be done
    // in. Both are kept as they were last left, per course.
    const orderKey = `modOrder:${c.id}`;
    // Next due: what is coming, soonest first; then what has gone by, most recent first; then the
    // modules with no dates at all. Canvas's own order breaks any tie.
    const rank = (el) => (el.dataset.date !== '' ? [0, Number(el.dataset.date)] : el.dataset.past !== '' ? [1, -Number(el.dataset.past)] : [2, 0]);
    const sortCards = (order) => {
      const sorted = cards.slice().sort((x, y) => {
        if (order !== 'date') return Number(x.dataset.pos) - Number(y.dataset.pos);
        const [ga, va] = rank(x), [gb, vb] = rank(y);
        if (ga !== gb) return ga - gb;
        if (va !== vb) return va - vb;
        return Number(x.dataset.pos) - Number(y.dataset.pos);
      });
      for (const el of sorted) col.append(el); // append moves; the cards themselves are never rebuilt
    };
    const allOpen = () => cards.every((x) => x.classList.contains('bcv-module--open'));
    const bulkBtn = h('button', { type: 'button', class: 'bcv-chip bcv-module__all', onclick: () => { const on = !allOpen(); for (const x of cards) x.setOpen(on); paintBulk(); } });
    function paintBulk() {
      bulkBtn.textContent = allOpen() ? 'Close all' : 'Open all';
    }
    for (const x of cards) x.addEventListener('click', (e) => { if (e.target.closest('.bcv-module__head')) paintBulk(); });
    let order = (await store.pref(orderKey, 'course')) === 'date' ? 'date' : 'course';
    const seg = U.seg([['course', 'Course order'], ['date', 'Next due']], order, (v) => {
      order = v;
      store.setPref(orderKey, v);
      for (const b of seg.querySelectorAll('.bcv-seg__btn')) b.classList.toggle('is-active', b.dataset.value === v);
      U.flipList(col, () => sortCards(v)); // (2.99.7: each module slides to its new place rather than jumping — 200 ms, translate only)
    });
    for (const x of cards) if (!x.dataset.flip) x.dataset.flip = `m-${x.dataset.pos}`;
    paintBulk();
    sortCards(order);
    col.prepend(U.el('bcv-module__bar', [seg, h('span', { class: 'bcv-ml-auto' }), bulkBtn]));
    return col;
  };
  T.modules = async (ctx, shell) => {
    const b = body();
    b.append(await T.modulesBlock(ctx, shell));
    return b;
  };

  BCV.screens.course = { render, prose, fitMath, rubricParts, rubricGrid, rubricScore, openRubric, rubricMorph, linksFrom, typeIcon, ptsLabel, statusBadge, contextShell, keptShell, holdShell, heldShell, syncShell, warmTab, warmTabIds };
  BCV.screens.courseTabs = T;
})();
