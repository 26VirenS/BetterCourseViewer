/* Quiz taking, drawn to the mockup: chrome hidden, an intro card, one
 * question at a time or all questions on one scroll, progress pills that
 * jump, flags, an elapsed/remaining pill, a review-before-submit screen and
 * a submitted screen. Every action is a Canvas quiz-submission API call and
 * the quiz's own settings (one at a time, no going back, time limit, access
 * code) are honoured. Nothing is ever auto-submitted. */
(function () {
  const BCV = (self.BCV = self.BCV || {});
  const { h, htmlToText } = BCV.utils;
  const U = BCV.ui;
  const IC = BCV.IC;
  const store = BCV.store;
  const QP = () => BCV.quizPage; // Canvas's own quiz page as a question source (one-question-at-a-time quizzes)
  const LETTERS = 'ABCDEFGHIJKLMNOP';
  const FLAG = 'M6 4v16M6 4h11l-2 4 2 4H6';
  const CHECK = 'M20 6L9 17l-5-5';
  const MODE_ONE = 'M5 7h14v10H5z';
  const MODE_ALL = 'M4 5h16M4 10h16M4 15h16M4 20h10';
  const MODE_SIDE = 'M3 5h18v14H3zM8 5v14M16 5v14'; // three columns: the list, the question, the controls
  // The layouts an attempt can be drawn in. 'side' (2.98.24, the default): the question in the middle
  // at Canvas's own reading size, the list of questions down the left and every control down the
  // right. 'one' and 'all' are the two that came before: one question a screen with the pills over it
  // and the buttons under it, or every question on one scroll. The choice is kept under a name of
  // its own (quizLayout), so everyone starts on the new layout once and keeps what they pick.
  // (2.99.78) Two to choose from now: 'side', and 'all' drawn in the same frame — the questions down the left, the controls
  // down the right — with every question in the middle, one after another, to scroll through. 'one' is the phone's alone;
  // a computer that had picked it opens on 'side'.
  const LAYOUTS = ['side', 'all'];

  // Canvas posts a grade apart from marking it, and keeps a quiz's results back until it has: its own
  // page says "Your quiz has been muted" and shows no score and no answers. The API is not so careful —
  // the questions and the grading history can still say which answers were right — so a finished
  // attempt whose assignment submission is not posted (posted_at null; absent means posted) shows
  // nothing of its grading here either.
  const heldBack = (asub) => !!asub && asub.posted_at === null && !!(asub.submitted_at || asub.workflow_state === 'graded' || asub.workflow_state === 'pending_review');
  const HELD_LINE = 'Your instructor hasn’t released the results yet. Your score and which answers were right show here once they do.';

  const pad = (n) => String(n).padStart(2, '0');
  const clock = (ms) => {
    const s = Math.max(0, Math.round(ms / 1000));
    const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
    return hh ? `${hh}:${pad(mm)}:${pad(ss)}` : `${mm}:${pad(ss)}`;
  };
  // Matching saves a list of pairs and the blank kinds save one value per blank, so neither an empty
  // list nor an empty set of blanks counts as answered.
  // An essay is rich text the way Canvas keeps it: what its editor wrote comes as HTML (paragraphs,
  // lists), and goes back the same way. The box shows it as readable text; the review and the
  // feedback show it as formatting, never as tags.
  const looksHtml = (v) => /<\/?(p|ul|ol|li|br|div|b|strong|i|em|u|span|a|h[1-6]|blockquote|pre)\b[^>]*>/i.test(String(v || ''));
  /** Rich text as an editor would show it: a blank line between paragraphs, a bullet (or a number) per item, no tags. */
  function htmlToPlain(html) {
    const box = h('div', { html: String(html || '') });
    const out = [];
    const walk = (node, depth) => {
      for (const n of node.childNodes) {
        if (n.nodeType === 3) { out.push(n.textContent.replace(/\u00a0/g, ' ')); continue; }
        if (n.nodeType !== 1) continue;
        const tag = n.tagName.toLowerCase();
        if (tag === 'br') { out.push('\n'); continue; }
        if (tag === 'li') {
          const ordered = n.parentElement?.tagName === 'OL';
          out.push(`${'  '.repeat(Math.max(0, depth - 1))}${ordered ? `${[...n.parentElement.children].indexOf(n) + 1}. ` : '• '}`);
          walk(n, depth);
          out.push('\n');
          continue;
        }
        if (tag === 'ul' || tag === 'ol') { walk(n, depth + 1); out.push('\n'); continue; }
        if (/^(p|div|h[1-6]|blockquote|pre|tr)$/.test(tag)) { walk(n, depth); out.push('\n\n'); continue; }
        walk(n, depth);
      }
    };
    walk(box, 0);
    return out.join('').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  /** Typed text as the simple HTML Canvas keeps essays in: a paragraph per blank line, a list where every line starts with a bullet or a number. */
  function plainToHtml(text) {
    const esc = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const item = /^\s*([•\-*]|\d+[.)])\s+/;
    return String(text || '').split(/\n{2,}/).map((block) => {
      const lines = block.split('\n').map((l) => l.trimEnd()).filter((l) => l.trim());
      if (!lines.length) return '';
      if (lines.every((l) => item.test(l))) {
        const ordered = lines.every((l) => /^\s*\d+[.)]\s+/.test(l));
        return `<${ordered ? 'ol' : 'ul'}>${lines.map((l) => `<li>${esc(l.replace(item, ''))}</li>`).join('')}</${ordered ? 'ol' : 'ul'}>`;
      }
      return `<p>${lines.map(esc).join('<br>')}</p>`;
    }).filter(Boolean).join('');
  }
  const answered = (v) => {
    if (v === null || v === undefined || v === '') return false;
    if (Array.isArray(v)) return !!v.length;
    if (typeof v === 'object') return !!Object.keys(v).length;
    return true;
  };
  const CHOICE = new Set(['multiple_choice_question', 'true_false_question']);
  const MULTI = new Set(['multiple_answers_question']);
  const TEXT = new Set(['short_answer_question', 'essay_question', 'numerical_question', 'calculated_question']);
  // a number to give: numerical, and formula (calculated) — its variables already put in the question for this attempt by Canvas
  const NUMERIC = new Set(['numerical_question', 'calculated_question']);
  // a file to hand in: uploaded to the student's quiz files, the answer naming it
  const FILE = new Set(['file_upload_question']);
  const MATCH = new Set(['matching_question']);
  // one field per blank: a dropdown of that blank's own list, or a line to type in
  const DROPS = new Set(['multiple_dropdowns_question']);
  const BLANKS = new Set(['multiple_dropdowns_question', 'fill_in_multiple_blanks_question']);
  /* Canvas takes an answer's id and a match's id as whole numbers and refuses anything else
   * ("match_id must be of type Integer"). A picker only ever hands back a string, so every id it
   * gives back is turned into one here. `Number(v) || v` used to do it, and let two through: an id
   * of 0, which is falsy and went as the string "0", and a missing one, which went as "undefined". */
  const whole = (v) => { const t = String(v ?? '').trim(); return /^-?\d+$/.test(t) ? Number(t) : v; };
  const hasId = (v) => v !== null && v !== undefined && String(v).trim() !== '';
  /* Canvas hands an answer back whole, not as picked (its questions endpoint deserializes "full"): a
   * matching answer lists every left-hand value, with a null match where nothing is picked yet, and a
   * blank kind lists every blank, null where it is empty. Those nulls are not picks. Read as picks
   * they were the string "null" — a row holding it, the untouched question counted as answered, and
   * every row sent up with the first real pick, which Canvas refused whole ("match_id must be of type
   * Integer"). So an answer is kept as what was picked, and nothing else. */
  const pairsOf = (v) => (Array.isArray(v) ? v : []).filter((p) => p && hasId(p.answer_id) && hasId(p.match_id));
  const filledOf = (v) => (v && typeof v === 'object' && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).filter(([, x]) => hasId(x))) : {});
  /** A question with its answer as picked: the rows and blanks Canvas lists with nothing in them taken out. */
  function tidy(q) {
    if (MATCH.has(q.question_type)) { const p = pairsOf(q.answer); q.answer = p.length ? p : null; }
    else if (BLANKS.has(q.question_type) && q.answer && typeof q.answer === 'object' && !Array.isArray(q.answer)) { const f = filledOf(q.answer); q.answer = Object.keys(f).length ? f : null; }
    return q;
  }
  /** The blanks a question has, as Canvas's page names them or as its own answers say. */
  const blanksOf = (q) => (q.blanks?.length ? q.blanks : [...new Set((q.answers || []).map((a) => a.blank_id).filter(Boolean))]);
  /* The question as something to read rather than answer. Canvas's own page writes a blank's field
   * into the sentence, so the review row and the feedback would otherwise carry a live dropdown —
   * and read it as its whole list of options run together. A blank shows there as a gap instead;
   * what was picked for it is listed beside it either way. The API's text names each blank in
   * brackets instead ("Roses are [colour1]"): those are gaps too. */
  const noFields = (html, q) => {
    if (!BLANKS.has(q.question_type) || !html) return html;
    const doc = new DOMParser().parseFromString(String(html), 'text/html');
    for (const w of doc.querySelectorAll(`[name^="question_${q.id}_"], .question_input`)) w.replaceWith(doc.createTextNode('_____'));
    const named = new Set(blanksOf(q).map(String));
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) n.textContent = n.textContent.replace(/\[([^\]\s]+)\]/g, (m, b) => (named.has(b) ? '_____' : m));
    return doc.body.innerHTML;
  };
  const INFO = new Set(['text_only_question']);

  // ---- the answer and feedback rules, shared with the iPhone app's own quiz (native-app.js) ----------------
  // A question with more than one part is answered when every part of it is. A blank kind saves one
  // value per blank and matching saves a pair per value, so with one of three blanks filled the old
  // test — anything in the object at all — called the question answered, painted its number blue and
  // counted it in the total, while two thirds of it was still empty.
  const isAnswered = (q) => {
    if (INFO.has(q.question_type)) return true;
    if (q.loaded === false) return !!q.answered; // not yet read from Canvas's page: what its list says
    if (BLANKS.has(q.question_type)) {
      const bs = blanksOf(q);
      const held = q.answer && typeof q.answer === 'object' && !Array.isArray(q.answer) ? q.answer : {};
      return bs.length ? bs.every((b) => answered(held[b])) : answered(q.answer);
    }
    if (MATCH.has(q.question_type)) {
      const pairs = pairsOf(q.answer);
      return (q.answers || []).length ? pairs.length >= q.answers.length : !!pairs.length;
    }
    return answered(q.answer);
  };
  /** An answer as something to compare: ids as text, lists in any order, an empty one as nothing. */
  const canon = (v) => {
    if (v === null || v === undefined || v === '') return '';
    if (Array.isArray(v)) return JSON.stringify(v.map((x) => (x && typeof x === 'object' ? JSON.stringify(Object.entries(x).map(([k, y]) => [k, String(y)]).sort()) : String(x))).sort());
    if (typeof v === 'object') return JSON.stringify(Object.entries(v).filter(([, y]) => hasId(y)).map(([k, y]) => [k, String(y)]).sort());
    return String(v).trim();
  };
  // a question's words and an option's, for telling the same question apart from another in the same place
  const flat = (v) => String(v || '').replace(/\s+/g, ' ').trim().toLowerCase();
  // (a blank's field — a box or a list rendered into the words on the attempt being taken, [name] on a finished one's — is no word of the question)
  const wordsOf = (q) => flat(htmlToText(String(q.question_text || '').replace(/<select[\s\S]*?<\/select>/gi, ' ').replace(/<input[^>]*>/gi, ' ').replace(/\[[^\]\s]+\]/g, ' '), 8000));
  const optWords = (a) => flat(a.text || a.left || htmlToText(a.html || '', 400));
  const optSet = (q) => (q.answers || []).map(optWords).sort().join('|');
  /** The very same question: of the same kind, in the same words, with the same options (their words, in any order). */
  function sameQuestion(q, e) {
    if (!e || q.question_type !== e.question_type || wordsOf(q) !== wordsOf(e)) return false;
    if (CHOICE.has(q.question_type) || MULTI.has(q.question_type) || MATCH.has(q.question_type) || DROPS.has(q.question_type)) {
      if (optSet(q) !== optSet(e)) return false;
      if (MATCH.has(q.question_type) && (q.matches || []).map((m) => flat(m.text)).sort().join('|') !== (e.matches || []).map((m) => flat(m.text)).sort().join('|')) return false;
    }
    return true;
  }
  /** An answer given to the earlier twin, put in today's question's terms: each option it names found again by
   *  its words (a group's draw can give the same options other ids); null when one of them is not there. */
  function carryOver(q, e, answer) {
    if (answer === null || answer === undefined) return null;
    const byWords = (list, words) => list.find((a) => optWords(a) === words);
    const option = (id, blank = null) => {
      const was = (e.answers || []).find((a) => String(a.id) === String(id) && (blank === null || String(a.blank_id) === String(blank)));
      if (!was) return null;
      const now = byWords((q.answers || []).filter((a) => blank === null || String(a.blank_id) === String(blank)), optWords(was));
      return now ? whole(now.id) : null;
    };
    if (CHOICE.has(q.question_type)) return option(answer);
    if (MULTI.has(q.question_type)) { const ids = [].concat(answer).map((id) => option(id)); return ids.every((id) => id !== null) && ids.length ? ids : null; }
    if (MATCH.has(q.question_type)) {
      const pairs = pairsOf(answer).map((p) => {
        const left = option(p.answer_id);
        const m = (e.matches || []).find((x) => String(x.match_id) === String(p.match_id));
        const mNow = m && (q.matches || []).find((x) => flat(x.text) === flat(m.text));
        return left !== null && mNow ? { answer_id: left, match_id: whole(mNow.match_id) } : null;
      });
      return pairs.length && pairs.every(Boolean) ? pairs : null;
    }
    if (DROPS.has(q.question_type)) {
      const out = {};
      for (const [blank, id] of Object.entries(answer || {})) { const now = option(id, blank); if (now === null) return null; out[blank] = now; }
      return Object.keys(out).length ? out : null;
    }
    return answer; // (words or a number typed: the same question takes them as they were)
  }
  const parseCorrect = (v) => (v === true || v === 'true' ? true : v === false || v === 'false' ? false : v === 'partial' ? 'partial' : null);
  /** The student's answer as the graded history records it: answer_id, answer_<id> — a "1" per
   *  option ticked (multiple answers) or the match each left-hand value was set to (matching) —
   *  answer_for_<blank> and answer_id_for_<blank> (the blank kinds), or text. */
  function histAnswer(q, d) {
    if (FILE.has(q.question_type)) { const ids = (Array.isArray(d.attachment_ids) ? d.attachment_ids : []).filter(hasId).map(whole); return ids.length ? ids : null; }
    if (MULTI.has(q.question_type)) {
      const on = Object.keys(d).filter((k) => /^answer_\d+$/.test(k) && String(d[k]) === '1').map((k) => Number(k.slice(7)));
      return on.length ? on : null;
    }
    if (MATCH.has(q.question_type)) {
      const pairs = Object.keys(d).filter((k) => /^answer_\d+$/.test(k) && hasId(d[k])).map((k) => ({ answer_id: whole(k.slice(7)), match_id: whole(d[k]) }));
      return pairs.length ? pairs : null;
    }
    if (BLANKS.has(q.question_type)) {
      const out = {};
      for (const k of Object.keys(d)) {
        const blank = /^answer_for_(.+)$/.exec(k)?.[1];
        if (!blank) continue;
        const v = DROPS.has(q.question_type) && hasId(d[`answer_id_for_${blank}`]) ? d[`answer_id_for_${blank}`] : d[k];
        if (hasId(v)) out[blank] = v;
      }
      return Object.keys(out).length ? out : null;
    }
    const text = d.text === undefined || d.text === null || d.text === '' ? null : d.text;
    if (CHOICE.has(q.question_type)) return d.answer_id ?? (text !== null && Number.isFinite(Number(text)) ? Number(text) : null);
    return text;
  }
  /** The correct answer(s): the answers Canvas weights 100 (absent when censored), as the pieces
   *  answerParts gives, so a formula shows as the formula rather than as nothing. */
  function fbRight(q) {
    const one = (a) => {
      if (String(a.text || '').trim() || String(a.html || '').trim()) return { text: a.text || '', html: a.html || '' };
      if (a.numerical_answer_type === 'range_answer' && a.start !== undefined) return { text: `${a.start} – ${a.end}`, html: '' };
      if (a.exact !== undefined && a.exact !== null) return { text: Number(a.margin) ? `${a.exact} ± ${a.margin}` : String(a.exact), html: '' };
      if (a.approximate !== undefined && a.approximate !== null) return { text: String(a.approximate), html: '' };
      if (a.answer !== undefined && a.answer !== null && a.answer !== '') return { text: String(a.answer), html: '' }; // (a formula's result for this attempt)
      if (a.left && a.right) return { text: `${a.left} → ${a.right}`, html: '' };
      return null;
    };
    const parts = (q.answers || []).filter((a) => Number(a.weight) === 100).map(one).filter(Boolean);
    return parts.length ? parts : null;
  }
  /** Solution html from the question data: the neutral comment, else the one for this outcome. */
  function fbSolution(q, ok) {
    const html = q.neutral_comments_html || (ok ? q.correct_comments_html : q.incorrect_comments_html);
    if (html && String(html).trim()) return { html };
    const text = q.neutral_comments || (ok ? q.correct_comments : q.incorrect_comments);
    return text && String(text).trim() ? { text: String(text).trim() } : null;
  }
  /** The correct answer(s) as Canvas's results page marks them, in the pieces answerParts gives: an
   *  option's own words from the question where it has them (the page's otherwise). */
  function pageRight(q, pq) {
    if (!pq?.right?.length) return null;
    const opts = new Map((q.answers || []).map((a) => [String(a.id), a]));
    const parts = pq.right.map((x) => {
      const o = opts.get(String(x.id));
      const own = o && (String(o.text || '').trim() || String(o.html || '').trim()) ? { text: o.text || '', html: o.html || '' } : { text: x.text || '', html: x.html || '' };
      return String(own.text).trim() || String(own.html).trim() ? { ...own, text: x.blank && BLANKS.has(q.question_type) && String(own.text).trim() ? `${x.blank}: ${own.text}` : own.text } : null;
    }).filter(Boolean);
    return parts.length ? parts : null;
  }
  const hasNum = (v) => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));
  /** An answer as pieces to show: its own words, and the rich content Canvas holds it in when there
   *  is any — which is how a formula arrives, as an equation image with the LaTeX on the tag. */
  const partText = (p) => (String(p.text).trim() ? p.text : htmlToText(p.html || '', 80)) || '—';
  function answerPartsOf(q, files = {}) {
    const a = q.answer;
    if (!answered(a)) return null;
    const opts = q.answers || [];
    const one = (id) => {
      const o = opts.find((x) => String(x.id) === String(id));
      return o ? { text: o.text || '', html: o.html || '' } : { text: String(id), html: '' };
    };
    // a pair each: the left-hand value and what it was set to
    if (MATCH.has(q.question_type)) {
      const nameOf = (mid) => (q.matches || []).find((m) => String(m.match_id) === String(mid))?.text || String(mid);
      const pairs = pairsOf(a);
      if (!pairs.length) return null;
      return pairs.map((p2) => ({ text: `${one(p2.answer_id).text || partText(one(p2.answer_id))} → ${nameOf(p2.match_id)}`, html: '' }));
    }
    // one value per blank, named for the blank it fills
    if (BLANKS.has(q.question_type)) {
      const filled = Object.entries(filledOf(a));
      if (!filled.length) return null;
      return filled.map(([blank, v]) => {
        const named = !/^[0-9a-f]{8,}$/i.test(blank); // a quiz read from Canvas's own page knows the blank only as a hash of its name
        const o = DROPS.has(q.question_type) ? opts.find((x) => String(x.id) === String(v) && String(x.blank_id) === String(blank)) : null;
        return { text: `${named ? `${blank}: ` : ''}${o ? (o.text || htmlToText(o.html || '', 60)) : v}`, html: '' };
      });
    }
    if (FILE.has(q.question_type)) return a.map((id) => ({ text: files[String(id)] || `File ${id}`, html: '' })); // (the name, where it was uploaded here)
    if (Array.isArray(a)) return a.map(one);
    if (CHOICE.has(q.question_type)) return [one(a)];
    if (looksHtml(a)) return [{ text: '', html: String(a), block: true }]; // (an essay written in Canvas's editor: formatting, not tags)
    return [{ text: String(a), html: '', block: q.question_type === 'essay_question' && (String(a).length > 90 || /\n/.test(String(a))) }];
  }

  async function render(ctx, course) {
    const { app, route } = ctx;
    const cid = course.id;
    const qid = route.arg;
    const quizUrl = `${course.url}/quizzes/${qid}`;
    // Settings → Developer → Quiz: the simulation quiz (content/app/quiz-sim.js) answers the quiz's
    // own calls in this tab — every Classic kind, marked here — and nothing goes to Canvas
    const simulated = route.params.get('sim') === '1' && String(qid) === '0';
    if (simulated && !BCV.quizSim) await BCV.lazy.load('quizsim');
    const store = simulated ? BCV.quizSim.store(BCV.store) : BCV.store;
    const simHome = `${quizUrl}?bcv=take&sim=1`;
    const html = document.documentElement;
    // The flow lives in the course's own column. The intro and the feedback sit there like any tab
    // (the course header and rail stay); an attempt sets html.bcv-quiz, which folds the sidebar, the
    // header and the rail away so the questions take the page. app.js clears it on the next render.

    // fbSub: the finished attempt the feedback stage shows; fbFrom: 'done' when it was opened from the receipt
    const st = { stage: 'intro', idx: 0, mode: 'one', quiz: null, sub: null, questions: [], flags: {}, files: {}, saving: 0, savedAt: 0, timer: null, warned: {}, done: null, code: '', fbSub: null, fbFrom: null, fb: null, page: null, paged: false, inflight: new Set(), loadingIdx: null, hints: null, follow: null, hold: null };
    const screen = U.el('bcv-qz');
    screen.append(U.loading('Loading the quiz…'));

    const [quiz, subs] = await Promise.all([store.quiz(cid, qid, { force: true }).catch(() => null), store.quizSubmissions(cid, qid, { force: true }).catch(() => [])]);
    if (!ctx.alive()) return screen;
    if (!quiz) {
      screen.replaceChildren(U.el('bcv-qz__intro', [U.errorBox('This quiz could not be loaded.'), h('button', { type: 'button', class: 'bcv-qz__big', text: 'Back to the course', onclick: () => app.go(course.url, { confirmed: true }) })]));
      return screen;
    }
    st.quiz = quiz;
    st.sub = (subs || []).find((s) => s.workflow_state === 'untaken') || null;
    // a phone shows one question per screen (the mockup); the scroll-through mode is a desktop choice
    const phone = !!BCV.phone?.active();
    const [picked, asub0] = await Promise.all([
      store.pref('quizLayout', 'side'),
      quiz.assignment_id && !simulated ? store.submission(cid, quiz.assignment_id).catch(() => null) : null,
    ]);
    // a grade the instructor has not posted yet (Canvas: "Your quiz has been muted") keeps the attempt's
    // results back too — its score and which answers were right. Read here for the buttons; the
    // feedback itself reads the submission afresh before it shows a thing (loadFeedback)
    st.held = heldBack(asub0);
    st.asub = asub0; // (the intro's attempts: the assignment's submission history)
    const layout = LAYOUTS.includes(picked) ? picked : 'side';
    // a quiz set to one question at a time can be drawn either way that shows one question: the side
    // layout or the plain one — never all on one scroll
    st.mode = phone ? 'one' : quiz.one_question_at_a_time && layout === 'all' ? 'side' : layout;
    let forcedOne = !!quiz.one_question_at_a_time || phone;
    // A quiz set to one question at a time cannot list its questions through the API (Canvas refuses:
    // "Cannot receive one question at a time questions in the API"), but Canvas's own page shows one
    // per request and the answer, flag, clock and submit calls still work. So the attempt runs here
    // as for any other quiz, each question read from that page (BCV.quizPage) and every move made
    // the way that page makes it — which is also how Canvas enforces "no going back".
    st.paged = !!quiz.one_question_at_a_time;
    const noBack = !!quiz.cant_go_back;
    // A quiz Canvas locks seals each question the moment you leave it: an answer cannot be changed
    // and a question cannot be returned to. It is taken here like any other — noBack below is what
    // enforces the sealing — and Open in Canvas is still on the page for anyone who wants it.
    const timed = !!quiz.time_limit;
    // Attempts come from Canvas's own count on the submission (plus any extra the instructor
    // granted); allowed === null means unlimited. The store refuses to start one past the limit too.
    const limit = store.quizAttemptLimit(quiz, subs);
    const attemptsLeft = limit.left;
    const allowed = limit.allowed;
    if (route.params.get('bcv') === 'feedback') {
      st.fbSub = pickFeedbackSub(route.params.get('sub'), route.params.get('attempt'));
      st.stage = 'feedback';
    }

    // ---- leave guard ---------------------------------------------------------------
    // app.go() asks before leaving while quizOpen is set (and clears it once you
    // say yes), so the browser-level guard only catches closing the tab, the back
    // button and typed URLs.
    const onUnload = (e) => {
      if (!app.state.quizOpen || !ctx.alive()) return;
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', onUnload);
    const setOpen = (open) => {
      app.state.quizOpen = open && ctx.alive();
      BCV.app?.syncQuizFlag?.(); // (the pinned tools go while the attempt is on)
    };
    const leave = () => {
      setOpen(false);
      clearInterval(st.timer);
      // (2.99.56: from the intro, back to the course's quizzes — the intro is the quiz's address now; 2.99.67: on a computer
      //  the intro is a popup over the page it was opened from, so closing it goes back to that page)
      const from = st.stage === 'intro' && !simulated && !phone ? app.backTo?.({ href: `${course.url}/quizzes` })?.href : null;
      app.go(st.stage === 'intro' ? (simulated ? course.url : from || `${course.url}/quizzes`) : simulated ? simHome : quizUrl, { confirmed: true });
    };

    // the dimmed page behind the intro's popup (2.99.67): a press on it closes the popup, as Escape does
    const veil = h('div', { class: 'bcv-qz-veil', 'aria-hidden': 'true', onclick: () => leave() });
    const dropVeil = () => { veil.remove(); document.removeEventListener('keydown', onPopKey, true); };
    U.onGone?.(screen, dropVeil); // (the screen gone — any navigation — takes the dimming with it)
    function onPopKey(e) {
      if (e.key !== 'Escape' || !screen.classList.contains('is-pop') || !ctx.alive()) { if (!ctx.alive()) dropVeil(); return; }
      if (document.querySelector('.bcv-sheet-ov, .bcv-menu, .bcv-pv')) return; // (something over it goes first)
      e.stopPropagation();
      leave();
    }

    // ---- header -------------------------------------------------------------------
    const dueDay = quiz.due_at ? U.DAYS_LONG[U.parse(quiz.due_at).getDay()] : 'No due date';
    const timerLabel = h('span', { class: 'bcv-qz__clock', text: '0:00' });
    const modeWrap = h('div', { class: 'bcv-seg bcv-qz__modes' });
    const progressWrap = h('div');
    // The way out of our quiz UI without giving anything up: Canvas's own quiz page, punched through.
    // Every answer is already with Canvas — the attempt is not restarted and nothing is re-asked.
    const toRaw = () => {
      setOpen(false); // leaving on purpose: no prompt from the unload guard
      clearInterval(st.timer);
      const attempt = st.sub && (st.stage === 'take' || st.stage === 'review');
      location.href = `${location.origin}${quizUrl}${attempt ? '/take' : ''}?bcv=native`;
    };
    const rawBtn = h('button', {
      type: 'button', class: 'bcv-qz__raw', onclick: toRaw,
      title: "Show Canvas's own quiz page. Your answers are already saved with Canvas — the attempt is not restarted and the page is not reloaded from the start.",
    }, [U.svg(IC.external, { size: 13, width: 2 }), h('span', { text: 'Canvas page' })]);
    // The instructions are on the intro card, but an attempt takes the page and the card with it —
    // and that is exactly when a rule about rounding or a link to a formula sheet is wanted. So they
    // stay one press away the whole way through, in a sheet over the questions, drawn as prose (the
    // quiz's own links, tables and formulas included) rather than flattened to text.
    const hasInstructions = !!htmlToText(quiz.description || '', 4000).trim();
    const instrBtn = h('button', {
      type: 'button', class: 'bcv-qz__instrbtn', onclick: openInstructions,
      title: "Show this quiz's instructions. Nothing about your attempt changes.",
    }, [U.svg(IC.book, { size: 13, width: 2 }), h('span', { text: 'Instructions' })]);
    const exitBtn = h('button', { type: 'button', class: 'bcv-qz__exit', title: 'Save and exit', 'aria-label': 'Save and exit', onclick: leave }, U.svg(IC.close, { size: 16, width: 2.2 }));
    // Developer (Settings → Developer → Quiz): what was right in an earlier attempt, shown in purple on this
    // one (2.98.70: shown, never picked or saved). Never there unless it was turned on there.
    const devImport = await BCV.settings.get().then((s) => s?.developer?.quizImport === true).catch(() => false);
    if (!ctx.alive()) return screen;
    const devBtn = h('button', {
      type: 'button', class: 'bcv-qz__devimport', hidden: true, onclick: () => importEarlier(),
      title: 'Developer: show in purple what you picked last time, where it was right — nothing is filled in',
    }, [U.svg('M12 4v11M7 10l5 5 5-5M5 20h14', { size: 13, width: 2 }), h('span', { text: 'Import answers' })]);
    const subLine = U.text('bcv-qz__sub', '');
    const timerBox = U.el('bcv-qz__timer', [U.svg('M12 5a8 8 0 100 16 8 8 0 000-16zM12 9v4l3 2', { size: 13, stroke: 'var(--bcv-ink3)', width: 2 }), timerLabel]);
    const headRow = U.el('bcv-qz__headrow', [
      exitBtn,
      h('div', { class: 'bcv-qz__titles' }, [U.text('bcv-qz__title bcv-ellip', quiz.title), subLine]),
      modeWrap,
      devBtn,
      instrBtn,
      rawBtn,
      timerBox,
    ]);
    const head = U.el('bcv-qz__head', [headRow, progressWrap]);
    // (2.99.87) the intro as a page in the app: the Canvas page and the timer move beside the page's own title (introTools);
    // anywhere else they are the head's again
    const introTools = U.el('bcv-qzi__tools');
    const body = h('div', { class: 'bcv-qz__body' });
    screen.replaceChildren(head, body);

    function openInstructions() {
      const written = hasInstructions
        ? BCV.screens.course.prose(quiz.description, { cls: 'bcv-qz__desc' })
        : h('p', { class: 'bcv-qz__p', text: 'This quiz came with no instructions.' });
      const inner = U.el('bcv-qz__instr', [written]);
      if (BCV.phone?.active()) {
        BCV.phone.openSheet({ label: 'Quiz instructions', title: 'Instructions', note: quiz.title, body: inner });
        return;
      }
      document.querySelector('.bcv-sheet-ov')?.remove();
      const ov = U.el('bcv-sheet-ov', null, { role: 'dialog', 'aria-label': 'Quiz instructions' });
      const close = () => BCV.ui.dismiss(ov);
      ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
      ov.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
      ov.append(U.el('bcv-sheet bcv-sheet--instr', [
        U.el('bcv-sheet__head', [
          h('div', { style: { flex: '1', minWidth: '0' } }, [U.text('bcv-sheet__title', 'Instructions'), U.text('bcv-sheet__desc bcv-ellip', quiz.title)]),
          h('button', { type: 'button', class: 'bcv-sheet__close', 'aria-label': 'Close', onclick: close }, U.svg(IC.close, { size: 13, stroke: 'var(--bcv-ink2)', width: 2.3 })),
        ]),
        inner,
      ]));
      document.body.append(ov);
      ov.tabIndex = -1;
      ov.focus();
    }

    const toTop = () => window.scrollTo(0, 0);

    function tick() {
      if (!ctx.alive()) { // the screen was left in place (a sidebar row): the clock stops with it, and no "1 minute left" lands on the Dashboard
        clearInterval(st.timer);
        window.removeEventListener('beforeunload', onUnload);
        return;
      }
      const sub = st.sub;
      if (!sub) {
        timerLabel.textContent = timed ? `${quiz.time_limit} min` : '0:00';
        return;
      }
      if (timed && sub.end_at) {
        const left = U.parse(sub.end_at) - Date.now();
        timerLabel.textContent = clock(left);
        timerLabel.classList.toggle('is-low', left < 5 * 60e3);
        if (left <= 5 * 60e3 && left > 4.9 * 60e3 && !st.warned[5]) { st.warned[5] = true; U.toast('5 minutes left.'); }
        if (left <= 60e3 && left > 50e3 && !st.warned[1]) { st.warned[1] = true; U.toast('1 minute left.', { error: true }); }
        if (left <= 0 && !st.warned[0] && st.stage === 'take') { st.warned[0] = true; timeUp(); }
      } else {
        const started = U.parse(sub.started_at);
        timerLabel.textContent = clock(started ? Date.now() - started : (sub.time_spent || 0) * 1000);
      }
    }
    st.timer = setInterval(tick, 1000);
    tick();

    // ---- state helpers -------------------------------------------------------------
    const cur = () => st.questions[Math.min(st.idx, st.questions.length - 1)];
    const answeredCount = () => st.questions.filter(isAnswered).length;
    const answeredLabel = () => `${answeredCount()} of ${st.questions.length} answered`;
    const saveState = () => (st.saving > 0 ? 'Saving…' : st.savedAt ? 'Saved' : '');

    // The access code, for the whole attempt: Canvas wants it on every answer, flag and the hand-in,
    // not only at the start. It is kept for this tab (sessionStorage, under the quiz), so an attempt
    // resumed here does not ask again; resumed in another tab, the intro asks first. Should Canvas
    // refuse a save for the code all the same (a code changed, an attempt begun on Canvas's own
    // page), the page asks for it there and then, and saves again — never a dead toast.
    const CODE_KEY = `bcv:qzcode:${qid}`;
    const remembered = () => { try { return sessionStorage.getItem(CODE_KEY) || ''; } catch { return ''; } };
    const remember = (code) => { try { if (code) sessionStorage.setItem(CODE_KEY, code); else sessionStorage.removeItem(CODE_KEY); } catch { /* fine without */ } };
    const codeFor = () => (st.code || '').trim() || remembered();
    const codeRefused = (e) => /access code/i.test(String(e?.message || ''));
    /* Canvas keeps an attempt's answers as one record, read, changed and written back whole on every
     * save (a flag too). Two saves at once each write over the other, and an answer is lost while the
     * screen shows it saved. So every write about the attempt goes up one at a time, in the order it
     * was made. */
    let writeChain = Promise.resolve();
    const inTurn = (fn) => { const run = writeChain.then(fn); writeChain = run.catch(() => {}); return run; };
    /** The answers Canvas holds for this attempt now, by question id (as picked: tidy), or null where it cannot say. */
    async function answersOnCanvas() {
      if (st.paged) return null; // (Canvas lists no questions for a one-at-a-time quiz)
      const list = await store.quizApi.questions(st.sub).catch(() => null);
      return list ? new Map(list.map((q) => [String(q.id), tidy({ ...q }).answer])) : null;
    }
    /** The questions answered here that Canvas does not hold as answered here, sent again one at a
     *  time; what is still not there after that comes back (null: Canvas could not be asked). */
    async function mendAnswers(questions) {
      let held = await answersOnCanvas();
      if (!held) return null;
      const off = (q) => canon(held.get(String(q.id))) !== canon(q.answer);
      const want = questions.filter((q) => !INFO.has(q.question_type) && answered(q.answer));
      const again = want.filter(off);
      if (!again.length) return [];
      for (const q of again) await inTurn(() => store.quizApi.answer(st.sub, q.id, q.answer, codeFor())).catch(() => {});
      held = await answersOnCanvas();
      if (!held) return null;
      return want.filter((q) => !answered(held.get(String(q.id)))); // (still missing altogether: a value Canvas writes its own way is not a loss)
    }
    let codePrompt = null; // the prompt on show, and the saves waiting on it: [q, answer][]
    function askForCode(q, answer) {
      if (codePrompt) { codePrompt.push([q, answer]); return; }
      codePrompt = [[q, answer]];
      U.promptSheet({
        label: 'Access code', title: 'Access code', note: 'Canvas wants the quiz’s access code to save your answers. Enter it to keep going — it stays with this attempt.',
        placeholder: 'Access code', value: '', saveLabel: 'Save answer',
        onSave: async (v) => {
          if (!v) throw new Error('Enter the access code.');
          await inTurn(() => store.quizApi.answer(st.sub, q.id, answer, v)); // (refused again: the prompt says so and stays)
          st.code = v;
          remember(v);
          st.savedAt = Date.now();
          const rest = codePrompt.slice(1);
          codePrompt = null;
          paintFooter();
          for (const [q2, a2] of rest) save(q2, a2); // the answers that waited on the code
        },
      });
      // (a prompt closed without a code: the answers stay unsaved, the footer says so, and the next save asks again)
      const watch = setInterval(() => { if (!document.querySelector('.bcv-sheet--prompt')) { clearInterval(watch); codePrompt = null; } }, 400);
    }
    async function save(q, answer) {
      q.answer = answer;
      st.saving++;
      paintFooter();
      const p = inTurn(() => store.quizApi.answer(st.sub, q.id, answer, codeFor()));
      st.inflight.add(p);
      try {
        await p;
        st.savedAt = Date.now();
      } catch (e) {
        if (codeRefused(e)) askForCode(q, answer);
        else U.toast(`Could not save that answer: ${e.message}`, { error: true });
      } finally {
        st.inflight.delete(p);
        st.saving--;
        paintFooter();
        paintProgress();
      }
    }
    // typing into a blank saves on a pause, the way every other typed answer does
    let blankTimer = null;
    const saveSoon = (fn) => { clearTimeout(blankTimer); blankTimer = setTimeout(fn, 600); };
    const textTimers = new Map();
    const textPending = new Map();
    function saveText(q, value) {
      q.answer = value;
      clearTimeout(textTimers.get(q.id));
      textPending.set(q.id, [q, value]);
      textTimers.set(q.id, setTimeout(() => { textPending.delete(q.id); save(q, value); }, 600));
    }
    /** Every answer on Canvas: typed text still waiting on its pause is sent now, and the saves in flight are awaited. */
    async function settled() {
      for (const [id, [q, value]] of [...textPending]) {
        clearTimeout(textTimers.get(id));
        textPending.delete(id);
        save(q, value);
      }
      if (st.inflight.size) await Promise.allSettled([...st.inflight]);
    }
    /** Developer (2.98.70): what was right before, shown on this attempt — never picked, never saved. An earlier
     *  answer goes only to the very question it was given for, never to the one in the same place: each earlier
     *  attempt's own questions are read (Canvas keeps the draw each attempt had) and today's question is the same
     *  one only if its kind, its words and its options are (sameQuestion) — the pick then carried by what the
     *  options say, not their place. A question with no such twin gets nothing. Of those, the latest attempt
     *  that got it right (the graded history's own mark, not partly) gives the answer, tinted purple where it
     *  would be picked — the option, the match, the dropdown's choice — or waiting in purple in an empty field. */
    async function importEarlier() {
      if (!quiz.assignment_id) { U.toast('This quiz keeps no graded history to import from.', { error: true }); return; }
      devBtn.disabled = true;
      try {
        const asub = await store.submission(cid, quiz.assignment_id, { force: true });
        if (!ctx.alive()) return;
        const earlier = (asub?.submission_history || [])
          .filter((x) => Array.isArray(x.submission_data) && x.submission_data.length && Number(x.attempt) !== Number(st.sub?.attempt))
          .sort((a, b) => Number(b.attempt) - Number(a.attempt)); // (newest first: the last time each was right)
        if (!earlier.length) { U.toast('No earlier attempt with answers to import.', { error: true }); return; }
        const map = new Map();
        const from = new Set();
        let read = 0;
        for (const x of earlier) {
          const then = await store.quizApi.attemptQuestions(cid, qid, st.sub, x.attempt).catch(() => null); // (hidden results: that attempt cannot be matched)
          if (!ctx.alive()) return;
          if (!then?.length) continue;
          read += 1;
          for (const q of st.questions) {
            if (map.has(String(q.id)) || INFO.has(q.question_type) || FILE.has(q.question_type)) continue;
            const twin = then.find((e) => sameQuestion(q, e));
            const d = twin && x.submission_data.find((y) => String(y.question_id) === String(twin.id));
            if (!d || parseCorrect(d.correct) !== true) continue;
            const answer = carryOver(q, twin, histAnswer(twin, d));
            if (answer === null || answer === undefined) continue;
            map.set(String(q.id), answer);
            from.add(Number(x.attempt));
          }
        }
        if (!read) { U.toast('Canvas would not show the questions of the earlier attempts, so none could be matched to these.', { error: true }); return; }
        if (!map.size) { U.toast('No earlier attempt got any of these exact questions right: nothing to show.'); return; }
        st.hints = { sub: st.sub?.id, map };
        draw();
        const n = map.size;
        const atts = [...from].sort((a, b) => a - b);
        U.toast(`${n} right ${n === 1 ? 'answer' : 'answers'} from ${atts.length === 1 ? 'attempt' : 'attempts'} ${atts.join(' and ')}, shown in purple on the same ${n === 1 ? 'question' : 'questions'}. Nothing is picked for you.`);
      } catch (e) {
        U.toast(`Could not import the answers: ${e.message}`, { error: true });
      } finally {
        devBtn.disabled = false;
      }
    }
    /** What was right before for a question, when Import answers has shown it on this attempt (undefined otherwise). */
    const hintFor = (q) => (st.hints && st.hints.sub === st.sub?.id ? st.hints.map.get(String(q.id)) : undefined);
    async function toggleFlag(q) {
      const on = !q.flagged;
      q.flagged = on;
      paintProgress();
      try {
        await inTurn(() => store.quizApi.flag(st.sub, q.id, on, codeFor()));
      } catch (e) {
        q.flagged = !on;
        paintProgress();
        U.toast(`Could not flag it: ${e.message}`, { error: true });
      }
      draw();
    }

    // ---- stages --------------------------------------------------------------------
    function draw() {
      if (!ctx.alive()) {
        clearInterval(st.timer);
        window.removeEventListener('beforeunload', onUnload);
        return;
      }
      // (2.99.56) every stage takes the page, the intro too — the quiz's own page, as the Mac's sheet holds its intro
      // and its attempt alike; the intro sat in the course's column under its header until then. A phone keeps the
      // intro a pushed course screen, its back bar and tab bar there.
      const embedded = phone && st.stage === 'intro';
      // (2.99.83) on a computer the intro is the quiz's page, in the app beside its sidebar and under its course, its head
      // (title, timer, Canvas page) at the top — no longer a popup over the page it was opened from (2.99.67); the
      // attempt itself still takes the page
      const pop = false;
      const asPage = !phone && st.stage === 'intro';
      const switchable = st.stage === 'take' && !phone; // (a phone shows one question a screen, always)
      const twoWays = switchable && !forcedOne; // (a quiz shown a question at a time has the one way to draw it)
      modeWrap.replaceChildren(...(twoWays ? [
        modeBtn('side', 'One question at a time', MODE_SIDE),
        modeBtn('all', 'Scroll through all questions', MODE_ALL),
      ] : []));
      modeWrap.hidden = !twoWays;
      if (twoWays) U.segSlide?.(modeWrap, '.bcv-qz__mode', 'qzmode'); // (its highlight slides between them, 2.98.71)
      devBtn.hidden = !(devImport && st.stage === 'take' && st.sub);
      const side = st.stage === 'take' && (st.mode === 'side' || st.mode === 'all'); // (2.99.78: both draw the side frame)
      if (!side && progressWrap.parentElement !== head) head.append(progressWrap); // (the side layout keeps the pills in its left rail)
      screen.classList.toggle('is-side', side);
      instrBtn.hidden = st.stage === 'intro' || st.stage === 'feedback'; // the intro card already has them in front of you; the feedback is about the answers
      rawBtn.hidden = simulated || st.stage === 'feedback'; // (the simulation has no page on Canvas)
      const closeWord = st.stage === 'feedback' ? 'Back to the quiz' : st.stage === 'intro' ? 'Close' : 'Save and exit';
      exitBtn.title = closeWord;
      exitBtn.setAttribute('aria-label', closeWord);
      // (2.99.55) the intro's line is the course alone, as the Mac's sheet names it; its facts say the due date below
      subLine.textContent = simulated ? 'Simulation · nothing goes to Canvas' : st.stage === 'intro' ? course.name : `${course.name} · ${dueDay}`;
      paintProgress();
      body.classList.toggle('is-busy', st.loadingIdx !== null && st.stage === 'take');
      if (asPage) { if (rawBtn.parentElement !== introTools) introTools.append(rawBtn); } else if (rawBtn.parentElement !== headRow) headRow.append(rawBtn, timerBox); // (2.99.93: no clock on the page before an attempt — the time limit is among its details)
      if (st.stage === 'intro') body.replaceChildren(intro());
      else if (st.stage === 'starting') body.replaceChildren(h('p', { class: 'bcv-qz__starting', text: st.sub ? 'Resuming your attempt…' : 'Starting your attempt…' }));
      else if (st.stage === 'take') body.replaceChildren(st.mode === 'all' ? takeAll() : st.mode === 'side' ? takeSide() : takeOne());
      else if (st.stage === 'review') body.replaceChildren(review());
      else if (st.stage === 'feedback') body.replaceChildren(feedback());
      else body.replaceChildren(done());
      screen.classList.toggle('is-feedback', st.stage === 'feedback');
      screen.classList.toggle('is-embedded', embedded);
      screen.classList.toggle('is-pop', pop);
      screen.classList.toggle('is-page', asPage);
      html.classList.toggle('bcv-quiz', !embedded && !pop && !asPage); // the attempt (and its receipt) takes the page
      if (pop && !veil.isConnected) { document.body.append(veil); document.addEventListener('keydown', onPopKey, true); }
      else if (!pop && veil.isConnected) dropVeil();
      setOpen(st.stage === 'take' || st.stage === 'review');
    }
    function modeBtn(key, label, icon) {
      return h('button', { type: 'button', class: `bcv-qz__mode ${st.mode === key ? 'is-active' : ''}`, title: label, 'aria-label': label, 'aria-pressed': st.mode === key ? 'true' : 'false', dataset: { mode: key }, onclick: () => {
        if (st.mode === key) return;
        st.mode = key;
        store.setPref('quizLayout', key);
        draw();
        if (key === 'all') sendTo(st.idx, { smooth: false }); // (the scroll opens on the question you were on)
        else toTop();
      } }, U.svg(icon, { size: 15, width: 1.9 }));
    }
    /** Scroll mode: the page goes to question k and the mark goes with it (followScroll holds it there
     *  while the page travels, so the questions passed on the way never take it). */
    function sendTo(k, { smooth = !U.reducedMotion() } = {}) {
      st.follow?.hold(k);
      const el = k > 0 ? document.getElementById(`bcv-q${k}`) : null;
      const there = el ? Math.abs(el.getBoundingClientRect().top - (parseFloat(getComputedStyle(el).scrollMarginTop) || 0)) < 1 : k <= 0 && window.scrollY < 1;
      if (there) { if (st.hold) st.hold.landed = true; return; } // (nothing to travel: the next scroll is yours)
      if (el) el.scrollIntoView({ block: 'start', behavior: smooth ? 'smooth' : 'auto' });
      else if (smooth) window.scrollTo({ top: 0, behavior: 'smooth' });
      else toTop();
    }

    // The pills are the progress bar (mockup 14): the pill of a question on its way fills left to right
    // like a sidebar row, while the question on screen stays put — no skeleton. Before the questions
    // arrive, one pill stands for each question the quiz says it has, the first of them filling.
    function paintProgress() {
      const starting = st.stage === 'starting';
      if (st.stage !== 'take' && !starting) {
        progressWrap.replaceChildren();
        return;
      }
      const all = st.mode === 'all' && !starting;
      const side = (st.mode === 'side' || st.mode === 'all') && !starting; // (a grid down the left rail)
      const list = st.questions.length ? st.questions : Array.from({ length: Math.max(1, Number(quiz.question_count) || 1) }, (_, k) => ({ id: `pending-${k}`, pending: true, flagged: false, answer: null }));
      progressWrap.replaceChildren(U.el(`bcv-qz__progress ${all ? 'bcv-qz__progress--all bcv-qz__progress--side' : side ? 'bcv-qz__progress--side' : ''}`, list.map((q, k) => {
        const current = !starting && k === st.idx;
        const locked = !starting && noBack && k < st.idx;
        const loading = st.loadingIdx === k;
        return h('button', {
          type: 'button',
          class: `bcv-qz__pill ${current ? 'is-current' : ''} ${!q.pending && isAnswered(q) ? 'is-answered' : ''} ${q.flagged ? 'is-flagged' : ''} ${loading ? 'is-loading' : ''}`,
          disabled: locked || null,
          title: `Question ${k + 1}${q.flagged ? ' · flagged' : ''}`,
          onclick: () => {
            if (locked || q.pending || st.loadingIdx !== null) return;
            if (st.paged) { if (k !== st.idx) turnPage({ questionId: q.id }); return; }
            st.idx = k;
            if (all) {
              sendTo(k);
              paintProgress();
            } else draw();
          },
        }, h('span', { class: 'bcv-qz__pilln', text: String(k + 1) }));
      })));
    }

    /** (2.99.55) Every finished attempt, newest first, with its score (where Canvas shows results) and when it was handed
     *  in, and the one Canvas keeps by the quiz's scoring rule — the Mac's intro's (native-app.js quizAttempts). */
    function introAttempts(survey) {
      const possible = store.fmtPts(quiz.points_possible || 0);
      const seen = new Set();
      const hist = (st.asub?.submission_history || [])
        .filter((x) => x && Number(x.attempt) > 0 && (x.submitted_at || (x.score !== null && x.score !== undefined)))
        .sort((a, b) => Number(b.attempt) - Number(a.attempt))
        .filter((x) => !seen.has(Number(x.attempt)) && seen.add(Number(x.attempt)));
      const hidden = hist.length ? resultsHidden(latestFinished() || hist[0]) : null;
      const scored = (x) => !survey && !hidden && x.workflow_state !== 'pending_review' && x.score !== null && x.score !== undefined;
      const rows = hist.map((x) => ({
        attempt: Number(x.attempt),
        score: scored(x) ? `${store.fmtPts(x.score)} / ${possible}` : null,
        when: x.submitted_at ? `Handed in ${U.fmtAt(x.submitted_at)}` : '',
        why: scored(x) ? '' : (survey ? 'Survey' : hidden ? 'Hidden' : x.workflow_state === 'pending_review' ? 'Waiting to be graded' : ''),
        kept: false,
      }));
      const marked = rows.filter((r) => r.score !== null);
      let keptNote = '';
      if (marked.length > 1 && !survey) {
        const policy = quiz.scoring_policy || 'keep_highest';
        if (policy === 'keep_latest') { marked[0].kept = true; keptNote = 'Canvas keeps your latest score.'; }
        else if (policy === 'keep_average') keptNote = 'Canvas keeps the average of your scores.';
        else {
          const best = hist.filter(scored).reduce((m, x) => (m === null || Number(x.score) > Number(m.score) ? x : m), null);
          const row = best && rows.find((r) => r.attempt === Number(best.attempt));
          if (row) row.kept = true;
          keptNote = 'Canvas keeps your highest score.';
        }
      }
      return { rows, keptNote };
    }
    /** (2.99.55) Whether an attempt may begin, and why not (the Mac's intro: canStart, begin). */
    const introCanStart = () => !quiz.locked_for_user && !quiz.require_lockdown_browser && (attemptsLeft === null || attemptsLeft > 0 || !!st.sub);
    const introNeedsCode = () => !!(quiz.access_code || quiz.has_access_code || st.needsCode);
    /**
     * A quiz before an attempt, as the Mac's quiz sheet opens on it (2.99.55): what it is — its facts, each with its
     * symbol, and where the attempts stand in one line — then why it cannot begin, its instructions ("Before You Start"),
     * the access code when it wants one, its rules, and every attempt so far; on a wide page the instructions on the
     * left and the code, the rules and the attempts in a column beside them. Just the buttons float at the foot: an
     * attempt under way, Continue; a finished one with its feedback and another attempt left, See Feedback and Take
     * Quiz side by side; none left, See Feedback alone; else Begin Attempt, waiting (greyed out) for the code. Enter
     * presses the main one.
     */
    function intro() {
      const survey = /survey/.test(quiz.quiz_type || '');
      const gradedSurvey = quiz.quiz_type === 'graded_survey';
      const needsCode = introNeedsCode();
      if (needsCode && !(st.code || '').trim()) st.code = remembered(); // (an attempt resumed in this tab: the code is still known)
      const lockdown = !!quiz.require_lockdown_browser;
      const canStart = introCanStart();
      const pts = quiz.points_possible !== null && quiz.points_possible !== undefined ? `${store.fmtPts(quiz.points_possible)} ${Number(quiz.points_possible) === 1 ? 'point' : 'points'}` : 'Ungraded';
      const facts = [
        [IC.list || IC.task, U.plural(quiz.question_count || 0, 'question')],
        [IC.star, survey ? (gradedSurvey ? `${pts} for taking part` : 'Not graded') : pts],
        [IC.cal, quiz.due_at ? `Due ${U.fmtAtUpper(quiz.due_at)}` : 'No due date'],
      ];
      // where the attempts stand, in one line that counts the attempt under way (the engine's note)
      const n = st.sub ? Number(st.sub.attempt) || limit.used + 1 : limit.used + 1;
      const N = allowed;
      const which = N === null ? `Attempt ${n}` : N === 1 ? 'This is your only attempt' : `Attempt ${n} of ${N}`;
      const after = N === null || N === 1 ? '' : N - n > 0 ? `${N - n} more after this one` : 'your last one';
      const note = st.sub ? [which, `started ${U.fmtAt(st.sub.started_at)}`, after].filter(Boolean).join(' · ')
        : N !== null && attemptsLeft <= 0 ? (N === 1 ? 'Your one attempt is used' : `All ${N} attempts used`)
          : N !== null ? [which, after].filter(Boolean).join(' · ')
            : 'Nothing is submitted until you say so.';
      const rules = [
        noBack ? [IC.lock, '#ff9500', 'Each question is sealed once you leave it: an answer cannot be changed and you cannot go back.'] : null,
        [IC.okcircle || IC.check, '#34c759', survey ? 'A survey has no right answers. Your responses save as you go, and you can leave and come back.' : 'Answers save as you pick them. You can leave and come back.'],
        quiz.anonymous_submissions ? [IC.people, 'var(--bcv-ink3)', 'Your responses are anonymous.'] : null,
        timed ? [IC.timer || IC.clock, '#ff9500', `Time limit: ${quiz.time_limit} minutes. The clock starts when you begin and keeps running if you leave.`] : null,
        quiz.one_question_at_a_time ? [MODE_ONE, 'var(--bcv-ink3)', noBack ? 'One question at a time, with no going back.' : 'One question at a time.'] : null,
        allowed === null ? [IC.bolt, 'var(--bcv-ink3)', 'Unlimited attempts.'] : null,
        quiz.lock_at ? [IC.cal, 'var(--bcv-ink3)', `Available until ${U.fmtAt(quiz.lock_at)}.`] : null,
        quiz.ip_filter ? [IC.globe || IC.lock, '#ff9500', 'This quiz can only be taken from an allowed network, such as the classroom or campus.'] : null,
        lockdown ? [IC.shield || IC.lock, '#ff9500', 'This quiz needs Respondus LockDown Browser. Open Canvas in that browser to take it.'] : null,
      ].filter(Boolean);
      const last = latestFinished();
      const lastHidden = last ? resultsHidden(last) : null;
      const seeable = !!last && !survey && !lastHidden; // (an earlier attempt's feedback can be seen)
      const feedback = seeable && !st.sub;
      const codeMissing = () => needsCode && !(st.code || '').trim();
      const beginTitle = canStart ? (st.sub ? (survey ? 'Continue Survey' : 'Continue Attempt') : (survey ? 'Begin Survey' : 'Begin Attempt')) : lockdown ? 'Needs LockDown Browser' : quiz.locked_for_user ? 'Locked' : 'No Attempts Left';
      const takeTitle = survey ? 'Take Survey' : 'Take Quiz';
      // (2.99.93) on a computer the page is laid out as the assignment page (introPage below): each section a heading over a card
      const sec = phone
        ? (title, body, part) => U.el(`bcv-qzi__sec bcv-qzi__sec--${part}`, [h('h2', { class: 'bcv-qzi__sechead', text: title }), body])
        : (title, body, part) => U.el(`bcv-asg__section bcv-qzi__sec--${part}`, [U.el('bcv-asg__sectionhead', [h('h2', { class: 'bcv-asg__h2 bcv-qzi__sechead', text: title })]), U.el('bcv-asg__panel', [body])]);
      const icon = (path, color) => U.svg(path, { size: 16, stroke: color, width: 2, style: { flex: 'none' } });

      const heading = U.el('bcv-qzi__heading', [
        U.el('bcv-qzi__titlerow', [h('h1', { class: 'bcv-qzi__title bcv-pretty', text: quiz.title }), introTools]), // (the Mac's sheet names it in its bar; here the page does)
        U.el('bcv-qzi__facts', facts.map(([ic, text]) => U.el('bcv-qzi__fact', [icon(ic, 'var(--bcv-cc, var(--bcv-blue))'), h('span', { text })]))),
        note ? U.el('bcv-qzi__note', [U.svg('M4 12a8 8 0 108-8 8 8 0 00-6 2.7M4 4v4h4', { size: 14, stroke: 'currentColor', width: 2, style: { flex: 'none' } }), h('span', { text: note })]) : null,
      ]);
      const lockText = quiz.locked_for_user ? (quiz.lock_explanation ? htmlToText(quiz.lock_explanation, 200) : 'This quiz is locked.') : '';
      const notices = st.codeErr || lockText ? U.el(`bcv-qzi__notices${phone ? '' : ' bcv-asg__panel'}`, [
        st.codeErr ? U.el('bcv-qzi__notice is-bad', [icon(IC.warn, 'currentColor'), h('span', { class: 'bcv-qz__codeerr', text: st.codeErr })]) : null,
        lockText ? U.el('bcv-qzi__notice', [icon(IC.lock, 'currentColor'), h('span', { text: lockText })]) : null,
      ]) : null;
      const instructions = htmlToText(quiz.description || '', 4000).trim() ? sec(phone ? 'Before You Start' : 'Instructions', BCV.screens.course.prose(quiz.description, { cls: phone ? 'bcv-qz__desc' : 'bcv-qz__desc bcv-asg__prose' }), 'instr') : null;
      let mainBtn = null;
      const codeInput = needsCode ? h('input', { class: 'bcv-input bcv-qz__code', type: 'text', placeholder: 'Access code', value: st.code || '', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Access code', oninput: (e) => { st.code = e.target.value; bar.querySelectorAll('[data-begin]').forEach((b) => { b.disabled = (!canStart || codeMissing()) || null; }); }, onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); if (canStart && !codeMissing()) begin(); } } }) : null;
      const code = needsCode ? sec('Access Code', U.el('bcv-qzi__code', [codeInput, U.text('bcv-qzi__caption', 'Your instructor gives the code. It stays with this attempt.')]), 'code') : null;
      const rulesEl = rules.length ? sec('Rules', U.el('bcv-qzi__rules', rules.map(([ic, color, text]) => U.el('bcv-qzi__rule', [U.el('bcv-qzi__ruleic', [icon(ic, color)]), h('span', { class: 'bcv-pretty', text })]))), 'rules') : null;
      const { rows, keptNote } = introAttempts(survey);
      const attemptsEl = rows.length
        ? sec(rows.length === 1 ? 'Your Attempt' : 'Your Attempts', U.el('bcv-qzi__attempts', [
          ...rows.map((r) => U.el('bcv-qzi__attempt', [
            U.el('bcv-qzi__attemptl', [
              U.el('bcv-qzi__attemptn', [h('span', { text: `Attempt ${r.attempt}` }), r.kept ? U.badge('Kept', 'green') : null]),
              r.when ? U.text('bcv-qzi__attemptwhen', r.when) : null,
            ]),
            r.score ? U.text(`bcv-qzi__score${r.kept ? ' is-kept' : ''}`, r.score) : r.why ? U.text('bcv-qzi__why', r.why) : null,
          ])),
          keptNote ? U.text('bcv-qzi__caption', keptNote) : null,
        ]), 'attempts')
        : null;
      // the buttons, floating at the foot
      const bar = U.el('bcv-qzi__bar');
      const BTN_IC = { 'See Feedback': IC.disc };
      const btn = (text, primary, onclick) => (phone
        ? h('button', { type: 'button', class: `bcv-qzi__btn${primary ? ' is-primary bcv-qz__begin' : ''}`, text, onclick }) // (bcv-qz__begin: the main one, as it has always been named)
        : h('button', { type: 'button', class: `bcv-qzi__btn bcv-asg__step${primary ? ' is-primary is-lit bcv-qz__begin' : ''}`, onclick }, [ // (the rail's pills, as the assignment page's Hand In)
          U.svg(BTN_IC[text] || 'M8 5v14l11-7z', { size: 16, stroke: 'currentColor', width: 2.1 }), h('span', { text }),
        ]));
      if (st.sub && seeable && canStart) {
        // (2.99.58) an attempt under way, an earlier one's feedback to see: See Feedback, Continue Attempt the smaller
        const cont = btn(beginTitle, false, () => { if (canStart && !codeMissing()) begin(); });
        cont.dataset.begin = '1';
        cont.disabled = codeMissing() || null;
        cont.title = codeMissing() ? 'Type the access code first' : beginTitle;
        mainBtn = btn('See Feedback', true, () => openFeedback(last, 'intro'));
        bar.append(cont, mainBtn);
      } else if (feedback && canStart) {
        mainBtn = btn(takeTitle, true, () => { if (canStart && !codeMissing()) begin(); });
        mainBtn.dataset.begin = '1';
        mainBtn.disabled = codeMissing() || null;
        mainBtn.title = codeMissing() ? 'Type the access code first' : takeTitle;
        bar.append(btn('See Feedback', false, () => openFeedback(last, 'intro')), mainBtn);
      } else if (feedback) {
        mainBtn = btn('See Feedback', true, () => openFeedback(last, 'intro'));
        bar.append(mainBtn);
      } else {
        mainBtn = btn(beginTitle, true, () => { if (canStart && !codeMissing()) begin(); });
        mainBtn.dataset.begin = '1';
        mainBtn.disabled = (!canStart || codeMissing()) || null;
        mainBtn.title = codeMissing() && canStart ? 'Type the access code first' : beginTitle;
        bar.append(mainBtn);
      }
      if (!phone) return introPage({ survey, gradedSurvey, pts, note, notices, code, instructions, rulesEl, attemptsEl, bar, mainBtn, codeInput, canStart, last, N, codeFocus: codeInput && !(st.code || '').trim() });
      // (2.99.56: no way-back row — the quiz's own page has Close at its top, as the Mac's sheet)
      const root = U.el('bcv-qzi', [
        U.el('bcv-qzi__cols', [
          U.el('bcv-qzi__main', [heading, notices, instructions].filter(Boolean)),
          U.el('bcv-qzi__side', [code, rulesEl, attemptsEl].filter(Boolean)),
        ]),
        bar,
      ].filter(Boolean));
      // Enter presses the main button (not while typing in a field other than the code's, which has its own)
      root.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.defaultPrevented && !e.target.closest('input,textarea,select,button,a') && mainBtn && !mainBtn.disabled) { e.preventDefault(); mainBtn.click(); } });
      // a quiz that wants a code: its field ready to type in
      if (codeInput && !(st.code || '').trim()) setTimeout(() => { if (codeInput.isConnected) codeInput.focus(); }, 120);
      return root;
    }

    /** (2.99.93) The quiz's page on a computer, as the assignment page: over the title its kind, its course and where it
     *  stands; down the right the one big button (and the attempts line under it) over the details — Due, Points,
     *  Questions, the time limit, the attempts; down the left what to know first (the code, the instructions, the rules,
     *  the attempts made). No clock before an attempt: the time limit is one of the details. */
    function introPage(o) {
      const kind = h('span', { class: 'bcv-asg__kind' }, [h('span', { class: 'bcv-asg__kindtile', 'aria-hidden': 'true' }, U.svg(IC.bolt, { size: 14, stroke: 'currentColor', width: 2 })), h('span', { text: o.survey ? 'Survey' : 'Quiz' })]);
      const used = o.N !== null && attemptsLeft <= 0;
      const [word, tone] = st.sub ? ['In progress', 'orange'] : quiz.locked_for_user ? ['Locked', 'grey'] : used ? ['Done', 'green'] : o.last ? ['Submitted', 'green'] : ['Open', 'blue'];
      const chips = U.el('bcv-asg__chips', [
        kind,
        h('span', { class: 'bcv-asg__coursechip bcv-ellip', text: course.shortName || course.name || '' }),
        h('div', { class: `bcv-asg__status is-${tone}` }, [U.text('bcv-asg__statustext', word, 'span')]),
        introTools, // (the Canvas page, at the row's end)
      ]);
      const headEl = U.el('bcv-detail__head bcv-asg__head', [chips, h('h1', { class: 'bcv-detail__title bcv-asg__title bcv-qzi__title bcv-pretty', text: quiz.title })]);
      const FACT = { Due: IC.cal, Points: IC.star, Questions: IC.list || IC.task, 'Time Limit': 'M12 5a8 8 0 100 16 8 8 0 000-16zM12 9v4l3 2M10 2h4', Attempts: 'M4 12a8 8 0 108-8 8 8 0 00-5.7 2.3L4 8.6M4 4v4.6h4.6', Available: 'M12 4a8 8 0 100 16 8 8 0 000-16zM12 8v4l3 2' };
      const fact = (k, v) => h('div', { class: 'bcv-asg__fact' }, [
        h('span', { class: 'bcv-asg__facttile', 'aria-hidden': 'true' }, U.svg(FACT[k], { size: 15, stroke: 'currentColor', width: 2 })),
        U.el('bcv-asg__facttext', [U.text('bcv-asg__factk', k, 'span'), U.text('bcv-asg__factv bcv-qzi__fact bcv-ellip', v, 'span')]),
      ]);
      const at = (d) => `${U.fmtShort(d)} at ${U.fmtTime(d)}`;
      const facts = U.el('bcv-asg__facts', [
        fact('Questions', U.plural(quiz.question_count || 0, 'question')),
        fact('Points', o.survey ? (o.gradedSurvey ? `${o.pts} for taking part` : 'Not graded') : o.pts),
        fact('Due', quiz.due_at ? at(quiz.due_at) : 'No due date'),
        timed ? fact('Time Limit', `${quiz.time_limit} minutes`) : null,
        fact('Attempts', o.N === null ? 'Unlimited' : o.N === 1 ? 'One attempt' : `${o.N} attempts`),
        quiz.lock_at ? fact('Available', `Until ${at(quiz.lock_at)}`) : null,
      ].filter(Boolean));
      o.bar.classList.add('bcv-asg__stepbtns');
      const steps = U.el('bcv-asg__steps', [
        o.bar,
        o.note ? U.el('bcv-qzi__note bcv-asg__drophint', [h('span', { text: o.note })]) : null,
      ].filter(Boolean));
      const rail = U.el('bcv-asg__rail bcv-qzi__side', [steps, facts]);
      const left = U.el('bcv-asg__left', [o.notices, o.code, o.instructions, o.rulesEl, o.attemptsEl].filter(Boolean));
      const root = U.el('bcv-qzi bcv-qzi--page bcv-asg', [headEl, U.el('bcv-asg__cols', [rail, left])], { style: { '--bcv-cc': course.color || 'var(--bcv-blue)', '--bcv-cc-ink': course.palette?.text || course.color || 'var(--bcv-blue)' } });
      root.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.defaultPrevented && !e.target.closest('input,textarea,select,button,a') && o.mainBtn && !o.mainBtn.disabled) { e.preventDefault(); o.mainBtn.click(); } });
      if (o.codeFocus) setTimeout(() => { if (o.codeInput.isConnected) o.codeInput.focus(); }, 120);
      return root;
    }

    async function begin() {
      if ((quiz.access_code || quiz.has_access_code || st.needsCode) && !(st.code || '').trim()) { st.codeErr = 'Enter the access code first.'; draw(); return; } // required before an attempt
      // the popup opens at once, its pills standing for the questions to come, the first filling while they load
      st.stage = 'starting';
      st.loadingIdx = 0;
      draw();
      try {
        st.sub = await store.quizApi.start(cid, qid, st.code);
        st.codeErr = '';
        if ((st.code || '').trim()) remember(st.code.trim());
        if (!st.paged) {
          try {
            st.questions = (await store.quizApi.questions(st.sub)).map(tidy);
          } catch (e) {
            if (!/one question at a time/i.test(e.message || '')) throw e;
            st.paged = true; // the quiz did not say so, but Canvas did
            forcedOne = true;
            if (st.mode === 'all') st.mode = 'side';
          }
        }
        if (st.paged) applyPage(await QP().fetchPage(quizUrl, { accessCode: codeFor() }));
        else pointsFromPage(); // (not waited for: the questions show at once, their points follow)
        // Question ids arrive as strings (our Accept header); Canvas wants numeric answer ids back.
        for (const q of st.questions) q.flagged = !!q.flagged;
        if (!st.paged) st.idx = noBack ? Math.max(0, st.questions.findIndex((q) => !isAnswered(q))) : 0;
        if (st.idx < 0) st.idx = 0;
        st.loadingIdx = null;
        st.stage = 'take';
        tick();
        draw();
        toTop();
      } catch (e) {
        st.loadingIdx = null;
        st.stage = 'intro';
        const msg = String(e?.message || '');
        // a restricted quiz refuses in words: the code field appears (or says the code was wrong), an IP filter is explained
        if (/access code/i.test(msg)) {
          st.codeErr = st.code ? 'That access code was refused. Check it with your instructor.' : 'This quiz needs an access code. Enter it above, then begin.';
          st.needsCode = true;
          draw();
          setTimeout(() => { const f = document.querySelector('.bcv-qz__code'); if (f) { f.focus(); f.select(); } }, 60);
          return;
        }
        if (/ip address|ip filter|from your (ip|location|network)/i.test(msg)) {
          st.codeErr = 'Canvas only allows this quiz from certain networks (an IP filter). Try from the classroom or campus network.';
          draw();
          return;
        }
        draw();
        U.toast(`Could not start the attempt: ${msg}`, { error: true });
      }
    }
    /** The points each question is worth. Canvas's API keeps them from a student — it censors every
     *  question it hands one — so they are read off Canvas's own take page for this attempt, the same
     *  numbers ("4 pts") it shows beside each question there. Asked for with the attempt already open,
     *  that page only draws it. Quietly: if it will not come, the questions simply go without. */
    async function pointsFromPage() {
      if (simulated || st.paged || !st.questions.some((q) => !hasNum(q.points_possible))) return;
      const pg = await QP().fetchPage(quizUrl, { accessCode: codeFor() }).catch(() => null);
      if (!ctx.alive() || !pg?.ok) return;
      const pts = new Map(pg.questions.filter((q) => hasNum(q.points_possible)).map((q) => [String(q.id), Number(q.points_possible)]));
      for (const q of st.questions) if (!hasNum(q.points_possible) && pts.has(String(q.id))) q.points_possible = pts.get(String(q.id));
      // painted in place: a redraw would take the cursor out of an answer being typed
      for (const el of screen.querySelectorAll('.bcv-qz__qof[data-qid]')) {
        const q = st.questions.find((x) => String(x.id) === el.dataset.qid);
        if (q) el.textContent = qofText(q);
      }
    }
    const qofText = (q) => `of ${st.questions.length}${hasNum(q.points_possible) ? ` · ${store.fmtPts(q.points_possible)} ${Number(q.points_possible) === 1 ? 'point' : 'points'}` : ''}`;
    /** A page of Canvas's quiz page folded into the attempt: its question list is the spine (every
     *  question in order, with what Canvas knows of each) and the question shown is filled in; the
     *  others keep what was read of them before, or stay stubs until their turn. */
    function applyPage(pg) {
      if (!pg.ok || !pg.questions.length) throw QP().notShown(pg);
      st.page = pg;
      const known = new Map(st.questions.map((q) => [String(q.id), q]));
      const shown = new Map(pg.questions.map((q) => [String(q.id), q]));
      const spine = pg.list.length ? pg.list : pg.questions.map((q) => ({ id: q.id, name: q.question_name, answered: answered(q.answer), flagged: q.flagged, textOnly: q.question_type === 'text_only_question' }));
      st.questions = spine.map((e, k) => {
        const full = shown.get(String(e.id));
        if (full) return tidy({ ...full, position: k + 1 });
        const old = known.get(String(e.id));
        if (old && old.loaded !== false) return { ...old, position: k + 1, flagged: !!e.flagged };
        return { id: String(e.id), position: k + 1, question_name: e.name, question_type: e.textOnly ? 'text_only_question' : 'unknown_question', question_text: '', answers: [], answer: null, answered: !!e.answered, flagged: !!e.flagged, loaded: false };
      });
      const at = st.questions.findIndex((q) => String(q.id) === String(pg.questions[0].id));
      st.idx = at >= 0 ? at : 0;
    }
    /** A move on a paged attempt goes through Canvas's own page: Next and Previous post its record-answer
     *  form (the question is marked read, which is what "no going back" rests on); a pill fetches that
     *  question's page. Every answer is on Canvas before the move, since a read question takes no more. */
    async function turnPage(how) {
      if (st.loadingIdx !== null) return; // one move at a time
      // the pill of the question on its way is the progress bar; the question on screen stays, inert, until it arrives
      const target = how.questionId !== undefined ? st.questions.findIndex((q) => String(q.id) === String(how.questionId)) : st.idx + (how.toward || 1);
      st.loadingIdx = Math.max(0, Math.min(st.questions.length - 1, target));
      paintProgress();
      body.classList.add('is-busy');
      await settled();
      if (!ctx.alive()) return;
      try {
        const f = st.page?.form || {};
        const fields = { attempt: f.attempt ?? st.sub.attempt, validation_token: f.validationToken || st.sub.validation_token, last_question_id: f.lastQuestionId || cur()?.id || null };
        const pg = how.action ? await QP().advance(how.action, fields) : await QP().fetchPage(quizUrl, { questionId: how.questionId, accessCode: codeFor() });
        if (!ctx.alive()) return;
        st.loadingIdx = null;
        applyPage(pg);
        draw();
        toTop();
      } catch (e) {
        if (!ctx.alive()) return;
        st.loadingIdx = null;
        draw();
        U.toast(`Could not move to that question: ${e.message}`, { error: true });
      }
    }

    /** A question: its number on top, its text, its answers. `side`: the side layout's — the number
     *  large over the question, the text at Canvas's own size and in its own lines (images, tables and
     *  videos at the size their author gave), the flag in the right rail instead of here. */
    function questionBlock(q, k, { compact = false, side = false, flag = false } = {}) {
      const flagBtn = side && !flag ? null : h('button', { type: 'button', class: `bcv-qz__flag ${q.flagged ? 'is-on' : ''}`, onclick: () => toggleFlag(q) }, [U.svg(FLAG, { size: compact ? 12 : 13, width: 2 }), h('span', { text: q.flagged ? (compact ? 'Flagged' : 'Flagged for review') : (compact ? 'Flag' : 'Flag for review') })]);
      const headRow = U.el(`bcv-qz__qhead ${side ? 'bcv-qz__qhead--side' : ''}`, [
        h('span', { class: 'bcv-qz__qnum', text: `Question ${k + 1}` }),
        h('span', { class: 'bcv-qz__qof', dataset: { qid: String(q.id) }, text: qofText(q) }),
        INFO.has(q.question_type) ? null : flagBtn,
      ]);
      const text = BCV.screens.course.prose(q.question_text || q.question_name || '', { cls: `bcv-qz__qtext ${side ? 'bcv-qz__qtext--canvas' : compact ? 'bcv-qz__qtext--compact' : ''}` });
      const area = answerArea(q, compact || side);
      weave(text, area, q);
      const left = area && area.bcvBlanks && !area.children.length ? null : area; // (every blank went into the sentence)
      return h('div', { id: `bcv-q${k}`, class: 'bcv-qz__q' }, [headRow, text, left]);
    }

    /* A blank belongs in the sentence it was written into, not in a list underneath it.
     *
     * Canvas's own take page puts the field inline — a dropdown in the middle of the question — and
     * that markup arrives with the question text, so the question showed its blanks twice: Canvas's
     * own control in the sentence, dead (its page sets the value with a script of its own, so it
     * always read "[ Select ]"), and the row below it, live. The API gives the same question as it
     * was written, with [name] where the field goes. Either way the field built for that blank is
     * moved into the gap and the row it came from goes. A blank the text never names keeps its row,
     * so nothing is left with no way to answer it. */
    function weave(textEl, areaEl, q) {
      const holds = areaEl && areaEl.bcvBlanks;
      if (!holds || !holds.size) return;
      const free = () => [...holds.keys()].filter((b) => !holds.get(b).placed);
      const put = (name, slot) => {
        const held = name == null ? null : holds.get(String(name));
        if (!held || held.placed) return false;
        held.placed = true;
        held.field.classList.add('bcv-qz__inblank');
        slot.replaceWith(held.field);
        held.row.remove();
        return true;
      };
      /* Which blank a control in the sentence stands for. Not its name: Canvas calls the field
       * question_<id>_<hash of the blank>, so the name says nothing a reader can match — which is
       * what left the fields stripped out and the rows still underneath. A dropdown says it outright
       * instead, in the answers it offers: those ids belong to one blank and no other. Failing that
       * (a line to type in offers nothing), the controls stand in the order the blanks do. */
      const ids = new Map([...holds.keys()].map((b) => [b, new Set((q.answers || []).filter((a) => String(a.blank_id) === b).map((a) => String(a.id)))]));
      const whose = (w) => {
        if (w.tagName === 'SELECT') {
          const vals = [...w.options].map((o) => String(o.value)).filter(Boolean);
          const hit = vals.length ? free().find((b) => vals.every((v) => ids.get(b).has(v))) : null;
          if (hit) return hit;
        }
        const tail = (w.getAttribute('name') || '').replace(`question_${q.id}_`, '');
        if (holds.has(tail) && !holds.get(tail).placed) return tail;
        return free()[0] || null;
      };
      const head = `question_${q.id}_`;
      for (const w of [...textEl.querySelectorAll(`select[name^="${head}"], input[name^="${head}"], textarea[name^="${head}"], select.question_input, input.question_input`)]) {
        if (!put(whose(w), w)) w.remove(); // Canvas's own control answers nothing here
      }
      const spare = free();
      if (!spare.length) return;
      const token = new RegExp(`\\[(${spare.map((b) => b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})\\]`);
      const walk = document.createTreeWalker(textEl, NodeFilter.SHOW_TEXT);
      const hits = [];
      for (let n = walk.nextNode(); n; n = walk.nextNode()) if (token.test(n.nodeValue)) hits.push(n);
      for (const hit of hits) {
        let node = hit;
        for (let m = token.exec(node.nodeValue); m; m = token.exec(node.nodeValue)) {
          const tok = node.splitText(m.index);
          const rest = tok.splitText(m[0].length);
          put(m[1], tok); // (a name written twice keeps the second one as it reads)
          node = rest;
        }
      }
    }

    function answerArea(q, compact) {
      const type = q.question_type;
      const opts = (q.answers || []);
      const hint = hintFor(q); // (Import answers: what was right before, in purple — see importEarlier)
      if (CHOICE.has(type) || MULTI.has(type)) {
        const multi = MULTI.has(type);
        const hinted = new Set(hint === undefined ? [] : [].concat(hint).map(String));
        const chosen = () => (multi
          ? new Set((Array.isArray(q.answer) ? q.answer : []).map(String))
          : new Set(q.answer !== null && q.answer !== undefined ? [String(q.answer)] : []));
        // A pick marks the options in place rather than drawing the question again: a question whose
        // text or options hold a formula would otherwise rebuild every equation image Canvas serves,
        // and the formulas visibly blink away and back on each press. save() repaints the count and
        // the pills itself, so nothing else here has to move.
        // (2.99.24) One answer or several, told apart at a glance: one answer's options are round, with a radio
        // ring at the end; several answers' are square, with a checkbox, under "Select all that apply" and how many
        // are picked — as a form's radios and checkboxes are.
        const btns = [];
        const count = multi ? h('span', { class: 'bcv-qz__multicount' }) : null;
        const marks = () => {
          const on = chosen();
          for (const [a, b] of btns) {
            const sel = on.has(String(a.id));
            b.classList.toggle('is-selected', sel);
            b.setAttribute('aria-checked', sel ? 'true' : 'false');
          }
          if (count) count.textContent = on.size ? `${on.size} selected` : '';
        };
        const wrap = h('div', { class: `bcv-qz__opts ${multi ? 'bcv-qz__opts--many' : 'bcv-qz__opts--one'}`, role: multi ? 'group' : 'radiogroup', 'aria-label': multi ? 'Select all that apply' : 'Choose one' }, opts.map((a, j) => {
          const label = a.html ? BCV.screens.course.prose(a.html, { cls: 'bcv-qz__optlabel' }) : h('span', { class: 'bcv-qz__optlabel', text: a.text || `Option ${LETTERS[j]}` });
          const b = h('button', { type: 'button', role: multi ? 'checkbox' : 'radio', class: `bcv-qz__opt ${compact ? 'bcv-qz__opt--compact' : ''}${hinted.has(String(a.id)) ? ' is-hinted' : ''}`, dataset: { aid: String(a.id) }, onclick: () => {
            if (multi) {
              const next = chosen();
              if (next.has(String(a.id))) next.delete(String(a.id)); else next.add(String(a.id));
              save(q, [...next].map(Number));
            } else save(q, Number(a.id));
            marks();
          } }, [
            h('span', { class: 'bcv-qz__letter', text: LETTERS[j] || String(j + 1) }),
            label,
            multi
              ? h('span', { class: 'bcv-qz__mark bcv-qz__mark--box', 'aria-hidden': 'true' }, [U.svg(CHECK, { size: 14, stroke: '#fff', width: 3.2, cls: 'bcv-qz__markcheck' })])
              : h('span', { class: 'bcv-qz__mark bcv-qz__mark--ring', 'aria-hidden': 'true' }),
          ]);
          btns.push([a, b]);
          return b;
        }));
        marks();
        if (!multi) return wrap;
        const note = h('div', { class: 'bcv-qz__multi' }, [
          U.svg('M9 11l3 3 8-8M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h9', { size: 16, width: 2.2, cls: 'bcv-qz__multiicon' }),
          h('span', { class: 'bcv-qz__multitext', text: 'Select all that apply' }),
          count,
        ]);
        return U.el('bcv-qz__choice', [note, wrap]);
      }
      if (TEXT.has(type)) {
        const isEssay = type === 'essay_question';
        const field = isEssay
          ? h('textarea', { class: 'bcv-textarea', rows: 6, placeholder: 'Your answer…', oninput: (e) => { const v = e.target.value; saveText(q, looksHtml(q.answer) || /\n/.test(v) || /^\s*([•\-*]|\d+[.)])\s+/.test(v) ? plainToHtml(v) : v); } })
          : h('input', { class: 'bcv-input', type: NUMERIC.has(type) ? 'number' : 'text', step: 'any', placeholder: NUMERIC.has(type) ? 'Number' : 'Your answer', oninput: (e) => saveText(q, NUMERIC.has(type) && e.target.value !== '' ? Number(e.target.value) : e.target.value) });
        field.value = q.answer === null || q.answer === undefined ? '' : isEssay && looksHtml(q.answer) ? htmlToPlain(q.answer) : String(q.answer);
        if (hint !== undefined && hint !== null && String(hint) !== '') { field.placeholder = looksHtml(hint) ? htmlToPlain(hint) : String(hint); field.classList.add('is-hinted'); } // (in the empty field, in purple, until something is typed)
        // a formula question says how precise the answer is to be, where the quiz says so
        const places = type === 'calculated_question' && Number.isInteger(Number(q.formula_decimal_places)) && q.formula_decimal_places !== null && q.formula_decimal_places !== '' ? Number(q.formula_decimal_places) : null;
        return U.el('bcv-qz__text', [field, places !== null ? U.text('bcv-qz__texthint', places ? `Give the answer to ${places} decimal ${places === 1 ? 'place' : 'places'}.` : 'Give the answer as a whole number.', 'span') : null]);
      }
      // Matching: each left-hand value with the same list of right-hand ones beside it. Canvas takes
      // the picks as pairs — the answer's own id against the match it was set to.
      if (MATCH.has(type)) {
        const matches = q.matches || [];
        const chosen = new Map(pairsOf(q.answer).map((p2) => [String(p2.answer_id), String(p2.match_id)]));
        const was = new Map(pairsOf(hint === undefined ? null : hint).map((p2) => [String(p2.answer_id), String(p2.match_id)]));
        const rows = [];
        const send = () => {
          const pairs = [];
          for (const [aid, sel] of rows) {
            const pair = { answer_id: whole(aid), match_id: whole(sel.bcvPicker ? sel.bcvPicker.value : sel.value) };
            if (Number.isInteger(pair.answer_id) && Number.isInteger(pair.match_id)) pairs.push(pair); // (a row with no pick sends nothing; Canvas takes whole numbers only)
          }
          save(q, pairs);
        };
        return U.el(`bcv-qz__match ${compact ? 'bcv-qz__match--compact' : ''}`, opts.map((a) => {
          const right = was.get(String(a.id));
          const sel = U.picker(
            [{ value: '', text: 'Choose…' }, ...matches.filter((m) => hasId(m.match_id)).map((m) => ({ value: String(m.match_id), text: m.text, html: m.html || '', cls: String(m.match_id) === right ? 'is-hinted' : '' }))],
            chosen.get(String(a.id)) || '', send, { label: `Match for ${a.text || a.left || 'this'}`, cls: `bcv-qz__sel${right ? ' is-hinted' : ''}` },
          );
          rows.push([String(a.id), sel]);
          const left = a.html ? BCV.screens.course.prose(a.html, { cls: 'bcv-qz__matchleft' }) : h('span', { class: 'bcv-qz__matchleft', text: a.text || a.left || '' });
          return U.el('bcv-qz__matchrow', [left, sel]);
        }));
      }
      // A blank each: a dropdown of that blank's own list, or a line to type in. Canvas takes them as
      // one value per blank, named for the blank.
      if (BLANKS.has(type)) {
        const drops = DROPS.has(type);
        const blanks = blanksOf(q);
        const held = q.answer && typeof q.answer === 'object' && !Array.isArray(q.answer) ? q.answer : {};
        const was = hint && typeof hint === 'object' && !Array.isArray(hint) ? hint : {};
        const fields = [];
        const send = () => {
          const out = {};
          for (const [blank, f] of fields) {
            const v = String((f.bcvPicker ? f.bcvPicker.value : f.value) || '').trim();
            if (v) out[blank] = drops ? whole(v) : v;
          }
          save(q, out);
        };
        if (!blanks.length) return null;
        const holds = new Map();
        const wrap = U.el(`bcv-qz__blanks ${compact ? 'bcv-qz__blanks--compact' : ''}`, blanks.map((blank) => {
          const mine = opts.filter((a) => String(a.blank_id) === String(blank));
          const held0 = held[blank] === undefined || held[blank] === null ? '' : String(held[blank]);
          const right = was[blank] === undefined || was[blank] === null ? '' : String(was[blank]);
          const f = drops
            ? U.picker(
              [{ value: '', text: 'Choose…' }, ...mine.map((a) => ({ value: String(a.id), text: a.text || '', html: a.html || '', cls: right && String(a.id) === right ? 'is-hinted' : '' }))],
              held0, send, { label: blank, cls: `bcv-qz__sel${right ? ' is-hinted' : ''}` },
            )
            : h('input', { class: `bcv-input${right ? ' is-hinted' : ''}`, type: 'text', placeholder: right || 'Your answer', 'aria-label': blank, oninput: () => saveSoon(send) });
          if (!drops) f.value = held0;
          fields.push([blank, f]);
          const row = U.el('bcv-qz__blankrow', [U.text('bcv-qz__blanklbl', blank, 'span'), f]);
          holds.set(String(blank), { field: f, row, placed: false });
          return row;
        }));
        wrap.bcvBlanks = holds; // the sentence takes what it names (see weave)
        return wrap;
      }
      // A file: chosen here, uploaded to the student's own quiz files on Canvas (the three steps an
      // assignment's file takes), and the answer set to name it. Replaced by choosing another; taken
      // off with Remove. Canvas's own page is one press away for anyone who wants it there instead.
      if (FILE.has(type)) {
        const ids = (Array.isArray(q.answer) ? q.answer : []).map(String).filter(Boolean);
        const shownName = ids.length ? (st.files[ids[0]] || `File ${ids[0]}`) : '';
        const status = h('span', { class: 'bcv-qz__filename', text: ids.length ? shownName : 'No file yet' });
        const box = U.el(`bcv-qz__file ${ids.length ? 'has-file' : ''}`);
        const pick = async (f) => {
          if (!f) return;
          box.classList.add('is-busy');
          status.textContent = `Uploading ${f.name}…`;
          try {
            const id = await store.quizApi.uploadFile(cid, qid, f, (p) => { if (Number.isFinite(p)) status.textContent = `Uploading ${f.name}… ${Math.round(Math.min(1, p) * 100)}%`; });
            if (!ctx.alive()) return;
            st.files[String(id)] = f.name;
            await save(q, [whole(id)]);
            draw();
          } catch (err) {
            status.textContent = ids.length ? shownName : 'No file yet';
            U.toast(`Could not upload ${f.name}: ${err.message}`, { error: true });
          } finally {
            box.classList.remove('is-busy');
          }
        };
        const input = h('input', { type: 'file', class: 'bcv-qz__fileinput', 'aria-label': ids.length ? 'Replace the file' : 'Choose a file', onchange: (e) => { const f = e.target.files?.[0]; e.target.value = ''; pick(f); } });
        box.addEventListener('dragover', (e) => { if ([...(e.dataTransfer?.items || [])].some((i) => i.kind === 'file')) { e.preventDefault(); box.classList.add('is-over'); } });
        box.addEventListener('dragleave', () => box.classList.remove('is-over'));
        box.addEventListener('drop', (e) => { const f = e.dataTransfer?.files?.[0]; if (!f) return; e.preventDefault(); box.classList.remove('is-over'); pick(f); });
        box.append(...[
          U.svg('M12 16V5M7 10l5-5 5 5M5 19h14', { size: 20, width: 2, cls: 'bcv-qz__fileic' }),
          h('div', { class: 'bcv-qz__filebody' }, [status, U.text('bcv-qz__filehint', ids.length ? 'Handed in with this attempt when you submit.' : 'Choose a file, or drop one here.', 'span')]),
          h('label', { class: 'bcv-qz__filepick' }, [h('span', { text: ids.length ? 'Replace' : 'Choose file' }), input]),
          ids.length ? h('button', { type: 'button', class: 'bcv-qz__fileclear', text: 'Remove', onclick: async () => { await save(q, []); draw(); } }) : null,
        ].filter(Boolean)); // (append writes a null out as the word)
        return box;
      }
      if (INFO.has(type)) return null;
      // Any other kind (a question type Canvas adds later): Canvas's own page handles it on the same attempt.
      return U.card(U.el('bcv-detail', [
        U.text('bcv-hint', `This ${type.replace(/_/g, ' ').replace(' question', '')} question is answered on Canvas's quiz page. Your other answers are already saved there.`),
        U.btn('Answer in Canvas', { kind: 'primary', icon: IC.external, iconColor: '#fff', onClick: () => { setOpen(false); app.go(st.paged && !noBack ? `${quizUrl}/take/questions/${q.id}?bcv=native` : `${quizUrl}/take?bcv=native`, { confirmed: true }); } }),
      ]), 'bcv-card--22');
    }

    let footerEl = null;
    function paintFooter() {
      if (!footerEl) return;
      const lbl = footerEl.querySelector('.bcv-qz__answered');
      if (lbl) lbl.textContent = `${answeredLabel()}${saveState() ? ` · ${saveState()}` : ''}`;
      const fill = footerEl.querySelector('.bcv-qz__meterfill'); // (the side layout's bar of what is answered)
      if (fill) fill.style.width = `${st.questions.length ? Math.round((answeredCount() / st.questions.length) * 100) : 0}%`;
    }
    function footer(buttons) {
      footerEl = U.el('bcv-qz__foot', U.el('bcv-qz__footin', [h('span', { class: 'bcv-qz__answered' }), ...buttons]));
      paintFooter();
      return footerEl;
    }

    /** Moving from question k: whether it is the last, and Back and Next — through Canvas's own page
     *  on a paged attempt, in place otherwise. */
    function moves(k) {
      const last = st.paged ? !st.page?.form.nextAction : k === st.questions.length - 1;
      const back = () => {
        if (st.paged) { turnPage(st.page?.form.prevAction ? { action: st.page.form.prevAction, toward: -1 } : { questionId: st.questions[k - 1].id }); return; }
        st.idx = Math.max(0, k - 1);
        draw();
        toTop();
      };
      const next = () => {
        if (st.paged) { turnPage({ action: st.page.form.nextAction, toward: 1 }); return; }
        st.idx = Math.min(st.questions.length - 1, k + 1);
        draw();
        toTop();
      };
      return { last, back, next };
    }
    const toReview = () => { st.stage = 'review'; draw(); toTop(); };

    function takeOne() {
      const q = cur();
      const k = st.idx;
      if (!q) return U.el('bcv-qz__page', U.emptyCard('This quiz has no questions.'));
      const { last, back, next } = moves(k);
      return h('div', { class: 'bcv-qz__stage' }, [
        U.el('bcv-qz__page', questionBlock(q, k)),
        footer([
          noBack ? null : h('button', { type: 'button', class: 'bcv-qz__btn', text: 'Back', disabled: k === 0 || null, onclick: back }),
          last
            ? h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--primary', text: 'Review answers', onclick: toReview })
            : h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--primary bcv-qz__btn--next', text: 'Next', onclick: next }),
        ]),
      ]);
    }

    /* The side layout (2.98.24): the page's width put to use. Down the left, every question as a
     * numbered square — answered, flagged, the one on screen — with a key to them; in the middle, the
     * question, its number large on top and its text as Canvas lays it out; down the right, every
     * control: how many are answered and whether it is saved, Next (Review answers on the last), Back,
     * the flag, and the review at any point. Both rails stay in view as the question scrolls. The same
     * pills, buttons and saves as the one-at-a-time layout, placed differently. */
    function takeSide() {
      const q = cur();
      const k = st.idx;
      if (!q) return U.el('bcv-qz__page', U.emptyCard('This quiz has no questions.'));
      const { last, back, next } = moves(k);
      const key = (cls, text) => U.el('bcv-qz__key', [h('span', { class: `bcv-qz__keydot ${cls}` }), h('span', { text })]);
      const left = h('aside', { class: 'bcv-qz__lrail', 'aria-label': 'Questions' }, [
        U.text('bcv-qz__railh', 'Questions', 'div'),
        progressWrap,
        U.el('bcv-qz__legend', [key('is-current', 'On screen'), key('is-answered', 'Answered'), key('is-flagged', 'Flagged'), key('', 'Not answered')]),
      ]);
      const flagBtn = INFO.has(q.question_type) ? null : h('button', { type: 'button', class: `bcv-qz__flag bcv-qz__flag--side ${q.flagged ? 'is-on' : ''}`, 'aria-pressed': q.flagged ? 'true' : 'false', onclick: () => toggleFlag(q) }, [U.svg(FLAG, { size: 14, width: 2 }), h('span', { text: q.flagged ? 'Flagged for review' : 'Flag for review' })]);
      footerEl = h('aside', { class: 'bcv-qz__foot bcv-qz__rrail', 'aria-label': 'Controls' }, [
        U.text('bcv-qz__railh', 'Progress', 'div'),
        h('span', { class: 'bcv-qz__answered' }),
        h('div', { class: 'bcv-qz__meter', 'aria-hidden': 'true' }, h('span', { class: 'bcv-qz__meterfill' })),
        U.el('bcv-qz__railbtns', [
          last
            ? h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--primary', text: 'Review answers', onclick: toReview })
            : h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--primary bcv-qz__btn--next', text: 'Next', onclick: next }),
          noBack ? null : h('button', { type: 'button', class: 'bcv-qz__btn', text: 'Back', disabled: k === 0 || null, onclick: back }),
        ]),
        flagBtn,
        last ? null : h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--quiet', text: 'Review answers', title: 'See every answer before you submit. Nothing is submitted until you say so.', onclick: toReview }),
      ]);
      paintFooter();
      return h('div', { class: 'bcv-qz__stage bcv-qz__side' }, [
        left,
        U.el('bcv-qz__page bcv-qz__page--side', questionBlock(q, k, { side: true })),
        footerEl,
      ]);
    }

    /* (2.99.78) The scrolling layout, in the side layout's frame: the questions down the left, every control down the
     * right, and in the middle every question one after another at Canvas's own reading size, each with its own flag —
     * the one under the reading line the current one, its square lit on the left (followScroll). Next and Back send the
     * page to the question after or before it. */
    function takeAll() {
      const page = U.el('bcv-qz__page bcv-qz__page--side bcv-qz__page--all', st.questions.map((q, k) => questionBlock(q, k, { side: true, flag: true })));
      followScroll(page);
      const key = (cls, text) => U.el('bcv-qz__key', [h('span', { class: `bcv-qz__keydot ${cls}` }), h('span', { text })]);
      const left = h('aside', { class: 'bcv-qz__lrail', 'aria-label': 'Questions' }, [
        U.text('bcv-qz__railh', 'Questions', 'div'),
        progressWrap,
        U.el('bcv-qz__legend', [key('is-current', 'On screen'), key('is-answered', 'Answered'), key('is-flagged', 'Flagged'), key('', 'Not answered')]),
      ]);
      const go = (d) => { const k = Math.max(0, Math.min(st.questions.length - 1, st.idx + d)); st.idx = k; sendTo(k); paintProgress(); };
      footerEl = h('aside', { class: 'bcv-qz__foot bcv-qz__rrail', 'aria-label': 'Controls' }, [
        U.text('bcv-qz__railh', 'Progress', 'div'),
        h('span', { class: 'bcv-qz__answered' }),
        h('div', { class: 'bcv-qz__meter', 'aria-hidden': 'true' }, h('span', { class: 'bcv-qz__meterfill' })),
        U.el('bcv-qz__railbtns', [
          h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--primary', text: 'Review answers', onclick: toReview }),
          h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--quiet', text: 'Next question', onclick: () => go(1) }),
          noBack ? null : h('button', { type: 'button', class: 'bcv-qz__btn bcv-qz__btn--quiet', text: 'Previous question', onclick: () => go(-1) }),
        ]),
      ]);
      paintFooter();
      return h('div', { class: 'bcv-qz__stage bcv-qz__side' }, [left, page, footerEl]);
    }

    // Scroll mode: the question you are reading is the current one. As the page scrolls, the question
    // under the reading line — a third of the way down what the head leaves of the window — is marked
    // is-current (a bar at its side, its number lit, the others standing back a little) and its pill
    // in the head lights with it; at the foot of the page the last question is current whatever the
    // line says. A question the page was sent to (a pill, a review row, the layout switch) or one you
    // are answering (focus lands in it) holds the mark until you scroll yourself — a wheel, a finger,
    // the keys, or a scroll after the sent one has landed — so the questions passed on the way never
    // take it. The mark lives in st.idx, which the other layouts open on.
    function followScroll(page) {
      let raf = 0, settle = 0;
      const blocks = () => [...page.querySelectorAll('.bcv-qz__q')];
      const pick = () => {
        const els = blocks();
        if (!els.length) return -1;
        if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2) return els.length - 1;
        const base = Math.max(0, head.getBoundingClientRect().bottom); // (the head may have slid up out of the way)
        const line = base + (window.innerHeight - base) / 3;
        let k = 0;
        els.forEach((el, i) => { if (el.getBoundingClientRect().top <= line) k = i; });
        return k;
      };
      const mark = (k) => {
        if (k < 0) return;
        st.idx = k;
        blocks().forEach((el, i) => el.classList.toggle('is-current', i === k));
        progressWrap.querySelectorAll('.bcv-qz__pill').forEach((p, i) => p.classList.toggle('is-current', i === k));
      };
      const tick = () => {
        raf = 0;
        if (!page.isConnected) return;
        mark(st.hold ? st.hold.k : pick());
      };
      const ask = () => { if (!raf) raf = requestAnimationFrame(tick); };
      const release = () => { st.hold = null; ask(); }; // a scroll of your own: the line takes over
      // (the sent scroll has landed once the page has been still a moment — Safari has no scrollend — and the next one is yours)
      const onEnd = () => { if (st.hold) st.hold.landed = true; };
      const onScroll = () => {
        if (st.hold && (st.hold.landed || Date.now() - st.hold.at > 1500)) st.hold = null;
        clearTimeout(settle);
        settle = setTimeout(onEnd, 140);
        ask();
      };
      const onKey = (e) => { if (/^(Arrow(Up|Down)|Page(Up|Down)|Home|End| )$/.test(e.key) && !e.target.closest?.('input, textarea, select, [contenteditable]')) release(); };
      const hold = (k) => { if (k < 0 || k >= blocks().length) return; st.hold = { k, at: Date.now(), landed: false }; mark(k); };
      const onFocus = (e) => { const q = e.target.closest?.('.bcv-qz__q'); if (q) hold(blocks().indexOf(q)); };
      window.addEventListener('scroll', onScroll, { passive: true });
      window.addEventListener('wheel', release, { passive: true });
      window.addEventListener('touchmove', release, { passive: true });
      window.addEventListener('keydown', onKey);
      window.addEventListener('resize', ask);
      page.addEventListener('focusin', onFocus);
      U.onGone(page, () => {
        window.removeEventListener('scroll', onScroll);
        window.removeEventListener('wheel', release);
        window.removeEventListener('touchmove', release);
        window.removeEventListener('keydown', onKey);
        window.removeEventListener('resize', ask);
        cancelAnimationFrame(raf);
        clearTimeout(settle);
        if (st.follow?.page === page) st.follow = null;
      });
      st.follow = { page, hold };
      ask(); // (the first mark, once the page is on the screen)
    }

    const answerParts = (q) => answerPartsOf(q, st.files);
    /** The same, flattened to one line — for the review list and anywhere a plain string is wanted. */
    function answerText(q) {
      const parts = answerParts(q);
      return parts ? parts.map(partText).join(', ') : null;
    }

    /** The question on its one line of the review: its words and formulas, without the videos,
     *  pictures and tables that belong to the question itself. */
    function sumText(q) {
      const el = BCV.screens.course.prose(noFields(q.question_text, q), { cls: 'bcv-qz__sumrich' });
      for (const n of el.querySelectorAll('iframe, video, audio, table, .bcv-embed-open, img:not(.equation_image)')) n.remove();
      return el;
    }
    function review() {
      const blanks = st.questions.length - answeredCount();
      const flagged = st.questions.filter((q) => q.flagged).length;
      const pct = st.questions.length ? Math.round((answeredCount() / st.questions.length) * 100) : 0;
      return U.el('bcv-qz__review bcv-qz__review--wide', [
        h('div', { class: 'bcv-qz__reviewhead' }, [
          h('h1', { class: 'bcv-qz__h1 bcv-qz__h1--30', text: 'Review before submitting' }),
          h('p', { class: 'bcv-qz__lead', text: `${answeredLabel()} · ${blanks === 0 ? 'nothing left blank' : `${blanks} left blank`}. Tap any question to change it.` }),
        ]),
        // (2.99.78) the right side: where the attempt stands, and the way to hand it in, in view as the list scrolls
        h('aside', { class: 'bcv-qz__reviewrail', 'aria-label': 'Submit' }, [
          U.text('bcv-qz__railh', 'Ready to submit', 'div'),
          h('div', { class: 'bcv-qz__rvcount' }, [String(answeredCount()), h('small', { text: `of ${st.questions.length} answered` })]),
          h('div', { class: 'bcv-qz__meter', 'aria-hidden': 'true' }, h('span', { class: 'bcv-qz__meterfill', style: { width: `${pct}%` } })),
          h('div', { class: 'bcv-qz__rvfacts' }, [
            h('span', { class: blanks ? 'is-blank' : '', text: blanks ? `${U.plural(blanks, 'question')} left blank` : 'Nothing left blank' }),
            flagged ? h('span', { class: 'is-flag', text: `${U.plural(flagged, 'question')} flagged` }) : null,
          ].filter(Boolean)),
          U.el('bcv-qz__reviewbtns', [
            h('button', { type: 'button', class: 'bcv-qz__big bcv-qz__big--primary', text: 'Submit quiz', onclick: submit }),
            h('button', { type: 'button', class: 'bcv-qz__big', text: 'Keep working', onclick: () => { st.stage = 'take'; draw(); toTop(); } }),
          ]),
          h('p', { class: 'bcv-qz__note bcv-pretty', text: 'Submitting ends the attempt. Blank questions are graded as incorrect.' }),
        ]),
        U.card(st.questions.map((q, k) => {
          const parts = INFO.has(q.question_type) ? null : answerParts(q);
          const txt = answerText(q);
          // the answer as it was given: its own words, or Canvas's own content where the words are a
          // formula (an equation image with the LaTeX on the tag — the image is shown, never the LaTeX)
          const cell = h('span', { class: `bcv-qz__suma ${txt === null && !INFO.has(q.question_type) && !isAnswered(q) ? 'is-blank' : ''}` });
          if (INFO.has(q.question_type)) cell.textContent = '—';
          else if (parts) parts.forEach((p2, i) => { if (i) cell.append(', '); if (String(p2.text || '').trim()) cell.append(p2.text); else if (String(p2.html || '').trim()) cell.append(BCV.screens.course.prose(p2.html, { cls: 'bcv-qz__sumrich' })); else cell.append('—'); });
          else cell.textContent = isAnswered(q) ? 'Answered' : 'Not answered';
          return h('button', { type: 'button', class: 'bcv-qz__sum', disabled: noBack || null, onclick: () => {
            if (noBack) return;
            st.stage = 'take';
            if (st.paged) { turnPage({ questionId: q.id }); return; }
            st.idx = k;
            draw();
            if (st.mode === 'all') sendTo(k, { smooth: false });
            else toTop();
          } }, [
            h('span', { class: 'bcv-qz__sumn', text: `Q${k + 1}` }),
            h('span', { class: 'bcv-qz__sumq' }, String(q.question_text || '').trim() ? sumText(q) : h('span', { text: q.question_name || '' })), // (the question as Canvas holds it: a formula in it is the formula, not its LaTeX)
            q.flagged ? U.svg(FLAG, { size: 13, stroke: '#ff9500', width: 2, style: { flex: 'none' } }) : null,
            cell,
          ]);
        }), 'bcv-card--list'),
      ]);
    }

    async function submit() {
      const blanks = st.questions.length - answeredCount();
      if (!window.confirm(`Submit this attempt now?${blanks ? `\n\n${U.plural(blanks, 'question is', 'questions are')} still blank.` : ''}`)) return;
      body.replaceChildren(h('p', { class: 'bcv-qz__starting', text: 'Submitting…' })); // inside the attempt nothing is a skeleton
      try {
        await settled(); // (an answer typed a moment ago is still on its pause, or on its way: it goes in before the attempt closes)
        // and every answer given here is on Canvas: one it does not hold is sent again first, and one that
        // will not stay is named before anything is handed in
        const missing = await mendAnswers(st.questions);
        if (missing?.length && !window.confirm(`${missing.map((q) => `Question ${st.questions.indexOf(q) + 1}`).join(', ')}: Canvas did not keep ${missing.length === 1 ? 'that answer' : 'those answers'}.\n\nSubmit anyway? Cancel to go back and answer ${missing.length === 1 ? 'it' : 'them'} again.`)) {
          st.stage = 'review';
          draw();
          return;
        }
        st.done = await store.quizApi.complete(cid, qid, st.sub, codeFor());
        // the attempt just handed in may be one whose grade waits to be posted: the receipt asks first
        if (quiz.assignment_id && !simulated) {
          const fresh = await store.submission(cid, quiz.assignment_id, { force: true }).catch(() => null);
          if (fresh) st.held = heldBack(fresh); // (not read: what was known stands)
        }
        st.stage = 'done';
        clearInterval(st.timer);
        app.refreshCounts();
        draw();
        toTop();
      } catch (e) {
        st.stage = 'review';
        draw();
        U.toast(`Could not submit: ${e.message}`, { error: true });
      }
    }

    function timeUp() {
      U.toast('Time is up. Canvas closes the attempt at the time limit.', { error: true });
      st.stage = 'review';
      draw();
    }

    function done() {
      const d = st.done || {};
      const survey = /survey/.test(quiz.quiz_type || '');
      const gradedSurvey = quiz.quiz_type === 'graded_survey';
      const scoreVisible = !survey && !quiz.hide_results && !st.held && d.score !== null && d.score !== undefined && d.workflow_state !== 'pending_review';
      const feedbackOn = scoreVisible && d.id && !resultsHidden(d);
      const fresh = st.checked !== st.done; // (the tick draws in once per attempt: the same result drawn again has it there)
      st.checked = st.done;
      return U.el('bcv-qz__done', [
        U.drawCheck(U.el('bcv-qz__donemark', U.svg(CHECK, { size: 34, stroke: '#34c759', width: 2.4 })), fresh),
        h('div', {}, [
          h('h1', { class: 'bcv-qz__h1 bcv-qz__h1--28', text: survey ? 'Responses recorded' : 'Attempt submitted' }),
          h('p', { class: 'bcv-qz__lead bcv-pretty', text: `${quiz.title} · submitted ${U.fmtAtUpper(d.finished_at || new Date())}. ${survey ? (gradedSurvey ? 'Thanks for taking part — the points for it post to your grades.' : 'Thanks for taking part.') : scoreVisible ? '' : 'Your score posts once your instructor releases it.'}` }),
        ]),
        U.el('bcv-qz__donecard', [h('span', { class: 'bcv-qz__donek', text: 'Questions answered' }), h('span', { class: 'bcv-qz__donev', text: answeredLabel() })]),
        scoreVisible ? U.el('bcv-qz__donecard', [h('span', { class: 'bcv-qz__donek', text: 'Score' }), h('span', { class: 'bcv-qz__donev', text: `${store.fmtPts(d.kept_score ?? d.score)} / ${store.fmtPts(quiz.points_possible || 0)}` })]) : null,
        gradedSurvey && quiz.points_possible ? U.el('bcv-qz__donecard', [h('span', { class: 'bcv-qz__donek', text: 'For taking part' }), h('span', { class: 'bcv-qz__donev', text: `${store.fmtPts(quiz.points_possible)} ${Number(quiz.points_possible) === 1 ? 'point' : 'points'}` })]) : null,
        U.el('bcv-qz__donebtns', [
          // feedback only once Canvas has released it (hide_results); the receipt says so otherwise. A survey has none.
          feedbackOn ? h('button', { type: 'button', class: 'bcv-qz__big bcv-qz__big--primary', text: 'See feedback', onclick: () => openFeedback(d, 'done') }) : null,
          h('button', { type: 'button', class: `bcv-qz__big ${feedbackOn ? '' : 'bcv-qz__big--primary'}`, text: survey ? 'Back to the survey' : 'Back to the quiz', onclick: () => exitTo(simulated ? simHome : quizUrl) }),
        ]),
      ]);
    }

    // ---- feedback (mockup 9) ---------------------------------------------------------
    // A finished attempt, question by question: your answer, the correct one when the
    // quiz's settings allow it, the instructor's worked solution. Everything comes from the attempt's own question data
    // and the assignment submission's comments; nothing is fetched beyond that.
    const CS = () => BCV.screens.course;
    const CROSS = 'M6 6l12 12M18 6L6 18';
    function finished(s) {
      return !!s && (s.workflow_state === 'complete' || s.workflow_state === 'pending_review');
    }
    function latestFinished() {
      return [...(subs || []), ...(st.done && finished(st.done) ? [st.done] : [])]
        .filter(finished)
        .sort((a, b) => (Number(b.attempt) || 0) - (Number(a.attempt) || 0))[0] || null;
    }
    function pickFeedbackSub(wantId, wantAttempt) {
      const list = (subs || []).filter(finished);
      if (wantId) {
        const m = list.find((s) => String(s.id) === String(wantId));
        if (m) return m;
      }
      const n = Number(wantAttempt);
      if (n > 0) {
        const m = list.find((s) => Number(s.attempt) === n);
        if (m) return m;
        // Canvas keeps one quiz submission per student, so an earlier attempt has none of its own:
        // it is read through that same submission, scoped to the attempt asked for, and its score
        // and grading come from the assignment submission's history.
        const any = (subs || [])[0];
        if (any) return { ...any, attempt: n, workflow_state: 'complete', finished_at: null, score: null, kept_score: null };
      }
      return latestFinished();
    }
    function exitTo(href) {
      setOpen(false);
      clearInterval(st.timer);
      app.go(href, { confirmed: true });
    }
    function openFeedback(sub, from) {
      st.fbSub = sub;
      st.fbFrom = from;
      st.fb = null;
      st.stage = 'feedback';
      draw();
      toTop();
    }
    /** Why results are withheld (a sentence), or null when Canvas shows them. */
    function resultsHidden(sub) {
      if (quiz.hide_results === 'always') return 'Your instructor has hidden the results for this quiz.';
      if (quiz.hide_results === 'until_after_last_attempt' && allowed !== null && attemptsLeft > 0) return `Results show after your last attempt — ${U.plural(attemptsLeft, 'attempt')} left.`;
      if (st.held) return HELD_LINE;
      if (sub && sub.workflow_state === 'untaken') return 'This attempt is still open.';
      return null;
    }
    /** Whether the quiz's show_correct_answers window is open right now. */
    function correctVisible() {
      if (!quiz.show_correct_answers) return false;
      const now = Date.now();
      if (quiz.show_correct_answers_at && U.parse(quiz.show_correct_answers_at) > now) return false;
      if (quiz.hide_correct_answers_at && U.parse(quiz.hide_correct_answers_at) < now) return false;
      if (quiz.show_correct_answers_last_attempt && allowed !== null && attemptsLeft > 0) return false;
      return true;
    }
    async function loadFeedback(sub) {
      // Canvas's questions carry the latest attempt's answers and marks alone: an earlier attempt
      // asked for is read from the graded history, its own answers and its own ticks
      const live = (subs || [])[0];
      const older = !!live && Number(sub.attempt) !== Number(live.attempt);
      const [qs, asub, page] = await Promise.all([
        store.quizApi.questions(sub, { courseId: cid, quizId: qid }),
        quiz.assignment_id ? store.submission(cid, quiz.assignment_id, { force: true }).catch(() => null) : Promise.resolve(null),
        // what the API keeps from a student (each question's points, the right answers, the comments): Canvas's own results page
        simulated ? Promise.resolve(null) : QP().results(cid, qid, sub).catch(() => null),
      ]);
      // held back since the page was drawn, or before: nothing of the attempt's grading is shown
      if (heldBack(asub)) { st.held = true; return { sub, held: true }; }
      const me = String(store.env().current_user_id || '');
      const comments = (asub?.submission_comments || []).filter((c) => !me || String(c.author_id ?? '') !== me);
      // per-question points, when the assignment submission's history carries this attempt's grading
      const hist = (asub?.submission_history || []).find((x) => Number(x.attempt) === Number(sub.attempt)) || null;
      const graded = new Map((hist?.submission_data || []).map((d) => [String(d.question_id), d]));
      const rows = qs.map(tidy).map((q, k) => { // (tidy: a matching answer of empty rows, or blanks all empty, is no answer — so the graded history is read instead)
        const d = graded.get(String(q.id)) || null;
        const pq = page?.get(String(q.id)) || null;
        if (d && (older || !answered(q.answer))) q.answer = histAnswer(q, d); // (a one-at-a-time quiz's answers come from the graded history too)
        const flag = older && d ? parseCorrect(d.correct) : (parseCorrect(q.correct) ?? (d ? parseCorrect(d.correct) : null));
        // the points a question was worth: the API's where it gives them (it never does to a student), else the results page's
        const possible = hasNum(q.points_possible) ? Number(q.points_possible) : hasNum(pq?.possible) ? Number(pq.possible) : null;
        // the points it got decide how it went: Canvas's right/wrong flag can lag behind them (a regrade, a
        // score the instructor changed), and an answer given full points is right whatever the flag says.
        // An answer not graded yet (an essay: no flag, no points) stays unmarked.
        const pts = d && hasNum(d.points) ? Number(d.points) : null;
        const correct = pts !== null && possible > 0 && (flag !== null || pts > 0) ? (pts >= possible - 1e-9 ? true : pts > 0 ? 'partial' : false) : flag;
        const earned = pts !== null ? pts : correct === true ? possible : correct === false ? 0 : null;
        const rightIds = new Set([...(q.answers || []).filter((a) => Number(a.weight) === 100).map((a) => String(a.id)), ...(pq?.right || []).map((x) => String(x.id))]);
        const sol = fbSolution(q, correct === true) || (pq?.comment ? { html: pq.comment } : null);
        return { q, k, correct, possible, earned, yours: answerParts(q), right: fbRight(q) || pageRight(q, pq), rightIds, shown: correctVisible() || !!pq?.shown, match: pq?.match || null, sol, read: !!pq, info: INFO.has(q.question_type) };
      }).filter((r) => !r.info);
      const released = rows.some((r) => r.correct !== null);
      const possible = Number(quiz.points_possible) || rows.reduce((s, r) => s + (r.possible || 0), 0);
      const score = hist?.score ?? sub.score ?? sub.kept_score; // that attempt's own score, not the best so far
      return { sub, rows, released, comments, possible, score: score === null || score === undefined ? null : Number(score), gradedAt: asub?.graded_at || sub.finished_at };
    }
    /** Every option the question offered, folded away under the answer. The chips say what you put
     *  and what was right; this is for checking the rest — what the other options actually were, and
     *  which of them you picked. Nothing is revealed that the quiz keeps back: an option is marked
     *  correct only where Canvas already shows the correct answer. */
    function fbOptions(r) {
      const q = r.q;
      const opts = q.answers || [];
      if (!(CHOICE.has(q.question_type) || MULTI.has(q.question_type)) || !opts.length) return null;
      const a = q.answer;
      const mine = new Set((Array.isArray(a) ? a : answered(a) ? [a] : []).map(String));
      const marksRight = r.shown && r.correct !== null;
      const list = U.el('bcv-fb__opts', opts.map((o, j) => {
        const picked = mine.has(String(o.id));
        const right = marksRight && r.rightIds.has(String(o.id));
        const body = String(o.text || '').trim()
          ? h('span', { class: 'bcv-fb__opttext', text: o.text })
          : String(o.html || '').trim()
            ? CS().prose(o.html, { cls: 'bcv-fb__opttext bcv-fb__chiprich' })
            : h('span', { class: 'bcv-fb__opttext', text: '—' });
        return U.el(`bcv-fb__opt ${picked ? 'is-mine' : ''} ${right ? 'is-right' : ''}`, [
          h('span', { class: 'bcv-fb__optletter', text: LETTERS[j] || String(j + 1) }),
          body,
          picked ? U.text('bcv-fb__opttag', 'Your answer', 'span') : null,
          right ? U.text('bcv-fb__opttag bcv-fb__opttag--right', 'Correct', 'span') : null,
        ]);
      }));
      const fold = U.collapsible(list, false, 'bcv-fb__fold'); // (sliding open and shut with the chevron's turn)
      const label = U.text('bcv-fb__morelbl', `Show all ${U.plural(opts.length, 'option')}`, 'span');
      const btn = h('button', {
        type: 'button', class: 'bcv-fb__more', 'aria-expanded': 'false',
        onclick: () => {
          const open = !btn.classList.contains('is-open');
          fold.setOpen(open);
          btn.setAttribute('aria-expanded', open ? 'true' : 'false');
          btn.classList.toggle('is-open', open);
          label.textContent = open ? 'Hide the options' : `Show all ${U.plural(opts.length, 'option')}`;
        },
      }, [label, U.svg(IC.chevron, { size: 12, width: 2.2, cls: 'bcv-fb__morechev' })]);
      return U.el('bcv-fb__optwrap', [btn, fold]);
    }

    /* ---- the feedback screen (2.98.27) ----------------------------------------------
     * The page is the attempt's, as the attempt itself had it. Down the left, a rail that stays in view:
     * the score, a filter (every question, the ones to look at again, the ones got right) and every
     * question as a numbered square coloured by how it went, the one being read outlined — press one
     * to go to it; J and K go on and back. On the right the questions themselves, at Canvas's reading
     * size: what the question asked, then your answer and the correct one side by side (a matching
     * question as a table, a row per value), the options, the worked solution. */
    const verdictOf = (r) => (r.correct === true ? 'right' : r.correct === false ? 'wrong' : r.correct === 'partial' ? 'partial' : 'none');
    const VERDICT = { right: 'Correct', wrong: 'Incorrect', partial: 'Partly right', none: 'Not marked yet' };
    const MARK = { right: CHECK, wrong: CROSS, partial: 'M5 12h14', none: 'M12 17h.01M9.5 9.5a2.5 2.5 0 015 0c0 1.6-2.5 2-2.5 4' };
    const inkOf = (v) => {
      const dark = app.isDark();
      return v === 'right' ? (dark ? ['#5ddb7d', 'rgba(52,199,89,.2)'] : ['#1e7a37', 'rgba(52,199,89,.14)'])
        : v === 'wrong' ? (dark ? ['#ff8098', 'rgba(255,45,85,.2)'] : ['#c01d43', 'rgba(255,45,85,.12)'])
          : v === 'partial' ? ['#ff9500', 'rgba(255,149,0,.16)'] : ['var(--bcv-ink3)', 'var(--bcv-fill)'];
    };
    /** An answer's pieces, one after another: its own words, or Canvas's own content where it has none. */
    function ansBody(parts) {
      if (!parts?.length) return [h('span', { class: 'bcv-qfb__noans', text: 'No answer' })];
      const out = [];
      parts.forEach((p, i) => {
        if (i) out.push(h('span', { class: 'bcv-qfb__sep', text: ', ' }));
        if (String(p.text || '').trim()) out.push(h('span', { text: p.text }));
        else if (String(p.html || '').trim()) out.push(CS().prose(p.html, { cls: 'bcv-fb__chiprich' }));
        else out.push(h('span', { text: '—' }));
      });
      return out;
    }
    /** A matching answer as a table: each value, the match you set, and — where the quiz shows correct
     *  answers and one was missed — the right match, each row marked. */
    function fbMatchTable(r, wantRight) {
      const q = r.q;
      const set = new Map(pairsOf(q.answer).map((p) => [String(p.answer_id), String(p.match_id)]));
      const nameOf = (mid) => (q.matches || []).find((m) => String(m.match_id) === String(mid))?.text ?? null;
      const rows = (q.answers || []).map((a) => {
        const mid = set.get(String(a.id));
        const mine = mid === undefined ? null : (nameOf(mid) ?? mid);
        // the right match: the question's own where it has one (a student's never does), else the results page's —
        // a row it marks right was matched right, and under a wrong one it writes the match that was
        const pr = r.match?.get(String(a.id)) || null;
        const right = wantRight ? (String(a.right || '').trim() || (hasId(a.match_id) ? nameOf(a.match_id) : null) || pr?.right || (pr?.ok === true ? mine : null)) : null;
        return { a, mine, right, ok: pr?.ok ?? null };
      });
      const showRight = rows.some((x) => x.right !== null);
      return h('table', { class: 'bcv-qfb__match' }, [
        h('thead', {}, h('tr', {}, [h('th', { text: 'Item' }), h('th', { text: 'Your match' }), showRight ? h('th', { text: 'Correct match' }) : null])),
        h('tbody', {}, rows.map(({ a, mine, right, ok: marked }) => {
          const ok = !showRight ? null : marked !== null ? marked : right !== null && mine !== null ? String(mine).trim() === String(right).trim() : null;
          return h('tr', { class: ok === true ? 'is-right' : ok === false || (showRight && mine === null) ? 'is-wrong' : '' }, [
            h('td', { class: 'bcv-qfb__mleft' }, a.html ? CS().prose(a.html, { cls: 'bcv-fb__chiprich' }) : h('span', { text: a.text || a.left || '—' })),
            h('td', { class: `bcv-qfb__mmine ${mine === null ? 'is-empty' : ''}`, text: mine ?? 'No match set' }),
            showRight ? h('td', { class: 'bcv-qfb__mright', text: right ?? '—' }) : null,
          ]);
        })),
      ]);
    }
    /** What you answered, and — when the quiz shows it and you missed it — the correct answer beside it. */
    function fbAnswers(r) {
      const q = r.q;
      const v = verdictOf(r);
      const reveal = v !== 'right' && r.correct !== null && r.shown;
      if (MATCH.has(q.question_type) && (q.answers || []).length) return U.el('bcv-qfb__answers', fbMatchTable(r, reveal));
      const showRight = reveal && !!r.right?.length;
      const essay = r.yours?.some((p) => p.block);
      const [ink, tint] = inkOf(v);
      const yours = U.el('bcv-qfb__ans is-yours', [
        U.text('bcv-qfb__anslbl', 'Your answer', 'span'),
        essay ? U.el('bcv-fb__essay', r.yours.map((p) => (p.html ? CS().prose(p.html, { cls: 'bcv-fb__essaybody bcv-prose' }) : h('p', { class: 'bcv-fb__essaybody', text: p.text }))))
          : h('div', { class: 'bcv-qfb__ansval', style: { color: v === 'none' ? '' : ink } }, ansBody(r.yours)),
      ]);
      if (!essay && v !== 'none') yours.style.background = tint;
      return U.el(`bcv-qfb__answers ${showRight ? 'bcv-qfb__answers--two' : ''}`, [
        yours,
        showRight ? U.el('bcv-qfb__ans is-right', [U.text('bcv-qfb__anslbl', 'Correct answer', 'span'), h('div', { class: 'bcv-qfb__ansval' }, ansBody(r.right))]) : null,
      ]);
    }
    function fbCard(r, i) {
      const v = verdictOf(r);
      const [ink, tint] = inkOf(v);
      const part = v === 'partial';
      // (the points a question was worth come from Canvas or are left out — never a "/ 0" standing in for them)
      const worth = r.possible !== null ? `${store.fmtPts(r.possible)} pts` : '';
      const scoreLbl = r.earned !== null ? (r.possible !== null ? `${store.fmtPts(r.earned)} / ${store.fmtPts(r.possible)}` : `${store.fmtPts(r.earned)} ${Number(r.earned) === 1 ? 'pt' : 'pts'}`) : part ? (worth ? `Partial · ${worth}` : 'Partial') : worth;
      const sol = r.sol;
      const card = U.el(`bcv-fb__q bcv-qfb__q is-${v}`, [
        U.el('bcv-fb__qhead', [
          h('span', { class: 'bcv-fb__mark', style: { background: tint } }, U.svg(MARK[v], { size: 13, stroke: ink, width: 2.8 })),
          h('span', { class: 'bcv-fb__qn', text: `Question ${r.k + 1}` }),
          h('span', { class: 'bcv-qfb__verdict', style: { color: ink }, text: VERDICT[v] }),
          h('span', { class: 'bcv-fb__score', style: { color: ink }, text: scoreLbl }),
        ]),
        CS().prose(noFields(r.q.question_text, r.q) || r.q.question_name || '', { cls: 'bcv-fb__qtext bcv-qfb__qtext' }),
        fbAnswers(r),
        fbOptions(r),
        sol ? U.el('bcv-fb__sol', [
          U.text('bcv-fb__kicker', 'Worked solution', 'span'),
          sol.html ? CS().prose(sol.html, { cls: 'bcv-fb__solbody' }) : h('p', { class: 'bcv-fb__solbody', text: sol.text }),
        ]) : r.read ? U.text('bcv-fb__none bcv-qfb__nosol', 'Your instructor left no worked solution for this question.') : null, // (said only once Canvas's results page was read: the API never hands a student the comments)
      ]);
      card.id = `bcv-fbq-${r.k}`;
      card.dataset.k = String(r.k);
      card.dataset.verdict = v;
      card.tabIndex = -1;
      return U.enter(card, i, 45);
    }
    const toReviewAgain = (v) => v === 'wrong' || v === 'partial';
    /** The rail: the score, the filter, a square per question, and the ways out. */
    function fbRail(fb, btns) {
      const { sub, rows } = fb;
      const pct = fb.possible > 0 && fb.score !== null ? Math.round((fb.score / fb.possible) * 100) : null;
      const nRight = rows.filter((r) => r.correct === true).length;
      const when = sub.workflow_state === 'pending_review' ? 'awaiting your instructor’s review' : `graded ${U.fmtAtUpper(fb.gradedAt)}`;
      const counts = { all: rows.length, wrong: rows.filter((r) => toReviewAgain(verdictOf(r))).length, right: nRight };
      const filters = fb.released ? U.el('bcv-qfb__filters', [['all', 'All'], ['wrong', 'To review'], ['right', 'Correct']].map(([key, label]) => h('button', {
        type: 'button', class: `bcv-qfb__filter ${key === 'all' ? 'is-on' : ''}`, dataset: { filter: key }, 'aria-pressed': key === 'all' ? 'true' : 'false',
      }, [h('span', { text: label }), h('span', { class: 'bcv-qfb__count', text: String(counts[key]) })]))) : null;
      return h('aside', { class: 'bcv-qfb__rail', 'aria-label': 'Your results' }, [
        U.el('bcv-qfb__score', [
          U.text('bcv-qz__railh', `Attempt ${sub.attempt || 1}`, 'div'),
          U.el('bcv-fb__scoreline', [
            h('span', { class: 'bcv-fb__big', text: `${fb.score !== null ? store.fmtPts(fb.score) : '—'} / ${store.fmtPts(fb.possible)}` }),
            pct !== null ? h('span', { class: 'bcv-fb__pct', text: `${pct}%` }) : null,
            h('span', { class: 'bcv-fb__summary', text: `${fb.released ? `${nRight} of ${rows.length} correct · ` : ''}${when}` }),
          ]),
          U.el('bcv-fb__bar', h('div', { class: 'bcv-fb__fill', style: { width: `${pct ?? 0}%` } })),
        ]),
        filters,
        U.text('bcv-qz__railh', 'Questions', 'div'),
        U.el('bcv-qfb__nav', rows.map((r) => {
          const v = verdictOf(r);
          return h('button', { type: 'button', class: `bcv-qfb__sq is-${v}`, dataset: { k: String(r.k) }, title: `Question ${r.k + 1} · ${VERDICT[v]}`, 'aria-label': `Question ${r.k + 1}, ${VERDICT[v]}` }, h('span', { text: String(r.k + 1) }));
        })),
        U.text('bcv-qfb__keys', 'J and K go to the next and previous question.', 'div'),
        btns,
      ]);
    }
    /** The rail and the questions, and what moves between them: the squares, the filter, J and K, and
     *  the square of the question being read kept lit as the page scrolls. */
    function feedbackView(fb, btns) {
      const comments = fb.comments.map((c) => U.el('bcv-fb__comment', [
        h('span', { class: 'bcv-fb__avatar', text: U.initials(c.author_name || c.author?.display_name || '') || '·' }),
        U.el('bcv-fb__cbody', [U.text('bcv-fb__ctitle', `Instructor comment${c.author_name ? ` · ${c.author_name}` : ''}`), h('p', { class: 'bcv-fb__ctext', text: c.comment || '' })]),
      ]));
      const notice = fb.released ? null : U.hint('Canvas has not released the question results for this attempt yet — your score and the questions are shown as they stand.', 'bcv-hint--narrow');
      let n = 1;
      const main = h('div', { class: 'bcv-qfb__main' }, [
        comments.length ? U.enter(U.el('bcv-qfb__comments', comments), n++, 45) : null,
        notice,
        ...fb.rows.map((r) => fbCard(r, n++)),
        h('p', { class: 'bcv-qfb__empty', hidden: true, text: 'Nothing here — every question in this attempt was answered correctly.' }),
      ]);
      const view = U.el('bcv-qfb', [U.enter(fbRail(fb, btns), 0, 45), main]);
      const cards = () => [...main.querySelectorAll('.bcv-qfb__q')];
      const squares = () => [...view.querySelectorAll('.bcv-qfb__sq')];
      const reduce = () => !!self.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      const line = () => (screen.querySelector('.bcv-qz__head')?.getBoundingClientRect().bottom || 0) + 14;
      const here = (k) => { for (const sq of squares()) sq.classList.toggle('is-here', sq.dataset.k === String(k)); };
      // a question gone to stays lit while the page is on its way there and once it has arrived, even
      // where the page cannot bring it up to the line (the last few of a short attempt); moving the
      // page yourself, or a trip cut short, hands the light back to whichever question is at the line
      let pin = null;
      const spy = () => {
        if (pin && main.querySelector(`#bcv-fbq-${pin.k}`)?.hidden !== false) pin = null; // (filtered away)
        if (pin) {
          const d = Math.abs(window.scrollY - pin.y);
          if (d < 3) pin.there = true;
          if (d < 3 || (!pin.there && Date.now() - pin.t < 1500)) { here(pin.k); return; }
          pin = null;
        }
        const at = line();
        const c = cards().find((x) => !x.hidden && x.getBoundingClientRect().bottom > at + 40);
        if (c) here(c.dataset.k);
      };
      function setFilter(key) {
        view.dataset.filter = key;
        for (const b of view.querySelectorAll('.bcv-qfb__filter')) { const on = b.dataset.filter === key; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); }
        let shown = 0;
        for (const c of cards()) {
          const v = c.dataset.verdict;
          c.hidden = !(key === 'all' || (key === 'wrong' && toReviewAgain(v)) || (key === 'right' && v === 'right'));
          if (!c.hidden) shown++;
        }
        for (const sq of squares()) sq.classList.toggle('is-out', !!main.querySelector(`#bcv-fbq-${sq.dataset.k}`)?.hidden);
        const empty = main.querySelector('.bcv-qfb__empty');
        empty.hidden = shown > 0;
        empty.textContent = key === 'right' ? 'No question in this attempt was answered correctly.' : 'Nothing to review — every question in this attempt was answered correctly.';
        spy();
      }
      function goTo(k) {
        const c = main.querySelector(`#bcv-fbq-${k}`);
        if (!c) return;
        if (c.hidden) setFilter('all');
        const y = Math.round(Math.max(0, Math.min(document.documentElement.scrollHeight - window.innerHeight, window.scrollY + c.getBoundingClientRect().top - line())));
        pin = { k: String(k), y, t: Date.now(), there: Math.abs(window.scrollY - y) < 3 };
        window.scrollTo({ top: y, behavior: reduce() ? 'auto' : 'smooth' });
        here(k);
        c.focus({ preventScroll: true });
      }
      view.addEventListener('click', (e) => {
        const sq = e.target.closest('.bcv-qfb__sq');
        if (sq) { goTo(sq.dataset.k); return; }
        const f = e.target.closest('.bcv-qfb__filter');
        if (f) setFilter(f.dataset.filter);
      });
      const onKey = (e) => {
        if (e.metaKey || e.ctrlKey || e.altKey || (e.key !== 'j' && e.key !== 'k')) return;
        if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target?.tagName || '') || e.target?.isContentEditable || document.querySelector('.bcv-sheet-ov')) return;
        const vis = cards().filter((c) => !c.hidden);
        if (!vis.length) return;
        const cur = vis.findIndex((c) => squares().find((sq) => sq.dataset.k === c.dataset.k)?.classList.contains('is-here'));
        const next = vis[Math.max(0, Math.min(vis.length - 1, (cur < 0 ? -1 : cur) + (e.key === 'j' ? 1 : -1)))];
        if (!next) return;
        e.preventDefault();
        goTo(next.dataset.k);
      };
      let raf = 0;
      const onScroll = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; spy(); }); };
      document.addEventListener('keydown', onKey);
      window.addEventListener('scroll', onScroll, { passive: true });
      U.onGone(view, () => { document.removeEventListener('keydown', onKey); window.removeEventListener('scroll', onScroll); cancelAnimationFrame(raf); });
      requestAnimationFrame(spy);
      return view;
    }
    function feedback() {
      const sub = st.fbSub;
      const wrap = U.el('bcv-qz__stage');
      const plain = (...kids) => U.el('bcv-fb', kids); // (the states before there is anything to review: one column, as before)
      const btns = () => U.el('bcv-fb__btns', [
        st.fbFrom === 'done' ? h('button', { type: 'button', class: 'bcv-qz__big', text: 'Back to receipt', onclick: () => { st.stage = 'done'; draw(); toTop(); } }) : null,
        st.fbFrom === 'intro' ? h('button', { type: 'button', class: 'bcv-qz__big', text: 'Quiz overview', onclick: () => { st.stage = 'intro'; draw(); toTop(); } }) : null,
        h('button', { type: 'button', class: 'bcv-qz__big bcv-qz__big--primary', text: /survey/.test(quiz.quiz_type || '') ? 'Back to the survey' : 'Back to the quiz', onclick: () => exitTo(simulated ? simHome : quizUrl) }),
      ]);
      if (!sub) {
        wrap.append(plain(U.emptyCard('No finished attempts yet — feedback appears here once one is submitted.'), btns()));
        return wrap;
      }
      const hidden = resultsHidden(sub);
      if (hidden) {
        wrap.append(plain(U.card(U.el('bcv-detail', [h('h2', { class: 'bcv-detail__title', text: 'Results not released' }), U.text('bcv-hint', hidden)]), 'bcv-card--22 bcv-qfb__withheld'), btns()));
        return wrap;
      }
      const heldCard = () => plain(U.card(U.el('bcv-detail', [h('h2', { class: 'bcv-detail__title', text: 'Results not released' }), U.text('bcv-hint', HELD_LINE)]), 'bcv-card--22 bcv-qfb__withheld'), btns());
      if (st.fb && st.fb.sub === sub) {
        wrap.append(st.fb.held ? heldCard() : feedbackView(st.fb, btns()));
        return wrap;
      }
      wrap.append(plain(U.loading('rows', 4)));
      loadFeedback(sub).then((fb) => {
        if (!ctx.alive() || st.stage !== 'feedback' || st.fbSub !== sub) return;
        st.fb = fb;
        wrap.replaceChildren(fb.held ? heldCard() : feedbackView(fb, btns()));
      }).catch((e) => {
        if (ctx.alive()) wrap.replaceChildren(plain(U.errorBox(`The feedback could not be loaded: ${e.message}`), btns()));
      });
      return wrap;
    }

    draw();
    // (2.99.55) New Attempt and Continue Quiz on the assignment page go straight into the attempt, as the Mac's do
    // (?bcv=take&begin=1) — unless it cannot begin, or wants its code typed first: then the intro is where they land
    if (route.params.get('begin') === '1' && st.stage === 'intro' && introCanStart() && !introNeedsCode()) begin();
    return screen;
  }

  BCV.screens.quiz = {
    render,
    // the rules the iPhone app's quiz shares (native-app.js): what an answer is, how one is compared, and how a finished one is read
    logic: { LETTERS, CHOICE, MULTI, TEXT, NUMERIC, FILE, MATCH, DROPS, BLANKS, INFO, whole, hasId, answered, isAnswered, pairsOf, filledOf, tidy, blanksOf, noFields, looksHtml, htmlToPlain, plainToHtml, heldBack, HELD_LINE, canon, sameQuestion, carryOver, parseCorrect, histAnswer, fbRight, fbSolution, pageRight, hasNum, partText, answerParts: answerPartsOf },
  };
})();
